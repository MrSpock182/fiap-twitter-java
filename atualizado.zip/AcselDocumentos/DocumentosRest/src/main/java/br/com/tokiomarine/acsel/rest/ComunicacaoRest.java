package br.com.tokiomarine.acsel.rest;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.dto.AgendamentoComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.AgendamentoSmsComunDTO;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.RetornoAgendamentoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.service.AgendamentoComunicacaoService;
import br.com.tokiomarine.acsel.service.EnvioComunicacaoService;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoService;
import br.com.tokiomarine.acsel.service.RelatorioAgendamentoService;
import br.com.tokiomarine.acsel.util.StringUtil;

@Path("/comunicacao")
public class ComunicacaoRest {

	/**
	 * SE O ENDPOINT PROCURADO NÃO SE ENCONTRAR NESSA CLASSE FAVOR VERIFICAR NO
	 * CONTROLLER DO PROJETO DocumentosView
	 */

	@EJB
	ModeloComunicacaoService modeloService;
	
	@EJB
	AgendamentoComunicacaoService agendamentoService;
	
	@EJB
	EnvioComunicacaoService envioService;
	
	@EJB
	RelatorioAgendamentoService relatorioService;

	private static Logger logger = LogManager.getLogger(ComunicacaoRest.class);

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento")
	public Response incluiAgendamento(@QueryParam("envia") String envia, AgendamentoComunicacaoDTO agendamento) {
		
		logger.error("Teste");
		logger.info("Teste");
		logger.warn("Teste");
		
		return null;
		
//		RetornoAgendamentoDTO retorno = new RetornoAgendamentoDTO();
//		
//		try {
//
//			AgendamentoComunicacao agend = agendamentoService.incluiAgendamento(agendamento);
//			agendamento.setSeqAgendamento(agend.getSeqAgendamento());
//			retorno.setSeqAgendamento(agend.getSeqAgendamento());
//
//			/// Se o parametro de envia for realiza o envio do agendamento.
//			if (!agend.getModelo().getPiloto().equals("S")) {
//				if (envia != null && envia.equals("S")) {
//					return envioAgendamento(agendamento);
//				}
//			}
//
//			retorno.setCodigoRetorno(0);
//			retorno.setMensagemRetorno("");
//		} catch (ServiceException e) {
//			retorno.setCodigoRetorno(1);
//			retorno.setMensagemRetorno(e.getMessage());
//		} catch (Exception e) {
//			logger.error("Erro ao incluir agendamento", e);
//			retorno.setCodigoRetorno(9);
//			retorno.setMensagemRetorno("Erro ao incluir agendamento");
//		}
//		
//		return Response.ok(retorno).build();
	}

	private void logJson(AgendamentoComunicacaoDTO agendamento, String log) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(agendamento);
		logger.debug(log + ". Json de entrada:" + json);
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento")
	public Response atualizaAgendamento(AgendamentoComunicacaoDTO agendamento) {

		RetornoAgendamentoDTO retorno = new RetornoAgendamentoDTO();

		try {

			logJson(agendamento, "Agendamento recebido para atualização");

			retorno.setSeqAgendamento(agendamento.getSeqAgendamento());
			agendamentoService.atualizaAgendamento(agendamento);
			retorno.setCodigoRetorno(0);
			retorno.setMensagemRetorno("");

		} catch (ServiceException e) {
			retorno.setCodigoRetorno(1);
			retorno.setMensagemRetorno(e.getMessage());
		} catch (Exception e) {
			logger.error("Erro ao atualizar agendamento", e);
			retorno.setCodigoRetorno(9);
			retorno.setMensagemRetorno("Erro ao atualizar agendamento");
		}

		return Response.ok(retorno).build();
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento/atualiza")
	public Response atualizaAgendamentoPost(AgendamentoComunicacaoDTO agendamento) {
		return atualizaAgendamento(agendamento);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento/envio")
	public Response envioAgendamento(AgendamentoComunicacaoDTO agendamento) {

		RetornoAgendamentoDTO retorno = new RetornoAgendamentoDTO();
		try {
			logJson(agendamento, "Agendamento recebido para envio");
			retorno.setSeqAgendamento(agendamento.getSeqAgendamento());

			if (envioService.solicitaEnvio(agendamento.getSeqAgendamento())) {
				retorno.setCodigoRetorno(0);
				retorno.setMensagemRetorno("");
			} else {
				retorno.setCodigoRetorno(2);
				retorno.setMensagemRetorno("Agendamento inválido");
			}

		} catch (ServiceException e) {
			retorno.setCodigoRetorno(1);
			retorno.setMensagemRetorno(e.getMessage());
		} catch (Exception e) {
			logger.error("Erro ao solicitar envio da comunicacação", e);
			retorno.setCodigoRetorno(9);
			retorno.setMensagemRetorno("Erro ao solicitar envio da comunicação");
		}

		return Response.ok(retorno).build();
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento/reenvio")
	public Response reenvioAgendamento(AgendamentoComunicacaoDTO agendamento) {

		RetornoAgendamentoDTO retorno = new RetornoAgendamentoDTO();
		try {
			logJson(agendamento, "Agendamento recebido para reenvio");
			retorno.setSeqAgendamento(agendamento.getSeqAgendamento());

			envioService.solicitaReenvio(agendamento.getSeqAgendamento(), null);
			retorno.setCodigoRetorno(0);
			retorno.setMensagemRetorno("");

		} catch (ServiceException e) {
			retorno.setCodigoRetorno(1);
			retorno.setMensagemRetorno(e.getMessage());
		} catch (Exception e) {
			logger.error("Erro ao solicitar o reeenvio da comunicação", e);
			retorno.setCodigoRetorno(9);
			retorno.setMensagemRetorno("Erro ao solicitar o reeenvio da comunicação");
		}

		return Response.ok(retorno).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento/{seqAgendamento}/status")
	public Response consultaStatus(@PathParam("seqAgendamento") Long seqAgendamento) {

		try {

			AgendamentoComunicacao agend = agendamentoService.obtemAgendamento(seqAgendamento);
			if (agend == null) {
				return Response.status(Status.NOT_FOUND).build();
			}
			AgendamentoComunicacaoDTO dto = new AgendamentoComunicacaoDTO();
			dto.setSeqAgendamento(seqAgendamento);
			dto.setStatusAgendamento(agend.getStatusAgendamento());
			dto.setDataEnvio(agend.getDtEnvioOriginal());
			return Response.ok(dto).build();

		} catch (Exception e) {
			logger.error("Erro ao consultar status", e);
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	@GET
	@Produces(MediaType.TEXT_HTML)
	@Path("/agendamento/{seqAgendamento}/email")
	public Response consultaEmail(@PathParam("seqAgendamento") Long seqAgendamento) {

		try {
			AgendamentoComunicacao agend = agendamentoService.obtemAgendamento(seqAgendamento);
			if (agend == null) {
				return Response.status(Status.NOT_FOUND).build();
			}

			return Response.ok(agend.getMensagemEnviada()).build();

		} catch (Exception e) {
			logger.error("Erro ao consultar status", e);
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/modelo/{codModelo}")
	public Response consultaParametros(@PathParam("codModelo") Long codModelo) {

		try {

			ModeloComunicacao modelo = modeloService.obtemModelo(codModelo);

			if (modelo == null) {
				return Response.status(Status.NOT_FOUND).build();
			}

			ModeloComunicacaoDTO dto = modeloService.obtemModeloComunicacaoDTO(modelo);
			
//			ModeloComunicacaoDTO dto = new ModeloComunicacaoDTO();
//			dto.setCodigoModelo(codModelo);
//			dto.setParametros(new ArrayList<ParametroComunicacaoDTO>());
//
//			for (ParametroModelo param : modelo.getParametros()) {
//				ParametroComunicacaoDTO paramDTO = new ParametroComunicacaoDTO();
//				paramDTO.setNomeParametro(param.getParametro().getNomeParametro());
//				dto.getParametros().add(paramDTO);
//			}

			return Response.ok(dto).build();

		} catch (Exception e) {
			logger.error("Erro ao consultar status", e);
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento/reprocessa")
	public Response reprocessa(AgendamentoComunicacaoDTO agendamento) {

		RetornoAgendamentoDTO retorno = new RetornoAgendamentoDTO();
		try {

			logJson(agendamento, "Agendamento recebido para reprocesso");
			retorno.setSeqAgendamento(agendamento.getSeqAgendamento());
			envioService.reprocessaEnvio(agendamento.getSeqAgendamento());
			retorno.setCodigoRetorno(0);
			retorno.setMensagemRetorno("");

		} catch (ServiceException e) {
			retorno.setCodigoRetorno(1);
			retorno.setMensagemRetorno(e.getMessage());
		} catch (Exception e) {
			logger.error("Erro ao reprocessar envio da comunicação", e);
			retorno.setCodigoRetorno(9);
			retorno.setMensagemRetorno("Erro ao reprocessar envio da comunicação");
		}

		return Response.ok(retorno).build();
	}

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento/reprocessa/envio")
	public Response envia(Long seqEnvio) {
		RetornoAgendamentoDTO retorno = new RetornoAgendamentoDTO();

		try {
			logger.info("Sequencia de agendamento recebida para envio: " + seqEnvio);
			envioService.enviaAgendamento(seqEnvio);
			retorno.setCodigoRetorno(0);
			retorno.setMensagemRetorno("");
		} catch (ServiceException e) {
			retorno.setCodigoRetorno(1);
			retorno.setMensagemRetorno(e.getMessage());
		}

		return Response.ok(retorno).build();
	}

	@GET
	@Path("/relatorio")
	public int geraRelatorio(@QueryParam("data") String dataProcessamento) {

		try {

			Date dataRef = new Date();

			if (!StringUtil.isNull(dataProcessamento)) {
				dataRef = new SimpleDateFormat("yyyyMMdd").parse(dataProcessamento);
			}

			relatorioService.geraRelatorioDia(dataRef);

		} catch (Exception e) {
			e.printStackTrace();
			return 1;
		}

		return 0;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agendamento/{seqAgendamento}/sms")
	public Response consultaSMS(@PathParam("seqAgendamento") Long seqAgendamento) {

		try {
			AgendamentoComunicacao agend = agendamentoService.obtemAgendamento(seqAgendamento);
			if (agend == null) {
				return Response.status(Status.NOT_FOUND).build();
			}

			if (!agend.getModelo().getTipoModelo().equals("SMS")) {
				return Response.status(Status.NOT_FOUND).build();
			}

			AgendamentoSmsComunDTO dto = new AgendamentoSmsComunDTO();
			dto.setSeqAgendamento(seqAgendamento);
			dto.setStatusAgendamento(agend.getStatusAgendamento());
			dto.setDataEnvio(agend.getDtEnvioOriginal());
			dto.setModelo(agend.getModelo().getCodigo());
			dto.setTipoModelo(agend.getModelo().getTipoModelo());
			if (agend.getEnvios() != null && agend.getEnvios().size() > 0) {
				dto.setCodRetornoEnvio(agend.getEnvios().get(agend.getEnvios().size() - 1).getCodRetornoEnvio());
			}
			return Response.ok(dto).build();

		} catch (Exception e) {
			logger.error("Erro ao consultar status", e);
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

}
