package br.com.tokiomarine.acsel.domain.orm.acx;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "AGENDAMENTO_ENVIO")
public class AgendamentoEnvio {

	@Id
	@Column(name = "CD_SEQUENCIA_ENVIO")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqEnvioGenerator")
	@SequenceGenerator(name = "seqEnvioGenerator", sequenceName = "SQ_AGENDAMENTO_ENVIO", allocationSize = 1)
	private Long seqEnvio;

	@ManyToOne
	@JoinColumn(name = "CD_SEQUENCIA_AGENDAMENTO", referencedColumnName = "CD_SEQUENCIA_AGENDAMENTO")
	private AgendamentoComunicacao agendamento;

	@Column(name = "DS_TITULO")
	private String titulo;

	@Column(name = "DS_REMETENTE")
	private String remetente;

	@Column(name = "DS_CAIXA_DEPTO")
	private String caixaDepto;

	@Column(name = "DT_SOLIC_ENVIO")
	private Date dtSolicEnvio;

	@Column(name = "DT_ENVIO")
	private Date dtEnvio;

	@Column(name = "ID_SITUACAO_ENVIO")
	private String statusEnvio;

	@Column(name = "CD_RETORNO_WS")
	private String codRetornoEnvio;

	@Column(name = "NM_USUARIO_INCLUSAO")
	private String usuarioInclusao;

	@Column(name = "DT_INCLUSAO")
	private Date dtInclusao;

	public Long getSeqEnvio() {
		return seqEnvio;
	}

	public void setSeqEnvio(Long seqEnvio) {
		this.seqEnvio = seqEnvio;
	}

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getRemetente() {
		return remetente;
	}

	public void setRemetente(String remetente) {
		this.remetente = remetente;
	}

	public String getCaixaDepto() {
		return caixaDepto;
	}

	public void setCaixaDepto(String caixaDepto) {
		this.caixaDepto = caixaDepto;
	}

	public Date getDtSolicEnvio() {
		return dtSolicEnvio;
	}

	public void setDtSolicEnvio(Date dtSolicEnvio) {
		this.dtSolicEnvio = dtSolicEnvio;
	}

	public Date getDtEnvio() {
		return dtEnvio;
	}

	public void setDtEnvio(Date dtEnvio) {
		this.dtEnvio = dtEnvio;
	}

	public String getStatusEnvio() {
		return statusEnvio;
	}

	public void setStatusEnvio(String statusEnvio) {
		this.statusEnvio = statusEnvio;
	}

	public String getCodRetornoEnvio() {
		return codRetornoEnvio;
	}

	public void setCodRetornoEnvio(String codRetornoEnvio) {
		this.codRetornoEnvio = codRetornoEnvio;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	@Transient
	public StatusAgendamento getStatus() {
		return StatusAgendamento.get(this.statusEnvio);
	}

	public String getUsuarioInclusao() {
		return usuarioInclusao;
	}

	public void setUsuarioInclusao(String usuarioInclusao) {
		this.usuarioInclusao = usuarioInclusao;
	}

	public void setAgendamentoComunicacaoMensagemEnviada(String mensagem) {
		this.agendamento.setMensagemEnviada(mensagem);
	}

	public List<AgendamentoAnexo> getAgendamentoAnexos() {
		return this.agendamento.getAnexos();
	}

	public TipoModelo getAgendamentoModeloCanalComunicacao() {
		return this.agendamento.getModeloCanalComunicacao();
	}

	public boolean contemAnexos() {
		return this.agendamento.getAnexos() != null && this.agendamento.getAnexos().size() > 0;
	}

	public List<AgendamentoDestinatario> getAgendamentoDestinatarios() {
		return this.agendamento.getDestinatarios();
	}

	public List<AgendamentoDestinatario> getAgendamentoDestinatariosValidos() {
		return this.agendamento.getDestinatariosValidos();
	}

}
