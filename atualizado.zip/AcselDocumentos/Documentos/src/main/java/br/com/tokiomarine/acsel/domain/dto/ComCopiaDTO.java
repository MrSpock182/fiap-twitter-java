package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class ComCopiaDTO {
	private String destino;
	private String cpfCnpj;
	private String copiaOculta;
}
