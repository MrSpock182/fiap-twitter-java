package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class DocumentoDocstoreDTO {
	private String url;
	private String docstoreId;
	private Integer cdDocumento;
	private String dsDocumento;
}
