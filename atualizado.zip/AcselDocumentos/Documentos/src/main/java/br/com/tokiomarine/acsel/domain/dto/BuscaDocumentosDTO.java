package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class BuscaDocumentosDTO {

	private String tipoBusca;
	private String cpf;
	private String cnpj;
	private String ramo;
	private Long apolice;
	private Integer numEndosso;
	private Integer negocio;
	private Date dataIni;
	private Date dataFim;
	private String codCorretor;
	private String tipoApoliceEndosso;
	private Boolean somenteApolice;
	private List<String> listaClientes;
	private List<Long> listaClientesPlataforma;

	public Long getNumDocumento() {
		String s = "";

		if (!StringUtil.isNull(getCpf())) {
			s = StringUtils.split(getCpf(), "-")[0];
		}
		
		if (!StringUtil.isNull(getCnpj())) {
			s = StringUtils.split(getCnpj(), "-")[0];
		}
		return Long.parseLong(StringUtil.removeSeparadores(s));
	}

	public Long getNumDocumentoSemFilial() {
		String s = "";

		if (!StringUtil.isNull(getCpf())) {
			s = StringUtils.split(getCpf(), "-")[0];
		}
		
		if (!StringUtil.isNull(getCnpj())) {
			s = StringUtils.split(getCnpj(), "/")[0];
		}
		
		return Long.parseLong(StringUtil.removeSeparadores(s));
	}

	public Long getNumFilial() {
		String s = "";
		if (!StringUtil.isNull(getCnpj())) {
			s = StringUtils.split(getCnpj(), "-")[0];
			s = StringUtils.split(s, "/")[1];
			return Long.parseLong(s);
		} else {
			return 0L;
		}
	}

	public String getDvDocumento() {
		if (!StringUtil.isNull(getCpf())) {
			return StringUtils.split(getCpf(), "-")[1];
		}
		
		if (!StringUtil.isNull(getCnpj())) {
			return StringUtils.split(getCnpj(), "-")[1];
		}
		
		return "";
	}

}
