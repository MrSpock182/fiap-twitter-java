package br.com.tokiomarine.acsel.domain.orm.ssv;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="EMP0062_SOLCT_SEGDA_VIA_DOCTO")
@IdClass(SolicitacaoSegundaViaPK.class)
public class SolicitacaoSegundaVia {

	@Id
	@Column(name="DT_HORA_SOLCT",nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtHoraSolct;
	
	@Id
	@Column(name="ID_DOCTO_FISCO",nullable=false)
	@GeneratedValue(generator="SSVEMSQ0016_SOLCT_SEGDA_VIA_DO_GEN")
	@SequenceGenerator(name="SSVEMSQ0016_SOLCT_SEGDA_VIA_DO_GEN",sequenceName="SSVEMSQ0016_SOLCT_SEGDA_VIA_DO",allocationSize=1)
	private Long idDoctoFisco;
	
	@Column(name="CD_CLASS_DESTN",nullable=false)
	private Long cdClassDestn;
	
	@Column(name="CD_CLIEN",nullable=false)
	private Long cdClien;
	
	@Column(name="CD_LOCAL")
	private Long cdLocal;
	
	@Column(name="CD_RCPTR_PACTE",nullable=false)
	private Long cdRcptrPacte;
	
	@Column(name="CD_SITUC_SOLCT",nullable=false)
	private Long cdSitucSolct;
	
	@Column(name="DT_PROCM_SOLCT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtProcmSolct;
	
	@Column(name="ID_ENDER_CLIEN",nullable=false)
	private Long idEnderClien;
	
	@Column(name="NM_SOLTT",nullable=false)
	private String nmSoltt;
	
	@Column(name="SG_EMPRE")
	private String sgEmpre;
	
	@Column(name="TP_LOCAL")
	private Long tpLocal;
	
	@Column(name="NM_USR_DEST")
	private String nmUsrDest;
	
	@Column(name="NM_LOCAL_DEST")
	private String nmLocalDest;
	
	@Column(name="DS_MOTIVO")
	private String dsMotivo;

	@Transient
	private SolicitacaoSegundaViaPK pk = new SolicitacaoSegundaViaPK();
	
}
