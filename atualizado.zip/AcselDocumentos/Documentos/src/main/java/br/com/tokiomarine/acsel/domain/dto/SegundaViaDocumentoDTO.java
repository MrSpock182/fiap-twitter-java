package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class SegundaViaDocumentoDTO implements Comparable {
	private String url;
	private String descricao;
	
	@Override
	public int compareTo(Object object) {
		SegundaViaDocumentoDTO outro = (SegundaViaDocumentoDTO) object;
		return this.descricao.compareTo(outro.descricao);
	}
}
