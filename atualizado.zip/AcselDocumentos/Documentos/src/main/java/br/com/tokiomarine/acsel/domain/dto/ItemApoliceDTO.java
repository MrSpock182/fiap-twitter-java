package br.com.tokiomarine.acsel.domain.dto;

import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class ItemApoliceDTO {

	private String codItem;
	private String descItem;
	private Long idePol;
	private Long numCert;
	private Long numOper;
	private Long ideReg;
	private List<DownloadDocumentoDTO> documentosDownload;
	
	public DownloadDocumentoDTO getDocumentoDownload(Long codDocumento){
		for (DownloadDocumentoDTO documento : documentosDownload) {
			if (documento.getIdDocumento().equals(codDocumento)) {
				return documento;
			}
		}
		return null;
	}
	
}
