package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Builder
@Getter
@EqualsAndHashCode
public class ModeloComunicacaoDestino {	
	private String codigo;
	private String descricao;
}
