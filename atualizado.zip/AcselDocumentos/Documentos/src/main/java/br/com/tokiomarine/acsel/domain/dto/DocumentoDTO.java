package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;
import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class DocumentoDTO implements Comparable {

	private Long id;
	private TipoDocumento tipo;
	private String codDocumento;
	private String descDocumento;
	private String descProduto;
	private String codCliente;
	private String nomeCliente;
	private Date dataGeracao;
	private Date dataEnvio;
	private String status;
	private String ramo;
	private Long numApolice;
	private Integer numEndosso;
	private Integer numNegocio;
	private String codPacote;
	private String descPacote;
	private EnderecoDTO enderecoEnvio;
	private String emailEnvio;
	private Date dataEnvioEmail;
	private String codCompanhia;
	private String nomeCompanhia;
	private String codCorretor;
	private String nomeCorretor;
	private String tipoDestino;
	private String indMultiItem;
	private EnderecoDTO enderecoCorretor;
	private List<EnderecoDTO> enderecosCliente;
	private boolean indSolicitado = false;
	private String formaEnvio;
	private String tipoEnvio;
	private String tipoEndosso;
	private String descEndosso;
	private String tipoOper;
	private Long idePol;
	private Long numCert;
	private Long numOper;
	private Long numItem;
	private Long seqAgendamento;
	private String codModProd;
	private Sistema sistemaOrigem;
	private SegundaViaDTO ultimaSolicitacao;
	private List<DownloadDocumentoDTO> documentosDownload;
	private List<ItemApoliceDTO> listaItens;
	private List<SegundaViaDTO> histSegundaVia;
	private String codItem;
	private String tipoApoliceEndosso;
	private String codProduto;
	
	@Override
	public int compareTo(Object object) {
		DocumentoDTO outro = (DocumentoDTO) object;
		return this.dataGeracao.compareTo(outro.dataGeracao);
	}

}
