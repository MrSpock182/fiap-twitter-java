package br.com.tokiomarine.acsel.domain.orm.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Table(name = "AGENDAMENTO_COMUNICACAO_COPIA")
@Entity
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@IdClass(AgendamentoComCopiaPK.class)
public class AgendamentoComCopia {
	
	@Id
	@ManyToOne
	@JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
	private AgendamentoComunicacao agendamento;

	@Id
	@Column(name="CD_SEQUENCIA_COPIA")
	private Integer seqCopia;

	@Column(name="DS_DESTINATARIO")
	private String destinatario;

	@Column(name="ID_COPIA_VALIDO")
	private String indValido;
	
	@Column(name="DS_COPIA_CPFCNPJ")
	private String cpfCnpj;
	
	@Column(name="ID_COPIA_OCULTA")	
	private String copiaOculta;
	
}
