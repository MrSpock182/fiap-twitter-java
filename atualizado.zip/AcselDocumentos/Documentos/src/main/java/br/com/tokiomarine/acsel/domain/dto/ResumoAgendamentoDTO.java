package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class ResumoAgendamentoDTO {
	private String nomeModelo;
	private String tipoModelo;
	private String nomeSistema;
	private Integer qtdEnviados;
	private Integer qtdNaoEnviados;
	private Integer qtdErro;
}
