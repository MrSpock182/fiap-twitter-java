package br.com.tokiomarine.acsel.domain.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class MensagemPushDTO {
	private String value;

	@JsonInclude(Include.NON_EMPTY)
	private Map<String, String> key = new HashMap<String,String>();
}
