package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;
import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class SolicSegundaViaDTO {
	private String tipoDestino;
	private Long numEndereco;
	private String motivo;
	private Integer opcao;
	private String local;
	private String colaborador;
	private String andarLocalTrabalho;
	private Date dataSolic;
	private DocumentoDTO documento;
	private Boolean indEnvioAR = false;
	private UsuarioDTO usuarioSolic;
	private List<String> listaItens;
	private List<String> listaDocumentos;
}
