package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown=true)
public class AgendamentoSmsComunDTO {

	private Long seqAgendamento;
	
	private String statusAgendamento;
	
	private String codRetornoEnvio;
	
	private String modelo;
	
	private String tipoModelo;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataEnvio;
}
