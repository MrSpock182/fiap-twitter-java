package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class SegundaViaDTO {
	
	private Long id;
	private DocumentoDTO documento;
	private Date dataSolic;
	private String usuarioSolic;
	private String nomeUsuarioSolic;
	private String status;
	private String tipoDestino;
	private Integer numEndereco;
	private String usuarioLocal;
	private String destinoLocal;
	private EnderecoDTO enderecoEnvio;
	private String opcaoSolic;
	private Boolean permiteCancelamento;
	private String codItem;
	private ItemApoliceDTO item;
	
	public TipoDestino getTipoDestino() {
		return TipoDestino.get(tipoDestino);
	}
	
	public StatusDocumento getStatus() {
		return StatusDocumento.get(status);
	}
	
}
