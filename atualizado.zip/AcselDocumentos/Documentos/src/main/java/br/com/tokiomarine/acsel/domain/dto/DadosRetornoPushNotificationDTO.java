package br.com.tokiomarine.acsel.domain.dto;

import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class DadosRetornoPushNotificationDTO {
	private List<String> erros;
	private List<String> logs;
}
