package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class EstatisticaAgendamentoDTO {

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataEnvio;
	private Long total;
	private Long enviado;	
	private Long naoEnviado;
	private Long pendente;
	private Long finalizado;
	private Long errado;
	
}
