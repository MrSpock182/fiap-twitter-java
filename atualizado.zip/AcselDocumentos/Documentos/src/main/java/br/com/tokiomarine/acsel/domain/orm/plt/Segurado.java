package br.com.tokiomarine.acsel.domain.orm.plt;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity(name = "SEGURADO")
@Builder
@Getter
@Setter
@EqualsAndHashCode
public class Segurado {

	@Id
	@Column(name = "CD_SEGURADO", nullable = false)
	private Long cdSegurado;

	@Column(name = "ID_TIPO_SEGURADO", nullable = false)
	private String tipoSegurado;

	@Column(name = "NR_CGC_CPF_SEGURADO", nullable = false)
	private Long nrCgcCpf;

	@Column(name = "NR_ESTABELECIMENTO_SEGURADO", nullable = false)
	private Long nrEstabelecimento;

	@Column(name = "NR_DIGITO_VERIFICADOR", nullable = false)
	private Long nrDigitoVerificador;

	@Column(name = "NM_SEGURADO", nullable = false)
	private String nomeSegurado;

}
