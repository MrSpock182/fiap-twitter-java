package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class EnderecoDTO {
	private Long id;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cidade;
	private String estado;
	private String cep;
	private String enderecoFormatado;

	public EnderecoDTO() {
	}

	public EnderecoDTO(Long id, String enderecoFormatado) {
		this.id = id;
		this.enderecoFormatado = enderecoFormatado;
	}

	public String getEnderecoFormatado() {
		if (this.enderecoFormatado != null) {
			return this.enderecoFormatado;
		}
		
		if (this.logradouro != null) {
			return logradouro + ", " + numero + (complemento == null ? "" : " - " + complemento) + " - " + bairro
					+ " - " + cidade + " - " + estado + " - " + cep;
		}
		
		return "";
	}
}
