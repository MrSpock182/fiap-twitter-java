package br.com.tokiomarine.acsel.domain.orm.ssv;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class DocumentoPK implements Serializable {

	@Id
	@Column(name="CD_DOCTO",nullable=false)
	public String cdDocto;
	
	@Id
	@Column(name="DT_INICO_VIGEN_DOCTO",nullable=false)
	public Date dtInicoVigenDocto;
	
	public boolean equals(Object other) {
		if(other instanceof DocumentoPK) {
			final DocumentoPK pk = (DocumentoPK) other;
			boolean ret = (pk.cdDocto.equals(cdDocto) && pk.dtInicoVigenDocto.equals(dtInicoVigenDocto));
			return ret;
		}
		return false;
	}

	public int hashCode() {
		return cdDocto.hashCode() ^ dtInicoVigenDocto.hashCode();
	}
	
}
