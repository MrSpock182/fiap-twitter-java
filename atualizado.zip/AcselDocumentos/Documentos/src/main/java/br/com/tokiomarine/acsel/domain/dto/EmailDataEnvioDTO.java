package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;
import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class EmailDataEnvioDTO {
	private Date dataEnvio;
	private List<String> emailsDestinatarios;
}
