package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class BuscaAgendamentoDTO {

	private Long codModelo;
	
	private Long seqAgendamento;
	
	private String destinatario;
	
	private String cpfCnpj;
	
	private String tipoEnvio;
	
	private Boolean novaBusca = false;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "GMT-3")
	private Date dataIni;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "GMT-3")
	private Date dataFim;
	
	private List<ParametroComunicacaoDTO> parametros;
	
	public String obtemValorParametro(Long codParametro){
		if (this.parametros == null) return null;

		for (ParametroComunicacaoDTO param : this.parametros){
			if (param.getCodParametro().equals(codParametro))
				return param.getValorParametro();
		}
		return null;
	}
}
