package br.com.tokiomarine.acsel.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class SegundaViaConsultaDTO {
	private Long idepol;
	private Long numcert;
	private Long numoper;
	private Long numendosso;
}
