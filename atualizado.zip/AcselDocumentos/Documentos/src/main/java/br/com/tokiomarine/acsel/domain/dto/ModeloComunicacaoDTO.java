package br.com.tokiomarine.acsel.domain.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class ModeloComunicacaoDTO {
	private Long codigoModelo;

	@JsonInclude(Include.NON_EMPTY)
	private List<DocumentoComunicacaoDTO> documentos;

	@JsonInclude(Include.NON_EMPTY)
	private List<ParametroComunicacaoDTO> parametros;
}
