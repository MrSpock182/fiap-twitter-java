package br.com.tokiomarine.acsel.domain.dto;

public class CDN {

	private final String publico;
	private final String restrito;
	private final String versao;
	
	public CDN() {
		publico = VariaveisAmbienteUtil.getCdnPublico();
		restrito = VariaveisAmbienteUtil.getCdnRestrito();
		versao = Aplicacao.cdnVersao.value();
	}
	
	public String getPublico() {
		return publico;
	}

	public String getRestrito() {
		return restrito;
	}

	public String getVersao() {
		return versao;
	}
	
}
