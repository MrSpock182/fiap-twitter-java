package br.com.tokiomarine.acsel.domain.orm.acx;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_CAD_SERVICOS")
public class CadServicos {

	@Id
	@Column(name = "IDSERVICO")
	private Integer idServico;

	@Column(name = "CODSERVICO")
	private String codServico;

	@Column(name = "TIPOSERVICO")
	private String tipoServico;

	@Column(name = "CHAMADA")
	private String chamada;

	@Column(name = "DESCSERVICO")
	private String descServico;

	@Column(name = "ENDERECO")
	private String endereco;

	@Column(name = "TEXTO_EMAIL")
	private String textoEmail;

	@Column(name = "TIPO_GER")
	private String tipoGeracao;

	@OneToMany(mappedBy = "servico", cascade = CascadeType.ALL)
	private List<CadEmail> emails;

	public Integer getIdServico() {
		return idServico;
	}

	public void setIdServico(Integer idServico) {
		this.idServico = idServico;
	}

	public String getCodServico() {
		return codServico;
	}

	public void setCodServico(String codServico) {
		this.codServico = codServico;
	}

	public String getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(String tipoServico) {
		this.tipoServico = tipoServico;
	}

	public String getChamada() {
		return chamada;
	}

	public void setChamada(String chamada) {
		this.chamada = chamada;
	}

	public String getDescServico() {
		return descServico;
	}

	public void setDescServico(String descServico) {
		this.descServico = descServico;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTextoEmail() {
		return textoEmail;
	}

	public void setTextoEmail(String textoEmail) {
		this.textoEmail = textoEmail;
	}

	public String getTipoGeracao() {
		return tipoGeracao;
	}

	public void setTipoGeracao(String tipoGeracao) {
		this.tipoGeracao = tipoGeracao;
	}

	public List<CadEmail> getEmails() {
		return emails;
	}

	public void setEmails(List<CadEmail> emails) {
		this.emails = emails;
	}

}
