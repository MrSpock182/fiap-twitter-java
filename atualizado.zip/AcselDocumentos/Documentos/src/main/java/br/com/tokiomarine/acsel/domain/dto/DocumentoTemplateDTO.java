package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@EqualsAndHashCode
@ToString
public class DocumentoTemplateDTO {
	private String seqAgendamento;
	private Integer codDocumento;
	private String urlDocumento;
	private String indEnviaEmail;

	public DocumentoTemplateDTO() {
		seqAgendamento = null;
		codDocumento = 1;
		urlDocumento = "https://portal.tokiomarine.com.br/docstore-services/rest/download-anexo/xxx";
		indEnviaEmail = "S";
	}
}
