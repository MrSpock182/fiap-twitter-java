package br.com.tokiomarine.acsel.domain.orm.acx;

import java.io.Serializable;

public class CiudadPK implements Serializable {

	private String codPais;
	private String codEstado;
	private String codCiudad;

	public String getCodPais() {
		return codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodCiudad() {
		return codCiudad;
	}

	public void setCodCiudad(String codCiudad) {
		this.codCiudad = codCiudad;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codCiudad == null) ? 0 : codCiudad.hashCode());
		result = prime * result + ((codEstado == null) ? 0 : codEstado.hashCode());
		result = prime * result + ((codPais == null) ? 0 : codPais.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CiudadPK other = (CiudadPK) obj;
		if (codCiudad == null) {
			if (other.codCiudad != null)
				return false;
		} else if (!codCiudad.equals(other.codCiudad))
			return false;
		if (codEstado == null) {
			if (other.codEstado != null)
				return false;
		} else if (!codEstado.equals(other.codEstado))
			return false;
		if (codPais == null) {
			if (other.codPais != null)
				return false;
		} else if (!codPais.equals(other.codPais))
			return false;
		return true;
	}

}