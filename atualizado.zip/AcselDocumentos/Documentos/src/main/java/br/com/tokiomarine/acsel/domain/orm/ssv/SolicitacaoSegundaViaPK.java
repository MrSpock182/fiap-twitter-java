package br.com.tokiomarine.acsel.domain.orm.ssv;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

public class SolicitacaoSegundaViaPK implements Serializable {
	
	@Id
	@Column(name="DT_HORA_SOLCT",nullable=false)
	public Date dtHoraSolct;
	
	@Id
	@Column(name="ID_DOCTO_FISCO",nullable=false)
	public Long idDoctoFisco;

	public SolicitacaoSegundaViaPK() {
		
	}

	public SolicitacaoSegundaViaPK(Date dtHoraSolct,Long idDoctoFisco) {
		this.dtHoraSolct = dtHoraSolct;
		this.idDoctoFisco = idDoctoFisco;
	}

	public boolean equals(Object other) {
		if(other instanceof SolicitacaoSegundaViaPK) {
			final SolicitacaoSegundaViaPK pk = (SolicitacaoSegundaViaPK) other;
			boolean ret = (pk.dtHoraSolct.equals(dtHoraSolct) && pk.idDoctoFisco.equals(idDoctoFisco));
			return ret;
		}
		return false;
	}

	public int hashCode() {
		return dtHoraSolct.hashCode() ^ idDoctoFisco.hashCode();
	}
}
