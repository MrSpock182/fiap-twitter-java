package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class DocumentoRegravar {
	private String ramo;
	private Long numApolice;
	private Long codDocumentoCsf;
	private String urlDocumentoCsf;
	private Long codDocumentoDigital;
	private String urlDocumentoDigital;
}
