package br.com.tokiomarine.acsel.domain.orm.ssv;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="EMP0018_DOCTO")
@IdClass(DocumentoPK.class)
public class Documento {

	@Id
	@Column(name="CD_DOCTO",nullable=false)
	private String cdDocto;
	
	@Id
	@Column(name="DT_INICO_VIGEN_DOCTO",nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtInicoVigenDocto;
	
	@Column(name="CD_CLASS_DOCTO",nullable=false)
	private String cdClassDocto;
	
	@Column(name="CD_EMPRE_IMP",nullable=false)
	private Long cdEmpreImp;
	
	@Column(name="CD_GRP_DOCTO")
	private Long cdGrpDocto;
	
	@Column(name="CD_SITUC_DOCTO",nullable=false)
	private String cdSitucDocto;
	
	@Column(name="CD_USURO_ULTMA_ALTER")
	private String cdUsuroUltmaAlter;
	
	@Column(name="DS_DOCTO",nullable=false)
	private String dsDocto;

	@Column(name="DT_FIM_VIGEN_DOCTO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtFimVigenDocto;

	@Column(name="DT_ULTMA_ALTER")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtUltmaAlter;
	
	@Column(name="IC_DOCTO_OFICL",nullable=false)
	private String icDoctoOficl;

	@Column(name="NM_DEPTO_RESPV")
	private String nmDeptoRespv;

	@Column(name="QT_VIA_DOCTO",nullable=false)
	private Long qtViaDocto;

	@Transient
	private DocumentoPK pk = new DocumentoPK();

	/** Retorna o objeto que representa a Primary-Key do registro no tabela do banco de dados relacional. */
	public Serializable getPk() {
		this.pk.cdDocto = this.cdDocto;
		this.pk.dtInicoVigenDocto = this.dtInicoVigenDocto;
		return this.pk;
	}
	
}
