package br.com.tokiomarine.acsel.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class PushNotificationDTO {
	
	private String finalidade;
	private String destinatario;
	private String titulo;
	private String chamada;
	private Integer dataDeValidade;
	
	@JsonInclude(Include.NON_NULL)
	private String mensagem;

	@JsonInclude(Include.NON_NULL)
	private MensagemPushDTO mensagemKey;

}
