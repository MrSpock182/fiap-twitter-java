package br.com.tokiomarine.acsel.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Builder
@Getter
@EqualsAndHashCode
@AllArgsConstructor
public class OpcaoDocumentoDTO {
	private String codDocumento;
	private String descDocumento;
	private Boolean obrigatorio;
}
