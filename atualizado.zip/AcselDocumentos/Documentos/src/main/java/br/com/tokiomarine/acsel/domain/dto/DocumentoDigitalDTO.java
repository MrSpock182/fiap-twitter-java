package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class DocumentoDigitalDTO {
	private Date dataEnvio;
	private Long codDocumento;
	private String descDocumento;
	private String dsUrlArquivo;
	private String dsUrlDocstore;
}
