package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class ResultadoREST {
	private Integer codigo;
	private String mensagem;
	private Long timestamp;

	public ResultadoREST(int codigo,String mensagemRetorno) {
		this.codigo = codigo;
		this.mensagem = mensagemRetorno;
		this.timestamp = System.currentTimeMillis();
	}

	public ResultadoREST(int codigo,String mensagemRetorno,long documentoID) {
		this.codigo = codigo;
		this.mensagem = mensagemRetorno;
		this.timestamp = System.currentTimeMillis();
	}

	public ResultadoREST(int codigo,String mensagemRetorno,String documentoID) {
		this.codigo = codigo;
		this.mensagem = mensagemRetorno;
		this.timestamp = System.currentTimeMillis();
	}

	public ResultadoREST(String mensagemRetorno,boolean comErro) {
		if (comErro) {
			this.timestamp = System.currentTimeMillis();
		}
		
		this.mensagem = mensagemRetorno;
	}
}
