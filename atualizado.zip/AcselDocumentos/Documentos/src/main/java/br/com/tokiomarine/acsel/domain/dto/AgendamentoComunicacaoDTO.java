package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
public class AgendamentoComunicacaoDTO {

	private String codigo;
	
	private Long seqAgendamento;
	
	private String statusAgendamento;
	
	private String tipoEnvio;

	private String codCorretor;

	private String rastreiaEnvio;
	
	@JsonInclude(Include.NON_NULL)
	private Long codigoModelo;

	@JsonInclude(Include.NON_NULL)
	private String indEnviaComunicacao;

	@JsonInclude(Include.NON_NULL)
	private String emailRemetente;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataEnvio;

	private List<Destinatario> destinatariosDetalhes;

	private List<AnexoEmail> anexos;
	
	@JsonInclude(Include.NON_EMPTY)
	private List<DocumentoComunicacaoDTO> documentos;

	@JsonInclude(Include.NON_EMPTY)
	private List<ParametroComunicacaoDTO> parametros;

	@JsonInclude(Include.NON_EMPTY)
	private List<String> destinatarios;
	
	@JsonInclude(Include.NON_EMPTY)
	private List<ListDocComunicacaoDTO> listDoc;
	
	@JsonInclude(Include.NON_EMPTY)
	private List<ComCopiaDTO> comCopias;

	public String getValorParametro(String nomeParam) {
		for (ParametroComunicacaoDTO p : this.getParametros()) {

			if(p.getNomeParametro().equals(nomeParam)) {
				return p.getValorParametro();
			}
		}
		return null;
	}
	
}
