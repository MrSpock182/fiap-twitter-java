package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class ListDocComunicacaoDTO {
	private Long seqAgendamento;
	private String nomeDocumento;
	private String urlDocumento;
	private String indEnviaEmail;
}
