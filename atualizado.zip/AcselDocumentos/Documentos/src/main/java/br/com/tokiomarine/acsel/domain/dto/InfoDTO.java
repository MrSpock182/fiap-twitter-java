package br.com.tokiomarine.acsel.domain.dto;

import java.util.Date;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class InfoDTO {
	private Integer codInfo;
	private Integer codCorretor;
	private Integer codTipoInfo;
	private String conteudoInfo;
	private String codProduto;
	private Date dtInicioVigencia;
	private String codUsuarioUltimaAlteracao;
	private Integer grupoTipoInfo;
}
