package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class UsuarioDTO {
	private String idUsuario;
	private String nomeUsuario;
	private TipoUsuario tipoUsuario;
	private String codCorretor;
	
	public boolean isCorretor(){
		return this.tipoUsuario.equals(TipoUsuario.corretor);
	}
	
	public String getCodUsuario(){
		if (isCorretor()){
			return this.codCorretor;
		} else{
			return this.idUsuario;
		}
	}
}
