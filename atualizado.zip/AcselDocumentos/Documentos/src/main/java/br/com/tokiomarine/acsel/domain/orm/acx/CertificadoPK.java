package br.com.tokiomarine.acsel.domain.orm.acx;

import java.io.Serializable;

public class CertificadoPK implements Serializable {

	private Poliza poliza;
	private Long numCert;

	public Long getNumCert() {
		return numCert;
	}
	public void setNumCert(Long numCert) {
		this.numCert = numCert;
	}
	public Poliza getPoliza() {
		return poliza;
	}
	public void setPoliza(Poliza poliza) {
		this.poliza = poliza;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numCert == null) ? 0 : numCert.hashCode());
		result = prime * result + ((poliza == null) ? 0 : poliza.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CertificadoPK other = (CertificadoPK) obj;
		if (numCert == null) {
			if (other.numCert != null)
				return false;
		} else if (!numCert.equals(other.numCert))
			return false;
		if (poliza == null) {
			if (other.poliza != null)
				return false;
		} else if (!poliza.equals(other.poliza))
			return false;
		return true;
	}
	
}
