package br.com.tokiomarine.acsel.domain.orm.acx;

import java.io.Serializable;

public class AgendamentoComCopiaPK implements Serializable {

	private Integer seqCopia;
	
	private AgendamentoComunicacao agendamento;
	
	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}

	public Integer getSeqCopia() {
		return seqCopia;
	}

	public void setSeqCopia(Integer seqCopia) {
		this.seqCopia = seqCopia;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agendamento == null) ? 0 : agendamento.hashCode());
		result = prime * result + ((seqCopia == null) ? 0 : seqCopia.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgendamentoComCopiaPK other = (AgendamentoComCopiaPK) obj;
		if (agendamento == null) {
			if (other.agendamento != null)
				return false;
		} else if (!agendamento.equals(other.agendamento))
			return false;
		if (seqCopia == null) {
			if (other.seqCopia != null)
				return false;
		} else if (!seqCopia.equals(other.seqCopia))
			return false;
		return true;
	}
	
}
