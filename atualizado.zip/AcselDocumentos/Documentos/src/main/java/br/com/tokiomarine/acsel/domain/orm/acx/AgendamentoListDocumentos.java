package br.com.tokiomarine.acsel.domain.orm.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "AGENDAMENTO_COMUNICACAO_LISTA")
public class AgendamentoListDocumentos implements Comparable<AgendamentoListDocumentos> {

	@Id
	@Column(name = "CD_SEQUENCIA_LISTA")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqListGenerator")
	@SequenceGenerator(name = "seqListGenerator", sequenceName = "SQ_AGENDAMENTO_LISTA", allocationSize = 1)
	private Long seqListaDocumentos;

	@ManyToOne
	@JoinColumn(name = "CD_SEQUENCIA_AGENDAMENTO", referencedColumnName = "CD_SEQUENCIA_AGENDAMENTO")
	private AgendamentoComunicacao agendamento;

	@Column(name = "NOME_DOCUMENTO")
	private String nomeDocumento;

	@Column(name = "DS_URL_ARQUIVO")
	private String urlArquivo;

	@Column(name = "ID_ENVIA_EMAIL")
	private String indEnviaEmail;

	@Column(name = "DT_ATUALIZACAO")
	private Date dtAtualizacao;

	public Long getSeqListaDocumentos() {
		return seqListaDocumentos;
	}

	public void setSeqListaDocumentos(Long seqListaDocumentos) {
		this.seqListaDocumentos = seqListaDocumentos;
	}

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}

	public String getNomeDocumento() {
		return nomeDocumento;
	}

	public void setNomeDocumento(String nomeDocumento) {
		this.nomeDocumento = nomeDocumento;
	}

	public String getUrlArquivo() {
		return urlArquivo;
	}

	public void setUrlArquivo(String urlArquivo) {
		this.urlArquivo = urlArquivo;
	}

	public String getIndEnviaEmail() {
		return indEnviaEmail;
	}

	public void setIndEnviaEmail(String indEnviaEmail) {
		this.indEnviaEmail = indEnviaEmail;
	}

	public Date getDtAtualizacao() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}

	@Override
	public int compareTo(AgendamentoListDocumentos outro) {
		if (this.getSeqListaDocumentos() < outro.getSeqListaDocumentos())
			return -1;
		if (this.getSeqListaDocumentos() > outro.getSeqListaDocumentos())
			return 1;
		return 0;
	}

}
