package br.com.tokiomarine.acsel.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class DownloadDocumentoDTO {
	private Long idDocumento;
	private String descDocumento;
	private String urlDocumento;
	private Long  idepol;
	private Integer  numEndosso;
}
