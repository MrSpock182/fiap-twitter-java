package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class DescricaoItemAutoFrotaDTO {
	private String placa;
	private String cor;
	private String ano;
	private String chassi;
}
