package br.com.tokiomarine.acsel.domain.dto;

import com.sun.mail.util.BASE64DecoderStream;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter 
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AnexoEmail {
	
	private String nome;
	private String fileBase64;
	private byte[] binario;
	
	public static class AnexoEmailBuilder {
		
		public AnexoEmailBuilder binario(String arquivoBase64) {
			byte[] bytes = arquivoBase64.getBytes();
			byte[] decode = BASE64DecoderStream.decode(bytes);
			this.binario = decode;
			return this;			
		}
		
	}

}
