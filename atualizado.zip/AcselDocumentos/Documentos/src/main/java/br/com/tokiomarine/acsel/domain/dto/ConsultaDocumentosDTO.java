package br.com.tokiomarine.acsel.domain.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class ConsultaDocumentosDTO {
	private Integer cdRamoProdutoTmsr;
	private Integer cdApoliceTmsr;
	private Integer cdEndossoTmsr;
	private Integer cdDocumento;
	private Integer codigoRetorno;
	private String mensagemRetorno;
	private List<DocumentoDocstoreDTO> documentos;
}
