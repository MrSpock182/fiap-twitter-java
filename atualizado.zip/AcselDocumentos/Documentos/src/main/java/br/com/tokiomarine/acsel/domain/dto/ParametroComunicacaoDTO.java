package br.com.tokiomarine.acsel.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class ParametroComunicacaoDTO {

	@JsonInclude(Include.NON_NULL)
	private Long seqAgendamento;
	
	@JsonInclude(Include.NON_NULL)
	private Long codParametro;
	
	@JsonInclude(Include.NON_NULL)
	private String descParametro;
	
	@JsonInclude(Include.NON_NULL)
	private String nomeParametro;
	
	@JsonInclude(Include.NON_NULL)
	private String valorParametro;
	
}
