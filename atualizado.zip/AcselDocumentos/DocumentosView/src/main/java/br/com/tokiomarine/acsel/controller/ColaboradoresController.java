package br.com.tokiomarine.acsel.controller;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import br.com.tokiomarine.acsel.service.ColaboradoresService;
import br.com.tokiomarine.acsel.ws.col.dto.LocalTrabalho;
import br.com.tokiomarine.acsel.ws.col.dto.RetColaboradorPorLocal;

@Controller
@SessionAttributes({"tipoDocumentos", "busca", "documentos"})
@RequestMapping(value = "/col")
public class ColaboradoresController {

	@Autowired
	ColaboradoresService colaboradoresService;

	private static Logger logger = LogManager.getLogger(ColaboradoresController.class);

	@RequestMapping(value="/locaisTrabalho")
	public  @ResponseBody List<LocalTrabalho> obtemLocais() {

		try{
			List<LocalTrabalho> locais = colaboradoresService.obtemLocaisTrabalho();
			return locais ;
		} catch (Exception e){
			logger.error("Erro", e);
		}
		return null;
	}

	@RequestMapping(value="/colaboradores", method=RequestMethod.POST)
	public  @ResponseBody List<RetColaboradorPorLocal> obtemColaboradoresPost(@RequestBody String local) {
		try{
			List<RetColaboradorPorLocal> colaborador = colaboradoresService.obtemColaboradores(local);
			return colaborador;
		} catch (Exception e){
			logger.error("Erro", e);
		}
		return null;
	}
}
