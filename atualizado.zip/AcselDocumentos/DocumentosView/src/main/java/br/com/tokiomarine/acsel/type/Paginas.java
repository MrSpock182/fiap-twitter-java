package br.com.tokiomarine.acsel.type;

public enum Paginas {

	home,
	heartbeat,
	parametros,
	segundavia,
	segundaviadet,
	histsegundavia("segundaviahist"),
	listamodelos,
	modeloemail,
	modelosms,
	modelopush,
	novomodelo,
	listamodelosagend,
	consultaagend,
	agendamento,
	errosagendamento,
	error("erros/exceptionPage"),
	listamodelosinativos,
	consultapiloto,	
	estatisticaAgendamento;


	Paginas(String value) {
		this.value = value;
	}

	Paginas() {}

	private String value;

	public String value() {
		if (value != null) {
			return value;
		} else {
			return this.name();
		}
	}
}
