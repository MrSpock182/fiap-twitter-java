package br.com.tokiomarine.acsel.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import br.com.tokiomarine.acsel.dto.BuscaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.DocumentoRecriar;
import br.com.tokiomarine.acsel.dto.DownloadDocumentoDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.service.ColaboradoresService;
import br.com.tokiomarine.acsel.service.DocumentosService;
import br.com.tokiomarine.acsel.service.SegundaViaService;
import br.com.tokiomarine.acsel.service.ValidaSegundaViaService;
import br.com.tokiomarine.acsel.type.OpcaoSolic;
import br.com.tokiomarine.acsel.type.Paginas;

@Controller
@Scope("request")
@SessionAttributes({ "busca", "documentos" })
@RequestMapping(value = "/segundavia")
public class SegundaViaController {

	// model attributes
	public static final String DOCUMENTO = "documento";
	public static final String DOCUMENTOS = "documentos";
	public static final String BUSCA = "busca";
	public static final String SHOWRESULT = "showGrid";
	public static final String ERRO = "errorMessage";
	public static final String ERROVAL = "errorValidacao";
	public static final String SUCESSO = "okMessage";
	public static final String MOTIVOS = "listaMotivos";
	public static final String SOLIC = "solicSegundaVia";
	public static final String OPCOES = "opcoesSolic";
	public static final String ENVIOAR = "envioAR";
	public static final String ID = "id";

	@Autowired
	MessageSource messages;
	@Autowired
	UsuarioSessao usuarioSessao;
	@Autowired
	DocumentosService documentosService;
	@Autowired
	SegundaViaService segundaViaService;
	@Autowired
	ColaboradoresService colaboradoresService;
	@Autowired
	ValidaSegundaViaService validaSegundaVia;

	private static Logger logger = LogManager.getLogger(SegundaViaController.class);

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String main(Integer id, HttpServletRequest request, Model model) throws Exception {

		if (usuarioSessao.getIdUsuario() == null || getDocumento(id, model) == null)
			return inicializa(request, model);
		else
			return buscaDetalhes(id, model);
	}

	@RequestMapping(value = "", method = RequestMethod.POST)
	public String post(Integer id, @ModelAttribute BuscaDocumentosDTO busca, @ModelAttribute SolicSegundaViaDTO solic,
			Model model) {

		if (busca.getTipoBusca() != null)
			return buscaDocumentos(busca, model);

		if (getDocumento(id, model) == null) {
			if (model.containsAttribute(DOCUMENTOS)) {
				model.addAttribute(SHOWRESULT, true);
			}
			if (!model.containsAttribute(BUSCA)) {
				model.addAttribute(BUSCA, new BuscaDocumentosDTO());
			}
			return Paginas.segundavia.value();
		}

		return emitirSegundaVia(id, solic, model);
	}

	private String inicializa(HttpServletRequest request, Model model) {
		try {
			usuarioSessao.loadUsuarioInterno(request);
			model.asMap().clear();
			model.addAttribute(BUSCA, new BuscaDocumentosDTO());

		} catch (final Exception e) {
			return obtemPaginaErro(e, model);
		}
		return Paginas.segundavia.value();
	}

	private String buscaDetalhes(Integer id, Model model) {

		DocumentoDTO doc = null;
		try {
			doc = getDocumento(id, model);

			if (!model.asMap().containsKey(SOLIC))
				model.addAttribute(SOLIC, new SolicSegundaViaDTO());

			model.addAttribute(MOTIVOS, segundaViaService.obtemMotivosSolic());

			documentosService.populaDetalhes(doc);

			model.addAttribute(DOCUMENTO, doc);
			model.addAttribute(ID, id);

			if (doc.isIndSolicitado()) {
				doc.setUltimaSolicitacao(doc.getHistSegundaVia().get(0));
				if (!model.asMap().containsKey(SUCESSO))
					model.addAttribute(SUCESSO,
							messages.getMessage("segundavia.detalhes.solicitado", null, Locale.getDefault()));
			} else {
				validaSegundaVia.permiteNovaSolicitacao(doc, usuarioSessao.getUsuario());
				model.addAttribute(OPCOES, segundaViaService.obtemOpcoesSolic(doc, usuarioSessao.getUsuario()));
				model.addAttribute(ENVIOAR, segundaViaService.permiteEnvioAR(doc, usuarioSessao.getUsuario()));
			}
		} catch (ServiceException s) {
			model.addAttribute(ERRO, s.getMessage());
		} catch (final Exception e) {
			return obtemPaginaErro(e, model);
		}

		return Paginas.segundaviadet.value();
	}

	private String buscaDocumentos(BuscaDocumentosDTO busca, Model model) {

		try {
			busca.setSomenteApolice(false);
			model.addAttribute(SHOWRESULT, true);
			model.addAttribute(BUSCA, busca);
			model.addAttribute(DOCUMENTOS, documentosService.buscaDocumentos(busca));
		} catch (ServiceException s) {
			model.addAttribute(ERRO, s.getMessage());
		} catch (final Exception e) {
			return obtemPaginaErro(e, model);
		}

		return Paginas.segundavia.value();
	}

	private String emitirSegundaVia(Integer id, SolicSegundaViaDTO solic, Model model) {

		DocumentoDTO doc = getDocumento(id, model);
		try {

			solic.setDocumento(doc);
			solic.setUsuarioSolic(usuarioSessao.getUsuario());
			segundaViaService.solicitaSegundaVia(solic);

			model.addAttribute(SUCESSO, messages.getMessage("segundavia.detalhes.sucesso",
					new String[] { OpcaoSolic.getOpcao(solic.getOpcao()).getDescDocumento() }, Locale.getDefault()));

			doc.setIndSolicitado(true);
			doc.setUltimaSolicitacao(doc.getHistSegundaVia().get(0));

		} catch (ServiceException s) {
			model.addAttribute(ERROVAL, s.getMessage());
			return buscaDetalhes(id, model);
		} catch (Exception e) {
			return obtemPaginaErro(e, model);
		}

		model.addAttribute(ID, id);
		model.addAttribute(SOLIC, solic);
		model.addAttribute(DOCUMENTO, doc);
		model.addAttribute(MOTIVOS, segundaViaService.obtemMotivosSolic());

		return Paginas.segundaviadet.value();
	}

	@RequestMapping(value = "/cancela", method = RequestMethod.POST)
	public String cancela(Integer id, Integer idVia, Model model) {

		try {
			DocumentoDTO doc = getDocumento(id, model);

			if (doc != null) {
				SegundaViaDTO via = doc.getHistSegundaVia().get(idVia);
				segundaViaService.cancelaSegundaVia(via, usuarioSessao.getUsuario());
				model.addAttribute(SUCESSO,
						messages.getMessage("segundavia.cancelamento.sucesso", null, Locale.getDefault()));
				doc.setIndSolicitado(false);

				model.addAttribute(ID, id);
				model.addAttribute(DOCUMENTO, doc);
				segundaViaService.obtemSolicitacoes(doc);
			}

		} catch (ServiceException s) {
			model.addAttribute(ERRO, s.getMessage());
		} catch (Exception e) {
			logger.error("Erro", e);
			model.addAttribute(ERRO, "Erro ao cancelar a solicitação");
		}

		return Paginas.histsegundavia.value();
	}

	@RequestMapping(value = "/hist", method = RequestMethod.GET)
	public String historico(Integer id, Model model) {

		try {
			DocumentoDTO doc = getDocumento(id, model);

			if (doc != null) {
				model.addAttribute(ID, id);
				model.addAttribute(DOCUMENTO, doc);
				documentosService.populaDetalhes(doc);
				segundaViaService.obtemSolicitacoes(doc);
			}

		} catch (final Exception e) {
			logger.error("Erro", e);
			return Paginas.histsegundavia.value();
		}

		return Paginas.histsegundavia.value();
	}

	@RequestMapping(value = "/geraDocumento", method = RequestMethod.GET)
	public @ResponseBody String geraDocumentoWeb(Integer id, String codItem, Long idDocto, Long idepol,
			Integer numEndosso, String email, Model model) {

		String result = null;
		DownloadDocumentoDTO downloadDocumentoDTO = new DownloadDocumentoDTO();
		downloadDocumentoDTO.setIdDocumento(idDocto);
		downloadDocumentoDTO.setIdepol(idepol);
		downloadDocumentoDTO.setNumEndosso(numEndosso);

		DocumentoDTO doc = new DocumentoDTO();
		doc.setIdePol(downloadDocumentoDTO.getIdepol());
		if (downloadDocumentoDTO.getNumEndosso() != null) {
			doc.setNumApolice(downloadDocumentoDTO.getNumEndosso().longValue());
		}
		List<DownloadDocumentoDTO> lista = null;

		try {
			doc = getDocumento(id, model);
			if (doc.getSistemaOrigem().isAcsel()) {
				lista = documentosService.segundaViaConsulta(doc);
			}
			if (doc != null) {
				result = segundaViaService.obtemLinkDownload(doc, codItem, idDocto, email, lista);
				if (result.equals("RECRIAR")) {
					result = segundaViaService.reprocessDocument(doc, idDocto);
				}
				return result;
			}

		} catch (final Exception e) {
			logger.error("Erro", e);
		}
		return null;
	}

	/**
	 * Gera PDF PARA TODAS URL DANIFICADAS (DATA DESATIVADA) FILTRO ESTA NA CLASSE
	 * DOCUMENTOPLATPREPOSITORY
	 * 
	 * @param datainicial
	 * @return
	 */
	@SuppressWarnings("unused")
	@RequestMapping(value = "/recriarPDF", method = RequestMethod.GET)
	public String recriarDocumentoWeb(Date datainicial) {
		List<DocumentoRecriar> lista = segundaViaService.listaDocument(datainicial);
		if (lista == null) {
			return null;
		}

		int contador = 0;
		for (DocumentoRecriar documentoRecriar : lista) {
			contador++;

			if (!segundaViaService.fileExists(documentoRecriar.getUrl())) {
				logger.error("RECRIAR URL: RAMO: " + documentoRecriar.getRamo() + ", APOLICE: "
						+ documentoRecriar.getNumApolice());
				try {

					DocumentoDTO doc = new DocumentoDTO();
					doc.setRamo(documentoRecriar.getRamo());
					doc.setNumApolice(documentoRecriar.getNumApolice());
					doc.setNumEndosso(documentoRecriar.getNumEndosso());
					doc.setCodDocumento(documentoRecriar.getCodDocumento());
					doc.setTipoApoliceEndosso(documentoRecriar.getTipoApoliceEndosso());
					String result = segundaViaService.reprocessDocument(doc,
							Long.parseLong(documentoRecriar.getCodDocumento()));
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (contador % 100 == 0) {
				System.out.println(contador);
			}
		}
		System.out.println("SUCESSO Registros Lidos: " + contador);
		return "SUCESSO";
	}

	@RequestMapping(value = "/headers", method = RequestMethod.GET)
	public String headers(HttpServletRequest request, Model model) throws Exception {
		return "headers";
	}

	public static DocumentoDTO getDocumento(Integer id, Model model) {

		if (id == null)
			return null;

		@SuppressWarnings("unchecked")
		List<DocumentoDTO> documentos = (List<DocumentoDTO>) model.asMap().get(DOCUMENTOS);

		if (documentos != null && id != null && id >= 0 && documentos.size() > id) {
			return documentos.get(id);
		}
		return null;
	}

	public static String obtemPaginaErro(Exception e, Model model) {
		model.addAttribute("mensagem", e.getMessage());
		model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
		logger.error("Erro", e);
		return Paginas.error.value();
	}

}
