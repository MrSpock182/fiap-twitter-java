package br.com.tokiomarine.acsel.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.tokiomarine.acsel.dto.BuscaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.service.ColaboradoresService;
import br.com.tokiomarine.acsel.service.DocumentosService;
import br.com.tokiomarine.acsel.service.SegundaViaService;
import br.com.tokiomarine.acsel.service.ValidaSegundaViaService;
import br.com.tokiomarine.acsel.type.OpcaoSolic;
import br.com.tokiomarine.acsel.type.Paginas;
import br.com.tokiomarine.acsel.type.PaginasCorretor;

@Controller
@Scope("request")
@SessionAttributes({"busca", "documentos"})
@RequestMapping(value = "/corretor/segundavia")
public class SegundaViaCorretorController {

	@Autowired
	MessageSource messages;
	@Autowired
	UsuarioSessao usuarioSessao;
	@Autowired
	DocumentosService documentosService;
	@Autowired
	SegundaViaService segundaViaService;
	@Autowired
	ColaboradoresService colaboradoresService;
	@Autowired
	ValidaSegundaViaService validaSegundaVia;

	@RequestMapping(value = "",method = RequestMethod.GET)
	public String main(Integer id, HttpServletRequest request,Model model) throws Exception {

		if (usuarioSessao.getIdUsuario() == null || SegundaViaController.getDocumento(id, model) == null)
			return inicializa(request, model);
		else
			return buscaDetalhes(id, model);
	}

	@RequestMapping(value = "",method = RequestMethod.POST)
	public String post(Integer id, @ModelAttribute BuscaDocumentosDTO busca, @ModelAttribute SolicSegundaViaDTO solic, Model model){

		if (busca.getTipoBusca() != null)
			return buscaDocumentos(busca, model);

		if (SegundaViaController.getDocumento(id, model) == null){
			if (model.containsAttribute(SegundaViaController.DOCUMENTOS)){
				model.addAttribute(SegundaViaController.SHOWRESULT, true);
			}
			if (!model.containsAttribute(SegundaViaController.BUSCA)){
				model.addAttribute(SegundaViaController.BUSCA, new BuscaDocumentosDTO());
			}
			return PaginasCorretor.segundavia.value();
		}

		return emitirSegundaVia(id, solic, model);
	}

	private String inicializa(HttpServletRequest request, Model model){
		try {
			usuarioSessao.loadUsuarioCorretor(request);
			if (!segundaViaService.permiteCorretor(usuarioSessao.getCodCorretor())){
				return PaginasCorretor.indisponivel.value();
			}
			model.asMap().clear();
			model.addAttribute(SegundaViaController.BUSCA, new BuscaDocumentosDTO());

		} catch (final Exception e) {
			return SegundaViaController.obtemPaginaErro(e, model);
		}
		return PaginasCorretor.segundavia.value();
	}

	public String buscaDocumentos(@ModelAttribute BuscaDocumentosDTO busca, Model model){

		try {
			if (busca.getTipoBusca() != null){
				busca.setCodCorretor(usuarioSessao.getCodCorretor());
				busca.setSomenteApolice(true);
				model.addAttribute(SegundaViaController.SHOWRESULT, true);
				model.addAttribute(SegundaViaController.BUSCA, busca);
				model.addAttribute(SegundaViaController.DOCUMENTOS, documentosService.buscaDocumentos(busca));
			}
		} catch (ServiceException s){
			model.addAttribute(SegundaViaController.ERRO, s.getMessage());
		} catch (final Exception e) {
			return SegundaViaController.obtemPaginaErro(e, model);
		}
		return PaginasCorretor.segundavia.value();
	}

	public String buscaDetalhes(Integer id, Model model){

		DocumentoDTO doc = null;
		try{
			doc = SegundaViaController.getDocumento(id, model);

			if (!model.asMap().containsKey(SegundaViaController.SOLIC))
				model.addAttribute(SegundaViaController.SOLIC, new SolicSegundaViaDTO());

			model.addAttribute(SegundaViaController.MOTIVOS, segundaViaService.obtemMotivosSolic());

			model.addAttribute(SegundaViaController.DOCUMENTO, doc);
			model.addAttribute(SegundaViaController.ID, id);

			if (doc.isIndSolicitado()){
				segundaViaService.obtemSolicitacoes(doc);
				doc.setUltimaSolicitacao(doc.getHistSegundaVia().get(0));
				if (!model.asMap().containsKey(SegundaViaController.SUCESSO))
					model.addAttribute(SegundaViaController.SUCESSO, messages.getMessage("segundavia.detalhes.solicitado",null,Locale.getDefault()));
			} else{
				model.addAttribute(SegundaViaController.OPCOES, segundaViaService.obtemOpcoesSolic(doc, usuarioSessao.getUsuario()));
				validaSegundaVia.permiteNovaSolicitacao(doc, usuarioSessao.getUsuario());
			}
		} catch(ServiceException s){
			model.addAttribute(SegundaViaController.ERRO, s.getMessage());
		}
		  catch (final Exception e) {
			  return SegundaViaController.obtemPaginaErro(e, model);
		}

		return PaginasCorretor.segundaviadet.value();
	}

	private String emitirSegundaVia(Integer id, SolicSegundaViaDTO solic, Model model){

		DocumentoDTO doc = SegundaViaController.getDocumento(id, model);
		try {

			solic.setDocumento(doc);
			solic.setUsuarioSolic(usuarioSessao.getUsuario());
			segundaViaService.solicitaSegundaVia(solic);

			model.addAttribute(SegundaViaController.SUCESSO, messages.getMessage("segundavia.detalhes.sucesso",
						new String[]{OpcaoSolic.getOpcao(solic.getOpcao()).getDescDocumento()},Locale.getDefault()));

			doc.setIndSolicitado(true);
			segundaViaService.obtemSolicitacoes(doc);
			doc.setUltimaSolicitacao(doc.getHistSegundaVia().get(0));

		} catch (ServiceException s){
			model.addAttribute(SegundaViaController.ERRO, s.getMessage());
		} catch (Exception e){
			return SegundaViaController.obtemPaginaErro(e, model);
		}

		model.addAttribute(SegundaViaController.ID, id);
		model.addAttribute(SegundaViaController.SOLIC, solic);
		model.addAttribute(SegundaViaController.DOCUMENTO, doc);
		model.addAttribute(SegundaViaController.MOTIVOS, segundaViaService.obtemMotivosSolic());

		return Paginas.segundaviadet.value();
	}

	@RequestMapping(value = "/cancela",method = RequestMethod.POST)
	public String cancela(Integer id, Integer idVia, final RedirectAttributes redirectAttributes, Model model){
		return "forward:/segundavia/cancela";
	}

	@RequestMapping(value = "/hist",method = RequestMethod.GET)
	public String historico(Integer id, Model model){
		return "forward:/segundavia/hist";
	}

	@RequestMapping(value = "/geraDocumento",method = RequestMethod.GET)
	public String geraDocumentoWeb(Integer id, Boolean geraCartao, String email, Model model){
		return "forward:/segundavia/geraDocumento";
	}
}