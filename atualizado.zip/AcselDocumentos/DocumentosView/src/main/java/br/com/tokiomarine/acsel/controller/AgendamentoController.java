package br.com.tokiomarine.acsel.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.dto.BuscaAgendamentoDTO;
import br.com.tokiomarine.acsel.dto.ParametroComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.RetornoAgendamentoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.service.AgendamentoComunicacaoService;
import br.com.tokiomarine.acsel.service.EnvioComunicacaoService;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoService;
import br.com.tokiomarine.acsel.type.Paginas;
import br.com.tokiomarine.acsel.type.StatusAgendamento;
import br.com.tokiomarine.acsel.type.TipoModelo;

@Controller
@Scope("request")
@RequestMapping(value = "/comunicacao/agendamento")
@SessionAttributes({"busca"})
public class AgendamentoController{

    // model attributes
    public static final String MODELOS = "modelos";
    public static final String MODELO = "modelo";
    public static final String DOCUMENTOS = "documentos";
    public static final String PARAMETROS = "parametros";
    public static final String SHOWRESULT = "showResult";
    public static final String AGENDAMENTOS = "agendamentos";
    public static final String AGENDAMENTO = "agendamento";
    public static final String PILOTOS = "pilotos";    
    public static final String BUSCA = "busca";
    public static final String ERROS = "erros";

    @Autowired
    UsuarioSessao usuarioSessao;
    @Autowired
    ModeloComunicacaoService modeloService;
    @Autowired
    AgendamentoComunicacaoService agendamentoService;
    @Autowired
	EnvioComunicacaoService envioService;

    private static Logger logger = LogManager.getLogger(AgendamentoController.class);

    @RequestMapping(value = "", method = RequestMethod.GET)
    public String main(Long id, HttpServletRequest request, Model model){

        try{
            usuarioSessao.loadUsuarioInterno(request);

            if (id == null){
            	model.asMap().clear();
                List<ModeloComunicacao> modelos = modeloService.obtemModelos();
                model.addAttribute(BUSCA, new BuscaAgendamentoDTO());
                model.addAttribute(MODELOS, modelos);
                return Paginas.listamodelosagend.value();
            } else{
                model.addAttribute(AGENDAMENTO, agendamentoService.obtemAgendamentoCompleto(id));
                BuscaAgendamentoDTO busca = (BuscaAgendamentoDTO) model.asMap().get(BUSCA);
                if (busca == null){
                	busca = new BuscaAgendamentoDTO();
                	model.addAttribute(BUSCA, busca);
                }
                busca.setNovaBusca(true);
                return Paginas.agendamento.value();
            }

        } catch (Exception e){
            return obtemPaginaErro(e, model);
        }
    }
    
    @RequestMapping(value = "/piloto", method = RequestMethod.GET)    
    public String piloto(HttpServletRequest request, Model model){
    	try {
            model.addAttribute(BUSCA, new BuscaAgendamentoDTO());
			model.addAttribute(PILOTOS, agendamentoService.buscaAgendamentosPiloto());
	    	return Paginas.consultapiloto.value();			
		} catch (ServiceException e) {
			return obtemPaginaErro(e, model);
		}
    }
    
    
    @RequestMapping(value = "/enviarPiloto", method = RequestMethod.POST)    
    public String enviarPiloto(Long idAgendamento, HttpServletRequest request, Model model){
    	
		AgendamentoComunicacao agendamento = agendamentoService.obtemAgendamento(idAgendamento);
		if (agendamento == null) {
			Exception exception = new Exception("Agendamento Não Existe");
			return obtemPaginaErro(exception, model);
		}
		
		agendamento.setStatusAgendamento(StatusAgendamento.naoenviado.getValue());
		agendamentoService.atualizaAgendamento(agendamento);
		
		try{
			if (envioService.solicitaEnvio(idAgendamento)){
				model.addAttribute(PILOTOS, agendamentoService.buscaAgendamentosPiloto());
		    	return Paginas.consultapiloto.value();			
			} else{
				Exception exception = new Exception("Agendamento Inválido");
				return obtemPaginaErro(exception, model);
			}

		} catch (ServiceException e){
			return obtemPaginaErro(e, model);
 		} catch (Exception e){
			Exception exception = new Exception("Erro ao solicitar envio da comunicação"); 			
			return obtemPaginaErro(exception, model);			
 		}
    	
    }
    
    @RequestMapping(value = "/enviarDataPiloto", method = RequestMethod.POST)    
    public ResponseEntity<String> enviarDataPiloto(String codigo, Date dataAgendamento, HttpServletRequest request, Model model){
    	
		String msgRet = "";
		HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		
		if (codigo == null || codigo.equals("")) {
			msgRet = "Código do modelo é obrigatório";
			return new ResponseEntity<String>(msgRet, httpStatus);
		}
		
		try {
			ModeloComunicacao modelo = modeloService.obtemModelo(codigo);
			if (modelo == null) {
				msgRet = "Código do modelo não cadastrado";
				return new ResponseEntity<String>(msgRet, httpStatus);
			}
			
			if ( !modelo.getSituacaoModelo().equals("S")) {
				msgRet = "Modelo não está ativo";
				return new ResponseEntity<String>(msgRet, httpStatus);
			}
		} catch (ServiceException se) {
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;			
			msgRet = "Erro ao obter modelo. "  + se.getMessage();
			return new ResponseEntity<String>(msgRet, httpStatus);
		}
		
    	List<AgendamentoComunicacao> lista = agendamentoService.buscaAgendamentosPiloto(codigo, dataAgendamento);
    	if (lista == null || lista.size() == 0) {
    		msgRet = "Nesta data não existe agendamento";
			httpStatus = HttpStatus.NOT_ACCEPTABLE;    		
			return new ResponseEntity<String>(msgRet, httpStatus);    		
    	}
    	
    	for (AgendamentoComunicacao agendamento : lista) {
    		agendamento.setStatusAgendamento(StatusAgendamento.naoenviado.getValue());
    		agendamentoService.atualizaAgendamento(agendamento);
    		
    		try{
    			if ( !envioService.solicitaEnvio(agendamento.getSeqAgendamento())) {
    				msgRet = "Agendamento Inválido: " + agendamento.getSeqAgendamento().toString();
    				return new ResponseEntity<String>(msgRet, httpStatus);
    			}

    		} catch (ServiceException e){
    			msgRet = e.getMessage();    			
    			httpStatus = HttpStatus.NOT_ACCEPTABLE;
				return new ResponseEntity<String>(msgRet, httpStatus);    			
     		} catch (Exception e){
     			msgRet = "Erro ao solicitar envio da comunicação";
     			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;     			
				return new ResponseEntity<String>(msgRet, httpStatus);     			
     		}
		}
    	
		try {
			model.addAttribute(PILOTOS, agendamentoService.buscaAgendamentosPiloto());
			httpStatus = HttpStatus.OK;
			msgRet = Paginas.consultapiloto.value();
			return new ResponseEntity<String>(msgRet, httpStatus);			
		} catch (ServiceException e) {
			msgRet = e.getMessage();
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;			
			return new ResponseEntity<String>(msgRet, httpStatus);			
		}
    	
    }

    @RequestMapping(value = "/consulta", method = RequestMethod.GET)
    public String consulta(Long id, HttpServletRequest request, Model model){

        try{

            ModeloComunicacao modelo = null;

            BuscaAgendamentoDTO busca;
            if (!model.containsAttribute(BUSCA)){
            	busca = new BuscaAgendamentoDTO();
            	model.addAttribute(BUSCA, busca);
            } else{
            	busca = (BuscaAgendamentoDTO) model.asMap().get(BUSCA);
            }

            if (id != null){
                modelo = modeloService.obtemModelo(id.longValue());
                model.addAttribute(MODELO, modelo);
            }

            List<ParametroComunicacaoDTO> listaParam = modeloService.obtemParametrosConsulta(modelo);
            if (listaParam != null){
            	for (ParametroComunicacaoDTO param : listaParam){
            		param.setValorParametro(busca.obtemValorParametro(param.getCodParametro()));
            	}
            	model.addAttribute(PARAMETROS, listaParam);
            }

            if (busca.getNovaBusca()){
                model.addAttribute(AGENDAMENTOS, agendamentoService.buscaAgendamentos(busca));
                model.addAttribute(SHOWRESULT, true);
                model.addAttribute(BUSCA, busca);
                busca.setNovaBusca(false);
            }

            return Paginas.consultaagend.value();
        } catch (Exception e){
            return obtemPaginaErro(e, model);
        }
    }

    @RequestMapping(value = "/consulta", method = RequestMethod.POST)
    public @ResponseBody String busca(Long id, @RequestBody BuscaAgendamentoDTO busca, Model model){

        try{

        	BuscaAgendamentoDTO buscaModel = (BuscaAgendamentoDTO) model.asMap().get(BUSCA);

        	buscaModel.setCodModelo(id);
        	buscaModel.setSeqAgendamento(busca.getSeqAgendamento());
        	buscaModel.setDestinatario(busca.getDestinatario());
        	buscaModel.setDataIni(busca.getDataIni());
        	buscaModel.setDataFim(busca.getDataFim());
        	buscaModel.setParametros(busca.getParametros());
        	buscaModel.setCpfCnpj(busca.getCpfCnpj());
        	buscaModel.setTipoEnvio(busca.getTipoEnvio());
        	buscaModel.setNovaBusca(true);
        } catch (Exception e){
            logger.error("Erro ao consultar agendamentos", e);
        }

        return "";
    }

    @RequestMapping(value = "/reenvio", method = RequestMethod.POST)
    public @ResponseBody RetornoAgendamentoDTO reenvio(String id){

   		RetornoAgendamentoDTO retorno = new RetornoAgendamentoDTO();
   		try{
    		envioService.solicitaReenvio(Long.parseLong(id), usuarioSessao.getCodUsuario());
    		retorno.setSeqAgendamento(Long.parseLong(id));
   			retorno.setCodigoRetorno(0);
   			retorno.setMensagemRetorno("");

    	} catch (ServiceException e){
   			retorno.setCodigoRetorno(1);
   			retorno.setMensagemRetorno(e.getMessage());
    	} catch (Exception e){
   			logger.error("Erro ao solicitar o reeenvio do e-mail", e);
   			retorno.setCodigoRetorno(9);
   			retorno.setMensagemRetorno("Erro ao solicitar o reeenvio do e-mail");
    	}

   		return retorno;
    }

    @RequestMapping(value = "/erros", method = RequestMethod.GET)
    public String consultaErros(Long id, HttpServletRequest request, Model model){

        try{
        	model.addAttribute(ERROS, agendamentoService.obtemErros(id));
            return Paginas.errosagendamento.value();
        } catch (Exception e){
            return obtemPaginaErro(e, model);
        }
    }

    @RequestMapping(value = "/email",method = RequestMethod.GET, produces={MediaType.TEXT_HTML_VALUE})
	public @ResponseBody String consultaEmail(Long id){

    	String msgRet = "";

		try{
			AgendamentoComunicacao agend = agendamentoService.obtemAgendamento(id);

			if (agend.getModelo().getCanalComunicacao().equals(TipoModelo.email)){
				msgRet = agend.getMensagemEnviada();
			}

		} catch (Exception e){
			msgRet = "Erro ao obter visualização do e-mail";
			logger.error("Erro ao obter visualização do e-mail", e);
 		}

		return msgRet;
	}

    public static String obtemPaginaErro(Exception e, Model model){
        model.addAttribute("mensagem",e.getMessage());
        model.addAttribute("stacktrace",ExceptionUtils.getFullStackTrace(e));
        logger.error("Erro",e);
        return Paginas.error.value();
    }
}