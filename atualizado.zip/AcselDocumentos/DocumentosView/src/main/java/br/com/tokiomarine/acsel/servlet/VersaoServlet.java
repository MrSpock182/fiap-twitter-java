package br.com.tokiomarine.acsel.servlet;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.tokiomarine.acsel.dto.CDN;
import br.com.tokiomarine.acsel.util.DateUtil;
import br.com.tokiomarine.acsel.util.POMUtil;
import br.com.tokiomarine.acsel.util.VariaveisAmbienteUtil;

public class VersaoServlet extends HttpServlet {

	private static final long serialVersionUID = -2836193315449886091L;

	private static final String PAGINA_VERSAO_JSP = "/versao.jsp";
	private static final String TMS = "tokiomarineseguradora";
	private static final String PROPRIEDADE_JAVA_VERSION = "java.version";
	private static final String CLASSLOADER = "classloader";
	private static final String BIBLIOTECAS = "libs";
	private static final String USUARIO_AUTENTICADO = "autenticado";
	private static final String VERSAO_DO_JAVA = "java";
	private static final String SERVLET = "servlet";
	private static final String SERVIDOR = "servidor";
	private static final String AMBIENTE = "ambiente";
	private static final String BUILD = "build";
	private static final String UPTIME_EM_DIAS = "uptimeEmDias";
	private static final String UPTIME_EM_HORAS = "uptimeEmHoras";
	private static final String UPTIME_EM_MINUTOS = "uptimeEmMinutos";
	private static final String UPTIME_EM_SEGUNDOS = "uptimeEmSegundos";
	private static final String DATA_DE_STARTUP = "dataDeStartup";
	private static final String PARAMETRO_PWD = "pwd";
	private static final String CDN_PUBLICO = "CDNpublico";
	private static final String CDN_PRIVADO = "CDNprivado";
	private static final String CDN_VERSAO = "CDNversao";
	private static final String POM_NOME = "POMnome";
	private static final String POM_GROUP_ID = "POMgroupId";
	private static final String POM_ARTIFACT_ID = "POMartifactId";
	private static final String POM_VERSAO = "POMversion";

	protected void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {

		String senha = request.getParameter(PARAMETRO_PWD);
		if (senhaValida(senha)) {

			RuntimeMXBean rb = ManagementFactory.getRuntimeMXBean();
			long secondsInMilli = 1000;
			long minutesInMilli = secondsInMilli * 60;
			long hoursInMilli = minutesInMilli * 60;
			long daysInMilli = hoursInMilli * 24;

			long uptime = rb.getUptime();
			long uptimeEmDias = uptime / daysInMilli;
			uptime = uptime % daysInMilli;

			long uptimeEmHoras = uptime / hoursInMilli;
			uptime = uptime % hoursInMilli;

			long uptimeEmMinutos = uptime / minutesInMilli;
			uptime = uptime % minutesInMilli;

			long uptimeEmSegundos = uptime / secondsInMilli;

			CDN cdn = new CDN();
			request.setAttribute(CDN_PUBLICO,cdn.getPublico());
			request.setAttribute(CDN_PRIVADO,cdn.getRestrito());
			request.setAttribute(CDN_VERSAO,cdn.getVersao());
			request.setAttribute(UPTIME_EM_DIAS,uptimeEmDias);
			request.setAttribute(UPTIME_EM_HORAS,uptimeEmHoras);
			request.setAttribute(UPTIME_EM_MINUTOS,uptimeEmMinutos);
			request.setAttribute(UPTIME_EM_SEGUNDOS,uptimeEmSegundos);
			request.setAttribute(DATA_DE_STARTUP,DateUtil.formataCompleta(new Date(rb.getStartTime())));
			request.setAttribute(AMBIENTE,VariaveisAmbienteUtil.getAmbienteDetectado());
			request.setAttribute(SERVIDOR,getServletContext().getServerInfo());
			request.setAttribute(SERVLET,getServletContext().getMajorVersion() + "." + getServletContext().getMinorVersion());
			request.setAttribute(VERSAO_DO_JAVA,System.getProperty(PROPRIEDADE_JAVA_VERSION));
			request.setAttribute(POM_NOME,POMUtil.getName());
			request.setAttribute(POM_GROUP_ID,POMUtil.getGroupId());
			request.setAttribute(POM_ARTIFACT_ID,POMUtil.getArtifactId());
			request.setAttribute(POM_VERSAO,POMUtil.getVersion());
			request.setAttribute(BUILD,POMUtil.getData());
			request.setAttribute(USUARIO_AUTENTICADO,true);

			StringBuilder libs = new StringBuilder();

			try {
				Class<? extends VersaoServlet> clazz = getClass();
				ClassLoader cl = clazz.getClassLoader();
				request.setAttribute(CLASSLOADER,cl.toString());
				if (cl instanceof URLClassLoader) {
					URL[] urls = ((URLClassLoader) cl).getURLs();
					for (int i = 0 ; i < urls.length ; i++) {
						libs.append(i + 1 + " - " + urls[i] + "</br>");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			request.setAttribute(BIBLIOTECAS,libs.toString());
		}

		request.getRequestDispatcher(PAGINA_VERSAO_JSP).forward(request,response);
	}

	private boolean senhaValida(String senha) {

		if (senha != null && senha.length() > 0) {
			String senhaDeHoje = TMS + DateUtil.getDiaDoMes();
			if (senha.toLowerCase().equals(senhaDeHoje)) { return true; }
		}

		return false;
	}

	@Override
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		processRequest(request,response);
	}

	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		processRequest(request,response);
	}

}
