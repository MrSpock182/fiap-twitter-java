/* meus scripts */
window.onload = function() {
 	$.unblockUI();
};
window.onsubmit = function() {
	$.blockUI();
};

$('.input-daterange').datepicker({
	    format: "dd/mm/yyyy",
	    language: "pt-BR"
	});

jQuery('input.mask-telefone').mask("(99) 9999-9999");
jQuery('input.mask-data').mask("99/99/9999");

jQuery('input.mask-cep').mask("99999-999");
jQuery('input.mask-placa').mask("aaa-9999");

jQuery('input.mask-cpf').mask("999.999.999-99");
jQuery('input.mask-cnpj').mask("99.999.999/9999-99");

$.fn.serializeObject = function(){
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

$.fn.dataTable.moment('DD/MM/YYYY');
$.fn.dataTable.moment('DD/MM/YYYY HH:mm:ss');

$.fn.dataTable.ext.order['dom-text-numeric'] = function  ( settings, col ){
	return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
		return $('input', td).val() * 1;
    });
}
