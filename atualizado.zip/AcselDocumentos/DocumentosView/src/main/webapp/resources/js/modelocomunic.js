var codModelo;
var tableNovoParam;
var tableNovoTexto;
var tableTexto;
var tableParam;
var tableImagem;
var selectedImage;
var callbackImage;
var rowData;

function initListaModelo(){
	$('#tableModelos').dataTable({
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        } 
    });
}

function initListaModeloInativo(){
	$('#tableModelosInativo').dataTable({
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });
	
	$('#tableModelosInativo tbody tr').click(function(){
	   rowData = $('#tableModelosInativo').DataTable().row(this).data();
	   $('#inptCodModelo').val($(this).attr('data-codModelo'));
	   $('#inptStatus').val(rowData[6]);

	   var newOptions;
	   if ($('#inptperfilUsuario').val() == "admin") {
		   if (rowData[6] == "PENDENTE") {
			   newOptions = { "     ":"", "A APROVAR":"A APROVAR"};			   
		   } else {
			   newOptions = { "     ":"", "ATIVAR":"ATIVADO"};
		   }
	   } else {
		   newOptions = { "     ":"", "APROVADO":"APROVADO", "RECUSADO":"RECUSADO" };
	   } 
	   
	   $('#inptStatus').empty();
	   $.each(newOptions, function(key, value) {
		   $('#inptStatus').append($("<option></option>")
		    .attr("value", value).text(key));
		});	   
	   
	}); 
	
}

function initModeloComunicacao(codMod, status, piloto, emailCopia, rastreiaEnvio) {
	codModelo = codMod;
	
	tableTexto = $('#tableTextos').DataTable({
        "paging" : false,
        "searching" : false,
        "ordering" : true,
        "order": [[ 1, "asc" ]],
        "columns": [
                    null,
                    { "orderDataType": "dom-text-numeric" },
                    null,
                    null,
                    null
                ],
        columnDefs: [
          { orderable: false, targets: [0,2,3,4] }
        ],
        "textarea": true,
        "bInfo": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

	if (codModelo === "" || !tableTexto.data().length){
		$("#divTexto").addClass("hide");
	}

    tableParam = $('#tableParametros').DataTable({
        "paging" : true,
        "searching" : false,
        "ordering" : false,
        "bInfo": true,
        "bLengthChange": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

    $('#tableNovoTexto').dataTable({
        "paging" : true,
        "searching" : true,
        "ordering" : true,
        "bInfo": true,
        "bLengthChange": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

    tableNovoTexto = $('#tableNovoTexto').DataTable();

    $('#tableNovoTexto tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('active') ) {
            $(this).removeClass('active');
        }
        else {
        	tableNovoTexto.$('tr.active').removeClass('active');
            $(this).addClass('active');
        }
    });

    $('#tableNovoParam').dataTable({
        "paging" : true,
        "searching" : true,
        "ordering" : true,
        "bInfo": true,
        "bLengthChange": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

    tableNovoParam = $('#tableNovoParam').DataTable();

    $('#tableNovoParam tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('active') ) {
            $(this).removeClass('active');
        }
        else {
        	tableNovoParam.$('tr.active').removeClass('active');
            $(this).addClass('active');
        }
    });

    $('#tableImagens').dataTable({
        "paging" : true,
        "searching" : true,
        "ordering" : false,
        "bInfo": true,
        "bLengthChange": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

    tableImagem = $('#tableImagens').DataTable();

    $('#tableImagens tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('active') ) {
            $(this).removeClass('active');
        }
        else {
        	tableImagem.$('tr.active').removeClass('active');
            $(this).addClass('active');
        }
    });

    $('.imgPreview').popover();

    $('textarea').each(function() {}).on('input', function () {
    	  this.style.height = 'auto';
    	  this.style.height = (this.scrollHeight) + 'px';
    });

    $('textarea').each(function() {}).trigger('input');

    $(document).on('change','.ckLista',function(){
    	var row = $(this).closest('tr');
    	if($(this).is(':checked')){
    	   	$(row).find('.lista').prop("disabled",false);
    	}
    	else{
    	   	$(row).find('.lista').prop("disabled",true);
    	}
    });

    if(status == "S"){
    	setAtivo();
    } else{
    	setInativo();
    }
    
    $("#inputCC").val(emailCopia);
	$("#inputPiloto").val(piloto);
	$("#inputEnvio").val(rastreiaEnvio);
    
}


function setAtivo() {
	$("#inputStatus").val("S");
	$("#statusAtivo").addClass("active");
	$("#statusInativo").removeClass("active");
}

function setInativo() {
	$("#inputStatus").val("N");
	$("#statusInativo").addClass("active");
	$("#statusAtivo").removeClass("active");
}

var showMessageErro = function(msgError) {
	$('#mensagemErro').html(msgError);
	$('#msgErro').removeClass("hide");	
	window.scrollTo(0, 0);
}

function atualizaModelo(){
	
	$('#msgErro').addClass("hide");
	$('#errorMessage').addClass("hide");
	$('#msgSucesso').addClass("hide");
	
	if(!$('#inputSistema').val()) {
		showMessageErro('Sistema de Origem Obrigatório');
		return;
	}
	
	if(!$('#inputPiloto').val()) {
		showMessageErro('Piloto Obrigatório');
		return;
	}
	
	if($('#inputEmailResponsavel').val() !== "") {
		if(!validaEmail($('#inputEmailResponsavel').val())) {
			showMessageErro('Email Responsavel: E-mail inválido');
			return;		
		}
	} else {
		showMessageErro('Email Responsavel: Informe um email');
		return;		
	}
	
	if($('#inputTipoModelo').val() == 'EMAIL') {
		if(!validaEmail($('#inputRemetente').val())) {
			showMessageErro('E-mail inválido');
			return;		
		}
		
		if($('#inputCaixa').val() !== "") {
			if(!validaEmail($('#inputCaixa').val())) {
				showMessageErro('Caixa Departamental: E-mail inválido');
				return;		
			}
		}	
	}
	
	$.ajax( {
		dataType: "text",
		contentType : "application/json", 
        type: "POST",
        url:  "atualiza?id=" + codModelo,
	    data : JSON.stringify($('#formAtualizaModelo').serializeObject()),
        success:function(result){
        	//if (result !== null && result !== ""){
        	//	$('#msgErro').removeClass("hide"); 
        	//	$('#mensagemErro').html(result);
        	//} else{
        		atualizaTextos();
        	//}
    	},
//    	error: function(jqXHR, textStatus, errorThrown) {
//    		alert("Erro ao atualizar modelo");
//    	}
    	error: function(error) { // jqXHR, textStatus, errorThrown) {
    		console.log(error);
    		var msgError = error.status == 406 ? error.responseText : 'Erro ao incluir modelo: ' + error.responseText;
    		showMessageErro(msgError);
    	}    	
	});
}

var validaEmail = function(email) {
	var pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
	return pattern.test(email);
}

var validaInclusao = function() {
	var msgError = "";

	if(!$('#inputCod').val()) 
		msgError += '\nCódigo do Modelo';
	
	if(!$('#inputSistema').val())   
		msgError += '\nSistema de Origem';

	if(!$('#inputNome').val()) 
		msgError += '\nNome do Modelo';
	
	if(!$('#inputProcesso').val()) 
		msgError += '\nNome do Processo';

	//if(!validaEmail($('#inputRemetente').val()))
	//	msgError = 'E-mail inválido:\n' + msgError;
	
	if(msgError) msgError = 'Campos Obrigatórios:\n' + msgError;

	return msgError; 
}  

function montarCodigo() {
	var novoCodigo  = $('#inputTipoModelo').val() == "EMAIL" ? "EM" : $('#inputTipoModelo').val() == "SMS" ? "SM" : "PU";
	    novoCodigo += $('#inputSistema option:selected').attr('data-codigo'); 
	    novoCodigo += $('#inputProcesso option:selected').attr('data-codproc');
	
	$.ajax( {
		dataType: "text",
		contentType : "application/json", 
        type: "GET",
        url:  "proximoCodigo?prefixo=" + novoCodigo,
        success:function(result){
        	novoCodigo =  result;
        	$('#inputCod').val(novoCodigo);
    	},
    	error: function(error) { // jqXHR, textStatus, errorThrown) {
    		console.log(error);
    		var msgError = error.status == 406 ? error.responseText : 'Erro ao localizar próximo código: ' + error.responseText;
    		showMessageErro(msgError);
    	}    	
	});
}

function incluiModelo(){
	
	var msgValid = validaInclusao();
	if(msgValid) {
		alert(msgValid);
		return;
	}
	
	$.ajax( {
		dataType: "text",
		contentType : "application/json",
        type: "POST",
        url:  "",
	    data : JSON.stringify($('#formAtualizaModelo').serializeObject()),
        success:function(result){
//        	window.location.href = "../modelos";
        	window.location.href = "../modelos/detalhes?id=" + result;	
    	},
    	error: function(error) { // jqXHR, textStatus, errorThrown) {
    		console.log(error);
    		if(error.status == 406) { 
    			alert(error.responseText);
    			return;
    		} 
    		alert('Erro ao incluir modelo: \n' + error.reponseText);
    	}
	});
	
}

function atualizaTextos(){
	$.ajax( {
		dataType: "text",
		contentType : "application/json",
        type: "POST",
        url:  "textos",
	    data : JSON.stringify($('#tableTextos').tableToJSON({
	    	  ignoreColumns : [2,4],
	    	  textExtractor : function(cellIndex, $cell) {
	    		  var nicEditor = $cell.find('.nicEdit-main').html();
	    		  if (nicEditor != undefined) {
	    			  return nicEditor;  
	    		  } else {
	    			  return $cell.find(':input').val();
	    		  }
	    	  }
	    	})),
        success:function(result){
        	if (result !== null && result !== ""){
        		$('#msgErro').removeClass("hide");
        		$('#mensagemErro').html(result);
        	} else{
        		$('#msgSucesso').removeClass("hide");
        		$('#mensagemSucesso').html("Modelo atualizado com sucesso");
        		window.scrollTo(0, 0);
        	}
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		alert("Erro ao atualizar textos");
    	}
	});
}

function atualizaParametros(){
	$.ajax( {
		dataType: "text",
		contentType : "application/json",
        type: "POST",
        url:  "parametros",
	    data : JSON.stringify($('#tableParametros').tableToJSON({
	    	ignoreColumns : [1,2],
	    	textExtractor : function(cellIndex, $cell) {
	    		if (cellIndex == 3){
	    			if ($cell.find('.ckLista').is(':checked')) return "S";
	    			return "N";
	    		}
	    	    return $cell.find('input').val() || $cell.text();
	    	}
	    })),
        success:function(result){
        	if (result !== null && result !== ""){
        		$('#msgErro').removeClass("hide");
        		$('#mensagemErro').html(result);
        	} else{
        		$('#msgSucesso').removeClass("hide");
        		$('#mensagemSucesso').html("Parâmetros atualizados com sucesso");
        		window.scrollTo(0, 0);
        	}
        	$('#modalParam').modal('toggle');
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		alert("Erro ao atualizar textos");
    	}
	});
}

function incluiTexto(){
	var row = tableNovoTexto.row('.active').data();
	if (typeof row != 'undefined'){
		$.ajax( {
			dataType: "text",
	        type: "POST",
	        url:  "texto?idModelo=" + codModelo + "&idTexto=" + row[0],
	        success:function(result){
	        	window.location.reload(true);
	    	},
	    	error: function(jqXHR, textStatus, errorThrown) {
	    		alert("Erro ao incluir texto");
	    	}
		});
	}
}

function removeTexto(id){

	$.ajax( {
		dataType: "text",
	       type: "DELETE",
	       url:  "texto?id=" + id,
	       success:function(result){
	       	window.location.reload(true);
	   	},
	   	error: function(jqXHR, textStatus, errorThrown) {
	   		alert("Erro ao remover texto");
	   	}
	});
}

function removeModelo(idModelo){
	$.ajax( {
		dataType: "text",
	       type: "DELETE",
	       url:  "modelos/excluir?idModelo=" + idModelo,
	       success:function(result){
	       	window.location.reload(true);
	   	},
	   	error: function(error) {
	   		alert(error.responseText);
	   	}
	});
}

function incluiParametro(){
	var row = tableNovoParam.row('.active').data();
	if (typeof row != 'undefined'){
		$.ajax( {
			dataType: "text",
	        type: "POST",
	        url:  "parametro?idModelo=" + codModelo + "&idParam=" + row[0],
	        success:function(result){
	        	window.location.reload(true);
	    	},
	    	error: function(jqXHR, textStatus, errorThrown) {
	    		alert("Erro ao incluir parâmetro");
	    	}
		});
	}
}

function removeParametro(id){

	$.ajax( {
		dataType: "text",
	       type: "DELETE",
	       url:  "parametro?id=" + id,
	       success:function(result){
	       	window.location.reload(true);
	   	},
	   	error: function(jqXHR, textStatus, errorThrown) {
	   		alert("Erro ao remover parâmetro");
	   	}
	});
}

function incluiCadParametro(){
	var msgError = "";
	if (!$('#inputParamNome').val()) {
		msgError += '\nNome do Parâmetro';
	}
	
	if (!$('#inputParamDescr').val()) {
		msgError += '\nDescrição do Parâmetro é Obrigatório';
	}
	
	if (!$('#optParamConsulta option:selected').val()) {
		msgError += '\nIndicador de Consulta';
	}
	
	if(msgError) {
		alert('Campos Obrigatórios:\n' + msgError);
		return;
	}
	
	$.ajax( {
		dataType: "text",
		contentType : "application/json",
        type: "POST",
        url:  "novoparametro",
	    data : JSON.stringify($('#frmCadastro').serializeObject()),
        success:function(result){
        	window.location.reload(true);
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		alert(result);
    	}
	});
	
}

function removeImagem(){
	$('#codImagemModelo').val("");
	$('#descImagemModelo').val("");
}

function setImagemInstitucional(){
	$('#codImagemModelo').val(selectedImage[0]);
	$('#descImagemModelo').val(selectedImage[2]);
}

function setImagemTexto(){
	$('#codImagemTxt'+idTexto).val(selectedImage[0]);
	$('#descImagemTxt'+idTexto).val(selectedImage[2]);
}

function buscaImagemTexto(id){
	idTexto = id;
	buscaImagem(setImagemTexto);
}

function buscaImagem(callback){
	callbackImage = callback;
	$('#modalImagem').modal('show');
}

function selecionaImagem(){
	var row = tableImagem.row('.active').data();
	if (typeof row != 'undefined'){
		selectedImage = row;
		callbackImage();
		$('#modalImagem').modal('toggle');
	}
}

function loadPreview(){
	$('#framePreview').attr("src","preview?id=" + codModelo);
}

function loadPreviewHist(id, datHistorico){
	if (typeof datHistorico == 'undefined'){
		return;
	}
	
	$('#framePreview').attr("src","previewHist?id=" + id + "&datAlteracao=" + datHistorico);	
}

function loadPreviewModelo(id){
	$('#framePreview2').attr("src","preview?id=" + id);	
}

function aprovarModelo(){
	var msgError = "";
	
	if (!$('#inptStatus').val())  {
		msgError += 'Status do Modelo\n';
	}
	
	if ($('#inptStatus option:selected').val() == 'RECUSADO' && !$('#inputMotivo').val())  {
		msgError += 'Motivo da Reprovação\n';
	}
	
	if(msgError) {
		alert('Campos Obrigatórios:\n' + msgError);
		return;
	}
	
	$.ajax( {
		dataType: "text",
		contentType : "application/json",
        type: "POST",
        url:  "aprovarmodelo",
	    data : JSON.stringify($('#frmMarketing').serializeObject()),
        success:function(result){
        	window.location.reload(true);
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		alert(result);
    	}
	});
	
}

function enviarEmail(codigoModelo, emailResponsavel, emailCopia) {
	if(!validaEmail(emailResponsavel)) {
		alert('E-mail inválido');
		return;		
	}
	
	var json = {};
	json.codModeloDocumento = codigoModelo;
	json.destinatario = emailResponsavel;
	json.emailCopia = emailCopia;
	
	$.ajax( {
		dataType: "text",
		contentType : "application/json",
        type: "POST",
        url:  "gerar-json",
	    data : JSON.stringify(json),
        success:function(result) {
        	alert('Template enviado com sucesso');
    	},
    	error: function(error) { // jqXHR, textStatus, errorThrown) {
    		console.log(error);
    		if(error.status == 406) {
    			alert(error.responseText);
    			return;
    		}
    		alert('Erro ao enviar template: \n' + error.reponseText);
    	}
	});
}