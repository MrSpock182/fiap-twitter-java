function initBuscaAgendamento(){
    $('#tableResult').dataTable({
        "order": [
			    [0, "asc"]
			 ],
		"paging" : true,
		"searching" : true,
		"ordering" : true,
		"bInfo": true,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

	tableResultado = $('#tableResult').DataTable();

	$('#tableResult tbody').on( 'click', 'tr', function () {
	    var id = tableResultado.row( this ).data()[0];
	    window.location.href = "../agendamento?id=" + id;
	} );

	$("input").keyup(function(event){
	    if(event.keyCode == 13){
	        $("#btnPesquisa").click();
	    }
	});
}

function initAgendamento(){
    $('#tableEnvios').dataTable({
        "order": [
			    [0, "asc"]
			 ],
		"paging" : false,
		"searching" : false,
		"ordering" : true,
		"bInfo": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });
}

function initListaModelos(){
	$('#tableModelos').dataTable({
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

	table = $('#tableModelos').DataTable();

	$('#tableModelos tbody').on( 'click', 'tr', function () {
	    id = table.row( this ).data()[0];
	    window.location.href = "agendamento/consulta?id=" +  id;
	} );
}


function buscaAgendamentos(id){

	$('#idMessageCpfCnpf').empty();
	
	var cpfNum = new Mask().num($('#inputCpfCnpj').val());
	
	if(cpfNum) {
		$('#inputCpfCnpj').val(cpfNum);
		var cpf = CPF(cpfNum);
		if(!cpf.isValid()) {
			var msgValid = cpfNum.length <= 11 ? "CPF Inválido" : "CNPJ inválido";
			$('#idMessageCpfCnpf').html(msgValid);
			return;
		}
	}
	
	var formData = $('#formBusca').serializeObject();

	var parametros = [];

	$('.paramConsulta').each(function(index){
		parametros[index] = {"codParametro" : this.id, "valorParametro" : this.value};
	});

	formData["parametros"] = parametros;

	$.ajax( {
		dataType: "text",
		contentType : "application/json",
        type: "POST",
        url:  "?id=" + id,
	    data : JSON.stringify(formData),
        success:function(result){
        	window.location.replace('../agendamento/consulta?id='+id);
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		alert("Erro ao consultar agendamentos");
    	}
	});
}

function enviarPiloto(idAgendamento){
	$.ajax( {
		dataType: "text",
	       type: "POST",
	       url:  "enviarPiloto?idAgendamento=" + idAgendamento,
	       success:function(result){
	       	window.location.reload(true);
	   	},
	   	error: function(error) {
	   		alert(error.responseText);
	   	}
	});
}

function enviarDataPiloto(){
	if(!$('#idModelo').val()) {
   		alert("Código do modelo é obrigatório");
   		return;
	}
	
	if(!$('#inputDataPiloto').val()) {
   		alert("Data do Agendamento é obrigatório");
   		return;
	}
	
	$.ajax( {
		dataType: "text",
	       type: "POST",
	       url:  "enviarDataPiloto?codigo=" + $('#idModelo').val() + "&dataAgendamento=" + $('#inputDataPiloto').val(),
	       success:function(result){
	       window.location.reload(true);
	   	},
	   	error: function(error) {
	   	   alert(error.responseText);
	   	}
	});
}

function loadErros(id){
	$('#divModalErros').html("<i class='fa fa-spinner fa-spin'></i> Por favor aguarde...");

	$.ajax( {
        dataType: 'text',
        type: "GET",
        url:  "agendamento/erros",
	    data : {
	    	id : id
	    },
        success:function(result){
        	$('#divModalErros').html(result);
		    initTableErros();
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		$('#divModalErros').html("Erro ao buscar histórico de erros");
    	}
	});
}

function initTableErros(){
    $('#tableErros').dataTable({
        "order": [
			    [0, "asc"]
			 ],
		"paging" : false,
		"searching" : true,
		"ordering" : true,
		"bInfo": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });
}

function solicitaReenvio(id){
	$("#messageReenvioAlert").removeClass('hide');
	$("#messageReenvio").html('Tem certeza que deseja reenviar o e-mail?');
	$.ajax({
	    url : 'agendamento/reenvio?id='+id,
	    headers : {
	        'Accept' : 'application/json'
	    },
	    type: 'POST',
	    success : function(resp) {
	    	if (resp["codigoRetorno"] == 0){
	    		$('#modalReenvio').modal('toggle');
	    		window.location.replace('agendamento?id='+id);
	    	} else{
	    		$("#messageReenvio").html(resp["mensagemRetorno"]);
	    	}
	    },
	    error : function(jqXHR, textStatus, errorThrown){
	    	$("#messageReenvio").html('Não foi possível solicitar o reenvio do e-mail. Por favor, tente novamente mais tarde.');
	    }
	});
} 

function convertBase64(base64) {
    var binaryString = window.atob(base64);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    
    for (var i = 0; i < binaryLen; i++) {
       var ascii = binaryString.charCodeAt(i);
       bytes[i] = ascii;
    }
    
    return bytes;
}

function downloadFile(base64, nome) {
	var file = convertBase64(base64);
	var blob = new Blob([file]);
	var link = document.createElement('a');
	link.href = window.URL.createObjectURL(blob);
	link.download = nome;
	link.click();
}
