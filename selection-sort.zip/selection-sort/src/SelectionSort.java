public class SelectionSort {

    public static void main(String[] args) {
        int[] array = {4, 3, 5, 1, 2};

        for (int i = 0; i < array.length; i++) {

            for (int s = 0; s < array.length; s++) {

                if(array[i] < array[s]) {
                    int val = array[i];
                    array[i] = array[s];
                    array[s] = val;
                }

            }

        }

    }

}
