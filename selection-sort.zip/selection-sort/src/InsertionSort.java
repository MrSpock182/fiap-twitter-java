
public class InsertionSort {

    public static void main(String[] args) {
        int[] array = {5, 8, 3, 1, 4};

        for (int i = 0; i < array.length; i++) {

            for (int s = i + 1; s >= 0; s--) {
                if(array[i] >= array[s]) {
                    int val = array[i];
                    array[i] = array[s];
                    array[s] = val;
                }
            }

            System.out.println(array[i]);
        }

    }
}
