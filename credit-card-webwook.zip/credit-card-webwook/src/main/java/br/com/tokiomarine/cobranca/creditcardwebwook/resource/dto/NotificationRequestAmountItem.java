package br.com.tokiomarine.cobranca.creditcardwebwook.resource.dto;

public record NotificationRequestAmountItem(
        String currency,
        Integer value
) {
}