package br.com.tokiomarine.cobranca.creditcardwebwook.configuration;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class HmacFilter implements Filter {
    private static final String HMAC_HEADER = "X-HMAC-SIGNATURE";
    private static final String SECRET_KEY = "49229CD9CE33C49D0C8C8AD4FF27B1728DB5938CBFA59755D327578B44351B04";

    @Override
    public void doFilter(
            final ServletRequest servletRequest,
            final ServletResponse servletResponse,
            final FilterChain filterChain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        String hmacSignature = request.getHeader(HMAC_HEADER);
        if (hmacSignature == null || !isValidSignature(request, hmacSignature)) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        SecurityContextHolder.getContext().setAuthentication(
                new PreAuthenticatedAuthenticationToken("hmacUser", null, null));
        filterChain.doFilter(request, response);
    }

    private boolean isValidSignature(HttpServletRequest request, String hmacSignature) {
        try {
            String data = request.getMethod() + request.getRequestURI();
            Mac hmac = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKeySpec = new SecretKeySpec(
                    SECRET_KEY.getBytes(StandardCharsets.UTF_8),
                    "HmacSHA256");
            hmac.init(secretKeySpec);
            byte[] rawHmac = hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            String expectedSignature = Base64.getEncoder().encodeToString(rawHmac);
            return expectedSignature.equals(hmacSignature);
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }
}
