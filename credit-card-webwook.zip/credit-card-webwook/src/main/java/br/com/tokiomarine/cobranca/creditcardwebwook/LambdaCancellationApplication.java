package br.com.tokiomarine.cobranca.creditcardwebwook;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"br.com.tokiomarine.cobranca.creditcardwebwook"})
public class LambdaCancellationApplication {
    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(LambdaCancellationApplication.class);
        application.setBannerMode(Banner.Mode.OFF);
        application.setLazyInitialization(true);
        application.run(args);
    }
}