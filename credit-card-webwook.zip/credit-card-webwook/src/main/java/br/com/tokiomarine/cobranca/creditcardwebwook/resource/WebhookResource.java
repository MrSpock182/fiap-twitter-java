package br.com.tokiomarine.cobranca.creditcardwebwook.resource;

import br.com.tokiomarine.cobranca.creditcardwebwook.messaging.AdyenCancellationProducer;
import br.com.tokiomarine.cobranca.creditcardwebwook.resource.dto.AdyenRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/webhook")
public class WebhookResource {
    private final AdyenCancellationProducer messageProducer;

    public WebhookResource(AdyenCancellationProducer messageProducer) {
        this.messageProducer = messageProducer;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public String adyen(@RequestBody final AdyenRequest request) {
        return "Hello";
//        messageProducer.sendMessage(request);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public String get() {
        return "Hello";
//        messageProducer.sendMessage(request);
    }
}