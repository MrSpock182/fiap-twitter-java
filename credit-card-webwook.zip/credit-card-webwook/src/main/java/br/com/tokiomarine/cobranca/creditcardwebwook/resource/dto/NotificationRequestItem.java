package br.com.tokiomarine.cobranca.creditcardwebwook.resource.dto;

public record NotificationRequestItem(
        String eventCode,
        String success,
        String eventDate,
        String merchantAccountCode,
        String pspReference,
        String merchantReference,
        NotificationRequestAmountItem amount
) {
}