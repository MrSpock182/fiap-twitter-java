package br.com.tokiomarine.cobranca.creditcardwebwook.resource.dto;

import java.util.List;

public record AdyenRequest(
        Boolean live,
        List<NotificationItem> notificationItems
) {
}