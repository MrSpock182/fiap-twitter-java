package br.com.tokiomarine.cobranca.creditcardwebwook.messaging;

import br.com.tokiomarine.cobranca.creditcardwebwook.resource.dto.AdyenRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

@Component
public class AdyenCancellationProducer {
    private final String queue;
    private final SqsClient sqsClient;
    private final ObjectMapper objectMapper;

    public AdyenCancellationProducer(
            @Value("${spring.cloud.aws.queue.my-queue}") String queue,
            SqsClient sqsClient,
            ObjectMapper objectMapper) {
        this.queue = queue;
        this.sqsClient = sqsClient;
        this.objectMapper = objectMapper;
    }

    public void sendMessage(final AdyenRequest request) {
        try {
            sqsClient.sendMessage(SendMessageRequest.builder()
                    .queueUrl(queue)
                    .messageBody(objectMapper.writeValueAsString(request))
                    .build());
        } catch (JsonProcessingException ex) {
            throw new RuntimeException(ex);
        }
    }
}