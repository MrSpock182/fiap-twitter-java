package br.com.tokiomarine.gntagendamento;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.domain.repository.AgendamentoEnvioRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("standalone")
public class GntAgendamentoApplicationTests {

	@Autowired
	private AgendamentoEnvioRepository repository;

	@Test
	public void contextLoads() {

		AgendamentoEnvio agendamentoEnvio = repository.findByAgendamentoSeqAgendamentoAndStatusEnvio(2368470L, "PND");

		agendamentoEnvio.getAgendamento();

	}

}

