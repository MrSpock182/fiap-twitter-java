package br.com.tokiomarine.gntagendamento.agendamento_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.service.agendamento_comunicacao.AgendamentoComunicacaoService;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("standalone")
public class AgendamentoComunicacaoTest {

    @Autowired
    private AgendamentoComunicacaoService service;

    public void incluirAgendamento() {
        try {
            service.incluirAgendamento("S", request());
            assertTrue(true);
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    private AgendamentoRequest request() {
        AgendamentoRequest.builder()
                .codigo("")
                .tipoEnvio("")
                .codCorretor("")
                .rastreiaEnvio("")
                .emailRemetente("")
                .indEnviaComunicacao("")
                .anexos(null)
                .comCopias(null)
                .destinatarios(null)
                .listDoc(null)
                .parametros(null)
                .documentos(null)
                .destinatariosDetalhes(null)
                .build();
        return null;
    }

}
