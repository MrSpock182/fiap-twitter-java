package br.com.tokiomarine.gntagendamento.validation;

import br.com.tokiomarine.gntagendamento.service.validation.ValidationBuilder;
import br.com.tokiomarine.gntagendamento.service.validation.ValidationImpl;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("standalone")
public class ValidationSmsTest {

    @Autowired
    private ValidationBuilder builder;

    public void validate() {
        ValidationImpl validation = builder.getValidation("SMS");

    }

}
