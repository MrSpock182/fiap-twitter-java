package br.com.tokiomarine.gntagendamento.jms.consumer;

import javax.jms.Message;
import javax.jms.Session;
import br.com.tokiomarine.gntagendamento.service.envio_mensagem.EnvioMensagemService;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.command.ActiveMQObjectMessage;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.listener.SessionAwareMessageListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class FilaConsumer implements SessionAwareMessageListener<Message> {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private StackLogger stackLogger;

    @Autowired
    private EnvioMensagemService envioService;

    @Override
    public void onMessage(@NotNull Message message, @NotNull Session session) {
        Long seqEnvio = 0L;
        try {
            seqEnvio = (Long)((ActiveMQObjectMessage) message).getObject();
            envioService.enviarAgendamento(seqEnvio);
        } catch (Exception ex) {
            log.error( "Erro producer: " + stackLogger.getMessage(ex));
            throw new InternalError("Erro consumer: " + seqEnvio);
        }
    }

}
