package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.ImagemComunicacao;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ImagemComunicacaoRepository extends PagingAndSortingRepository<ImagemComunicacao, Long>,
        JpaSpecificationExecutor<ImagemComunicacao> {
}
