package br.com.tokiomarine.gntagendamento.service.param_acsel;

import br.com.tokiomarine.gntagendamento.domain.orm.ParamAcsel;
import br.com.tokiomarine.gntagendamento.domain.repository.ParamAcselRepository;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ParamAcselServiceImpl implements ParamAcselService {

    @Autowired
    private ParamAcselRepository paramAcselRepository;

    @Override
    public ParamAcsel findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(@NotNull String codGrpParametro,@NotNull String codParametro) {
        ParamAcsel paramAcsel = paramAcselRepository
                .findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(codGrpParametro, codParametro);

        if (paramAcsel == null) {
            throw new InternalServerError("Parametro acsel não encontrado");
        }

        return paramAcsel;
    }
}
