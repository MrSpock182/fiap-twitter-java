package br.com.tokiomarine.gntagendamento.service.body_mail;

import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.service.imagem_comunicacao.ImagemComunicacaoService;
import br.com.tokiomarine.gntagendamento.service.param_acsel.ParamAcselService;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

@Slf4j
@Service
public class BodyMailServiceImpl implements BodyMailService {

    private static final String COD_CORRETOR = "COD_CORRETOR";

    private Document emailHtml;
    private String codCorretor;
    private DocumentBuilder documentBuilder;
    private ModeloComunicacao modeloComunicacao;
    private List<ImagemComunicacao> imagens;
    private HashMap<String, String> parametros = new HashMap<>();
    private HashMap<String, String> documentos = new HashMap<>();
    private DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
    private List<AgendamentoListDocumentos> listaDocumentos = new ArrayList<>();

    @Autowired
    private StackLogger stackLogger;

    @Autowired
    private ParamAcselService paramAcselService;

    @Autowired
    private ImagemComunicacaoService imagemComunicacaoService;

    @Override
    public String getBody(AgendamentoEnvio agendamentoEnvio) {
        try {
            documentBuilder = builderFactory.newDocumentBuilder();
            AgendamentoComunicacao agendamentoComunicacao = agendamentoEnvio.getAgendamento();
            modeloComunicacao = agendamentoComunicacao.getModelo();

            for (ParametroModelo param : modeloComunicacao.getParametros()) {
                if (COD_CORRETOR.equals(param.getParametro().getNomeParametro())) {
                    codCorretor = agendamentoEnvio.getAgendamento().getValorParametro(param.getParametro().getNomeParametro());
                } else {
                    parametros.put(param.getParametro().getNomeParametro(), agendamentoEnvio.getAgendamento()
                            .getValorParametro(param.getParametro().getNomeParametro()));
                }
            }

            emailHtml = documentBuilder.parse(new InputSource(new StringReader(modeloComunicacao.getPadrao().getFormatacaoPadrao())));

            for (AgendamentoDocumento doc : agendamentoComunicacao.getDocumentos()) {
                if ("S".equalsIgnoreCase(doc.getIndEnviaEmail())) {
                    documentos.put(doc.getDocumento().getDescDocumento(), doc.getUrlArquivo());
                }
            }

            if (agendamentoComunicacao.getListDoc() != null && !agendamentoComunicacao.getListDoc().isEmpty()) {
                Collections.sort(agendamentoComunicacao.getListDoc());
                listaDocumentos = agendamentoComunicacao.getListDoc();
            } else {
                listaDocumentos = new ArrayList<>();
            }

            imagens = imagemComunicacaoService.findAll();
            return gerarHtml();
        } catch (Exception ex) {
            log.error("Erro conversão EMAIL html: " + stackLogger.getMessage(ex), ex);
            throw new InternalServerError("Erro na conversão do EMAIL html");
        }
    }

    private String gerarHtml() {
        try {
            processarModelo();
            Transformer trans = defineTransformer();
            StringWriter sw = new StringWriter();
            StreamResult result = new StreamResult(sw);
            DOMSource source = new DOMSource(emailHtml);
            trans.transform(source, result);
            return new String(sw.toString().getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        } catch (Exception ex) {
            log.error("Erro ao gerar html BodyMail: " + stackLogger.getMessage(ex), ex);
            throw new InternalServerError("Erro ao gerar html BodyMail: " + ex.getMessage(), ex);
        }
    }

    private Transformer defineTransformer() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = factory.newTransformer();
            DOMImplementation domImpl = emailHtml.getImplementation();
            DocumentType doctype = domImpl.createDocumentType("html",
                    "-//W3C//DTD XHTML 1.0 Transitional//EN",
                    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
            transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, doctype.getPublicId());
            transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype.getSystemId());
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            return transformer;
        } catch (Exception ex) {
            throw new InternalServerError("Erro define transformer: " + ex.getMessage());
        }
    }

    private void processarModelo() {
        ProcessaModelo processaModelo = ProcessaModelo.builder()
                .emailHtml(emailHtml)
                .documentBuilder(documentBuilder)
                .modeloComunicacao(modeloComunicacao)
                .processaTexto(getProcessaTexto())
                .processaImagem(getProcessaImagem())
                .processaVariaveis(getProcessaVariaveis())
                .processaDocumentos(getProcessaDocumentos())
                .processaListaDocumentos(getProcessaListaDocumentos())
                .build();

        processaModelo.processar();
    }

    private ProcessaTexto getProcessaTexto() {
        return ProcessaTexto.builder()
                .emailHtml(emailHtml)
                .codCorretor(codCorretor)
                .documentBuilder(documentBuilder)
                .parametros(parametros)
                .modeloComunicacao(modeloComunicacao)
                .paramAcselService(paramAcselService)
                .build();
    }

    private ProcessaImagem getProcessaImagem() {
        return ProcessaImagem.builder()
                .imagens(imagens)
                .build();
    }

    private ProcessaDocumentos getProcessaDocumentos() {
        return ProcessaDocumentos.builder()
                .documentos(documentos)
                .build();
    }

    private ProcessaListaDocumentos getProcessaListaDocumentos() {
        return ProcessaListaDocumentos.builder()
                .listaDocumentos(listaDocumentos)
                .build();
    }

    private ProcessaVariaveis getProcessaVariaveis() {
        return ProcessaVariaveis.builder()
                .modeloComunicacao(modeloComunicacao)
                .parametros(parametros)
                .build();
    }

}
