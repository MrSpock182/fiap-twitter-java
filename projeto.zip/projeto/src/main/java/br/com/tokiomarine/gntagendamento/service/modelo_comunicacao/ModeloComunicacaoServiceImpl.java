package br.com.tokiomarine.gntagendamento.service.modelo_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.orm.ModeloComunicacao;
import br.com.tokiomarine.gntagendamento.domain.repository.ModeloComunicacaoRepository;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ModeloComunicacaoServiceImpl implements ModeloComunicacaoService {

    @Autowired
    private ModeloComunicacaoRepository modeloComunicacaoRepository;

    @Override
    public ModeloComunicacao findByCodigo(@NotNull String modelo) {
        ModeloComunicacao modeloComunicacao = modeloComunicacaoRepository.findByCodigo(modelo);

        if(modeloComunicacao == null) {
            throw new InternalServerError("Nenhum modelo de comunicação localizado");
        }

        return modeloComunicacao;
    }

    @Override
    public ModeloComunicacao findById(@NotNull Long codigoModelo) {
        Optional<ModeloComunicacao> optional = modeloComunicacaoRepository.findById(codigoModelo);

        if(!optional.isPresent()) {
            throw new InternalServerError("Nenhum modelo de comunicação localizado");
        }

        return optional.get();
    }
}
