package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "MODELO_COMUNICACAO")
@SequenceGenerator(name = "SEQ_MODELO_COMUNICACAO", sequenceName = "SEQ_MODELO_COMUNICACAO", initialValue = 1, allocationSize = 1)
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ModeloComunicacao implements Serializable {

    @Id
    @Column(name = "CD_MODELO_COMUNICACAO")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MODELO_COMUNICACAO")
    private Long codModelo;

    @Column(name = "CD_MODELO_CODIGO")
    private String codigo;

    @Column(name = "NM_MODELO_COMUNICACAO")
    private String nomeModelo;

    @Column(name = "DS_MODELO_COMUNICACAO")
    private String descricaoModelo;

    @Column(name = "CD_TIPO_MODELO")
    private String tipoModelo;

    @Column(name = "DS_TITULO_MODELO")
    private String tituloModelo;

    @Column(name = "DS_REMETENTE")
    private String emailRemetente;

    @Column(name = "DS_CAIXA_DEPTO")
    private String emailCaixaDept;

    @Column(name = "NM_SISTEMA_ORIGEM")
    private String nomeSistemaOrigem;

    @Column(name = "CD_IMAGEM", insertable = false, updatable = false)
    private Long codImagem;

    @Column(name = "ID_SITUACAO")
    private String situacaoModelo;

    @Column(name = "DT_INCLUSAO")
    private Date dtInclusao;

    @Column(name = "NM_USUARIO_INCLUSAO")
    private String nomeUsuarioInclusao;

    @Column(name = "DT_ATUALIZACAO")
    private Date dtAtualizacao;

    @Column(name = "NM_USUARIO_ATUALIZACAO")
    private String nomeUsuarioAtualizacao;

    @Column(name = "DS_DEST_MODELO_COMUNICACAO")
    private String destinoMensagem;

    @Column(name = "DS_PROC_MODELO_COMUNICACAO")
    private String processo;

    @Column(name = "CD_STATUS")
    private String status;

    @Column(name = "EMAIL_COPIA")
    private String emailCopia;

    @Column(name = "TP_MOVIM")
    private String tipoMovimento;

    @Column(name = "INICIO_VIGENCIA")
    private Date dtInicioVigencia;

    @Column(name = "FINAL_VIGENCIA")
    private Date dtFinalVigencia;

    @Column(name = "DS_MOTIVO")
    private String motivo;

    @Column(name = "PILOTO")
    private String piloto;

    @Column(name = "EMAIL_RESPONSAVEL")
    private String emailResponsavel;

    @Column(name = "CD_PADRAO_COMUNICACAO", insertable = false, updatable = false)
    private Long codPadrao;

    @Column(name = "CD_RATREIA_ENVIO")
    private String rastreiaEnvio;

    @Column(name="MODELO_FACEBOOK")
    private String modeloFacebook;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CD_IMAGEM", referencedColumnName = "CD_IMAGEM")
    private ImagemComunicacao imagem;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CD_PADRAO_COMUNICACAO", referencedColumnName = "CD_PADRAO_COMUNICACAO")
    private PadraoComunicacao padrao;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "modelo", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("numeroSeq")
    private List<TextoModeloComunicacao> textos;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "modelo", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("cdSequencia")
    private List<ParametroModelo> parametros;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "modelo", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("codTextoHist")
    private List<ModeloComunicacaoTextoHist> modeloTextoHist;

}