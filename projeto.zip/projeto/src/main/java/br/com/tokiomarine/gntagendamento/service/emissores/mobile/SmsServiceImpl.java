package br.com.tokiomarine.gntagendamento.service.emissores.mobile;

import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.domain.repository.ParamAcselRepository;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.service.emissores.EmissorService;
import br.com.tokiomarine.gntagendamento.util.Const;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.URL;
import java.util.Map;

@Slf4j
@Service
public class SmsServiceImpl extends MobileServiceImpl implements EmissorService {

    private static final String CODGRPPARAMETRO = "PUSH_NOTIFICATION";
    private static final String MENSAGEM = "mensagem";

    @Autowired
    private StackLogger stackLogger;

    @Autowired
    private ParamAcselRepository param;

    @Override
    public void enviarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        try {
            ParamAcsel url = param.findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(CODGRPPARAMETRO, "URL_SMS_ENVIO");
            ParamAcsel chave = param.findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(CODGRPPARAMETRO, "SMS_API_KEY");
            ParamAcsel chaveAtivaResposta = param.findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(CODGRPPARAMETRO, "SMS_API_KEY_RESPOSTA");
            Map<String, String> mensagens = agendamentoEnvio.getAgendamento().getMensagens();

            for (AgendamentoDestinatario cel : agendamentoEnvio.getAgendamento().getDestinatarios()) {
                URL request = new URL(url.getVlrParametro());
                RestTemplate restTemplate = new RestTemplate();
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.MULTIPART_FORM_DATA);
                headers.setAccept(Lists.newArrayList(MediaType.TEXT_PLAIN));

                MultiValueMap<String, Object> forms = new LinkedMultiValueMap<>();

                if (Const.ATIVA_RESPOSTA_SMS.equals(agendamentoEnvio.getAgendamento().getAtivaRespostaSms())) {
                    forms.add("apikey", chaveAtivaResposta.getVlrParametro());
                } else {
                    forms.add("apikey", chave.getVlrParametro());
                }

                forms.add("ntc", "55" + cel.getDestinatario());
                forms.add(MENSAGEM, mensagens.get(MENSAGEM));
                forms.add("id", "SQ_AGENDAMENTO=" + agendamentoEnvio.getAgendamento()
                        .getSeqAgendamento().toString());

                HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(forms, headers);
                ResponseEntity<String> response = restTemplate.postForEntity(request.toURI(), entity, String.class);

                if(response.getStatusCode().equals(HttpStatus.OK) && response.getBody() != null) {
                    String body = response.getBody();

                    if (response.getBody().length() > 20) {
                        body = response.getBody().substring(0, 20);
                    }

                    agendamentoEnvio.setCodRetornoEnvio(body);
                } else {
                    log.error("Erro ao acessar serviço de envio de SMS: " + response.getBody());
                    throw new InternalServerError("Erro ao acessar serviço de envio de SMS: " + response.getBody());
                }
            }

        } catch (Exception ex) {
            log.error("Erro enviar SMS: " + stackLogger.getMessage(ex));
            throw new InternalServerError("Erro ao enviar SMS: " + ex.getMessage(), ex);
        }
    }

    @Override
    public void gerarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        this.mensagem(agendamentoEnvio);
    }

}
