package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "PADRAO_COMUNICACAO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class PadraoComunicacao implements Serializable {

    @Id
    @Column(name="CD_PADRAO_COMUNICACAO")
    private Long codPadrao;

    @Column(name="DS_PADRAO")
    private String descPadrao;

    @Column(name="DS_FORMATACAO_PADRAO")
    private String formatacaoPadrao;

    @Column(name="DT_ATUALIZACAO")
    private Date dtAtualizacao;

    @Column(name="NM_USUARIO_ATUALIZACAO")
    private String nomeUsuarioAtualizacao;

}
