package br.com.tokiomarine.gntagendamento.service.imagem_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.orm.ImagemComunicacao;
import br.com.tokiomarine.gntagendamento.domain.repository.ImagemComunicacaoRepository;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ImagemComunicacaoServiceImpl implements ImagemComunicacaoService {

    @Autowired
    private ImagemComunicacaoRepository imagemComunicacaoRepository;

    @Override
    public List<ImagemComunicacao> findAll() {
        return Lists.newArrayList(imagemComunicacaoRepository.findAll());
    }
}
