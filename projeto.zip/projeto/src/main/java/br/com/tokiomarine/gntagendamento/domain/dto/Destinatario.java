package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;
import org.jetbrains.annotations.NotNull;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Destinatario {
    @NotNull(value = "Destinatario obrigatório")
    private String destino;
    private String cpfCnpj;
}
