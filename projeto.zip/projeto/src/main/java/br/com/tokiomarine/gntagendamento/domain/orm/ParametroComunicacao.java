package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "PARAMETROS_COMUNICACAO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ParametroComunicacao implements Serializable {

    @Id
    @Column(name="CD_PARAMETRO")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="paramComunicacaoGenerator")
    @SequenceGenerator(name = "paramComunicacaoGenerator", sequenceName = "SQ_PARAMETROS_COMUNICACAO", allocationSize=1)
    private Long codParametro;

    @Column(name="NM_PARAMETRO")
    private String nomeParametro;

    @Column(name="DS_PARAMETRO")
    private String descParametro;

    @Column(name="ID_CONSULTA")
    private String indConsulta;

    @Column(name="DT_INCLUSAO")
    private Date dtInclusao;

    @Column(name="NM_USUARIO_INCLUSAO")
    private String nomeUsuarioInclusao;

    @Column(name="DT_ATUALIZACAO")
    private Date dtAtualizacao;

    @Column(name="NM_USUARIO_ATUALIZACAO")
    private String nomeUsuarioAtualizacao;

}
