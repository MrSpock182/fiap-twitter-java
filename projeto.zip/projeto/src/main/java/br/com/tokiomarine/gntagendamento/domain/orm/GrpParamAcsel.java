package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "TAB_GRP_PARAM_ACSEL")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class GrpParamAcsel implements Serializable {
    @Id
    @Column(name="ID_GRP_PARAMETRO")
    private Integer idGrpParametro;

    @Column(name="COD_GRP_PARAMETRO")
    private String codGrpParametro;

    @Column(name="DESC_GRP_PARAMETRO")
    private String descGrpParametro;
}
