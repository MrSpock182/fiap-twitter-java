package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@IdClass(AgendamentoDocumentoPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_DOC")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoDocumento implements Serializable {

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
    private AgendamentoComunicacao agendamento;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_DOCUMENTO", referencedColumnName="CD_DOCUMENTO")
    private DocumentoComunicacao documento;

    @Column(name="DS_URL_ARQUIVO")
    private String urlArquivo;

    @Column(name="ID_ENVIA_EMAIL")
    private String indEnviaEmail;

    @Column(name="DT_ATUALIZACAO")
    private Date dtAtualizacao;

}
