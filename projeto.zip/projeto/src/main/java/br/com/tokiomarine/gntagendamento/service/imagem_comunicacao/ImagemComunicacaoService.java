package br.com.tokiomarine.gntagendamento.service.imagem_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.orm.ImagemComunicacao;

import java.util.List;

public interface ImagemComunicacaoService {
    List<ImagemComunicacao> findAll();
}
