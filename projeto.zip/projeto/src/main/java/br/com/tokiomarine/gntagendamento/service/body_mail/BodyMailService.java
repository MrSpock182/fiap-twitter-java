package br.com.tokiomarine.gntagendamento.service.body_mail;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;

public interface BodyMailService {
    String getBody(AgendamentoEnvio agendamentoEnvio);
}
