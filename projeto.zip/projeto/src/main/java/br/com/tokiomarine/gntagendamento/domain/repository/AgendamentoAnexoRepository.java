package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoAnexo;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface AgendamentoAnexoRepository extends PagingAndSortingRepository<AgendamentoAnexo, Long>,
        JpaSpecificationExecutor<AgendamentoAnexo> {
}
