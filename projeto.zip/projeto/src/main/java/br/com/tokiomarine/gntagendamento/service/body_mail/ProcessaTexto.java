package br.com.tokiomarine.gntagendamento.service.body_mail;

import br.com.tokiomarine.gntagendamento.domain.dto.InfoDTO;
import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.service.param_acsel.ParamAcselService;
import br.com.tokiomarine.gntagendamento.util.BodyMailUtil;
import br.com.tokiomarine.gntagendamento.util.DateFormatter;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import java.util.*;

@Builder
@AllArgsConstructor
public class ProcessaTexto {

    private Document emailHtml;
    private String codCorretor;
    private DocumentBuilder documentBuilder;
    private HashMap<String, String> parametros;
    private ModeloComunicacao modeloComunicacao;
    private ParamAcselService paramAcselService;

    public void processar(Element tag, String texto) {
        try {
            NodeList tagsVar = (tag).getElementsByTagName("*");

            if (tagsVar.getLength() == 0) {
                incluirTexto(tag, texto);
            } else {
                for (int j = 0; j < tagsVar.getLength(); j++) {
                    Element tagVar = (Element) tagsVar.item(j);

                    if (tagVar.getAttribute("class").contains("texto")) {
                        incluirTexto(tagVar, texto);
                    }
                }
            }
        } catch (Exception ex) {
            throw new InternalServerError("Erro no processamento de textos: " + ex.getMessage());
        }
    }

    private void incluirTexto(Node tag, String texto) {
        String[] tokens = texto.split("\n");

        for (int i = 0; i < tokens.length; i++) {
            String token = tokens[i];
            String fragment = "<span>" + token + "</span>";
            String[] vars = StringUtils.substringsBetween(token, "[", "]");

            if (vars != null) {
                verificaAtendimento(vars, fragment);
            }

            Node fragmentNode = BodyMailUtil
                    .createNode(documentBuilder, emailHtml, StringUtil.escapeXml(fragment));
            tag.appendChild(fragmentNode);

            if ((i + 1) < tokens.length) {
                tag.appendChild(emailHtml.createElement("br"));
            }
        }
    }

    private void verificaAtendimento(String[] vars, String fragment) {
        for (String var : vars) {
            ParametroModelo param;
            String valor = null;

            if ("CENTRAL_ATENDIMENTO".equalsIgnoreCase(var)) {
                valor = getCentralAtendimento();
                fragment = fragment.replace("[" + var + "]", valor);
            } else {
                param = obtemParametro(var);

                if (this.parametros.containsKey(var)) {
                    valor = getTelefoneCorretor(var);
                    fragment = getFragment(var, valor, fragment, param);
                }
            }
        }
    }

    private ParametroModelo obtemParametro(String nomeParam) {
        for (ParametroModelo param : modeloComunicacao.getParametros()) {
            if (param.getParametro().getNomeParametro().equals(nomeParam)) {
                return param;
            }
        }
        return null;
    }

    private String getTelefoneCorretor(String var) {
        if ("TEL_CORRETOR".equalsIgnoreCase(var)) {
            List<InfoDTO> telefonesEspeciais = getContatosEspeciais(this.codCorretor, 2, new Date());
            if (!telefonesEspeciais.isEmpty()) {
                return getContatosEspeciais(telefonesEspeciais);
            }
        }

        if(this.parametros.get(var) == null) {
            throw new InternalServerError("Parâmetro " + var + " não informado");
        }

        return this.parametros.get(var);
    }

    private String getFragment(String var, String valor, String fragment, ParametroModelo param) {
        try {
            int total = 0;
            for (int x = 0; x < valor.length(); x++) {
                if (valor.charAt(x) == ' ') {
                    total++;
                    break;
                }
            }

            if (valor.length() > 120 && total == 0) {
                String textoVelho = valor;
                int numeroDeCaracteresPorLinha = 110;
                int tamanhoDoTextoQueVouQuebrar = textoVelho.length();
                StringBuilder textoNovo = new StringBuilder();
                for (int y = 1; y <= tamanhoDoTextoQueVouQuebrar; y++) {
                    textoNovo.append(textoVelho.charAt(y - 1));
                    if (y % numeroDeCaracteresPorLinha == 0 && y < tamanhoDoTextoQueVouQuebrar) {
                        textoNovo.append("\n");
                    }
                }
                valor = textoNovo.toString();
            }

            if (param.getFormatacao() != null && !param.getFormatacao().isEmpty()) {
                return fragment.replace("[" + var + "]", param.getFormatacao().replace("[PARAM]", valor));
            } else {
                return fragment.replace("[" + var + "]", valor);
            }
        } catch (Exception ex) {
            throw new InternalServerError("Erro ao criar fragment: " + ex.getMessage());
        }
    }

    private String getCentralAtendimento() {
        List<InfoDTO> centraisEspeciais = getContatosEspeciais(this.codCorretor, 1, new Date());

        if (!centraisEspeciais.isEmpty()) {
            return getContatosEspeciais(centraisEspeciais);
        } else {
            return "0300 33 TOKIO(86546)";
        }
    }

    private String getContatosEspeciais(List<InfoDTO> contatosEspeciais) {
        int aux = 0;
        StringBuilder sb = new StringBuilder();

        for (InfoDTO centralDeAtendimento : contatosEspeciais) {
            if (++aux > 1) {
                sb.append(" / ");
            }
            sb.append(centralDeAtendimento.getConteudoInfo());
        }
        return sb.toString();
    }

    private List<InfoDTO> getContatosEspeciais(@NotNull String codCorretor, @NotNull int codContato, @NotNull Date date) {
        ParamAcsel paramAcsel = paramAcselService
                .findDistinctByGrpParamAcselCodGrpParametroAndCodParametro("APOL_DIGITAL", "URL_CORR_ESP_REST");

        String corretoresEspeciaisRestUrl = new StringBuilder().append(paramAcsel.getVlrParametro())
                .append("/corretores/")
                .append(codCorretor)
                .append("/contatos/")
                .append(codContato)
                .append("/data/")
                .append(DateFormatter.getSimpleDate(date))
                .toString();

        RestTemplate restTemplate = new RestTemplate();
        return Arrays.asList(restTemplate.getForObject(corretoresEspeciaisRestUrl, InfoDTO[].class));
    }

}
