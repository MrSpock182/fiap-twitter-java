package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ComCopia {
    private String destino;
    private String cpfCnpj;
    private String copiaOculta;
}
