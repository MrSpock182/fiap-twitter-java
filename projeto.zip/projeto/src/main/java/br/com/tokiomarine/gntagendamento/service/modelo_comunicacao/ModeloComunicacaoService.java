package br.com.tokiomarine.gntagendamento.service.modelo_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.orm.ModeloComunicacao;
import org.jetbrains.annotations.NotNull;

public interface ModeloComunicacaoService {
    ModeloComunicacao findByCodigo(@NotNull String modelo);
    ModeloComunicacao findById(@NotNull Long codigoModelo);
}
