package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.ParamAcsel;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParamAcselRepository extends PagingAndSortingRepository<ParamAcsel, Integer>,
        JpaSpecificationExecutor<ParamAcsel> {

    ParamAcsel findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(String codGrpParametro, String codParametro);

}
