package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode
public class AgendamentoDestinatarioPK implements Serializable {

    private static final long serialVersionUID = 1361670530027017627L;

    private Integer seqDestinatario;
    private AgendamentoComunicacao agendamento;
}
