package br.com.tokiomarine.gntagendamento.service.body_mail;

import br.com.tokiomarine.gntagendamento.domain.orm.ImagemComunicacao;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.List;

@Builder
@AllArgsConstructor
public class ProcessaImagem {
    private List<ImagemComunicacao> imagens;

    public void processar(@NotNull Element tag, @NotNull Long id) {
        try {
            NodeList tagsVar = (tag).getElementsByTagName("*");

            if (tagsVar.getLength() == 0) {
                setImagem(tag, id);
            } else {
                for (int j = 0; j < tagsVar.getLength(); j++) {
                    Element tagVar = (Element) tagsVar.item(j);
                    if (tagVar.getNodeName().equals("img")) {
                        setImagem(tag, id);
                    }
                }
            }
        } catch (Exception ex) {
            throw new InternalServerError("Erro no processamento de imangem: " + ex.getMessage());
        }
    }

    private void setImagem(@NotNull Element tag, @NotNull Long id) {
        ImagemComunicacao img = buscaImagem(id);

        tag.setAttribute("src", img.getUrl());
        tag.setAttribute("alt", img.getDescImagem());
        tag.setAttribute("width", img.getLargura().toString());
        tag.setAttribute("height", img.getAltura().toString());
    }

    private ImagemComunicacao buscaImagem(@NotNull Long id) {
        for (ImagemComunicacao imagem : this.imagens) {
            if (imagem.getCodImagem().equals(id)) {
                return imagem;
            }
        }

        throw new InternalServerError("Nenhuma imagem comunicação encontrada");
    }
}
