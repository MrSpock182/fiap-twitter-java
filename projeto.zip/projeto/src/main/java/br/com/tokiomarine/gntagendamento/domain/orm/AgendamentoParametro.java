package br.com.tokiomarine.gntagendamento.domain.orm;

import io.micrometer.core.instrument.util.StringUtils;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(AgendamentoParametroPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_PARAM")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoParametro implements Serializable {
    private static final int TAMANHO_PADRAO_PARAMETRO = 4000;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
    private AgendamentoComunicacao agendamento;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_PARAMETRO", referencedColumnName="CD_PARAMETRO")
    private ParametroComunicacao parametro;

    @Column(name="DS_VALOR_PARAMETRO")
    private String dsValorParametro;

    @Column(name="DS_VALOR_PARAMETRO_EXTENSO")
    private String dsValorParametroExtenso;

    // GNT-99 - Necessidade do parametro [MENSAGEM_GENERICA] com mais de 4.000 caracteres
    public String getValorParametro() {
        if (Boolean.TRUE.equals(StringUtils.isNotEmpty(dsValorParametroExtenso))) {
            return this.dsValorParametroExtenso;
        } else {
            return this.dsValorParametro;
        }
    }

    // GNT-99 - Necessidade do parametro [MENSAGEM_GENERICA] com mais de 4.000 caracteres
    public void setValorParametro(String valorParametro) {
        if (Boolean.TRUE.equals(StringUtils.isNotEmpty(valorParametro) && valorParametro.length() > TAMANHO_PADRAO_PARAMETRO)) {
            this.dsValorParametroExtenso = valorParametro;
        } else {
            this.dsValorParametro = valorParametro;
        }
    }

}
