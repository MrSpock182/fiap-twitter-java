package br.com.tokiomarine.gntagendamento.service.emissores.comunicador;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.enumerable.TipoModelo;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.service.emissores.EmissorService;
import br.com.tokiomarine.gntagendamento.service.emissores.email.EmailServiceImpl;
import br.com.tokiomarine.gntagendamento.service.emissores.mobile.PushServiceImpl;
import br.com.tokiomarine.gntagendamento.service.emissores.mobile.SmsServiceImpl;
import br.com.tokiomarine.gntagendamento.service.emissores.mobile.WhatsappServiceImpl;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ComunicadorService {

    @Autowired
    private SmsServiceImpl smsService;

    @Autowired
    private EmailServiceImpl emailService;

    @Autowired
    private PushServiceImpl pushService;

    @Autowired
    private WhatsappServiceImpl whatsappService;

    public void enviar(@NotNull AgendamentoEnvio env) {
        EmissorService emissorService;
        TipoModelo tipo = TipoModelo.get(env.getAgendamento().getModelo().getTipoModelo());
        boolean reenvio = (env.getQuantidadeEnvio() > 0);

        switch (tipo) {
            case SMS:
                emissorService = smsService;
                break;
            case EMAIL:
                emissorService = emailService;
                break;
            case PUSH:
                emissorService = pushService;
                break;
            case WHATSAPP:
                emissorService = whatsappService;
                break;
            default:
                throw new InternalServerError("Metodo de envio não cadastrado");
        }

        if (!reenvio) {
            emissorService.gerarMensagem(env);
        }

        emissorService.enviarMensagem(env);
    }

}
