package br.com.tokiomarine.gntagendamento.service.validation;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;

interface Validation {
    void validate(AgendamentoComunicacao agendamento, AgendamentoRequest agendamentoRequest);
}
