package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;
import org.jetbrains.annotations.NotNull;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoRequest {
    private String codigo;
    private Long codigoModelo;
    private String tipoEnvio;
    private String codCorretor;
    private String rastreiaEnvio;
    private String emailRemetente;
    private String indEnviaComunicacao;
    private List<AnexoEmail> anexos;
    private List<ComCopia> comCopias;
    private List<String> destinatarios;
    private List<ListDocComunicacao> listDoc;
    @NotEmpty(message = "Parametros obrigatório")
    @NotNull(value = "Parametros obrigatório")
    private List<ParametroComunicacaoDTO> parametros;
    private List<DocumentoComunicacaoDTO> documentos;
    private List<Destinatario> destinatariosDetalhes;

    public String getValorParametro(@NotNull String nomeParam) {

        for (ParametroComunicacaoDTO p : this.getParametros()) {
            if(p.getNomeParametro() != null && p.getNomeParametro().equals(nomeParam)) {
                return p.getValorParametro();
            }
        }

        return null;
    }
}
