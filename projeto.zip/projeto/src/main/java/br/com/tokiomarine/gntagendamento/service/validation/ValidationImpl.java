package br.com.tokiomarine.gntagendamento.service.validation;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.dto.Destinatario;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import lombok.Builder;

@Builder
public class ValidationImpl implements Validation {

    private static final String FOUND_DESTINATARIO = "Destinatario obrigatório";

    @Override
    public void validate(AgendamentoComunicacao agendamento, AgendamentoRequest agendamentoRequest) {
        validateCodModelo(agendamentoRequest);
        validateDestinatario(agendamentoRequest);
    }

    void validateTelefone(AgendamentoRequest agendamentoRequest) {
        if (agendamentoRequest.getDestinatarios() != null) {
            for (String destinatario : agendamentoRequest.getDestinatarios()) {
                if(!this.verifyTelefone(destinatario)) {
                    throw new BadRequest("Número: " + destinatario + " invalido.");
                }
            }
        }

        if (agendamentoRequest.getDestinatariosDetalhes() != null) {
            for (Destinatario destinatario : agendamentoRequest.getDestinatariosDetalhes()) {
                if(!this.verifyTelefone(destinatario.getDestino())) {
                    throw new BadRequest("Número: " + destinatario.getDestino() + " invalido.");
                }
            }
        }
    }
    
    private void validateCodModelo(AgendamentoRequest agendamentoRequest) {
        if (StringUtil.isNull(agendamentoRequest.getCodigo()) && agendamentoRequest.getCodigoModelo() == null) {
            throw new BadRequest("Código de modelo não encontrado");
        }

        if (agendamentoRequest.getCodigoModelo() != null && agendamentoRequest.getCodigo() != null) {
            throw new BadRequest("Utilizado os dois atributos (codigoModelo e codigo). Por favor utilize somente codigo.");
        }
    }

    private void validateDestinatario(AgendamentoRequest agendamentoRequest) {
        if(agendamentoRequest.getDestinatariosDetalhes() == null && agendamentoRequest.getDestinatarios() == null) {
            throw new BadRequest(FOUND_DESTINATARIO);
        }

        if(agendamentoRequest.getDestinatarios() != null) {
            for (String destinatario : agendamentoRequest.getDestinatarios()) {
                if (StringUtil.isNull(destinatario)) {
                    throw new BadRequest(FOUND_DESTINATARIO);
                }
            }
        }

        if (agendamentoRequest.getDestinatarios() != null && agendamentoRequest.getDestinatariosDetalhes() != null) {
            throw new BadRequest("Utilizado os dois atributos (destinatario e destinatarioDetalhes)." +
                    " Por favor utilize somente destinatarioDetalhes.");
        }
    }

    private Boolean verifyTelefone(String number) {
        return number.matches("\\d+");
    }

}
