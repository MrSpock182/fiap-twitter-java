package br.com.tokiomarine.gntagendamento.service.parametro_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.dto.ParametroComunicacaoDTO;
import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.domain.repository.ParametroComunicacaoRepository;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParametroComunicacaoServiceImpl implements ParametroComunicacaoService {

    @Autowired
    private ParametroComunicacaoRepository parametroComunicacaoRepository;

    @Override
    public void setParametro(@NotNull AgendamentoComunicacao agendamento,@NotNull AgendamentoRequest agendamentoRequest) {
        this.validateParametro(agendamentoRequest, agendamento.getModelo());

        List<ParametroComunicacaoDTO> parametros = agendamentoRequest.getParametros();
        for (ParametroComunicacaoDTO parametro : parametros) {
            ParametroComunicacao param = findByNomeParametro(parametro.getNomeParametro());

            AgendamentoParametro paramAgend = new AgendamentoParametro();
            paramAgend.setAgendamento(agendamento);
            paramAgend.setParametro(param);
            paramAgend.setValorParametro(parametro.getValorParametro());

            agendamento.setParametros(paramAgend);
        }
    }

    private void validateParametro(@NotNull AgendamentoRequest agendamentoRequest, ModeloComunicacao modelo) {
        StringBuilder sb = new StringBuilder();
        for (ParametroModelo param : modelo.getParametros()) {
            if (param.getIndExibeLista().equals("N") || param.getParametro().getIndConsulta().equals("S")) {
                String valor = agendamentoRequest.getValorParametro(param.getParametro().getNomeParametro());
                if (StringUtil.isNull(valor)) {
                    sb.append("O parâmetro " + param.getParametro().getNomeParametro() + " não foi informado");
                }
            }
        }

        if(sb.length() > 0) {
            throw new BadRequest(sb.toString());
        }
    }

    @Override
    public ParametroComunicacao findByNomeParametro(@NotNull String nome) {
        ParametroComunicacao parametroComunicacao = parametroComunicacaoRepository.findByNomeParametro(nome);

        if(parametroComunicacao == null) {
            throw new BadRequest("Parâmetro " + nome + " não encontrado");
        }

        return parametroComunicacao;
    }

}
