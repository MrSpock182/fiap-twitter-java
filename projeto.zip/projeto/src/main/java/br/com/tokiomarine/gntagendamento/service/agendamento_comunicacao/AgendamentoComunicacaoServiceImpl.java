package br.com.tokiomarine.gntagendamento.service.agendamento_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoResponse;
import br.com.tokiomarine.gntagendamento.domain.dto.Link;
import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.domain.repository.AgendamentoComunicacaoRepository;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import br.com.tokiomarine.gntagendamento.jms.producer.FilaProducer;
import br.com.tokiomarine.gntagendamento.service.agendamento_envio.AgendamentoEnvioService;
import br.com.tokiomarine.gntagendamento.service.documento_comunicacao.DocumentoComunicacaoService;
import br.com.tokiomarine.gntagendamento.service.modelo_comunicacao.ModeloComunicacaoService;
import br.com.tokiomarine.gntagendamento.service.parametro_comunicacao.ParametroComunicacaoService;
import br.com.tokiomarine.gntagendamento.service.validation.ValidationBuilder;
import br.com.tokiomarine.gntagendamento.service.validation.ValidationImpl;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Slf4j
@Service
public class AgendamentoComunicacaoServiceImpl implements AgendamentoComunicacaoService {

    //VARIAVEL
    @Value("${server.servlet.context-path}")
    private String context;

    // REPOSITORY
    @Autowired
    private AgendamentoComunicacaoRepository agendamentoComunicacaoRepository;

    // JMS
    @Autowired
    private FilaProducer filaProducer;

    // SERVICES
    @Autowired
    private StackLogger stackLogger;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private ValidationBuilder validationBuilder;

    @Autowired
    private AgendamentoEnvioService agendamentoEnvioService;

    @Autowired
    private ModeloComunicacaoService modeloComunicacaoService;

    @Autowired
    private ParametroComunicacaoService parametroComunicacaoService;

    @Autowired
    private DocumentoComunicacaoService documentoComunicacaoService;

    @Override
    public AgendamentoResponse incluirAgendamento(String envia, AgendamentoRequest agendamentoRequest) {

        try {
            ModeloComunicacao modelo;

            if (agendamentoRequest.getCodigo() != null) {
                modelo = modeloComunicacaoService.findByCodigo(agendamentoRequest.getCodigo());
            } else if (agendamentoRequest.getCodigoModelo() != null) {
                modelo = modeloComunicacaoService.findById(agendamentoRequest.getCodigoModelo());
            } else {
                throw new BadRequest("Modelo informado não encontrado");
            }

            AgendamentoComunicacao agendamentoComunicacao = AgendamentoComunicacao.builder()
                    .modelo(modelo)
                    .dtAgendamento(new Date())
                    .tipoEnvio(agendamentoRequest.getTipoEnvio())
                    .rastreiaEnvio(agendamentoRequest.getRastreiaEnvio())
                    .emailRemetente(agendamentoRequest.getEmailRemetente())
                    .codCorretor(agendamentoRequest.getCodCorretor())
                    .build();

            agendamentoComunicacao.setIndEnviaComunicacao(agendamentoRequest.getIndEnviaComunicacao());
            agendamentoComunicacao.statusAgendamentoComunicacao(agendamentoRequest.getIndEnviaComunicacao());
            agendamentoComunicacao.setDestinatarios(agendamentoRequest);

            parametroComunicacaoService.setParametro(agendamentoComunicacao, agendamentoRequest);

            if (agendamentoRequest.getDocumentos() != null) {
                documentoComunicacaoService.setDocumento(agendamentoComunicacao, agendamentoRequest.getDocumentos());
            }

            if (agendamentoRequest.getListDoc() != null) {
                agendamentoComunicacao.setListDoc(agendamentoRequest.getListDoc());
            }

            if (agendamentoRequest.getComCopias() != null) {
                agendamentoComunicacao.setComCopias(agendamentoRequest.getComCopias());
            }

            if (agendamentoRequest.getAnexos() != null) {
                agendamentoComunicacao.setAnexos(agendamentoRequest.getAnexos());
            }

            if (StringUtil.in(agendamentoRequest.getIndEnviaComunicacao(), "S", "N")) {
                agendamentoComunicacao.setIndEnviaComunicacao(agendamentoComunicacao.getIndEnviaComunicacao());
            }

            validate(agendamentoComunicacao, agendamentoRequest);

            agendamentoComunicacao = agendamentoComunicacaoRepository.save(agendamentoComunicacao);
            AgendamentoEnvio agendamentoEnvio = agendamentoEnvioService.save(agendamentoComunicacao);

            //ENVIA PARA FILA CASO NÃO SEJA PILOTO
            if (!"S".equalsIgnoreCase(modelo.getPiloto()) && "S".equalsIgnoreCase(envia)) {
                filaProducer.producer(agendamentoEnvio);
            }

            return AgendamentoResponse.builder()
                    .seqAgendamento(agendamentoComunicacao.getSeqAgendamento())
                    .codigoRetorno(0)
                    .mensagemRetorno("cadastrado")
                    .link(new Link("status", getUrl(agendamentoComunicacao.getSeqAgendamento())))
                    .build();

        } catch (Exception ex) {
            log.error(stackLogger.logRequest(agendamentoRequest), ex);
            throw ex;
        }
    }

    private void validate(AgendamentoComunicacao agendamento, AgendamentoRequest agendamentoRequest) {
        ValidationImpl validation = validationBuilder.getValidation(agendamento.getModelo().getTipoModelo());
        validation.validate(agendamento, agendamentoRequest);
    }

    private String getUrl(Long seqAgendamento) {
        return String.format("%s://%s:%d%s", request.getScheme(), request.getServerName(), request.getServerPort(), context + "/v1/agendamento/status/" + seqAgendamento);
    }

}
