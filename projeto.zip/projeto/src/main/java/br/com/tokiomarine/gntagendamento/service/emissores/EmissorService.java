package br.com.tokiomarine.gntagendamento.service.emissores;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import org.jetbrains.annotations.NotNull;

public interface EmissorService {
    void enviarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio);
    void gerarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio);
}
