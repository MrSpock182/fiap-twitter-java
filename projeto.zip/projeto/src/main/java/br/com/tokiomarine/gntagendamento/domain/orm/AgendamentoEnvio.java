package br.com.tokiomarine.gntagendamento.domain.orm;

import br.com.tokiomarine.gntagendamento.enumerable.StatusAgendamento;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "AGENDAMENTO_ENVIO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoEnvio implements Serializable {

    @Id
    @Column(name="CD_SEQUENCIA_ENVIO")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="seqEnvioGenerator")
    @SequenceGenerator(name = "seqEnvioGenerator", sequenceName = "SQ_AGENDAMENTO_ENVIO",allocationSize=1)
    private Long seqEnvio;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
    private AgendamentoComunicacao agendamento;

    @Column(name="DS_TITULO")
    private String titulo;

    @Column(name="DS_REMETENTE")
    private String remetente;

    @Column(name="DS_CAIXA_DEPTO")
    private String caixaDepto;

    @Column(name="DT_SOLIC_ENVIO")
    private Date dtSolicEnvio;

    @Column(name="DT_ENVIO")
    private Date dtEnvio;

    @Column(name="ID_SITUACAO_ENVIO")
    private String statusEnvio;

    @Column(name="CD_RETORNO_WS")
    private String codRetornoEnvio;

    @Column(name="NM_USUARIO_INCLUSAO")
    private String usuarioInclusao;

    @Column(name="DT_INCLUSAO")
    private Date dtInclusao;

    public boolean contemAnexos() {
        return !this.agendamento.getAnexos().isEmpty();
    }

    public Integer getQuantidadeEnvio() {
        int envios = 0;

        if (this.getStatusEnvio().equals(StatusAgendamento.ENVIADO.getValue())) {
            envios++;
        }

        return envios;
    }

    public void setAgendamentoComunicacaoMensagemEnviada(String mensagem) {
        this.agendamento.setMensagemEnviada(mensagem);
    }
}
