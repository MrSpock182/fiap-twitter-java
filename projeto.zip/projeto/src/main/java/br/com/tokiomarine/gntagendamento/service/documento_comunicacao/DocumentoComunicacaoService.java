package br.com.tokiomarine.gntagendamento.service.documento_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.dto.DocumentoComunicacaoDTO;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.DocumentoComunicacao;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface DocumentoComunicacaoService {
    void setDocumento(@NotNull AgendamentoComunicacao agendamento,@NotNull List<DocumentoComunicacaoDTO> documentos);
    DocumentoComunicacao findById(@NotNull Long codDocumento);
}
