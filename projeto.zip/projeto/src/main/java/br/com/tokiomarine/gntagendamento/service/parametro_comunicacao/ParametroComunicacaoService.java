package br.com.tokiomarine.gntagendamento.service.parametro_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.ParametroComunicacao;
import org.jetbrains.annotations.NotNull;

public interface ParametroComunicacaoService {
    void setParametro(@NotNull AgendamentoComunicacao agendamento,@NotNull AgendamentoRequest agendamentoRequest);
    ParametroComunicacao findByNomeParametro(@NotNull String nome);
}
