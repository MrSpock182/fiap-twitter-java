package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Link {
    private String rel;
    private String href;
}
