package br.com.tokiomarine.gntagendamento.util;

import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import java.io.StringReader;

public class BodyMailUtil {

    private BodyMailUtil() {}

    public static void removeChilds(@NotNull Element element) {
        NodeList recList = element.getChildNodes();
        int len = recList.getLength();
        for (int i = 0; i < len; i++) {
            element.removeChild(recList.item(0));
        }
    }

    public static Node createNode(@NotNull DocumentBuilder builder, @NotNull Document emailHtml, @NotNull String fragment) {
        fragment = fragment.replaceAll("&nbsp;", " ").replaceAll("<br>", "<br/>");

        Node fragmentNode;
        try {
            fragmentNode = builder.parse(new InputSource(new StringReader(fragment))).getDocumentElement();
            return emailHtml.importNode(fragmentNode, true);
        } catch (Exception e) {
            throw new InternalServerError(String.format("Erro ao processar texto HTML: %s - Texto: %s", e.getMessage(), fragment));
        }
    }

}
