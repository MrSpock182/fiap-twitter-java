package br.com.tokiomarine.gntagendamento.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class PushNotificationDTO {

    private String finalidade;
    private String destinatario;
    private String titulo;
    private String chamada;
    private Integer dataDeValidade;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String mensagem;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private MensagemPushDTO mensagemKey;
}
