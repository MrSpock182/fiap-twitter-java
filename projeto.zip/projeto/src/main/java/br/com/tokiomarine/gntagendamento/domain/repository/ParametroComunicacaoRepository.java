package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.ParametroComunicacao;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Component;

@Component
public interface ParametroComunicacaoRepository extends PagingAndSortingRepository<ParametroComunicacao, Long>,
        JpaSpecificationExecutor<ParametroComunicacao> {
    ParametroComunicacao findByNomeParametro(String nome);
}
