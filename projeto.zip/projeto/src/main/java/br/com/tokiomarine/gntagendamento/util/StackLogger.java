package br.com.tokiomarine.gntagendamento.util;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StackLogger {

    @Autowired
    private ObjectMapper mapper;

    public String getMessage(@NotNull Exception exception) {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("Error: %s", exception.getMessage()) + '\n');
        sb.append(String.format("Cause: %s", exception.getCause()) + '\n');

        for (StackTraceElement stack : exception.getStackTrace()) {
            sb.append(String.format("Class: %s", stack.getClassName()) + '\n');
            sb.append(String.format("Method: %s", stack.getMethodName()) + '\n');
            sb.append(String.format("File: %s", stack.getFileName()) + '\n');
            sb.append(String.format("Line Error: %d", stack.getLineNumber()) + '\n');
        }

        return sb.toString();
    }

    public String logRequest(@NotNull AgendamentoRequest agendamentoRequest) {
        try {
            String json = mapper.writeValueAsString(agendamentoRequest);
            return String.format("Erro ao realizar agendamento, request: %s ", json);
        } catch (Exception ex) {
            throw new BadRequest(String.format("Agendamento %s com erro no JSON",
                    StringUtil.getCodigo(agendamentoRequest)));
        }
    }

}
