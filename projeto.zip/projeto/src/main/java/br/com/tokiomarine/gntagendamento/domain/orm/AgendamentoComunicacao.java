package br.com.tokiomarine.gntagendamento.domain.orm;

import br.com.tokiomarine.gntagendamento.domain.dto.*;
import br.com.tokiomarine.gntagendamento.enumerable.StatusAgendamento;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import lombok.*;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.jetbrains.annotations.NotNull;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "AGENDAMENTO_COMUNICACAO")
@SequenceGenerator(name = "agendamentoGenerator", sequenceName = "SQ_AGENDAMENTO_COMUNICACAO", allocationSize = 1)
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoComunicacao implements Serializable {

    @Id
    @Column(name = "CD_SEQUENCIA_AGENDAMENTO")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "agendamentoGenerator")
    private Long seqAgendamento;

    @Column(name = "ID_ENVIA_COMUNIC")
    private String indEnviaComunicacao;

    @Column(name = "DT_AGENDAMENTO")
    private Date dtAgendamento;

    @Column(name = "DT_ENVIO_ORIGINAL")
    private Date dtEnvioOriginal;

    @Column(name = "ID_SITUACAO_AGENDAMENTO")
    private String statusAgendamento;

    @Column(name = "DS_MSG_ENVIADA")
    private String mensagemEnviada;

    @Column(name = "COD_CORRETOR")
    private String codCorretor;

    @Column(name = "DS_CORRETOR_CPFCNPJ")
    private String corretorCpfCnpj;

    @Column(name = "DS_TIPO_ENVIO")
    private String tipoEnvio;

    @Column(name = "DS_REMETENTE_OPCIONAL")
    private String emailRemetente;

    @Column(name = "DS_RASTREIA_ENVIO")
    private String rastreiaEnvio;

    @Column(name = "CD_NIVEL_PRIORIDADE")
    private Integer nivelPrioridade;

    @Column(name="ATIVA_RESPOSTA_SMS")
    private String ativaRespostaSms;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("seqDestinatario")
    private List<AgendamentoDestinatario> destinatarios;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AgendamentoParametro> parametros;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AgendamentoDocumento> documentos;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AgendamentoEnvio> envios;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AgendamentoAnexo> anexos;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AgendamentoListDocumentos> listDoc;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("seqCopia")
    private List<AgendamentoComCopia> comCopias;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CD_MODELO_COMUNICACAO", referencedColumnName = "CD_MODELO_COMUNICACAO")
    private ModeloComunicacao modelo;

    public String getValorParametro(String nomeParam) {
        if (this.getParametros() != null && this.getParametros().size() > 0) {
            for (AgendamentoParametro p : this.getParametros()) {
                if (p.getParametro().getNomeParametro().equals(nomeParam)) {
                    return p.getValorParametro();
                }
            }
        }

        return null;
    }

    private String getIndEnviaComunicacao(String indEnviaComunicacao) {
        return StringUtil.isNull(indEnviaComunicacao) ? "S" : indEnviaComunicacao;
    }

    public void setAnexos(List<AnexoEmail> anexos) {
        if (this.getAnexos() == null) {
            this.anexos = new ArrayList<>();
        }

        for (AnexoEmail anexoEmail : anexos) {
            AgendamentoAnexo anexo = AgendamentoAnexo.builder()
                    .id(anexos.indexOf(anexoEmail) + 1L)
                    .agendamento(this)
                    .arquivoBase64(anexoEmail.getFileBase64())
                    .nome(anexoEmail.getNome())
                    .build();

            this.getAnexos().add(anexo);
        }
    }

    public void setParametros(AgendamentoParametro param) {
        if (this.getParametros() == null) {
            this.parametros = new ArrayList<>();
        }

        for (AgendamentoParametro p : this.getParametros()) {
            if (p.getParametro().equals(param.getParametro())) {
                p.setValorParametro(param.getValorParametro());
            }
        }

        this.getParametros().add(param);
    }

    public void setDocumentos(AgendamentoDocumento doc) {
        if (this.getDocumentos() == null) {
            this.documentos = new ArrayList<>();
        }

        for (AgendamentoDocumento d : this.getDocumentos()) {
            if (d.getDocumento().equals(doc.getDocumento())) {
                if (!StringUtil.isNull(doc.getIndEnviaEmail())) {
                    d.setIndEnviaEmail(doc.getIndEnviaEmail());
                }

                d.setUrlArquivo(doc.getUrlArquivo());
                d.setDtAtualizacao(new Date());
            }
        }

        this.getDocumentos().add(doc);
    }

    public void setListDoc(List<ListDocComunicacao> listDoc) {
        if (this.getListDoc() == null) {
            this.listDoc = new ArrayList<>();
        }

        for (ListDocComunicacao listDocComunicacao : listDoc) {
            AgendamentoListDocumentos agendamento = new AgendamentoListDocumentos();
            agendamento.setAgendamento(this);
            agendamento.setNomeDocumento(listDocComunicacao.getNomeDocumento());
            agendamento.setUrlArquivo(listDocComunicacao.getUrlDocumento());
            agendamento.setIndEnviaEmail(listDocComunicacao.getIndEnviaEmail());

            if (agendamento.getSeqListaDocumentos() != null) {
                setListaDocumentos(agendamento);
            }

            this.getListDoc().add(agendamento);
        }
    }

    private void setListaDocumentos(AgendamentoListDocumentos agendamento) {
        for (AgendamentoListDocumentos agendamentoListDocumentos : this.getListDoc()) {
            if (agendamentoListDocumentos.getSeqListaDocumentos().equals(agendamento.getSeqListaDocumentos())) {
                if (!StringUtil.isNull(agendamento.getIndEnviaEmail())) {
                    agendamentoListDocumentos.setIndEnviaEmail(agendamento.getIndEnviaEmail());
                }

                agendamentoListDocumentos.setUrlArquivo(agendamento.getUrlArquivo());
                agendamentoListDocumentos.setDtAtualizacao(new Date());
            }
        }
    }

    public void setDestinatarios(@NotNull AgendamentoRequest agendamentoRequest) {
        int i = 0;
        if (agendamentoRequest.getDestinatarios() != null) {
            for (String dest : agendamentoRequest.getDestinatarios()) {
                if (!StringUtil.isNull(dest)) {
                    AgendamentoDestinatario destinatario = AgendamentoDestinatario.builder()
                            .agendamento(this)
                            .seqDestinatario(i + 1)
                            .destinatario(dest)
                            .indValido("N")
                            .build();

                    this.addDestinatario(destinatario);
                }
            }
        }

        if (agendamentoRequest.getDestinatariosDetalhes() != null) {
            for (Destinatario dest : agendamentoRequest.getDestinatariosDetalhes()) {
                if (!StringUtil.isNull(dest.getDestino())) {
                    AgendamentoDestinatario destinatario = AgendamentoDestinatario.builder()
                            .agendamento(this)
                            .seqDestinatario(i + 1)
                            .destinatario(dest.getDestino())
                            .indValido("N")
                            .build();

                    this.addDestinatario(destinatario);
                }
            }

        }

    }

    private void addDestinatario(AgendamentoDestinatario dest) {
        if (this.getDestinatarios() == null) {
            this.destinatarios = new ArrayList<>();
        }

        for (AgendamentoDestinatario e : this.getDestinatarios()) {
            if (e.getSeqDestinatario().equals(dest.getSeqDestinatario())) {
                e.setDestinatario(dest.getDestinatario());
                return;
            }
        }

        this.getDestinatarios().add(dest);
    }

    public void setComCopias(List<ComCopia> comCopias) {
        int i = 0;
        if (this.getComCopias() == null) {
            this.comCopias = new ArrayList<>();
        }

        for (ComCopia comCopia : comCopias) {
            AgendamentoComCopia agendamentoComCopia = new AgendamentoComCopia();
            agendamentoComCopia.setAgendamento(this);
            agendamentoComCopia.setSeqCopia(++i);
            agendamentoComCopia.setDestinatario(comCopia.getDestino());
            agendamentoComCopia.setIndValido("N");

            if (comCopia.getCpfCnpj() != null) {
                agendamentoComCopia.setCpfCnpj(comCopia.getCpfCnpj());
            }

            if (comCopia.getCopiaOculta() != null) {
                agendamentoComCopia.setCopiaOculta(comCopia.getCopiaOculta());
            } else {
                agendamentoComCopia.setCopiaOculta("N");
            }

            for (AgendamentoComCopia agendamento : this.getComCopias()) {
                if (agendamento.getSeqCopia().equals(agendamentoComCopia.getSeqCopia())) {
                    agendamento.setDestinatario(agendamentoComCopia.getDestinatario());
                }
            }

            this.getComCopias().add(agendamentoComCopia);
        }
    }

    public void setIndEnviaComunicacao(String indEnviaComunicacao) {
        this.indEnviaComunicacao = this.getIndEnviaComunicacao(indEnviaComunicacao);
    }

    public void statusAgendamentoComunicacao(String indEnviaComunicacao) throws InternalError {
        String indEnvCom = this.getIndEnviaComunicacao(indEnviaComunicacao);

        if ("S".equals(indEnvCom))
            if (this.modelo.getPiloto().equals("S")) {
                this.statusAgendamento = StatusAgendamento.PILOTO.getValue();
            } else {
                this.statusAgendamento = StatusAgendamento.NAOENVIADO.getValue();
            }
        else if("N".equals(indEnvCom)) {
            this.statusAgendamento = StatusAgendamento.FINALIZADO.getValue();
        } else {
            throw new BadRequest("Indicador de envio de comunicação inválido");
        }
    }

    public Map<String, String> getMensagens() {
        Map<String, String> mapMsg = null;

        try {
            if (!StringUtil.isNull(this.getMensagemEnviada())) {
                mapMsg = (Map<String, String>) StringUtil.deserialize(this.getMensagemEnviada());
            }
        } catch (Exception e) {
            throw new InternalServerError("Erro Get Mensagens: " + e.getMessage(), e);
        }

        return mapMsg;
    }

}
