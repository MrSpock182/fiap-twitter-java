package br.com.tokiomarine.gntagendamento.service.validation;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.dto.Destinatario;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.ParamAcsel;
import br.com.tokiomarine.gntagendamento.domain.repository.ParamAcselRepository;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import lombok.AllArgsConstructor;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@AllArgsConstructor
class ValidationEmail extends ValidationImpl {

    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

    private static final Pattern pattern = Pattern.compile(EMAIL_PATTERN, Pattern.CASE_INSENSITIVE);
    private ParamAcselRepository paramAcselRepository;

    @Override
    public void validate(AgendamentoComunicacao agendamento, AgendamentoRequest agendamentoRequest) {
        super.validate(agendamento, agendamentoRequest);

        if (agendamentoRequest.getDestinatarios() != null) {
            for (String destinatario : agendamentoRequest.getDestinatarios()) {
                validaEmail(destinatario);
                validaEmailExterno(destinatario);
            }
        }

        if (agendamentoRequest.getDestinatariosDetalhes() != null) {
            for (Destinatario destinatario : agendamentoRequest.getDestinatariosDetalhes()) {
                validaEmail(destinatario.getDestino());
                validaEmailExterno(destinatario.getDestino());
            }
        }
    }

    private void validaEmail(String email) {
        try {
            Matcher matcher = pattern.matcher(email);

            if(!matcher.matches()) {
                throw new BadRequest("Email: " + email + " invalido.");
            }

            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
        } catch (AddressException ex) {
            throw new BadRequest("Email: " + email + " invalido.");
        }
    }

    private void validaEmailExterno(String email) {
        ParamAcsel paramAcsel = paramAcselRepository
                .findDistinctByGrpParamAcselCodGrpParametroAndCodParametro("PUSH_NOTIFICATION", "ENVIA_EMAIL_EXTERNO");

        if (!"S".equalsIgnoreCase(paramAcsel.getVlrParametro()) &&
                !email.toUpperCase().contains("@TOKIOMARINE.COM.BR")) {
            throw new BadRequest("Email externo habilitado, EMAIL: " + email + " fora do dominio tokio marine");
        }
    }

}
