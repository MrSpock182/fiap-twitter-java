package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(AgendamentoDestinatarioPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_DEST")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoDestinatario implements Serializable {

    @Id
    @Column(name="CD_SEQUENCIA_DEST")
    private Integer seqDestinatario;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
    private AgendamentoComunicacao agendamento;

    @Column(name="DS_DESTINATARIO")
    private String destinatario;

    @Column(name="ID_DEST_VALIDO")
    private String indValido;

    @Column(name="DS_DEST_CPFCNPJ")
    private String cpfCnpj;

}
