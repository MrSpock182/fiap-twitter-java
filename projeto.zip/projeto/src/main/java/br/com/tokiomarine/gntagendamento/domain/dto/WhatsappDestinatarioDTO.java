package br.com.tokiomarine.gntagendamento.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class WhatsappDestinatarioDTO {
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String id;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String correlationId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String destination;
}
