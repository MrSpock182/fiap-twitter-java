package br.com.tokiomarine.gntagendamento.service.agendamento_envio;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.domain.type.TypeStatusAgendamento;
import org.jetbrains.annotations.NotNull;

public interface AgendamentoEnvioService {
    AgendamentoEnvio save(@NotNull AgendamentoEnvio agendamentoEnvio);
    AgendamentoEnvio save(@NotNull AgendamentoComunicacao agendamentoComunicacao);
    AgendamentoEnvio findById(@NotNull Long seqEnvio);
    TypeStatusAgendamento findStatusAgendamento(@NotNull Long seqAgendamento);
}
