package br.com.tokiomarine.gntagendamento.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class MensagemPushDTO {
    private String value;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private Map<String, String> key = new HashMap<>();
}
