package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.domain.type.TypeStatusAgendamento;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(excerptProjection = TypeStatusAgendamento.class)
public interface AgendamentoEnvioRepository extends PagingAndSortingRepository<AgendamentoEnvio, Long>,
        JpaSpecificationExecutor<AgendamentoEnvio> {

    AgendamentoEnvio findDistinctByAgendamentoSeqAgendamento(Long seqAgendamento);

    AgendamentoEnvio findByAgendamentoSeqAgendamentoAndStatusEnvio(Long seqAgendamento, String statusEnvio);

    @Query(value = "SELECT A.CD_SEQUENCIA_AGENDAMENTO AS seqAgendamento, A.ID_SITUACAO_ENVIO AS statusEnvio, " +
            "   AE.DS_ERRO AS mensagemErro, A.DT_SOLIC_ENVIO AS dataSolicitacao, A.DT_ENVIO AS dataEnvio" +
            "   FROM AGENDAMENTO_ENVIO A" +
            "   LEFT JOIN AGENDAMENTO_ERRO_ENVIO AE ON A.CD_SEQUENCIA_ENVIO = AE.CD_SEQUENCIA_ENVIO" +
            "   WHERE CD_SEQUENCIA_AGENDAMENTO = :seqAgendamento", nativeQuery = true)
    TypeStatusAgendamento findStatusAgendamento(@Param("seqAgendamento") Long seqAgendamento);

}
