package br.com.tokiomarine.gntagendamento.service.emissores.email;

import br.com.tokiomarine.gntagendamento.domain.dto.AnexoEmail;
import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.domain.repository.AgendamentoComunicacaoRepository;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.service.body_mail.BodyMailService;
import br.com.tokiomarine.gntagendamento.service.emissores.EmissorService;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class EmailServiceImpl implements EmissorService, EmailService {

    @Autowired
    private StackLogger stackLogger;

    @Autowired
    private JavaMailSender emailSender;

    @Autowired
    private BodyMailService bodyMailService;

    @Autowired
    private AgendamentoComunicacaoRepository agendamentoComunicacaoRepository;

    @Override
    public void enviarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        try {
            salvarMensagem(agendamentoEnvio);

            MimeMessage mimeMessage = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

            helper.setFrom(new InternetAddress(agendamentoEnvio.getRemetente()));

            setDestinatario(agendamentoEnvio, helper);
            setComCopiaOculta(agendamentoEnvio, helper);
            setAnexo(agendamentoEnvio, helper);

            helper.setSentDate(new Date());
            helper.setSubject(agendamentoEnvio.getTitulo());
            helper.setText(agendamentoEnvio.getAgendamento().getMensagemEnviada(), true);

            emailSender.send(mimeMessage);

        } catch (Exception ex) {
            log.error("Erro enviar EMAIL: " + stackLogger.getMessage(ex));
            throw new InternalServerError("Erro ao enviar EMAIL: " + ex.getMessage(), ex);
        }
    }

    private void setDestinatario(@NotNull AgendamentoEnvio agendamentoEnvio,@NotNull MimeMessageHelper helper) throws MessagingException {
        //EMAIL DESTINATARIO
        for (AgendamentoDestinatario email : agendamentoEnvio.getAgendamento().getDestinatarios()) {
            helper.addTo(new InternetAddress(email.getDestinatario()));
        }
    }

    private void setComCopiaOculta(@NotNull AgendamentoEnvio agendamentoEnvio,@NotNull MimeMessageHelper helper) throws MessagingException {
        //EMAIL COM CÓPIA / CÓPIA OCULTA
        List<String> cc = new ArrayList<>();
        List<String> oculta = new ArrayList<>();

        if (!StringUtil.isNull(agendamentoEnvio.getCaixaDepto())) {
            cc.add(agendamentoEnvio.getCaixaDepto());
        }

        if (agendamentoEnvio.getAgendamento().getComCopias() != null && !agendamentoEnvio.getAgendamento().getComCopias().isEmpty()) {
            for (AgendamentoComCopia agendamentoComCopia : agendamentoEnvio.getAgendamento().getComCopias()) {
                if (agendamentoComCopia.getCopiaOculta().equals("S")) {
                    oculta.add(agendamentoComCopia.getDestinatario());
                } else {
                    cc.add(agendamentoComCopia.getDestinatario());
                }
            }
        }

        for (String email : cc) {
            helper.addTo(new InternetAddress(email));
        }

        for (String email : oculta) {
            helper.addBcc(new InternetAddress(email));
        }
    }

    private void setAnexo(@NotNull AgendamentoEnvio agendamentoEnvio,@NotNull MimeMessageHelper helper) throws MessagingException {
        if (agendamentoEnvio.contemAnexos()) {
            List<AnexoEmail> anexos = new ArrayList<>();
            for (AgendamentoAnexo anexo : agendamentoEnvio.getAgendamento().getAnexos()) {
                anexos.add(
                        AnexoEmail.builder()
                                .nome(anexo.getNome())
                                .binario(anexo.getArquivoBase64())
                                .build());
            }

            for (AnexoEmail anexo : anexos) {
                helper.addAttachment(anexo.getNome(), new ByteArrayResource(anexo.getBinario()));
            }
        }
    }

    @Override
    public void emailTemplate(@NotNull String destinatario,@NotNull String codigo,@NotNull String template) {
        try {
            MimeMessage mimeMessage = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

            helper.setFrom(new InternetAddress("noreply@tokiomarine.com.br"));

            StringBuilder sb = new StringBuilder();
            sb.append("<h1>Prezado,</h1>");
            sb.append("<p>Segue informações para uso do GNT referente ao documento de código: " + codigo + " </p>");
            sb.append("<p>" + template + "</p>");
            sb.append("<br/>");
            sb.append("<h1>RESTful API Service</h1>");
            sb.append("Dev: http://srvacx01d:8080/acx/documentos-rest/comunicacao/agendamento?envia=S</p>");
            sb.append("Act: https://servicos-aceiteint.tokiomarine.com.br/acx/documentos-rest/comunicacao/agendamento?envia=S</p>");
            sb.append("Prod: https://servicos-int.tokiomarine.com.br/acx/documentos-rest/comunicacao/agendamento?envia=S</p>");
            sb.append("<br/>");
            sb.append("<p>Para maiores informações acesse nossa documentação:</p>");
            sb.append("http://gitlab.tokiomarine.com.br/gestao-de-apolices/gnt/wikis/home");

            helper.addTo(new InternetAddress(destinatario));
            helper.setSentDate(new Date());
            helper.setSubject("Template GNT");
            helper.setText(sb.toString(), true);

            emailSender.send(mimeMessage);
        } catch (Exception ex) {
            log.error("Erro enviar template: " + stackLogger.getMessage(ex));
            throw new InternalServerError("Erro ao enviar template: " + ex.getMessage(), ex);
        }
    }

    @Override
    public void gerarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        String mensagem = bodyMailService.getBody(agendamentoEnvio);
        agendamentoEnvio.setAgendamentoComunicacaoMensagemEnviada(mensagem);
    }

    private void salvarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        AgendamentoComunicacao agendamentoComunicacao = agendamentoEnvio.getAgendamento();
        agendamentoComunicacao.setMensagemEnviada(bodyMailService.getBody(agendamentoEnvio));
        agendamentoComunicacaoRepository.save(agendamentoComunicacao);
    }

}
