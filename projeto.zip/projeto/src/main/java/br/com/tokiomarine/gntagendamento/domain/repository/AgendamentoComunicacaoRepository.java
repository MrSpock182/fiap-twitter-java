package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AgendamentoComunicacaoRepository extends PagingAndSortingRepository<AgendamentoComunicacao, Long>,
        JpaSpecificationExecutor<AgendamentoComunicacao> {

}
