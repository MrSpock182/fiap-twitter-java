package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "MODELO_COMUNICACAO_PARAM")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ParametroModelo implements Serializable {

    @Id
    @Column(name="CD_MODELO_COM_PARAM")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="modeloParamGenerator")
    @SequenceGenerator(name = "modeloParamGenerator", sequenceName = "SQ_MODELO_COMUNIC_PARAM",allocationSize=1)
    private Long idModeloParam;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="CD_MODELO_COMUNICACAO", referencedColumnName="CD_MODELO_COMUNICACAO")
    private ModeloComunicacao modelo;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="CD_PARAMETRO", referencedColumnName="CD_PARAMETRO")
    private ParametroComunicacao parametro;

    @Column(name="ID_EXIBE_LISTA")
    private String indExibeLista;

    @Column(name="NM_LISTA")
    private String nomeExibicao;

    @Column(name="CD_SEQUENCIA")
    private Integer cdSequencia;

    @Column(name="NM_FORMATACAO")
    private String formatacao;

    @Column(name="DT_INCLUSAO")
    private Date dataInclusao;

    @Column(name="NM_USUARIO_INCLUSAO")
    private String nomeUsuarioInclusao;

    @Column(name="DT_ATUALIZACAO")
    private Date dataAtualizacao;

    @Column(name="NM_USUARIO_ATUALIZACAO")
    private String nomeUsuarioAtualizacao;

    @Column(name="ORDEM")
    private Integer ordem;
}
