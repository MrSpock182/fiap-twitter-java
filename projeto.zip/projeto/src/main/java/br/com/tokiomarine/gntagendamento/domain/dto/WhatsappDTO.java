package br.com.tokiomarine.gntagendamento.domain.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class WhatsappDTO {
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<WhatsappDestinatarioDTO> destinations;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private WhatsappMessageDTO message;
}
