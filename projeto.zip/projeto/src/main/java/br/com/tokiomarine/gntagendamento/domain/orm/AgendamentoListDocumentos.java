package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "AGENDAMENTO_COMUNICACAO_LISTA")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoListDocumentos implements Comparable<AgendamentoListDocumentos>, Serializable {

    @Id
    @Column(name="CD_SEQUENCIA_LISTA")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="seqListGenerator")
    @SequenceGenerator(name = "seqListGenerator", sequenceName = "SQ_AGENDAMENTO_LISTA",allocationSize=1)
    private Long seqListaDocumentos;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
    private AgendamentoComunicacao agendamento;

    @Column(name="NOME_DOCUMENTO")
    private String nomeDocumento;

    @Column(name="DS_URL_ARQUIVO")
    private String urlArquivo;

    @Column(name="ID_ENVIA_EMAIL")
    private String indEnviaEmail;

    @Column(name="DT_ATUALIZACAO")
    private Date dtAtualizacao;

    @Override
    public int compareTo(AgendamentoListDocumentos outro) {
        if (this.getSeqListaDocumentos() < outro.getSeqListaDocumentos()) return -1;
        if (this.getSeqListaDocumentos() > outro.getSeqListaDocumentos()) return 1;
        return 0;
    }
}
