package br.com.tokiomarine.gntagendamento.util;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.StringWriter;

public class StringUtil {

    private StringUtil() {

    }

    public static boolean isNull(String val) {
        return (val == null || val.isEmpty());
    }

    public static boolean in(String valor, String... lista) {
        if (valor == null) return false;
        for (String s : lista) {
            if (valor.equals(s))
                return true;
        }
        return false;
    }

    public static String escapeXml(String texto){

        StringWriter stringWriter = new StringWriter((int) (texto.length() + (texto.length() * 0.1)));
        int len = texto.length();
        for (int i = 0; i < len; i++) {
            int c = texto.charAt(i);
            switch (c) {
                case 34:
                    stringWriter.write(texto.charAt(i));
                    break;
                case 38:
                    stringWriter.write("&amp;");
                    break;
                case 39:
                    stringWriter.write(texto.charAt(i));
                    break;
                case 60:
                    stringWriter.write(texto.charAt(i));
                    break;
                case 62:
                    stringWriter.write(texto.charAt(i));
                    break;
                default:
                    stringWriter.write(texto.charAt(i));
                    break;
            }
        }

        return stringWriter.toString();
    }

    public static String serialize(@NotNull Object obj) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException ex) {
            throw new BadRequest("Erro ao serializar JSON");
        }
    }

    public static Object deserialize(@NotNull String json) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, Object.class);
    }

    public static String getCodigo(@NotNull AgendamentoRequest agendamentoRequest) {
        if(agendamentoRequest.getCodigoModelo() != null) {
            return agendamentoRequest.getCodigoModelo().toString();
        }

        if(agendamentoRequest.getCodigo() != null) {
            return agendamentoRequest.getCodigo();
        }

        return null;
    }

}
