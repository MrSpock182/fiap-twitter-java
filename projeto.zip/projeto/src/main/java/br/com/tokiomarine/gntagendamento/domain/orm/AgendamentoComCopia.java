package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(AgendamentoComCopiaPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_COPIA")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoComCopia implements Serializable {

    @Id
    @Column(name="CD_SEQUENCIA_COPIA")
    private Integer seqCopia;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
    private AgendamentoComunicacao agendamento;

    @Column(name="DS_DESTINATARIO")
    private String destinatario;

    @Column(name="ID_COPIA_VALIDO")
    private String indValido;

    @Column(name="DS_COPIA_CPFCNPJ")
    private String cpfCnpj;

    @Column(name="ID_COPIA_OCULTA")
    private String copiaOculta;
}
