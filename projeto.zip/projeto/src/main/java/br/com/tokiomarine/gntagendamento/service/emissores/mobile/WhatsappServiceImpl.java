package br.com.tokiomarine.gntagendamento.service.emissores.mobile;

import br.com.tokiomarine.gntagendamento.domain.dto.*;
import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.domain.repository.ParamAcselRepository;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.service.emissores.EmissorService;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Slf4j
@Service
public class WhatsappServiceImpl extends MobileServiceImpl implements EmissorService {

    private static final String CODGRPPARAMETRO = "PUSH_NOTIFICATION";

    @Value("${movile.url}")
    private String url;

    @Autowired
    private StackLogger stackLogger;

    @Autowired
    private ParamAcselRepository param;

    @Autowired
    private ObjectMapper mapper;

    @Override
    public void enviarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        try {
            ParamAcsel user = param.findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(CODGRPPARAMETRO, "USER_WHATSAPP");
            ParamAcsel password = param.findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(CODGRPPARAMETRO, "PASSWORD_WHATSAPP");

            for (AgendamentoDestinatario cel : agendamentoEnvio.getAgendamento().getDestinatarios()) {
                String json = mapper.writeValueAsString(getWhatsappDTO(agendamentoEnvio, cel.getDestinatario()));

                RestTemplate restTemplate = new RestTemplate();
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.add("username", user.getVlrParametro());
                headers.add("authenticationToken", password.getVlrParametro());

                HttpEntity<String> entity = new HttpEntity<>(json, headers);
                ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

                if (response.getStatusCode().equals(HttpStatus.OK) && response.getBody() != null) {
                    String body = response.getBody();

                    if (response.getBody().length() > 20) {
                        body = response.getBody().substring(0, 20);
                    }

                    agendamentoEnvio.setCodRetornoEnvio(body);
                } else {
                    log.error("Erro ao acessar serviço de envio de Whatsapp: " + response.getBody());
                    throw new InternalServerError("Erro ao acessar serviço de envio de Whatsapp: " + response.getBody());
                }
            }
        } catch (Exception ex) {
            log.error("Erro enviar Whatsapp: " + stackLogger.getMessage(ex));
            throw new InternalServerError("Erro ao enviar whatsapp: " + ex.getMessage(), ex);
        }
    }

    @Override
    public void gerarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        this.mensagem(agendamentoEnvio);
    }

    private List<String> getMessage(@NotNull AgendamentoComunicacao agendamentoComunicacao) {
        Map<Integer, String> mensagem = new HashMap<>();

        for (AgendamentoParametro parametroAgendamento : agendamentoComunicacao.getParametros()) {
            for (ParametroModelo parametroModelo : agendamentoComunicacao.getModelo().getParametros()) {
                if (parametroModelo.getParametro().getCodParametro()
                        .equals(parametroAgendamento.getParametro().getCodParametro())) {
                    mensagem.put(parametroModelo.getOrdem(), parametroAgendamento.getValorParametro());
                }
            }
        }

        return new ArrayList<>(mensagem.values());
    }

    private WhatsappDTO getWhatsappDTO(@NotNull AgendamentoEnvio agendamentoEnvio, @NotNull String destinatario) {
        try {
            List<String> message = getMessage(agendamentoEnvio.getAgendamento());

            List<WhatsappDestinatarioDTO> destination = new ArrayList<>();
            destination.add(WhatsappDestinatarioDTO.builder()
                    .correlationId(agendamentoEnvio.getAgendamento().getSeqAgendamento().toString())
                    .destination("55" + destinatario)
                    .build());

            return WhatsappDTO.builder()
                    .destinations(destination)
                    .message(WhatsappMessageDTO.builder()
                            .hsm(WhatsappHmsDTO.builder()
                                    .namespace("whatsapp:hsm:ecommerce:movile")
                                    .elementName(agendamentoEnvio.getAgendamento().getModelo().getModeloFacebook())
                                    .parameters(message)
                                    .build())
                            .document(null)
                            .build())
                    .build();
        } catch (Exception ex) {
            throw new InternalServerError("Erro ao formatar json whatsapp: " + ex.getMessage(), ex);
        }
    }
}
