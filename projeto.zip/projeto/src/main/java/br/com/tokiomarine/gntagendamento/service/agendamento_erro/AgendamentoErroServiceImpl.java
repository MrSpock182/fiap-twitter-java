package br.com.tokiomarine.gntagendamento.service.agendamento_erro;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoErro;
import br.com.tokiomarine.gntagendamento.domain.repository.AgendamentoErroRepository;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class AgendamentoErroServiceImpl implements AgendamentoErroService {

    @Autowired
    private AgendamentoErroRepository agendamentoErroRepository;

    @Override
    public void incluirErro(@NotNull AgendamentoEnvio agendamento,@NotNull String msgErro) {
        AgendamentoErro agendamentoErro = AgendamentoErro.builder()
                .agendamento(agendamento)
                .dtErro(new Date())
                .descErro(msgErro)
                .build();

        agendamentoErroRepository.save(agendamentoErro);
    }
}
