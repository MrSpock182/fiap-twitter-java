package br.com.tokiomarine.gntagendamento.service.validation;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.ParametroModelo;
import br.com.tokiomarine.gntagendamento.domain.orm.TextoModeloComunicacao;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;


class ValidationSms extends ValidationImpl {

    private static final String MENSAGEM = "mensagem";

    @Override
    public void validate(AgendamentoComunicacao agendamento, AgendamentoRequest agendamentoRequest) {
        super.validate(agendamento, agendamentoRequest);

        validateTelefone(agendamentoRequest);
        validaParametros(agendamento);
    }

    private void validaParametros(AgendamentoComunicacao agendamento) {
        Map<String, String> parametros = new HashMap<>();
        for (ParametroModelo param : agendamento.getModelo().getParametros()) {
            parametros.put(param.getParametro().getNomeParametro(),
                    agendamento.getValorParametro(param.getParametro().getNomeParametro()));
        }

        Map<String, String> params = new HashMap<>();
        for (TextoModeloComunicacao texto : agendamento.getModelo().getTextos()) {
            if (texto.getTextoComunicacao().getTipoTexto().equals("P")) {
                params.put("chamada", formataTexto(parametros, texto.getTexto()));
            } else {
                params.put(MENSAGEM, formataTexto(parametros, texto.getTexto()));
            }
        }

        StringUtil.serialize(params);

        if(params.get(MENSAGEM).length() > 150) {
            throw new BadRequest("Sua mensagem possui valor maior que 150 caracteres: " + params.get(MENSAGEM));
        }
    }

    private String formataTexto(Map<String, String> parametros, String texto) {

        String txtRetorno = texto;

        String[] vars = StringUtils.substringsBetween(texto, "[", "]");

        if (vars != null) {
            for (String var : vars) {
                if (parametros.containsKey(var)) {
                    String valor = parametros.get(var);
                    if (valor == null) {
                        throw new BadRequest("Parâmetro " + var + " não informado");
                    }
                    txtRetorno = txtRetorno.replace("[" + var + "]", valor);
                }
            }
        }

        return txtRetorno;
    }

}
