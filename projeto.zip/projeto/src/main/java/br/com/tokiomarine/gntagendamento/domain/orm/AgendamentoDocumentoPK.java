package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode
public class AgendamentoDocumentoPK implements Serializable {
    private static final long serialVersionUID = 1249882555827771803L;

    private AgendamentoComunicacao agendamento;
    private DocumentoComunicacao documento;
}
