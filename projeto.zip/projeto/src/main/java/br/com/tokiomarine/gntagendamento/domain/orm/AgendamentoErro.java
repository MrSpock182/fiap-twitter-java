package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "AGENDAMENTO_ERRO_ENVIO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoErro implements Serializable {

    @Id
    @Column(name="CD_SEQUENCIA_ERRO_ENVIO")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="seqErroGenerator")
    @SequenceGenerator(name = "seqErroGenerator", sequenceName = "SQ_AGENDAMENTO_ERRO_ENVIO",allocationSize=1)
    private Long seqErroEnvio;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CD_SEQUENCIA_ENVIO", referencedColumnName="CD_SEQUENCIA_ENVIO")
    private AgendamentoEnvio agendamento;

    @Column(name="DS_ERRO")
    private String descErro;

    @Column(name="DT_INCLUSAO")
    private Date dtErro;

}
