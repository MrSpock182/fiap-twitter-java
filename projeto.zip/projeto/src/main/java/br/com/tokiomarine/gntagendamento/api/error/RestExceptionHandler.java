package br.com.tokiomarine.gntagendamento.api.error;

import br.com.tokiomarine.gntagendamento.domain.dto.ErrorResponse;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.exception.NotFoundException;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.Date;

@RestControllerAdvice
public class RestExceptionHandler {

    private static Logger logger = LogManager.getLogger(RestExceptionHandler.class);

    @Autowired
    private StackLogger stackLogger;

    @ExceptionHandler(BadRequest.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ErrorResponse handleBadRequest(BadRequest badRequest, WebRequest request) {
        logger.error(stackLogger.getMessage(badRequest));

        return ErrorResponse.builder()
                .timestamp(new Date())
                .status(HttpStatus.BAD_REQUEST.value())
                .error("BAD REQUEST")
                .message(badRequest.getMessage())
                .path(request.getDescription(false).replace("uri=", ""))
                .build();
    }

    @ExceptionHandler(InternalServerError.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ErrorResponse handleInternalServerError(Exception exception, WebRequest request) {
        logger.error(stackLogger.getMessage(exception));

        return ErrorResponse.builder()
                .timestamp(new Date())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .error("INTERNAL SERVER ERROR")
                .message(exception.getMessage())
                .path(request.getDescription(false).replace("uri=", ""))
                .build();
    }

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public ErrorResponse handleExpectationFailedError(NotFoundException notFoundException, WebRequest request) {
        logger.error(stackLogger.getMessage(notFoundException));

        return ErrorResponse.builder()
                .timestamp(new Date())
                .status(HttpStatus.EXPECTATION_FAILED.value())
                .error("EXPECTATION FAILED")
                .message(notFoundException.getMessage())
                .path(request.getDescription(false).replace("uri=", ""))
                .build();
    }

}
