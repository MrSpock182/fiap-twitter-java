package br.com.tokiomarine.gntagendamento.service.agendamento_envio;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.domain.orm.ModeloComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.ParametroModelo;
import br.com.tokiomarine.gntagendamento.domain.repository.AgendamentoEnvioRepository;
import br.com.tokiomarine.gntagendamento.domain.type.TypeStatusAgendamento;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Optional;

@Slf4j
@Service
public class AgendamentoEnvioServiceImpl implements AgendamentoEnvioService {

    private HashMap<String, String> parametros;

    @Autowired
    private AgendamentoEnvioRepository agendamentoEnvioRepository;

    @Override
    public AgendamentoEnvio save(@NotNull AgendamentoEnvio agendamentoEnvio) {
        return agendamentoEnvioRepository.save(agendamentoEnvio);
    }

    @Override
    public AgendamentoEnvio save(@NotNull AgendamentoComunicacao agendamentoComunicacao) {
        parametros = new HashMap<>();

        AgendamentoEnvio envio = AgendamentoEnvio.builder()
                .agendamento(agendamentoComunicacao)
                .caixaDepto(agendamentoComunicacao.getModelo().getEmailCaixaDept())
                .dtSolicEnvio(new Date())
                .usuarioInclusao(null)
                .dtInclusao(new Date())
                .statusEnvio(agendamentoComunicacao.getStatusAgendamento())
                .build();

        if (agendamentoComunicacao.getEmailRemetente() != null
                && !agendamentoComunicacao.getEmailRemetente().trim().equals("")) {
            envio.setRemetente(agendamentoComunicacao.getEmailRemetente());
        } else {
            envio.setRemetente(agendamentoComunicacao.getModelo().getEmailRemetente());
        }

        AgendamentoComunicacao agend = envio.getAgendamento();
        ModeloComunicacao modelo = agend.getModelo();

        this.parametros.clear();

        for (ParametroModelo param : modelo.getParametros()) {
            this.parametros.put(param.getParametro().getNomeParametro(),
                    agendamentoComunicacao.getValorParametro(param.getParametro().getNomeParametro()));
        }

        envio.setTitulo(formataTexto(modelo.getTituloModelo()));
        return agendamentoEnvioRepository.save(envio);
    }

    @Override
    public AgendamentoEnvio findById(@NotNull Long seqEnvio) {
        Optional<AgendamentoEnvio> optional = agendamentoEnvioRepository.findById(seqEnvio);

        if(!optional.isPresent()) {
            throw new InternalServerError("Agendamento envio não encontrado");
        }

        return optional.get();
    }

    @Override
    public TypeStatusAgendamento findStatusAgendamento(@NotNull Long seqAgendamento) {
        return agendamentoEnvioRepository.findStatusAgendamento(seqAgendamento);
    }

    private String formataTexto(String texto) {

        String txtRetorno = texto;

        String[] vars = StringUtils.substringsBetween(texto, "[", "]");

        if (vars != null) {
            for (String var : vars) {
                if (this.parametros.containsKey(var)) {
                    String valor = this.parametros.get(var);
                    if (valor == null) {
                        throw new InternalServerError("Parâmetro " + var + " não informado");
                    }
                    txtRetorno = txtRetorno.replace("[" + var + "]", valor);
                }
            }
        }
        return txtRetorno;
    }

}
