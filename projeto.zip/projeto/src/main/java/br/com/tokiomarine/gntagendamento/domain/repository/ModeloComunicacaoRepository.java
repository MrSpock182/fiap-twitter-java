package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.ModeloComunicacao;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ModeloComunicacaoRepository extends PagingAndSortingRepository<ModeloComunicacao, Long>,
        JpaSpecificationExecutor<ModeloComunicacao> {

    ModeloComunicacao findByCodigo(String modelo);

}