package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "DOCUMENTOS_COMUNICACAO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class DocumentoComunicacao implements Serializable {

    @Id
    @Column(name="CD_DOCUMENTO")
    private Long codDocumento;

    @Column(name="DS_DOCUMENTO")
    private String descDocumento;

    @Column(name="DT_ATUALIZACAO")
    private Date dtAtualizacao;

    @Column(name="NM_USUARIO_ATUALIZACAO")
    private String nomeUsuarioAtualizacao;

}
