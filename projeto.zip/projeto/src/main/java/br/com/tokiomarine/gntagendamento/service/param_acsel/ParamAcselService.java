package br.com.tokiomarine.gntagendamento.service.param_acsel;

import br.com.tokiomarine.gntagendamento.domain.orm.ParamAcsel;
import org.jetbrains.annotations.NotNull;

public interface ParamAcselService {
    ParamAcsel findDistinctByGrpParamAcselCodGrpParametroAndCodParametro(@NotNull String codGrpParametro,@NotNull String codParametro);
}
