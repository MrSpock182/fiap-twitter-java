package br.com.tokiomarine.gntagendamento.api.v1;

import org.springframework.web.bind.annotation.*;
import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoResponse;
import br.com.tokiomarine.gntagendamento.domain.type.TypeStatusAgendamento;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.exception.NotFoundException;
import br.com.tokiomarine.gntagendamento.service.agendamento_comunicacao.AgendamentoComunicacaoService;
import br.com.tokiomarine.gntagendamento.service.agendamento_envio.AgendamentoEnvioService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping(value = "/v1/agendamento")
public class AgendamentoRest {

    @Autowired
    private AgendamentoEnvioService agendamentoEnvioService;

    @Autowired
    private AgendamentoComunicacaoService agendamentoComunicacaoService;

    @ApiOperation(value = "Agendamento",
            response = String.class,
            notes = "Serviço de agendamento do GNT")
    @ApiResponses(value= {
            @ApiResponse(
                    code = 400,
                    message ="Erro na requisição",
                    response = BadRequest.class
            ),
            @ApiResponse(
                    code = 404,
                    message ="Requisição não encontrada",
                    response = NotFoundException.class
            ),
            @ApiResponse(
                    code = 500,
                    message ="Erro interna na aplicação",
                    response = InternalServerError.class
            )
    })

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/incluir")
    public AgendamentoResponse incluir(@RequestParam("envia") String envia, @RequestBody AgendamentoRequest agendamentoRequest) {
        try {

            return agendamentoComunicacaoService.incluirAgendamento(envia, agendamentoRequest);
        } catch (Exception ex) {
            return AgendamentoResponse.builder()
                    .codigoRetorno(-1)
                    .mensagemRetorno(ex.getMessage())
                    .build();
        }
    }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/status/{seqAgendamento}")
    public TypeStatusAgendamento status(@PathVariable("seqAgendamento") Long seqAgendamento) {
        return agendamentoEnvioService.findStatusAgendamento(seqAgendamento);
    }

}
