package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class InfoDTO {
    private Integer codInfo;
    private Integer codCorretor;
    private Integer codTipoInfo;
    private String conteudoInfo;
    private String codProduto;
    private Date dtInicioVigencia;
    private String codUsuarioUltimaAlteracao;
    private Integer grupoTipoInfo;
}
