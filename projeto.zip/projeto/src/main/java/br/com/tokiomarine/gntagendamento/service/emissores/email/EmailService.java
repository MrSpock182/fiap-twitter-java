package br.com.tokiomarine.gntagendamento.service.emissores.email;

public interface EmailService {
    void emailTemplate(String destinatario, String codigo, String template);
}
