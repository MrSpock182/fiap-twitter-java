package br.com.tokiomarine.gntagendamento.enumerable;

public enum TipoModelo {
    EMAIL("EMAIL", "EMAIL"),
    SMS("SMS", "SMS"),
    PUSH("PUSH", "PUSH NOTIFICATION"),
    WHATSAPP("WTAPP", "WHATSAPP");

    private String value;
    private String descricao;

    TipoModelo(String value, String desc) {
        this.value = value;
        this.descricao = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDescricao() {
        return descricao;
    }

    public static TipoModelo get(String status) {
        for (TipoModelo tipo : TipoModelo.values()) {
            if (tipo.value.equals(status)) {
                return tipo;
            }
        }
        return null;
    }

}
