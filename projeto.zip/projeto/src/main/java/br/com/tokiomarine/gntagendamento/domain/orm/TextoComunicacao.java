package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "TEXTO_COMUNICACAO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class TextoComunicacao implements Serializable {

    @Id
    @Column(name="CD_TEXTO")
    private Long codTexto;

    @Column(name="NM_TEXTO")
    private String nomeTexto;

    @Column(name="CD_TIPO_MODELO")
    private String tipoModelo;

    @Column(name="DS_TEXTO")
    private String descTexto;

    @Column(name="TIP_TEXTO")
    private String tipoTexto;

    @Column(name="DS_FORMATACAO_TEXTO")
    private String formatacao;

}
