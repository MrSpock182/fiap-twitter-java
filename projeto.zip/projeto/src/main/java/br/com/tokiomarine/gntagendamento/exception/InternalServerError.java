package br.com.tokiomarine.gntagendamento.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class InternalServerError extends RuntimeException {
	private static final long serialVersionUID = 6161227793226026577L;
	
	public InternalServerError() {
		super();
	}

	public InternalServerError(final String message) {
		super(message);
	}

	public InternalServerError(final String message, final Throwable cause) {
		super(message, cause);
	}

	public InternalServerError(final Throwable cause) {
		super(cause);
	}
}
