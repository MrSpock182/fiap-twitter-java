package br.com.tokiomarine.gntagendamento.service.validation;

import br.com.tokiomarine.gntagendamento.domain.repository.ParamAcselRepository;
import br.com.tokiomarine.gntagendamento.enumerable.TipoModelo;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ValidationBuilder {

    @Autowired
    private ParamAcselRepository paramAcselRepository;

    public ValidationImpl getValidation(@NotNull String tipoModelo) {
        switch (TipoModelo.get(tipoModelo)) {
            case SMS:
                return ValidationSms.builder().build();
            case EMAIL:
                return new ValidationEmail(paramAcselRepository);
            case PUSH:
                return ValidationImpl.builder().build();
            case WHATSAPP:
                return ValidationImpl.builder().build();
            default:
                throw new BadRequest("Emissor não existe para validação");
        }
    }

}
