package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.DocumentoComunicacao;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentoComunicacaoRepository extends PagingAndSortingRepository<DocumentoComunicacao, Long>,
        JpaSpecificationExecutor<DocumentoComunicacao> {
}
