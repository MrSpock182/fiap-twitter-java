package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;

import java.util.Base64;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AnexoEmail {
    private String nome;
    private String fileBase64;
    private byte [] binario;

    public static class AnexoEmailBuilder {
        public AnexoEmailBuilder binario(String arquivoBase64) {
            byte[] bytes = arquivoBase64.getBytes();
            byte[] decode = Base64.getDecoder().decode(bytes);
            this.binario = decode;
            return this;
        }
    }
}
