package br.com.tokiomarine.gntagendamento.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoResponse {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Long seqAgendamento;
    private Integer codigoRetorno;
    private String mensagemRetorno;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Link link;
}
