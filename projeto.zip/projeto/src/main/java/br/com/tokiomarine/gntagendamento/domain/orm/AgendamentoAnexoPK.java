package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode
public class AgendamentoAnexoPK implements Serializable {
    private static final long serialVersionUID = -648652861L;

    private Long id;
    private AgendamentoComunicacao agendamento;
}
