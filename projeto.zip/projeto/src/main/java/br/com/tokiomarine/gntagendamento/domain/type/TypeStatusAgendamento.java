package br.com.tokiomarine.gntagendamento.domain.type;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoErro;
import org.springframework.data.rest.core.config.Projection;

import java.util.Date;

@Projection(name = "typeStatusAgendamento", types = {AgendamentoEnvio.class, AgendamentoErro.class})
public interface TypeStatusAgendamento {
    Long getSeqAgendamento();
    String getStatusEnvio();
    String getMensagemErro();
    Date getDataSolicitacao();
    Date getDataEnvio();
}
