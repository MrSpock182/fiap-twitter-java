package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@IdClass(ParamAcselPK.class)
@Table(name = "TAB_PARAM_ACSEL")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ParamAcsel implements Serializable {

    @Id
    @Column(name="ID_GRP_PARAMETRO")
    private Integer idGrpParamAcsel;

    @Id
    @Column(name="COD_PARAMETRO")
    private String codParametro;

    @Column(name="DESC_PARAMETRO")
    private String descParametro;

    @Column(name="VLR_PARAMETRO")
    private String vlrParametro;

    @Column(name="COD_USU_ULT_ALTER")
    private String codUsuarioAlter;

    @Column(name="DT_ULTIMA_ALTER")
    private Date dtUltimaAlter;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(insertable=false, updatable=false, name = "ID_GRP_PARAMETRO", referencedColumnName = "ID_GRP_PARAMETRO")
    private GrpParamAcsel grpParamAcsel;

}
