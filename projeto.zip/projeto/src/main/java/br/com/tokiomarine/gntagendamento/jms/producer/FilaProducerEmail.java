package br.com.tokiomarine.gntagendamento.jms.producer;

import br.com.tokiomarine.gntagendamento.util.StackLogger;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
class FilaProducerEmail {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    private StackLogger stackLogger;

    @Value("${queue.email.boot}")
    private String queue;

    void produce(@NotNull Long seqEnvio) {
        try {
            jmsTemplate.convertAndSend(queue, seqEnvio);
        } catch (Exception ex) {
            log.error( "Erro producer: " + seqEnvio + " Stack:" + stackLogger.getMessage(ex));
            throw new InternalError("Erro ao produzir mensagem de email na fila");
        }
    }

}
