package br.com.tokiomarine.gntagendamento.service.agendamento_erro;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import org.jetbrains.annotations.NotNull;

public interface AgendamentoErroService {
    void incluirErro(@NotNull AgendamentoEnvio envio,@NotNull String msgErro);
}
