package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ParametroComunicacaoDTO {
    private Long seqAgendamento;
    private Long codParametro;
    private String descParametro;
    private String valorParametro;
    private String nomeParametro;
}
