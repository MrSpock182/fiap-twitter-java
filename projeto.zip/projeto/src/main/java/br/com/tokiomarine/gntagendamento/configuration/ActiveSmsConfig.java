package br.com.tokiomarine.gntagendamento.configuration;

import br.com.tokiomarine.gntagendamento.jms.consumer.FilaConsumer;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.listener.SimpleMessageListenerContainer;

import javax.annotation.PostConstruct;
import javax.jms.ConnectionFactory;

@EnableJms
@Configuration
public class ActiveSmsConfig {

    @Autowired
    private ConfigurableListableBeanFactory beanFactory;

    @Autowired
    private String[] failOverConnectionString;

    @Value("${queue.sms.boot}")
    private String queueSms;

    @Value("${spring.activemq.custom.user}")
    private String user;

    @Value("${spring.activemq.custom.password}")
    private String pwd;

    @PostConstruct
    public void contextConstruct() {
        consumer();
    }

    private void consumer() {
        String[] connections = failOverConnectionString;

        for (String servidor : connections) {

            SimpleMessageListenerContainer consumer = new SimpleMessageListenerContainer();

            String brokerURL = String.format(
                    "failover:(%s)?randomize=false&startupMaxReconnectAttempts=1&maxReconnectAttempts=1&priorityBackup=true&priorityURIs=%s",
                    servidor, servidor);

            consumer.setConnectionFactory(getConnectionFactory(brokerURL));
            consumer.setDestinationName(queueSms);

            FilaConsumer filaConsumer = new FilaConsumer();
            beanFactory.autowireBean(filaConsumer);

            consumer.setMessageListener(filaConsumer);

            consumer.start();
        }
    }

    private ConnectionFactory getConnectionFactory(String brokerURL) {
        return new CachingConnectionFactory(
                new ActiveMQConnectionFactory(this.user, this.pwd, brokerURL));

    }

}
