package br.com.tokiomarine.gntagendamento.jms.producer;

import br.com.tokiomarine.gntagendamento.util.StackLogger;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
class FilaProducerSms {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    private StackLogger stackLogger;

    @Value("${queue.sms.boot}")
    private String queue;

    void produce(@NotNull Long seqEnvio) {
        try {
            jmsTemplate.convertAndSend(queue, seqEnvio);
        } catch (Exception ex) {
            log.error( "Erro producer: " + seqEnvio + " Stack:" + stackLogger.getMessage(ex));
            throw new InternalError("Erro ao produzir mensagem de sms na fila");
        }
    }

}
