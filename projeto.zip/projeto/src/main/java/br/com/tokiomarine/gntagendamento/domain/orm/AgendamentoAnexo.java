package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(AgendamentoAnexoPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_ANEXO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoAnexo implements Serializable {

    @Id
    @Column(name="CD_ANEXO_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
    private AgendamentoComunicacao agendamento;

    @Column(name="NM_ANEXO_NOME")
    private String nome;

    @Lob
    @Column(name="DS_ANEXO_ARQBASE64", columnDefinition="CLOB NOT NULL")
    private String arquivoBase64;

}
