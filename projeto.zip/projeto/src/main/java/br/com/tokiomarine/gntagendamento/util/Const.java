package br.com.tokiomarine.gntagendamento.util;

public class Const {

    public static final String ATIVA_RESPOSTA_SMS = "S";
    public static final String INATIVA_RESPOSTA_SMS = "N";
    public static final String VALIDA_MODELO = "S";
    public static final String TEXT_CHARSET = "text/plain; charset=UTF-8";

    private Const() {

    }

}
