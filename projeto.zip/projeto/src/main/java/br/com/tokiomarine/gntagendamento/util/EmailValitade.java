package br.com.tokiomarine.gntagendamento.util;

import br.com.tokiomarine.gntagendamento.domain.orm.ParamAcsel;
import br.com.tokiomarine.gntagendamento.domain.repository.ParamAcselRepository;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

@Component
public class EmailValitade {

    @Autowired
    private ParamAcselRepository paramAcselRepository;

    public void valitade(@NotNull String email) {
        try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
        } catch (AddressException ex) {
            throw new BadRequest("Email: " + email + " invalido.");
        }
    }

    public void emailExterno(@NotNull String email) {
        ParamAcsel paramAcsel = paramAcselRepository
                .findDistinctByGrpParamAcselCodGrpParametroAndCodParametro("PUSH_NOTIFICATION", "ENVIA_EMAIL_EXTERNO");

        if (!"S".equalsIgnoreCase(paramAcsel.getVlrParametro()) &&
                !email.toUpperCase().contains("@TOKIOMARINE.COM.BR")) {
            throw new BadRequest("Email externo habilitado, EMAIL: " + email + " fora do dominio tokio marine");
        }
    }

}
