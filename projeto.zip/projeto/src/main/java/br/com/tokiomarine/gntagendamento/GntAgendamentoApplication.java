package br.com.tokiomarine.gntagendamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GntAgendamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GntAgendamentoApplication.class, args);
	}

}

