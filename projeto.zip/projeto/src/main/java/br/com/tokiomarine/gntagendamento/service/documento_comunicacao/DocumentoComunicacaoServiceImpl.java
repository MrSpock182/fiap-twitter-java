package br.com.tokiomarine.gntagendamento.service.documento_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.dto.DocumentoComunicacaoDTO;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoDocumento;
import br.com.tokiomarine.gntagendamento.domain.orm.DocumentoComunicacao;
import br.com.tokiomarine.gntagendamento.domain.repository.DocumentoComunicacaoRepository;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DocumentoComunicacaoServiceImpl implements  DocumentoComunicacaoService {

    @Autowired
    private DocumentoComunicacaoRepository documentoComunicacaoRepository;

    @Override
    public void setDocumento(@NotNull AgendamentoComunicacao agendamento,@NotNull List<DocumentoComunicacaoDTO> documentos) {
        for (DocumentoComunicacaoDTO documento : documentos) {
            DocumentoComunicacao doc = findById(documento.getCodDocumento());

            AgendamentoDocumento docAgend = new AgendamentoDocumento();
            docAgend.setAgendamento(agendamento);
            docAgend.setDocumento(doc);
            docAgend.setIndEnviaEmail(documento.getIndEnviaEmail());
            docAgend.setUrlArquivo(documento.getUrlDocumento());

            agendamento.setDocumentos(docAgend);
        }
    }

    @Override
    public DocumentoComunicacao findById(@NotNull Long codDocumento) {
        Optional<DocumentoComunicacao> optional = documentoComunicacaoRepository.findById(codDocumento);

        if(!optional.isPresent()) {
            throw new BadRequest("Documento " + codDocumento + " não encontrado");
        }

        return optional.get();
    }
}
