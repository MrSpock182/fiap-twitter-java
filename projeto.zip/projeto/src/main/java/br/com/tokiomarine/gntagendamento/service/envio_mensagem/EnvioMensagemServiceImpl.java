package br.com.tokiomarine.gntagendamento.service.envio_mensagem;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.domain.repository.AgendamentoComunicacaoRepository;
import br.com.tokiomarine.gntagendamento.domain.repository.AgendamentoEnvioRepository;
import br.com.tokiomarine.gntagendamento.enumerable.StatusAgendamento;
import br.com.tokiomarine.gntagendamento.jms.producer.FilaProducer;
import br.com.tokiomarine.gntagendamento.service.agendamento_envio.AgendamentoEnvioService;
import br.com.tokiomarine.gntagendamento.service.agendamento_erro.AgendamentoErroService;
import br.com.tokiomarine.gntagendamento.service.emissores.comunicador.ComunicadorService;
import br.com.tokiomarine.gntagendamento.util.StackLogger;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class EnvioMensagemServiceImpl implements EnvioMensagemService {

    @Autowired
    private StackLogger stackLogger;

    @Autowired
    private FilaProducer filaProducer;

    @Autowired
    private AgendamentoEnvioRepository agendamentoEnvioRepository;

    @Autowired
    private AgendamentoComunicacaoRepository agendamentoComunicacaoRepository;

    @Autowired
    private ComunicadorService comunicadorService;

    @Autowired
    private AgendamentoErroService agendamentoErroService;

    @Autowired
    private AgendamentoEnvioService agendamentoEnvioService;

    @Override
    public void enviarAgendamento(@NotNull Long seqEnvio) {
        AgendamentoEnvio agendamentoEnvio = agendamentoEnvioService.findById(seqEnvio);
        boolean reenvio = agendamentoEnvio.getQuantidadeEnvio() > 0;

        try {
            comunicadorService.enviar(agendamentoEnvio);
            agendamentoEnvio.setStatusEnvio(StatusAgendamento.ENVIADO.getValue());
            agendamentoEnvio.setDtEnvio(new Date());
        } catch (Exception ex) {
            agendamentoEnvio.setStatusEnvio(StatusAgendamento.ERRO.getValue());
            agendamentoErroService.incluirErro(agendamentoEnvio, "Erro ao enviar agendamento: " + ex.getMessage());
            log.error("Erro envio agendamento: " + stackLogger.getMessage(ex), ex);
        }

        agendamentoEnvioService.save(agendamentoEnvio);
        if(!reenvio) {
            agendamentoEnvio.getAgendamento().setDtEnvioOriginal(agendamentoEnvio.getDtEnvio());
            agendamentoEnvio.getAgendamento().setStatusAgendamento(agendamentoEnvio.getStatusEnvio());
            agendamentoComunicacaoRepository.save(agendamentoEnvio.getAgendamento());
        }
    }

    @Override
    public void reenviarAgendamento(@NotNull List<Long> seqAgendamentos) {
        reenviarAgendamentoPendente(seqAgendamentos);
        reenviarAgendamentoNaoEnviado(seqAgendamentos);
    }

    private void reenviarAgendamentoPendente(@NotNull List<Long> seqAgendamentos) {
        for (Long seqAgendamento : seqAgendamentos) {
            AgendamentoEnvio agendamentoEnvio = agendamentoEnvioRepository
                    .findByAgendamentoSeqAgendamentoAndStatusEnvio(seqAgendamento, "PND");
            filaProducer.producer(agendamentoEnvio);
        }
    }

    private void reenviarAgendamentoNaoEnviado(@NotNull List<Long> seqAgendamentos) {
        for (Long seqAgendamento : seqAgendamentos) {
            AgendamentoEnvio agendamentoEnvio = agendamentoEnvioRepository
                    .findByAgendamentoSeqAgendamentoAndStatusEnvio(seqAgendamento, "NEV");
            filaProducer.producer(agendamentoEnvio);
        }
    }
}
