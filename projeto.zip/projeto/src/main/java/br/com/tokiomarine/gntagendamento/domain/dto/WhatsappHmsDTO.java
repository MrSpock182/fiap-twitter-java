package br.com.tokiomarine.gntagendamento.domain.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class WhatsappHmsDTO {
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String namespace;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String elementName;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> parameters;
}
