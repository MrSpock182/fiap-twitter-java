package br.com.tokiomarine.gntagendamento.enumerable;

public enum StatusAgendamento {
    NAOENVIADO("NEV", "NÃO ENVIADO"),
    PENDENTE("PND", "PENDENTE"),
    FINALIZADO("FIN", "FINALIZADO"),
    ERRO("ERR", "ERRO"),
    ENVIADO("ENV", "ENVIADO"),
    PILOTO("PIL", "PILOTO");

    private String value;
    private String descricao;

    StatusAgendamento(String value, String desc) {
        this.value = value;
        this.descricao = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDescricao() {
        return descricao;
    }

    public static StatusAgendamento get(String status) {
        for (StatusAgendamento tipo : StatusAgendamento.values()) {
            if (tipo.value.equals(status)) {
                return tipo;
            }
        }
        return null;
    }
}
