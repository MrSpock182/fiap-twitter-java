package br.com.tokiomarine.gntagendamento.service.body_mail;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoListDocumentos;
import br.com.tokiomarine.gntagendamento.util.BodyMailUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;

@Builder
@AllArgsConstructor
public class ProcessaListaDocumentos {

    private List<AgendamentoListDocumentos> listaDocumentos;

    public void processar(Element tag) {
        Node tagClone = tag.cloneNode(true);
        BodyMailUtil.removeChilds(tag);

        for (AgendamentoListDocumentos agendamentoListDocumentos : this.listaDocumentos) {
            Node doc = tagClone.cloneNode(true);

            NodeList tagsDoc = ((Element) doc).getElementsByTagName("*");

            for (int j = 0; j < tagsDoc.getLength(); j++) {

                Element tagDoc = (Element) tagsDoc.item(j);

                if (tagDoc.getTagName().equals("a")) {
                    tagDoc.setAttribute("href", agendamentoListDocumentos.getUrlArquivo());
                    tagDoc.setTextContent(agendamentoListDocumentos.getNomeDocumento());
                }
            }

            for (int j = 0; j < tagsDoc.getLength(); j++) {
                if (tagsDoc.item(j).getParentNode().equals(doc)) {
                    tag.appendChild(tagsDoc.item(j).cloneNode(true));
                }
            }
        }
    }

}
