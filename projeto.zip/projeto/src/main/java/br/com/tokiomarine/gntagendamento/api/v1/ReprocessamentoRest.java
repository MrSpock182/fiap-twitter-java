package br.com.tokiomarine.gntagendamento.api.v1;

import br.com.tokiomarine.gntagendamento.service.envio_mensagem.EnvioMensagemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/v1/reprocessamento")
public class ReprocessamentoRest {

    @Autowired
    private EnvioMensagemService envioMensagemService;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/enviar")
    public void reprocessar(@RequestBody List<Long> seqAgendamentos) {
        envioMensagemService.reenviarAgendamento(seqAgendamentos);
    }

}