package br.com.tokiomarine.gntagendamento.service.emissores.mobile;

import br.com.tokiomarine.gntagendamento.domain.orm.*;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.util.StringUtil;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

class MobileServiceImpl {

    String formataTexto(Map<String, String> parametros, String texto) {
        String txtRetorno = texto;

        String[] vars = StringUtils.substringsBetween(texto, "[", "]");

        if (vars != null) {
            for (String var : vars) {
                if (parametros.containsKey(var)) {
                    String valor = parametros.get(var);
                    if (valor == null) {
                        throw new InternalServerError("Parâmetro " + var + " não informado");
                    }
                    txtRetorno = txtRetorno.replace("[" + var + "]", valor);
                }
            }
        }
        return txtRetorno;
    }

    void mensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        String mensagem;

        Map<String, String> parametros = new HashMap<>();
        Map<String, String> params = new HashMap<>();
        AgendamentoComunicacao agend = agendamentoEnvio.getAgendamento();
        ModeloComunicacao modelo = agend.getModelo();


        for (ParametroModelo paramModelo : modelo.getParametros()) {
            parametros.put(paramModelo.getParametro().getNomeParametro(),
                    agend.getValorParametro(paramModelo.getParametro().getNomeParametro()));
        }

        for (TextoModeloComunicacao texto : modelo.getTextos()) {
            if (texto.getTextoComunicacao().getTipoTexto().equals("P")) {
                params.put("chamada", formataTexto(parametros, texto.getTexto()));
            } else {
                params.put("mensagem", formataTexto(parametros, texto.getTexto()));
            }
        }

        try {
            mensagem = StringUtil.serialize(params);
        } catch (Exception e) {
            throw new InternalServerError("Erro ao formatar mensagem: " + e.getMessage());
        }

        agendamentoEnvio.setAgendamentoComunicacaoMensagemEnviada(mensagem);
    }

}
