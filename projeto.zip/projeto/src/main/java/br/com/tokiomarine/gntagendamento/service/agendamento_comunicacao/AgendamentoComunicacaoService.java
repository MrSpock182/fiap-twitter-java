package br.com.tokiomarine.gntagendamento.service.agendamento_comunicacao;

import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoRequest;
import br.com.tokiomarine.gntagendamento.domain.dto.AgendamentoResponse;

public interface AgendamentoComunicacaoService {
    AgendamentoResponse incluirAgendamento(String envia, AgendamentoRequest agendamentoRequest);
}
