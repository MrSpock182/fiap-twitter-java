package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;
import org.jetbrains.annotations.NotNull;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class DocumentoComunicacaoDTO {
    private Long seqAgendamento;
    @NotNull(value = "Código documento obrigatório")
    private Long codDocumento;
    @NotNull(value = "URL do documento obrigatória")
    private String urlDocumento;
    @NotNull(value = "Identificador de envio obrigatório")
    private String indEnviaEmail;
}
