package br.com.tokiomarine.gntagendamento.service.body_mail;

import br.com.tokiomarine.gntagendamento.domain.orm.ModeloComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.TextoModeloComunicacao;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.util.BodyMailUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;

@Builder
@AllArgsConstructor
public class ProcessaModelo {

    private static final String IMG_FOOTER = "imgFooter";
    private static final String IMG_HEADER = "imgHeader";
    private static final String ATTR_NAME = "class";

    private Document emailHtml;
    private DocumentBuilder documentBuilder;
    private ModeloComunicacao modeloComunicacao;
    private ProcessaTexto processaTexto;
    private ProcessaImagem processaImagem;
    private ProcessaVariaveis processaVariaveis;
    private ProcessaDocumentos processaDocumentos;
    private ProcessaListaDocumentos processaListaDocumentos;

    public void processar() {
        NodeList tags = emailHtml.getElementsByTagName("*");

        for (int i = 0; i < tags.getLength(); i++) {
            Element tag = (Element) tags.item(i);

            if ("img".equalsIgnoreCase(tag.getNodeName())) {
                if (tag.getAttribute(ATTR_NAME).contains(IMG_FOOTER)
                        && modeloComunicacao.getCodImagem() != null) {
                    processaImagem.processar(tag, modeloComunicacao.getCodImagem());
                } else if (tag.getAttribute(ATTR_NAME).contains(IMG_HEADER)) {
                    processaImagem.processar(tag, Long.parseLong(tag.getAttribute("id")));
                }
            }

            if (tag.getAttribute("id").contains("body")) {
                incluirTextos(tag);
            }
        }
    }

    private void incluirTextos(@NotNull Element tag) {
        String seqTexto = null;
        try {
            for (TextoModeloComunicacao texto : modeloComunicacao.getTextos()) {

                Element el = (Element) BodyMailUtil
                        .createNode(documentBuilder, emailHtml, texto.getTextoComunicacao().getFormatacao());

                tag.appendChild(el);
                seqTexto = texto.getNumeroSeq().toString();

                switch (texto.getTextoComunicacao().getTipoTexto()) {
                    case "T":
                        processaTexto.processar(el, texto.getTexto());
                        break;
                    case "V":
                        processaVariaveis.processar(el);
                        break;
                    case "D":
                        processaDocumentos.processar(el);
                        break;
                    case "I":
                        processaImagem.processar(el, texto.getCodigoImagem());
                        break;
                    case "L":
                        processaListaDocumentos.processar(el);
                        break;
                    default:
                        throw new InternalServerError("Nenhum tipo de comunicação encontrada para a inclusão do texto");
                }
            }

        } catch (Exception e) {
            throw new InternalServerError(String.format("Sequencia texto: %s - %s", seqTexto, e.getMessage()));
        }
    }

}
