package br.com.tokiomarine.gntagendamento.util;

import org.jetbrains.annotations.NotNull;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatter {

	private DateFormatter() {
		
	}
	
	public static String getBaseDate(@NotNull Date date) throws InternalError {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		return dateFormat.format(date);
	}

	public static String getSimpleDate(@NotNull Date date) throws InternalError {
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
		return dateFormat.format(date);
	}

	public static String getBaseDateHour(@NotNull Date date) throws InternalError {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		return dateFormat.format(date);
	}
	
	public static Date convertToDate(@NotNull String date) throws InternalError {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			return dateFormat.parse(date);
		} catch (ParseException e) {
			throw new InternalError("Erro ao converter texto para data");
		}
	}
	
	public static Date convertToDateHour(@NotNull String date) throws InternalError {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			return dateFormat.parse(date);
		} catch (ParseException e) {
			throw new InternalError("Erro ao converter texto para data");
		}
	}
	
}
