package br.com.tokiomarine.gntagendamento.service.body_mail;

import br.com.tokiomarine.gntagendamento.domain.orm.ModeloComunicacao;
import br.com.tokiomarine.gntagendamento.domain.orm.ParametroModelo;
import br.com.tokiomarine.gntagendamento.util.BodyMailUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.HashMap;

@Builder
@AllArgsConstructor
public class ProcessaVariaveis {

    private static final String ATTR_NAME = "class";

    private HashMap<String, String> parametros;
    private ModeloComunicacao modeloComunicacao;

    public void processar(Element tag) {
        Node tagClone = tag.cloneNode(true);
        BodyMailUtil.removeChilds(tag);

        for (ParametroModelo param : modeloComunicacao.getParametros()) {
            if ("S".equals(param.getIndExibeLista())) {
                String valor = this.parametros.get(param.getParametro().getNomeParametro());

                if (valor == null) {
                    continue;
                }

                Node var = tagClone.cloneNode(true);
                NodeList tagsVar = ((Element) var).getElementsByTagName("*");
                setTag(param, tagsVar, valor);
                appendTag(tag, var, tagsVar);
            }
        }
    }

    private void setTag(ParametroModelo param, NodeList tagsVar, String valor) {
        for (int j = 0; j < tagsVar.getLength(); j++) {

            Element tagVar = (Element) tagsVar.item(j);

            if (tagVar.getAttribute(ATTR_NAME).contains("nome")) {
                tagVar.setTextContent(param.getNomeExibicao());
            } else if (tagVar.getAttribute(ATTR_NAME).contains("valor")) {
                tagVar.setTextContent(valor);
            }
        }
    }

    private void appendTag(Element tag, Node var, NodeList tagsVar) {
        for (int j = 0; j < tagsVar.getLength(); j++) {
            if (tagsVar.item(j).getParentNode().equals(var)) {
                tag.appendChild(tagsVar.item(j).cloneNode(true));
            }
        }
    }

}
