package br.com.tokiomarine.gntagendamento.domain.dto;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ListDocComunicacao {
    private Long seqAgendamento;
    private String nomeDocumento;
    private String urlDocumento;
    private String indEnviaEmail;
}
