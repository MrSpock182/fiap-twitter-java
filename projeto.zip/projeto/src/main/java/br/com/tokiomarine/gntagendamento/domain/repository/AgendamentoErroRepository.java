package br.com.tokiomarine.gntagendamento.domain.repository;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoErro;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgendamentoErroRepository extends PagingAndSortingRepository<AgendamentoErro, Long>,
        JpaSpecificationExecutor<AgendamentoErro> {
}
