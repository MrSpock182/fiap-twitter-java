package br.com.tokiomarine.gntagendamento.enumerable;

import br.com.tokiomarine.gntagendamento.util.Const;
import org.apache.commons.lang.StringUtils;

public enum MimeTypeEnum {

    CSV("csv", "text/csv; charset=UTF-8"),
    DOC("doc", "application/msword"),
    DOCX("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    LOG("log", Const.TEXT_CHARSET),
    PDF("pdf", "application/pdf"),
    TXT("txt", Const.TEXT_CHARSET),
    TEXT("text", Const.TEXT_CHARSET),
    XLS("xls", "application/excel"),
    XLSX("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

    private String extensaoArquivo;
    private String mimeType;

    MimeTypeEnum(String extensaoArquivo, String mimeType) {
        this.extensaoArquivo = extensaoArquivo;
        this.mimeType = mimeType;
    }

    public String getExtensaoArquivo() {
        return this.extensaoArquivo;
    }

    public String getMimeType() {
        return this.mimeType;
    }

    public static String getMimeTypeByExtensao(String extensaoArquivo) {
        if (Boolean.TRUE.equals(StringUtils.isNotEmpty(extensaoArquivo))) {
            for (MimeTypeEnum mime : MimeTypeEnum.values()) {
                if (mime.extensaoArquivo.equalsIgnoreCase(extensaoArquivo)) {
                    return mime.getMimeType();
                }
            }
        }
        return null;
    }
}
