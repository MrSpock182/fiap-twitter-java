package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "IMAGENS_COMUNICACAO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ImagemComunicacao implements Serializable {

    @Id
    @Column(name="CD_IMAGEM")
    private Long codImagem;

    @Column(name="NM_IMAGEM")
    private String nomeImagem;

    @Column(name="DS_IMAGEM")
    private String descImagem;

    @Column(name="URL_IMAGEM")
    private String url;

    @Column(name="ALTURA")
    private Integer altura;

    @Column(name="LARGURA")
    private Integer largura;

    @Column(name="DT_ATUALIZACAO")
    private Date dtAtualizacao;

    @Column(name="NM_USUARIO_ATUALIZACAO")
    private String nomeUsuarioAtualizacao;

}
