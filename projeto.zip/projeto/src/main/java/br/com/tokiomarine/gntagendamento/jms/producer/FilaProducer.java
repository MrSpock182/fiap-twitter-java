package br.com.tokiomarine.gntagendamento.jms.producer;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.enumerable.TipoModelo;
import br.com.tokiomarine.gntagendamento.exception.BadRequest;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class FilaProducer {

    @Autowired
    private FilaProducerEmail emailProducer;

    @Autowired
    private FilaProducerPush pushProducer;

    @Autowired
    private FilaProducerSms smsProducer;

    @Autowired
    private FilaProducerWhatsapp whatsappProducer;

    public void producer(@NotNull AgendamentoEnvio envio) {
        log.info("Enviando para fila mensagem: " + envio.getSeqEnvio());

        String tipoModelo = envio.getAgendamento().getModelo().getTipoModelo();
        switch (TipoModelo.get(tipoModelo)) {
            case SMS:
                smsProducer.produce(envio.getSeqEnvio());
                break;
            case EMAIL:
                emailProducer.produce(envio.getSeqEnvio());
                break;
            case PUSH:
                pushProducer.produce(envio.getSeqEnvio());
                break;
            case WHATSAPP:
                whatsappProducer.produce(envio.getSeqEnvio());
                break;
            default:
                throw new BadRequest("Fila de produção não encontrada.");
        }
    }

}
