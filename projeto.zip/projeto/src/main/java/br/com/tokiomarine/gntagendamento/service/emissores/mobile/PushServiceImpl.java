package br.com.tokiomarine.gntagendamento.service.emissores.mobile;

import br.com.tokiomarine.gntagendamento.domain.orm.AgendamentoEnvio;
import br.com.tokiomarine.gntagendamento.exception.InternalServerError;
import br.com.tokiomarine.gntagendamento.service.emissores.EmissorService;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

@Service
public class PushServiceImpl implements EmissorService {

    @Override
    public void enviarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        throw new InternalServerError("Emissor não implementado");
    }

    @Override
    public void gerarMensagem(@NotNull AgendamentoEnvio agendamentoEnvio) {
        throw new InternalServerError("Emissor não implementado");
    }
}
