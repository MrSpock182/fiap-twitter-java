package br.com.tokiomarine.gntagendamento.domain.orm;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "MODELO_COMUNICACAO_TEXTO_HIST")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ModeloComunicacaoTextoHist implements Serializable {

    @Id
    @Column(name="CD_MODELO_COM_TEXTO_HIST")
    private Long codTextoHist;

    @Column(name="CD_TEXTO")
    private Integer textoModelo;

    @Column(name="DS_TEXTO")
    private String texto;

    @Column(name="CD_SEQUENCIA")
    private Integer sequencia;

    @Column(name="CD_IMAGEM")
    private Long imagem;

    @Column(name="DT_INCLUSAO")
    private Date inclusao;

    @Column(name="NM_USUARIO_INCLUSAO")
    private String usuarioInclusao;

    @Column(name="TP_MOVIM")
    private String movim;

    @Column(name="INICIO_VIGENCIA")
    private Date inicioVigencia;

    @Column(name="FINAL_VIGENCIA")
    private Date finalVigencia;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name="CD_MODELO_COMUNICACAO", referencedColumnName="CD_MODELO_COMUNICACAO")
    private ModeloComunicacao modelo;
}
