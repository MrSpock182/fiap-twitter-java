package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode
public class AgendamentoComCopiaPK implements Serializable {
    private static final long serialVersionUID = 3342963990492235120L;

    private AgendamentoComunicacao agendamento;
    private Integer seqCopia;
}
