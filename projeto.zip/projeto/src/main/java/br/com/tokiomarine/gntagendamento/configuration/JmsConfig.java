package br.com.tokiomarine.gntagendamento.configuration;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

@Configuration
public class JmsConfig {

    @Bean
    public JmsTemplate jmsTemplate(@Value("${spring.activemq.custom.broker-url}") String url,
                                   @Value("${spring.activemq.custom.user}") String user, @Value("${spring.activemq.custom.password}") String pwd) {

        return new JmsTemplate(
                new CachingConnectionFactory(new ActiveMQConnectionFactory(user, pwd, url)));
    }

    @Bean
    public String[] failOverConnectionString(@Value("${spring.activemq.custom.broker-url}") String url) {
        int i = url.indexOf('?');

        if (i > -1) {
            url = url.substring(0, (i - 1));
        }

        return url.replace("failover:", "").replace("(", "").replace(")", "").split("[,]");
    }

}
