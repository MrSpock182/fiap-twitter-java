package br.com.tokiomarine.gntagendamento.service.envio_mensagem;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface EnvioMensagemService {
    void enviarAgendamento(@NotNull Long seqEnvio);
    void reenviarAgendamento(@NotNull List<Long> seqAgendamentos);
}
