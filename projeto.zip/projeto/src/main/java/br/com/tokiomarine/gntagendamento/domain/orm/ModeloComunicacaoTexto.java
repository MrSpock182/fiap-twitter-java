package br.com.tokiomarine.gntagendamento.domain.orm;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "MODELO_COMUNICACAO_TEXTO")
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ModeloComunicacaoTexto implements Serializable {

    @Id
    @Column(name="CD_MODELO_COM_TEXTO")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="modeloComTextoGenerator")
    @SequenceGenerator(name = "modeloComTextoGenerator", sequenceName = "SQ_MODELO_COMUNIC_TEXTO",allocationSize=1)
    private Long idTexto;

    @Column(name="DS_TEXTO")
    private String texto;

    @Column(name="CD_IMAGEM", insertable=false, updatable=false)
    private Long codImagem;

    @Column(name="CD_SEQUENCIA")
    private Integer numSequencia;

    @Column(name="DT_INCLUSAO")
    private Date dtInclusao;

    @Column(name="NM_USUARIO_INCLUSAO")
    private String nomeUsuarioInclusao;

    @Column(name="DT_ATUALIZACAO")
    private Date dataAtualizacao;

    @Column(name="NM_USUARIO_ATUALIZACAO")
    private String nomeUsuarioAtualizacao;

    @Column(name="TP_MOVIM")
    private String tipoMovimento;

    @Column(name="INICIO_VIGENCIA")
    private Date dtInicioVigencia;

    @Column(name="FINAL_VIGENCIA")
    private Date dtFinalVigencia;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="CD_MODELO_COMUNICACAO", referencedColumnName="CD_MODELO_COMUNICACAO")
    private ModeloComunicacao modelo;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="CD_IMAGEM", referencedColumnName="CD_IMAGEM")
    private ImagemComunicacao imagem;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="CD_TEXTO", referencedColumnName="CD_TEXTO")
    private TextoComunicacao textoComunicacao;

}
