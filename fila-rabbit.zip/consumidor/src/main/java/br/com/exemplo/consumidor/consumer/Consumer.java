package br.com.exemplo.consumidor.consumer;

import br.com.exemplo.consumidor.model.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

    @RabbitListener(queues = "${jsa.rabbitmq.queue}", containerFactory = "jsaFactory")
    public void recievedMessage(Message message) {
        System.out.println("Recebendo mensagem: " + message.getText());
    }

}
