package br.com.exemplo.produtor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdutorApplication.class, args);
	}
}
