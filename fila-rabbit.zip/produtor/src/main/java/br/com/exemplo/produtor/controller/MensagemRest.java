package br.com.exemplo.produtor.controller;

import br.com.exemplo.produtor.orm.Message;
import br.com.exemplo.produtor.producer.Producer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/mensagem")
public class MensagemRest {

    @Autowired
    private Producer producer;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/post")
    public void post(@RequestBody Message message) {
        producer.produce(message);
    }

}
