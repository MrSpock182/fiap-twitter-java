package io.github.mrspock182.repository;

import io.github.mrspock182.entity.Client;

public class ClientRepositoryImpl implements ClientRepository {

    @Override
    public Client save(final Client client) {
//        PutItemRequest putItemRequest = new PutItemRequest("client", )
//        dynamoDb.getDynamo().putItem()

        return null;
    }

    @Override
    public Client findById(final String id) {
        return null;
    }
}
