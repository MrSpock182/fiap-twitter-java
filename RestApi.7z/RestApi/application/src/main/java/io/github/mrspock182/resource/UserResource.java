package io.github.mrspock182.resource;

import io.github.mrspock182.repository.ClientRepository;
import io.github.mrspock182.repository.ClientRepositoryImpl;
import io.github.mrspock182.resource.dto.UserResponse;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/user")
public class UserResource {

    private final ClientRepository repository = new ClientRepositoryImpl();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public UserResponse test() {
        return new UserResponse("Kleber", "klebernunes182@gmail.com");
    }

}
