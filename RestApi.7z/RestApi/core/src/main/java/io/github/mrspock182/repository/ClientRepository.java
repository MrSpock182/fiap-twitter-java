package io.github.mrspock182.repository;

import io.github.mrspock182.entity.Client;

public interface ClientRepository {
    Client save(Client client);

    Client findById(String id);
}
