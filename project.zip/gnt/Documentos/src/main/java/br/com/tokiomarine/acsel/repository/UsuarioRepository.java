package br.com.tokiomarine.acsel.repository;

import javax.inject.Inject;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.OperUsuario;

public class UsuarioRepository{

	@Inject
	BaseAcxDAO base;

	public boolean permiteOperUsuario(String codUsuario, String codOper){

		Criteria crit = base.getSession().createCriteria(OperUsuario.class)
				.add(Restrictions.eq("codUsuario", codUsuario))
				.add(Restrictions.eq("codOperacao", codOper));

		OperUsuario ret = (OperUsuario) crit.uniqueResult();

		return ret != null;
	}

}
