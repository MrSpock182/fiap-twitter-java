
package br.com.tokiomarine.acsel.ws.col.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retornoWS complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retornoWS">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="colaboradorCallCenter" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="colaboradores" type="{http://ws.col.tokiomarine.com.br/}colaborador" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="locaisTrabalho" type="{http://ws.col.tokiomarine.com.br/}localTrabalho" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="retorno" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retornoWS", propOrder = {
    "colaboradorCallCenter",
    "colaboradores",
    "locaisTrabalho",
    "retorno"
})
public class RetornoWS {

    protected String colaboradorCallCenter;
    @XmlElement(nillable = true)
    protected List<Colaborador> colaboradores;
    @XmlElement(nillable = true)
    protected List<LocalTrabalho> locaisTrabalho;
    protected String retorno;

    /**
     * Obt�m o valor da propriedade colaboradorCallCenter.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getColaboradorCallCenter() {
        return colaboradorCallCenter;
    }

    /**
     * Define o valor da propriedade colaboradorCallCenter.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setColaboradorCallCenter(String value) {
        this.colaboradorCallCenter = value;
    }

    /**
     * Gets the value of the colaboradores property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the colaboradores property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getColaboradores().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Colaborador }
     *
     *
     */
    public List<Colaborador> getColaboradores() {
        if (colaboradores == null) {
            colaboradores = new ArrayList<Colaborador>();
        }
        return this.colaboradores;
    }

    /**
     * Gets the value of the locaisTrabalho property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the locaisTrabalho property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocaisTrabalho().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LocalTrabalho }
     *
     *
     */
    public List<LocalTrabalho> getLocaisTrabalho() {
        if (locaisTrabalho == null) {
            locaisTrabalho = new ArrayList<LocalTrabalho>();
        }
        return this.locaisTrabalho;
    }

    /**
     * Obt�m o valor da propriedade retorno.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getRetorno() {
        return retorno;
    }

    /**
     * Define o valor da propriedade retorno.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setRetorno(String value) {
        this.retorno = value;
    }

}
