package br.com.tokiomarine.acsel.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TempoDeExecucaoUtil {

	private long inicioProcesso;
	private final long inicio;
	private long fim;
	private long fimProcesso;
	private double duracao;
	private double duracaoProcesso;

	private static Logger logger = LogManager.getLogger(TempoDeExecucaoUtil.class);

	public TempoDeExecucaoUtil(Long threadId) {
		logger.info("Iniciando calculo de tempo na thread " + threadId);
		inicio = System.currentTimeMillis();
	}

	public void inicioProcesso() {
		inicioProcesso = System.currentTimeMillis();
	}

	public void fim() {
		fim = System.currentTimeMillis();
		duracao = fim - inicio;
	}

	public void fimProcesso() {
		fimProcesso = System.currentTimeMillis();
		duracaoProcesso = fimProcesso - inicioProcesso;
	}

	public double getDuracaoEmMilisegundos() {
		return duracao;
	}

	public double getDuracaoProcessoEmMilisegundos() {
		return duracaoProcesso;
	}

	public double getDuracaoEmSegundos() {
		return duracao / 1000;
	}

	public double getDuracaoProcessoEmSegundos() {
		return duracaoProcesso / 1000;
	}

	public double getDuracaoEmMinutos() {
		return duracao / (1000 * 60);
	}

	public double getDuracaoProcessoEmMinutos() {
		return duracaoProcesso / (1000 * 60);
	}
}
