package br.com.tokiomarine.acsel.type;

public enum RastreiaEnvioType {
	
	SEMPRE,
	NUNCA,
	AGENDAMENTO

}
