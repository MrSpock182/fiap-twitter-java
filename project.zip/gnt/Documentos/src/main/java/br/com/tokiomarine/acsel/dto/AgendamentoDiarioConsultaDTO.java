package br.com.tokiomarine.acsel.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class AgendamentoDiarioConsultaDTO {
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataInicialConsulta;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataFinalConsulta;
	
	private String tipoModelo;

	public Date getDataInicialConsulta() {
		return dataInicialConsulta;
	}


	public void setDataInicialConsulta(Date dataInicialConsulta) {
		this.dataInicialConsulta = dataInicialConsulta;
	}


	public Date getDataFinalConsulta() {
		return dataFinalConsulta;
	}


	public void setDataFinalConsulta(Date dataFinalConsulta) {
		this.dataFinalConsulta = dataFinalConsulta;
	}


	public String getTipoModelo() {
		return tipoModelo;
	}


	public void setTipoModelo(String tipoModelo) {
		this.tipoModelo = tipoModelo;
	}
	
	
	


}
