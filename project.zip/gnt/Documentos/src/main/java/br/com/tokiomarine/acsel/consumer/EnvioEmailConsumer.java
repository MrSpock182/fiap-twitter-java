package br.com.tokiomarine.acsel.consumer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.EnvioComunicacaoService;
import br.com.tokiomarine.seguradora.arquitetura.framework.queue.QueueManager;

@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Singleton
public class EnvioEmailConsumer {

	private static Logger logger = LogManager.getLogger(EnvioEmailConsumerSingleton.class);
	
	@EJB
	EnvioComunicacaoService envioService;

	@Inject
	ParametrosRepository parametrosDao;

	private Thread thread;

	@PostConstruct
	public void init() {
		
		logger.info("Inicializando o consumidor da fila");
		EnvioEmailConsumerSingleton envioEmailConsumerSingleton = new EnvioEmailConsumerSingleton(envioService,
				parametrosDao);
		thread = new Thread(envioEmailConsumerSingleton);
		thread.start();
		logger.info("Consumidor da fila inicializado");
		
		/*
		 * try {
		 * PropertyConfigurator.configure(this.getClass().getClassLoader().
		 * getResource("META-INF/log4j.properties"));
		 * 
		 * logger.info("Iniciando conexão com fila");
		 * 
		 * this.gerenciadorFila = QueueManager.getInstance();
		 * 
		 * String nomeFila = parametrosDao.obtemVlrParametro("JMS_FILAS",
		 * "JMS.FILA.EMAIL"); gerenciadorFila.addQueueListener(nomeFila, new
		 * QueueListenner() {
		 * 
		 * @Override public boolean onReceive(String mensagem) { try {
		 * logger.info("Nova mensagem: " + mensagem);
		 * envioService.enviaAgendamento(Long.parseLong(mensagem)); } catch
		 * (Throwable e) { logger.error("Erro ao ler mensagem", e);
		 * logger.error("Mensagem com erros: " + mensagem); } return true; } });
		 * 
		 * logger.info("Consumer iniciado"); } catch (Exception e) {
		 * logger.error(e.fillInStackTrace()); }
		 */
		
	}

	@PreDestroy
	public void onDestroy() {
		try {
			QueueManager.getInstance().disconnect(parametrosDao.obtemVlrParametro("JMS_FILAS", "JMS.FILA.EMAIL"));	
		} catch (Exception e) {
			logger.error("Erro ao falha fila: " + e.getMessage(), e);
		}
		
		thread.interrupt();
	}

//	private boolean trataMensagem(String mensagem) {
//
//		try {
//			logger.info("Nova mensagem: " + mensagem);
//			envioService.enviaAgendamento(Long.parseLong(mensagem));
//		} catch (Throwable e) {
//			logger.error("Erro ao ler mensagem", e);
//			logger.error("Mensagem com erros: " + mensagem);
//		}
//		return true;
//	}
}
