package br.com.tokiomarine.acsel.domain.ssv;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

public class DocumentoPK implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = -4499262923204099651L;

	/** Atributo que mapeia o campo CD_DOCTO. */
	@Id
	@Column(name="CD_DOCTO",nullable=false)
	public String cdDocto;
	/** Atributo que mapeia o campo DT_INICO_VIGEN_DOCTO. */
	@Id
	@Column(name="DT_INICO_VIGEN_DOCTO",nullable=false)
	public Date dtInicoVigenDocto;

	/**
	 * Construtor da classe.
	 */
	public DocumentoPK() {
	}

	/**
	 * Construtor da classe.
	 * @param cdDocto valor do atributo cdDocto
	 * @param dtInicoVigenDocto valor do atributo dtInicoVigenDocto
	 */
	public DocumentoPK(String cdDocto,Date dtInicoVigenDocto) {
		this.cdDocto = cdDocto;
		this.dtInicoVigenDocto = dtInicoVigenDocto;
	}

	public boolean equals(Object other) {
		if(other instanceof DocumentoPK) {
			final DocumentoPK pk = (DocumentoPK) other;
			boolean ret = (pk.cdDocto.equals(cdDocto) && pk.dtInicoVigenDocto.equals(dtInicoVigenDocto));
			return ret;
		}
		return false;
	}

	public int hashCode() {
		return cdDocto.hashCode() ^ dtInicoVigenDocto.hashCode();
	}
}
