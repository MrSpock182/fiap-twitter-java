package br.com.tokiomarine.acsel.dto;

@SuppressWarnings("rawtypes")
public class SegundaViaDocumentoDTO implements Comparable {
	String url;
	String descricao;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public int compareTo(Object object) {
		SegundaViaDocumentoDTO outro = (SegundaViaDocumentoDTO) object;
		  return this.descricao.compareTo(outro.descricao);
	}

}
