package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import br.com.tokiomarine.acsel.type.RastreiaEnvioType;
import br.com.tokiomarine.acsel.type.StatusModelo;
import br.com.tokiomarine.acsel.type.TipoModelo;
import lombok.Getter;
import lombok.Setter;

/**
 * @author T803520
 *
 */
@Entity
@Table(name = "MODELO_COMUNICACAO")
@SequenceGenerator(name = "SEQ_MODELO_COMUNICACAO", sequenceName = "SEQ_MODELO_COMUNICACAO", initialValue = 1, allocationSize = 1)
public class ModeloComunicacao {

	@Id
	@Column(name = "CD_MODELO_COMUNICACAO")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MODELO_COMUNICACAO")
	private Long codModelo;

	@Getter
	@Setter
	@Column(name = "CD_MODELO_CODIGO")
	private String codigo;

	@Column(name = "NM_MODELO_COMUNICACAO")
	private String nomeModelo;

	@Column(name = "DS_MODELO_COMUNICACAO")
	private String descricaoModelo;

	@Column(name = "CD_TIPO_MODELO")
	private String tipoModelo;

	@Column(name = "DS_TITULO_MODELO")
	private String tituloModelo;

	@Column(name = "DS_REMETENTE")
	private String emailRemetente;

	@Column(name = "DS_CAIXA_DEPTO")
	private String emailCaixaDept;

	@Column(name = "NM_SISTEMA_ORIGEM")
	private String nomeSistemaOrigem;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CD_IMAGEM", referencedColumnName = "CD_IMAGEM")
	private ImagemComunicacao imagem;

	@Column(name = "CD_IMAGEM", insertable = false, updatable = false)
	private Long codImagem;

	@Column(name = "ID_SITUACAO")
	private String situacaoModelo;

	@Column(name = "DT_INCLUSAO")
	private Date dtInclusao;

	@Column(name = "NM_USUARIO_INCLUSAO")
	private String nomeUsuarioInclusao;

	@Column(name = "DT_ATUALIZACAO")
	private Date dtAtualizacao;

	@Column(name = "NM_USUARIO_ATUALIZACAO")
	private String nomeUsuarioAtualizacao;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CD_PADRAO_COMUNICACAO", referencedColumnName = "CD_PADRAO_COMUNICACAO")
	private PadraoComunicacao padrao;

	@Column(name = "CD_PADRAO_COMUNICACAO", insertable = false, updatable = false)
	private Long codPadrao;

	@OneToMany(mappedBy = "modelo", cascade = CascadeType.ALL)
	@OrderBy("numSequencia")
	List<TextoModeloComunicacao> textos;

	@OneToMany(mappedBy = "modelo", cascade = CascadeType.ALL)
	@OrderBy("cdSequencia")
	List<ParametroModelo> parametros;

	@Column(name = "DS_DEST_MODELO_COMUNICACAO")
	private String destinoMensagem;

	@Column(name = "DS_PROC_MODELO_COMUNICACAO")
	private String processo;

	@Enumerated(EnumType.STRING)
	@Column(name = "CD_RATREIA_ENVIO")
	private RastreiaEnvioType rastreiaEnvio = RastreiaEnvioType.NUNCA;

	@Column(name = "CD_STATUS")
	private String status;

	@Column(name = "TP_MOVIM")
	private String tipoMovimento;

	@Column(name = "INICIO_VIGENCIA")
	private Date dtInicioVigencia;

	@Column(name = "FINAL_VIGENCIA")
	private Date dtFinalVigencia;

	@Column(name = "DS_MOTIVO")
	private String motivo;

	@Column(name = "PILOTO")
	private String piloto;

	@Column(name = "EMAIL_RESPONSAVEL")
	private String emailResponsavel;
	
	@Column(name = "EMAIL_COPIA")
	private String emailCopia;

	public Long getCodModelo() {
		return codModelo;
	}

	public void setCodModelo(Long codModelo) {
		this.codModelo = codModelo;
	}

	public String getTipoModelo() {
		return tipoModelo;
	}

	public void setTipoModelo(String tipoModelo) {
		this.tipoModelo = tipoModelo;
	}

	public String getNomeModelo() {
		return nomeModelo;
	}

	public void setNomeModelo(String nomeModelo) {
		this.nomeModelo = nomeModelo;
	}

	public String getDescricaoModelo() {
		return descricaoModelo;
	}

	public void setDescricaoModelo(String descricaoModelo) {
		this.descricaoModelo = descricaoModelo;
	}

	public String getTituloModelo() {
		return tituloModelo;
	}

	public void setTituloModelo(String tituloModelo) {
		this.tituloModelo = tituloModelo;
	}

	public String getEmailRemetente() {
		return emailRemetente;
	}

	public void setEmailRemetente(String emailRemetente) {
		this.emailRemetente = emailRemetente;
	}

	public String getEmailCaixaDept() {
		return emailCaixaDept;
	}

	public void setEmailCaixaDept(String emailCaixaDept) {
		this.emailCaixaDept = emailCaixaDept;
	}

	public String getNomeSistemaOrigem() {
		return nomeSistemaOrigem;
	}

	public void setNomeSistemaOrigem(String nomeSistemaOrigem) {
		this.nomeSistemaOrigem = nomeSistemaOrigem;
	}

	public ImagemComunicacao getImagem() {
		return imagem;
	}

	public void setImagem(ImagemComunicacao imagem) {
		this.imagem = imagem;
	}

	public Long getCodImagem() {
		return codImagem;
	}

	public void setCodImagem(Long codImagem) {
		this.codImagem = codImagem;
	}

	public String getSituacaoModelo() {
		return situacaoModelo;
	}

	public void setSituacaoModelo(String situacaoModelo) {
		this.situacaoModelo = situacaoModelo;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDtAtualizacao() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}

	public String getNomeUsuarioAtualizacao() {
		return nomeUsuarioAtualizacao;
	}

	public void setNomeUsuarioAtualizacao(String nomeUsuarioAtualizacao) {
		this.nomeUsuarioAtualizacao = nomeUsuarioAtualizacao;
	}

	public List<TextoModeloComunicacao> getTextos() {
		return textos;
	}

	public void setTextos(List<TextoModeloComunicacao> textos) {
		this.textos = textos;
	}

	public List<ParametroModelo> getParametros() {
		return parametros;
	}

	public void setParametros(List<ParametroModelo> parametros) {
		this.parametros = parametros;
	}

	public String getDescStatus() {
		return StatusModelo.get(this.getSituacaoModelo()).getDescricao();
	}

	public PadraoComunicacao getPadrao() {
		return padrao;
	}

	public void setPadrao(PadraoComunicacao padrao) {
		this.padrao = padrao;
	}

	public Long getCodPadrao() {
		return codPadrao;
	}

	public void setCodPadrao(Long codPadrao) {
		this.codPadrao = codPadrao;
	}

	@Transient
	public TipoModelo getCanalComunicacao() {
		return TipoModelo.get(this.tipoModelo);
	}

	public String getDestinoMensagem() {
		return destinoMensagem;
	}

	public void setDestinoMensagem(String destinoMensagem) {
		this.destinoMensagem = destinoMensagem;
	}

	public String getProcesso() {
		return processo;
	}

	public void setProcesso(String processo) {
		this.processo = processo;
	}

	public RastreiaEnvioType getRastreiaEnvio() {
		return rastreiaEnvio;
	}

	public void setRastreiaEnvio(RastreiaEnvioType rastreiaEnvio) {
		if (rastreiaEnvio == null)
			this.rastreiaEnvio = RastreiaEnvioType.NUNCA;
		else
			this.rastreiaEnvio = rastreiaEnvio;
	}

	public boolean sempreRastreia() {
		return RastreiaEnvioType.SEMPRE == this.rastreiaEnvio;
	}

	public boolean definidoRastreioNoAgendamento() {
		return RastreiaEnvioType.AGENDAMENTO == this.rastreiaEnvio;
	}

	public String getTipoMovimento() {
		return tipoMovimento;
	}

	public void setTipoMovimento(String tipoMovimento) {
		this.tipoMovimento = tipoMovimento;
	}

	public Date getDtInicioVigencia() {
		return dtInicioVigencia;
	}

	public void setDtInicioVigencia(Date dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia;
	}

	public Date getDtFinalVigencia() {
		return dtFinalVigencia;
	}

	public void setDtFinalVigencia(Date dtFinalVigencia) {
		this.dtFinalVigencia = dtFinalVigencia;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPiloto() {
		return piloto;
	}

	public void setPiloto(String piloto) {
		this.piloto = piloto;
	}

	public String getEmailResponsavel() {
		return emailResponsavel;
	}

	public void setEmailResponsavel(String emailResponsavel) {
		this.emailResponsavel = emailResponsavel;
	}

	public String getEmailCopia() {
		return emailCopia;
	}

	public void setEmailCopia(String emailCopia) {
		this.emailCopia = emailCopia;
	}
}