package br.com.tokiomarine.acsel.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgendamentoComunicacaoDTO {

	private Long seqAgendamento;

	@JsonInclude(Include.NON_NULL)
	private Long codigoModelo;

	@Getter
	@Setter
	private String codigo;

	@JsonInclude(Include.NON_NULL)
	private String indEnviaComunicacao;

	private String statusAgendamento;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataEnvio;

	@Getter
	private String tipoEnvio;

	@JsonInclude(Include.NON_EMPTY)
	private List<DocumentoComunicacaoDTO> documentos;

	@JsonInclude(Include.NON_EMPTY)
	private List<ParametroComunicacaoDTO> parametros;

	@JsonInclude(Include.NON_EMPTY)
	private List<String> destinatarios;
	
	@JsonInclude(Include.NON_EMPTY)
	private List<ListDocComunicacaoDTO> listDoc;
	
	@JsonInclude(Include.NON_EMPTY)
	private List<ComCopiaDTO> comCopias;
	
	@JsonInclude(Include.NON_NULL)
	private String emailRemetente;
	
	@Getter
	private List<Destinatario> destinatariosDetalhes;

	@Getter
	private List<AnexoEmail> anexos;

	@Getter
	private String codCorretor;

	@Getter
	private String rastreiaEnvio;

	public Long getSeqAgendamento() {
		return seqAgendamento;
	}

	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}

	public Long getCodigoModelo() {
		return codigoModelo;
	}

	public void setCodigoModelo(Long codModelo) {
		this.codigoModelo = codModelo;
	}

	public String getIndEnviaComunicacao() {
		return indEnviaComunicacao;
	}

	public void setIndEnviaComunicacao(String indEnviaComunicacao) {
		this.indEnviaComunicacao = indEnviaComunicacao;
	}

	public String getStatusAgendamento() {
		return statusAgendamento;
	}

	public void setStatusAgendamento(String statusAgendamento) {
		this.statusAgendamento = statusAgendamento;
	}

	public Date getDataEnvio() {
		return dataEnvio;
	}

	public void setDataEnvio(Date dataEnvio) {
		this.dataEnvio = dataEnvio;
	}

	public List<DocumentoComunicacaoDTO> getDocumentos() {
		return documentos;
	}

	public void setDocumentos(List<DocumentoComunicacaoDTO> documentos) {
		this.documentos = documentos;
	}

	public List<ParametroComunicacaoDTO> getParametros() {
		return parametros;
	}

	public void setParametros(List<ParametroComunicacaoDTO> parametros) {
		this.parametros = parametros;
	}
	
	public List<String> getDestinatarios() {
		return destinatarios;
	}

	public void setDestinatarios(List<String> destinatarios) {
		this.destinatarios = destinatarios;
	}

	public String getValorParametro(String nomeParam) {
		for (ParametroComunicacaoDTO p : this.getParametros()) {

			if(p.getNomeParametro().equals(nomeParam)) {
				return p.getValorParametro();
			}
		}
		return null;
	}

	public List<ListDocComunicacaoDTO> getListDoc() {
		return listDoc;
	}

	public void setListDoc(List<ListDocComunicacaoDTO> listDoc) {
		this.listDoc = listDoc;
	}

	public String getEmailRemetente() {
		return emailRemetente;
	}

	public void setEmailRemetente(String emailRemetente) {
		this.emailRemetente = emailRemetente;
	}

	public List<ComCopiaDTO> getComCopias() {
		return comCopias;
	}

	public void setComCopias(List<ComCopiaDTO> comCopias) {
		this.comCopias = comCopias;
	}

}
