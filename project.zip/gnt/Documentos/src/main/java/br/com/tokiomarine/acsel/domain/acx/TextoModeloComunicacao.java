package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "MODELO_COMUNICACAO_TEXTO")
public class TextoModeloComunicacao {

	@Id
	@Column(name="CD_MODELO_COM_TEXTO")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="modeloComTextoGenerator")
	@SequenceGenerator(name = "modeloComTextoGenerator", sequenceName = "SQ_MODELO_COMUNIC_TEXTO",allocationSize=1)
	private Long idTexto;

	@ManyToOne
	@JoinColumn(name="CD_MODELO_COMUNICACAO", referencedColumnName="CD_MODELO_COMUNICACAO")
	private ModeloComunicacao modelo;

	@Column(name="DS_TEXTO")
	private String texto;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CD_IMAGEM", referencedColumnName="CD_IMAGEM")
	private ImagemComunicacao imagem;

	@Column(name="CD_IMAGEM", insertable=false, updatable=false)
	private Long codImagem;

	@Column(name="CD_SEQUENCIA")
	private Integer numSequencia;

	@Column(name="DT_INCLUSAO")
	private Date dtInclusao;

	@Column(name="NM_USUARIO_INCLUSAO")
	private String nomeUsuarioInclusao;

	@Column(name="DT_ATUALIZACAO")
	private Date dataAtualizacao;

	@Column(name="NM_USUARIO_ATUALIZACAO")
	private String nomeUsuarioAtualizacao;

	@ManyToOne
	@JoinColumn(name="CD_TEXTO", referencedColumnName="CD_TEXTO")
	private TextoComunicacao textoComunicacao;
	
	@Column(name="TP_MOVIM")
	private String tipoMovimento;

	@Column(name="INICIO_VIGENCIA")
	private Date dtInicioVigencia;
	  
	  
	@Column(name="FINAL_VIGENCIA")
	private Date dtFinalVigencia;
	  
	public Long getIdTexto() {
		return idTexto;
	}

	public void setIdTexto(Long idTexto) {
		this.idTexto = idTexto;
	}

	public ModeloComunicacao getModelo() {
		return modelo;
	}

	public void setModelo(ModeloComunicacao modelo) {
		this.modelo = modelo;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public ImagemComunicacao getImagem() {
		return imagem;
	}

	public void setImagem(ImagemComunicacao imagem) {
		this.imagem = imagem;
	}

	public Long getCodImagem() {
		return codImagem;
	}

	public void setCodImagem(Long codImagem) {
		this.codImagem = codImagem;
	}

	public Integer getNumSequencia() {
		return numSequencia;
	}

	public void setNumSequencia(Integer numSequencia) {
		this.numSequencia = numSequencia;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public String getNomeUsuarioAtualizacao() {
		return nomeUsuarioAtualizacao;
	}

	public void setNomeUsuarioAtualizacao(String nomeUsuarioAtualizacao) {
		this.nomeUsuarioAtualizacao = nomeUsuarioAtualizacao;
	}

	public TextoComunicacao getTextoComunicacao() {
		return textoComunicacao;
	}

	public void setTextoComunicacao(TextoComunicacao textoComunicacao) {
		this.textoComunicacao = textoComunicacao;
	}

	public String getTipoMovimento() {
		return tipoMovimento;
	}

	public void setTipoMovimento(String tipoMovimento) {
		this.tipoMovimento = tipoMovimento;
	}

	public Date getDtInicioVigencia() {
		return dtInicioVigencia;
	}

	public void setDtInicioVigencia(Date dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia;
	}

	public Date getDtFinalVigencia() {
		return dtFinalVigencia;
	}

	public void setDtFinalVigencia(Date dtFinalVigencia) {
		this.dtFinalVigencia = dtFinalVigencia;
	}

}