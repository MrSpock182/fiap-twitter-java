package br.com.tokiomarine.acsel.type;

public enum StatusModelo {


	ativo("S", "ATIVO"),
	inativo("N", "INATIVO");

	private String value;
	private String descricao;

	StatusModelo(String value, String desc) {
		this.value = value;
		this.descricao = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDescricao() {
		return descricao;
	}

	public static StatusModelo get(String status){
		for (StatusModelo tipo : StatusModelo.values()){
			if (tipo.value.equals(status)){
				return tipo;
			}
		}
		return null;
	}
}
