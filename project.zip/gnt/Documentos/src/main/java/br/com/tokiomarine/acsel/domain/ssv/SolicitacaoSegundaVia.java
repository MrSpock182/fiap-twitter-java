package br.com.tokiomarine.acsel.domain.ssv;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="EMP0062_SOLCT_SEGDA_VIA_DOCTO")
@IdClass(SolicitacaoSegundaViaPK.class)
public class SolicitacaoSegundaVia{

	@Column(name="CD_CLASS_DESTN",nullable=false)
	private Long cdClassDestn;
	@Column(name="CD_CLIEN",nullable=false)
	private Long cdClien;
	@Column(name="CD_LOCAL")
	private Long cdLocal;
	@Column(name="CD_RCPTR_PACTE",nullable=false)
	private Long cdRcptrPacte;
	@Column(name="CD_SITUC_SOLCT",nullable=false)
	private Long cdSitucSolct;
	@Id
	@Column(name="DT_HORA_SOLCT",nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtHoraSolct;
	@Column(name="DT_PROCM_SOLCT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtProcmSolct;
	@Id
	@Column(name="ID_DOCTO_FISCO",nullable=false)
	@GeneratedValue(generator="SSVEMSQ0016_SOLCT_SEGDA_VIA_DO_GEN")
	@SequenceGenerator(name="SSVEMSQ0016_SOLCT_SEGDA_VIA_DO_GEN",sequenceName="SSVEMSQ0016_SOLCT_SEGDA_VIA_DO",allocationSize=1)
	private Long idDoctoFisco;
	@Column(name="ID_ENDER_CLIEN",nullable=false)
	private Long idEnderClien;
	@Column(name="NM_SOLTT",nullable=false)
	private String nmSoltt;
	@Column(name="SG_EMPRE")
	private String sgEmpre;
	@Column(name="TP_LOCAL")
	private Long tpLocal;
	@Column(name="NM_USR_DEST")
	private String nmUsrDest;
	@Column(name="NM_LOCAL_DEST")
	private String nmLocalDest;
	@Column(name="DS_MOTIVO")
	private String dsMotivo;

	@Transient
	private SolicitacaoSegundaViaPK pk = new SolicitacaoSegundaViaPK();


	public SolicitacaoSegundaVia() {
	}

	public Serializable getPk() {
		this.pk.dtHoraSolct = this.dtHoraSolct;
		this.pk.idDoctoFisco = this.idDoctoFisco;
		return this.pk;
	}

	public Long getCdClassDestn() {
		return this.cdClassDestn;
	}

	public void setCdClassDestn(Long cdClassDestn) {
		this.cdClassDestn = cdClassDestn;
	}

	public Long getCdClien() {
		return this.cdClien;
	}

	public void setCdClien(Long cdClien) {
		this.cdClien = cdClien;
	}

	public Long getCdLocal() {
		return this.cdLocal;
	}

	public void setCdLocal(Long cdLocal) {
		this.cdLocal = cdLocal;
	}

	public Long getCdRcptrPacte() {
		return this.cdRcptrPacte;
	}

	public void setCdRcptrPacte(Long cdRcptrPacte) {
		this.cdRcptrPacte = cdRcptrPacte;
	}

	public Long getCdSitucSolct() {
		return this.cdSitucSolct;
	}

	public void setCdSitucSolct(Long cdSitucSolct) {
		this.cdSitucSolct = cdSitucSolct;
	}

	public Date getDtHoraSolct() {
		return this.dtHoraSolct;
	}

	public void setDtHoraSolct(Date dtHoraSolct) {
		this.dtHoraSolct = dtHoraSolct;
	}

	public Date getDtProcmSolct() {
		return this.dtProcmSolct;
	}

	public void setDtProcmSolct(Date dtProcmSolct) {
		this.dtProcmSolct = dtProcmSolct;
	}

	public Long getIdDoctoFisco() {
		return this.idDoctoFisco;
	}

	public void setIdDoctoFisco(Long idDoctoFisco) {
		this.idDoctoFisco = idDoctoFisco;
	}

	public Long getIdEnderClien() {
		return this.idEnderClien;
	}

	public void setIdEnderClien(Long idEnderClien) {
		this.idEnderClien = idEnderClien;
	}

	public String getNmSoltt() {
		return this.nmSoltt;
	}

	public void setNmSoltt(String nmSoltt) {
		this.nmSoltt = nmSoltt;
	}

	public String getSgEmpre() {
		return this.sgEmpre;
	}

	public void setSgEmpre(String sgEmpre) {
		this.sgEmpre = sgEmpre;
	}

	public Long getTpLocal() {
		return this.tpLocal;
	}

	public void setTpLocal(Long tpLocal) {
		this.tpLocal = tpLocal;
	}

	public String getNmUsrDest() {
		return nmUsrDest;
	}

	public void setNmUsrDest(String nmUsrDest) {
		this.nmUsrDest = nmUsrDest;
	}

	public String getNmLocalDest() {
		return nmLocalDest;
	}

	public void setNmLocalDest(String nmLocalDest) {
		this.nmLocalDest = nmLocalDest;
	}

	public String getDsMotivo() {
		return dsMotivo;
	}

	public void setDsMotivo(String dsMotivo) {
		this.dsMotivo = dsMotivo;
	}

}