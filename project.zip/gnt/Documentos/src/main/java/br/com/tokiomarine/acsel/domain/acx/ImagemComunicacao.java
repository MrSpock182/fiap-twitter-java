package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMAGENS_COMUNICACAO")
public class ImagemComunicacao {

	@Id
	@Column(name="CD_IMAGEM")
	private Long codImagem;

	@Column(name="NM_IMAGEM")
	private String nomeImagem;

	@Column(name="DS_IMAGEM")
	private String descImagem;

	@Column(name="URL_IMAGEM")
	private String url;

	@Column(name="ALTURA")
	private Integer altura;

	@Column(name="LARGURA")
	private Integer largura;

	@Column(name="DT_ATUALIZACAO")
	private Date dtAtualizacao;

	@Column(name="NM_USUARIO_ATUALIZACAO")
	private String nomeUsuarioAtualizacao;

	public Long getCodImagem() {
		return codImagem;
	}

	public void setCodImagem(Long codImagem) {
		this.codImagem = codImagem;
	}

	public String getNomeImagem() {
		return nomeImagem;
	}

	public void setNomeImagem(String nomeImagem) {
		this.nomeImagem = nomeImagem;
	}

	public String getDescImagem() {
		return descImagem;
	}

	public void setDescImagem(String descImagem) {
		this.descImagem = descImagem;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getAltura() {
		return altura;
	}

	public void setAltura(Integer altura) {
		this.altura = altura;
	}

	public Integer getLargura() {
		return largura;
	}

	public void setLargura(Integer largura) {
		this.largura = largura;
	}

	public Date getDtAtualizacao() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}

	public String getNomeUsuarioAtualizacao() {
		return nomeUsuarioAtualizacao;
	}

	public void setNomeUsuarioAtualizacao(String nomeUsuarioAtualizacao) {
		this.nomeUsuarioAtualizacao = nomeUsuarioAtualizacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((codImagem == null) ? 0 : codImagem.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ImagemComunicacao other = (ImagemComunicacao) obj;
		if (codImagem == null) {
			if (other.codImagem != null)
				return false;
		} else if (!codImagem.equals(other.codImagem)){
			return false;
		}

		return true;
	}
}