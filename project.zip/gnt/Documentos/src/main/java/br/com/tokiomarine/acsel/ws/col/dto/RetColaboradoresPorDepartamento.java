
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retColaboradoresPorDepartamento complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retColaboradoresPorDepartamento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cargo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cpf" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="departamento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="matricula" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retColaboradoresPorDepartamento", propOrder = {
    "cargo",
    "cpf",
    "departamento",
    "matricula",
    "nome"
})
public class RetColaboradoresPorDepartamento {

    protected String cargo;
    protected String cpf;
    protected String departamento;
    protected Integer matricula;
    protected String nome;

    /**
     * Obt�m o valor da propriedade cargo.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * Define o valor da propriedade cargo.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCargo(String value) {
        this.cargo = value;
    }

    /**
     * Obt�m o valor da propriedade cpf.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * Define o valor da propriedade cpf.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCpf(String value) {
        this.cpf = value;
    }

    /**
     * Obt�m o valor da propriedade departamento.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDepartamento() {
        return departamento;
    }

    /**
     * Define o valor da propriedade departamento.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDepartamento(String value) {
        this.departamento = value;
    }

    /**
     * Obt�m o valor da propriedade matricula.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getMatricula() {
        return matricula;
    }

    /**
     * Define o valor da propriedade matricula.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setMatricula(Integer value) {
        this.matricula = value;
    }

    /**
     * Obt�m o valor da propriedade nome.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNome(String value) {
        this.nome = value;
    }

}
