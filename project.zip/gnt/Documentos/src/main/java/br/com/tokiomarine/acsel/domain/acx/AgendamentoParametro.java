package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;

@Entity
@IdClass(AgendamentoParametroPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_PARAM")
public class AgendamentoParametro {
	
	private static final int TAMANHO_PADRAO_PARAMETRO = 4000;

	@Id
	@ManyToOne
	@JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
	private AgendamentoComunicacao agendamento;

	@Id
	@ManyToOne
	@JoinColumn(name="CD_PARAMETRO", referencedColumnName="CD_PARAMETRO")
	private ParametroComunicacao parametro;

	@Column(name="DS_VALOR_PARAMETRO")
	private String dsValorParametro;
	
	@Column(name="DS_VALOR_PARAMETRO_EXTENSO")
	private String dsValorParametroExtenso;

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoComunicacao agendamento) {		
		this.agendamento = agendamento;
	}

	public ParametroComunicacao getParametro() {
		return parametro;
	}

	public void setParametro(ParametroComunicacao parametro) {
		this.parametro = parametro;
	}

	public String getDsValorParametro() {
		return dsValorParametro;
	}

	public void setDsValorParametro(String dsValorParametro) {
		this.dsValorParametro = dsValorParametro;
	}

	public String getDsValorParametroExtenso() {
		return dsValorParametroExtenso;
	}

	public void setDsValorParametroExtenso(String dsValorParametroExtenso) {
		this.dsValorParametroExtenso = dsValorParametroExtenso;
	}

	// GNT-99 - Necessidade do parametro [MENSAGEM_GENERICA] com mais de 4.000 caracteres
	public String getValorParametro() {
		if (Boolean.TRUE.equals(StringUtils.isNotEmpty(dsValorParametroExtenso))) {
			return this.dsValorParametroExtenso;
		} else {
			return this.dsValorParametro;
		}		
	}

	// GNT-99 - Necessidade do parametro [MENSAGEM_GENERICA] com mais de 4.000 caracteres
	public void setValorParametro(String valorParametro) {
		if (Boolean.TRUE.equals(StringUtils.isNotEmpty(valorParametro) && valorParametro.length() > TAMANHO_PADRAO_PARAMETRO)) {
			this.dsValorParametroExtenso = valorParametro;
		} else {
			this.dsValorParametro = valorParametro;
		}
	}
}