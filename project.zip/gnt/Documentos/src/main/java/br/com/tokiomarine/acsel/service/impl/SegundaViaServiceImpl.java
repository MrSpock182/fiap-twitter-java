package br.com.tokiomarine.acsel.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.time.DateUtils;
import org.jboss.resteasy.client.ClientRequest;
import org.jboss.resteasy.client.ClientResponse;

import br.com.tokiomarine.acsel.domain.acx.CadEmail;
import br.com.tokiomarine.acsel.domain.acx.CadServicos;
import br.com.tokiomarine.acsel.domain.acx.IEspelhoEmp;
import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.domain.ssv.SolicitacaoSegundaVia;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.DocumentoRecriar;
import br.com.tokiomarine.acsel.dto.DownloadDocumentoDTO;
import br.com.tokiomarine.acsel.dto.ItemApoliceDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.dto.UsuarioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ApoliceRepository;
import br.com.tokiomarine.acsel.repository.DocumentoSSVRepository;
import br.com.tokiomarine.acsel.repository.DocumentosPlatRepository;
import br.com.tokiomarine.acsel.repository.EmpacotadorRepository;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.repository.SegundaViaSSVRepository;
import br.com.tokiomarine.acsel.repository.UsuarioRepository;
import br.com.tokiomarine.acsel.service.ColaboradoresService;
import br.com.tokiomarine.acsel.service.EmailService;
import br.com.tokiomarine.acsel.service.EnderecosService;
import br.com.tokiomarine.acsel.service.ParametrosService;
import br.com.tokiomarine.acsel.service.SegundaViaService;
import br.com.tokiomarine.acsel.service.ValidaSegundaViaService;
import br.com.tokiomarine.acsel.type.OpcaoSolic;
import br.com.tokiomarine.acsel.type.StatusDocumento;
import br.com.tokiomarine.acsel.util.Constants;
import br.com.tokiomarine.acsel.util.StringUtil;
import br.com.tokiomarine.infra.componente.email.dto.Anexo;

@Stateless(name = "SegundaViaService")
@Local(value = SegundaViaService.class)
public class SegundaViaServiceImpl implements SegundaViaService {

	@Inject
	DocumentoSSVRepository documentoSSVRep;
	@Inject
	SegundaViaSSVRepository segundaViaSSVRep;
	@Inject
	EmpacotadorRepository empacotadorRep;
	@Inject
	DocumentosPlatRepository plataformaRep;
	@Inject
	ParametrosRepository parametrosRep;
	@Inject
	EnderecosService enderecoService;
	@Inject
	ColaboradoresService colaboradoresService;
	@Inject
	UsuarioRepository usuarioRep;
	@EJB
	ValidaSegundaViaService validaSegundaViaService;
	@Inject
	ParametrosService paramService;
	@Inject
	EmailService emailService;
	@Inject
	ApoliceRepository apoliceDao;

	@Override
	public void solicitaSegundaVia(SolicSegundaViaDTO solic) throws ServiceException {

		validaSegundaViaService.validaSegundaVia(solic);

		solic.setDataSolic(new Date());

		int vias = solic.getDocumento().getHistSegundaVia().size();

		if (solic.getDocumento().getSistemaOrigem().isAcsel() && !"80".equals(solic.getDocumento().getCodItem())) {

			if (solic.getListaItens() == null || solic.getListaItens().isEmpty()) {

				String ret = empacotadorRep.solicitarSegundaVia(solic);
				validateReturn(ret);

			} else {
				if (solic.getDocumento().getCodProduto() != null
						&& solic.getDocumento().getCodProduto().equals(Constants.AUTO_FROTA_COD_PRUDUTO)) {
					List<ItemApoliceDTO> items = empacotadorRep.buscaItensPorCodigo(solic.getListaItens(),
							solic.getDocumento().getIdePol(), solic.getDocumento().getNumEndosso());
					String ret = empacotadorRep.solicitarSegundaViaAutoFrota(solic, items);
					validateReturn(ret);

				} else {

					for (String codItem : solic.getListaItens()) {
						ItemApoliceDTO item = solic.getDocumento().getItem(codItem);
						String ret = empacotadorRep.solicitarSegundaVia(solic, item);
						validateReturn(ret);
					}
				}
			}

		} else if (solic.getDocumento().getSistemaOrigem().isPlataforma()) {

			if (solic.getListaItens() == null || solic.getListaItens().isEmpty()) {

				String ret = plataformaRep.solicitarSegundaVia(solic);
				if (!StringUtil.isNull(ret)) {
					if (verificaBoletoQuitado(ret)) {
						throw new ServiceException(
								"Solicitação de 2ª via efetivada. O boleto não será gerado pois está quitado/cancelado.");
					} else {
						throw new ServiceException(
								"Não foi possível solicitar a segunda via do documento. Por favor, tente novamente mais tarde. Motivo: "
										+ ret);
					}
				}
			} else {
				for (String codItem : solic.getListaItens()) {
					String ret = plataformaRep.solicitarSegundaVia(solic, codItem);
					if (!StringUtil.isNull(ret)) {
						if (verificaBoletoQuitado(ret)) {
							throw new ServiceException(
									"Solicitação de 2ª via efetivada. O boleto não será gerado pois está quitado/cancelado.");
						} else {
							throw new ServiceException(
									"Não foi possível solicitar a segunda via do documento. Por favor, tente novamente mais tarde. Motivo: "
											+ ret);
						}
					}
				}
			}
		} else if (solic.getDocumento().getSistemaOrigem().isSSV() || "80".equals(solic.getDocumento().getCodItem())) {
			criaSolicitacaoSSV(solic);
			// solicitaSegundaViaCartao(solic);

		}

		obtemSolicitacoes(solic.getDocumento());

		if (solic.getDocumento().getHistSegundaVia().size() <= vias) {
			throw new ServiceException(
					"Não foi possível solicitar a segunda via do documento. Motivo: Já existe solicitação");					
//					"Não foi possível solicitar a segunda via do documento. Por favor, tente novamente mais tarde. Motivo: Dados da solicitação não encontrados");
		}
	}

	private void validateReturn(String ret) throws ServiceException {
		if (StringUtil.isNull(ret) || ret.equals("N")) {
			throw new ServiceException(
					"Não foi possível solicitar a segunda via do documento. Por favor, tente novamente mais tarde");
		}
	}

	private boolean verificaBoletoQuitado(String mensagem) {
		if (mensagem.contains("Seguro quitado ou Cancelado")) {
			return true;
		}
		return false;
	}

	@Override
	public String obtemLinkDownload(DocumentoDTO doc, String codItem, Long idDocto, String email,
			List<DownloadDocumentoDTO> lista) throws ServiceException {
		String result = "";
		DownloadDocumentoDTO docDownload = null;
		try {
			if (doc.getSistemaOrigem().isAcsel()) {
				if (lista != null && lista.size() > 0) {
					for (int i = 0; i < lista.size(); i++) {
						if (idDocto.intValue() == (i + 1)) {
							docDownload = new DownloadDocumentoDTO();
							docDownload.setUrlDocumento(lista.get(i).getUrlDocumento());
							docDownload.setDescDocumento(lista.get(i).getDescDocumento());
							break;
						}
					}
				} else {
					if (StringUtil.isNull(codItem)) {
						docDownload = doc.getDocumentoDownload(idDocto);
					} else {
						docDownload = doc.getItem(codItem).getDocumentoDownload(idDocto);
					}
				}

				ClientRequest request = new ClientRequest(docDownload.getUrlDocumento());
				ClientResponse<String> response = request.get(String.class);

				if (response.getResponseStatus().getStatusCode() != 200) {
					throw new RuntimeException(
							"Erro na chamada do webservice: " + response.getResponseStatus().getStatusCode());
				}

				if (email != null && !email.equals("")) {
					CadServicos servicoEmail = paramService.obtemServico("EMAIL_SEG_VIA_PDF");

					if (servicoEmail.getEmails() == null) {
						servicoEmail.setEmails(new ArrayList<CadEmail>());
					}

					// Anexo anexo = geraAnexo(docDownload.getUrlDocumento());
					Anexo anexo = anexar(docDownload.getUrlDocumento());

					emailService.enviaEmail(servicoEmail, servicoEmail.getTextoEmail(), anexo, email);
				}

				return docDownload.getUrlDocumento();
				/*
				 * if (lista != null && lista.size() > 0) { return
				 * docDownload.getUrlDocumento(); } else { return (String) response.getEntity();
				 * }
				 */

			} else if (doc.getSistemaOrigem().isPlataforma()) {

				docDownload = doc.getDocumentoDownload(idDocto);

				if (email != null && !email.equals("")) {

					CadServicos servicoEmail = paramService.obtemServico("EMAIL_SEG_VIA_PDF");

					if (servicoEmail.getEmails() == null) {
						servicoEmail.setEmails(new ArrayList<CadEmail>());
					}

					// Anexo anexo = geraAnexo(docDownload.getUrlDocumento());
					Anexo anexo = anexar(docDownload.getUrlDocumento());

					emailService.enviaEmail(servicoEmail, servicoEmail.getTextoEmail(), anexo, email);
				}

				// return docDownload.getUrlDocumento();
				result = docDownload.getUrlDocumento();
				if (!fileExists(result)) {
					return "RECRIAR";
				} else {
					return result;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(
					"Não foi possível solicitar a segunda via web do documento. Por favor, tente novamente mais tarde",
					e);
		}

		return "";
	}

	@Override
	public boolean fileExists(String urlSegundaVia) {
		try {
			HttpURLConnection.setFollowRedirects(false);
			HttpURLConnection con = (HttpURLConnection) new URL(urlSegundaVia).openConnection();
			con.setRequestMethod("HEAD");
			if (!con.getContentType().contains("application/pdf")) {
				return false;
			}
			return (con.getResponseCode() == HttpURLConnection.HTTP_OK);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/*
	 * private Anexo geraAnexo(String urlDocumento) throws Exception {
	 * 
	 * ClientRequest request = new ClientRequest(urlDocumento);
	 * 
	 * ClientResponse<InputStream> response = request.get(InputStream.class);
	 * 
	 * if(response.getResponseStatus().getStatusCode() != 200){ throw new
	 * RuntimeException("Erro na chamada do webservice: " +
	 * response.getResponseStatus().getStatusCode()); }
	 * 
	 * InputStream s = (InputStream) response.getEntity();
	 * 
	 * return new Anexo("SegundaViaTKM.pdf", "Segunda via do documento",
	 * "application/pdf", IOUtils.toByteArray(s));
	 * 
	 * }
	 */

	private Anexo anexar(String urlDocumento) throws Exception {
		try {
			URL url = new URL(urlDocumento);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			int responseCode = connection.getResponseCode();
			if (responseCode != HttpURLConnection.HTTP_OK) {
				throw new Exception("URL de Download Inválido");
			}

			InputStream inputStream = connection.getInputStream();
			return new Anexo("SegundaViaTKM.pdf", "Segunda via do documento", "application/pdf",
					IOUtils.toByteArray(inputStream));
		} catch (MalformedURLException e) {
			throw new Exception("URL de Download Inválido");
		} catch (IOException e) {
			throw new Exception("URL de Download Inválido");
		}
	}

	@Override
	public void cancelaSegundaVia(SegundaViaDTO segundaVia, UsuarioDTO usuarioSessao) throws ServiceException {

		if (!segundaVia.isPermiteCancelamento()
				|| !segundaVia.getUsuarioSolic().equals(usuarioSessao.getCodUsuario())) {
			throw new ServiceException("Você não tem permissão para cancelar esta solicitação");
		}

		if (segundaVia.getDocumento().getSistemaOrigem().isAcsel()) {

			int count = -1;
			for (SegundaViaDTO hist : segundaVia.getDocumento().getHistSegundaVia()) {
				if (!hist.getId().equals(segundaVia.getId())
						&& DateUtils.isSameDay(hist.getDataSolic(), segundaVia.getDataSolic()))
					count++;
			}

			IEspelhoEmp espelhoEmp = empacotadorRep.obtemEspelhoEmp(segundaVia.getId());
			espelhoEmp.setChaveGenerica(espelhoEmp.getChaveGenerica() + "C" + (count + 1));
			espelhoEmp.setIndProcessado(StatusDocumento.cancelado.getValue());
			empacotadorRep.atualizaEspelhoEmp(espelhoEmp);

			for (IEspelhoEmp espelhoEmpCartao : empacotadorRep.obtemEspelhoEmpCartao(espelhoEmp)) {
				espelhoEmpCartao.setChaveGenerica(espelhoEmpCartao.getChaveGenerica() + "C" + (count + 1));
				espelhoEmpCartao.setIndProcessado(StatusDocumento.cancelado.getValue());
				empacotadorRep.atualizaEspelhoEmp(espelhoEmpCartao);
			}

		} else if (segundaVia.getDocumento().getSistemaOrigem().isSSV()) {

			SolicitacaoSegundaVia solic = segundaViaSSVRep.buscaSolicitacao(segundaVia.getId(),
					segundaVia.getDataSolic());

			solic.setCdSitucSolct(2L);
			segundaViaSSVRep.atualizaSegundaVia(solic);

			for (DocumentoDTO cartao : documentoSSVRep.obtemCartaoAssociado(segundaVia.getDocumento())) {
				SolicitacaoSegundaVia solicCartao = segundaViaSSVRep.buscaSolicitacao(cartao.getId(),
						segundaVia.getDataSolic());
				solicCartao.setCdSitucSolct(2L);
				segundaViaSSVRep.atualizaSegundaVia(solicCartao);
			}
		}
	}

	/*
	 * private void solicitaSegundaViaCartao(SolicSegundaViaDTO solic){
	 * for(DocumentoDTO cartao :
	 * documentoSSVRep.obtemCartaoAssociado(solic.getDocumento())){
	 * SolicSegundaViaDTO solicCartao = new SolicSegundaViaDTO();
	 * solicCartao.setDocumento(cartao);
	 * solicCartao.setDataSolic(solic.getDataSolic());
	 * solicCartao.setTipoDestino(solic.getTipoDestino().getValue());
	 * solicCartao.setNumEndereco(solic.getNumEndereco());
	 * solicCartao.setUsuarioSolic(solic.getUsuarioSolic());
	 * solicCartao.setColaborador(solic.getColaborador());
	 * solicCartao.setLocal(solic.getLocal());
	 * solicCartao.setAndarLocalTrabalho(solic.getAndarLocalTrabalho());
	 * solicCartao.setMotivo(solic.getMotivo()); criaSolicitacaoSSV(solicCartao); }
	 * }
	 */

	private void criaSolicitacaoSSV(SolicSegundaViaDTO solic) {

		SolicitacaoSegundaVia segundaVia = new SolicitacaoSegundaVia();
		// segundaVia.setIdDoctoFisco(solic.getDocumento().getId());
		segundaVia.setDtHoraSolct(solic.getDataSolic());
		segundaVia.setCdClien(Long.parseLong(solic.getDocumento().getCodCliente()));
		segundaVia.setCdClassDestn(solic.getTipoDestino().getSsvValue());
		segundaVia.setCdRcptrPacte(1L);
		segundaVia.setCdSitucSolct(0L);
		segundaVia.setDtProcmSolct(null);
		segundaVia.setIdEnderClien(solic.getNumEndereco() == null ? 0L : solic.getNumEndereco());
		segundaVia.setNmSoltt(solic.getUsuarioSolic().getCodUsuario());
		segundaVia.setNmUsrDest(StringUtil.substr(solic.getColaborador(), 0, 30));
		segundaVia.setNmLocalDest(StringUtil.isNull(solic.getLocal()) ? ""
				: StringUtil.substr(solic.getLocal() + ' ' + solic.getAndarLocalTrabalho(), 0, 30));
		segundaVia.setDsMotivo(solic.getMotivo());
		segundaVia.setSgEmpre("1");

		Long idDoctoFisco = documentoSSVRep.buscaridDoctoFisco(solic.getDocumento().getNumApolice(),
				solic.getDocumento().getNumEndosso(), solic.getDocumento().getNumNegocio());
		segundaVia.setIdDoctoFisco(idDoctoFisco);
		segundaViaSSVRep.solicitaSegundaVia(segundaVia);
	}

	@Override
	public List<SegundaViaDTO> obtemSolicitacoes(DocumentoDTO documentoDTO) {

		List<SegundaViaDTO> segundaViaDTOList = new ArrayList<SegundaViaDTO>();

		if (documentoDTO.getSistemaOrigem().isAcsel() && !"80".equals(documentoDTO.getCodItem())) {
			
			if (isAutoFrota(documentoDTO)) {
				
				segundaViaDTOList.addAll(empacotadorRep.buscaSegundaViaAutoFrota(documentoDTO.getId(), documentoDTO.getIdePol(), documentoDTO.getNumEndosso()));
				
			} else if (!documentoDTO.getIndMultiItem()) {
				
				segundaViaDTOList = empacotadorRep.buscaSegundaVia(documentoDTO.getIdePol(), documentoDTO.getNumCert(), documentoDTO.getNumOper(), documentoDTO.getTipoOper());
				
			} else {
				
				for (ItemApoliceDTO item : documentoDTO.getListaItens()) {
					segundaViaDTOList.addAll(empacotadorRep.buscaSegundaVia(item.getIdePol(), item.getNumCert(),
							item.getNumOper(), documentoDTO.getTipoOper()));
				}
				
			}
			
		} else if (documentoDTO.getSistemaOrigem().isPlataforma()) {
			
			segundaViaDTOList = plataformaRep.buscaSegundaVia(documentoDTO.getRamo(), documentoDTO.getNumApolice(), documentoDTO.getNumEndosso());
			
		} else if (documentoDTO.getSistemaOrigem().isSSV() || "80".equals(documentoDTO.getCodItem())) {
			
			Long idDoctoFisco = documentoSSVRep.buscaridDoctoFisco(documentoDTO.getNumApolice(), documentoDTO.getNumEndosso(), documentoDTO.getNumNegocio());
			segundaViaDTOList = segundaViaSSVRep.buscaSegundaVia(idDoctoFisco);
			
		}

		for (SegundaViaDTO segundaViaDTO : segundaViaDTOList) {
			segundaViaDTO.setDocumento(documentoDTO);

			if (documentoDTO.getSistemaOrigem().isPlataforma()) {
				segundaViaDTO.setPermiteCancelamento(false);
				segundaViaDTO.setEnderecoEnvio(enderecoService.obtemEnderecoEnvio(segundaViaDTO));
			} else {
				segundaViaDTO.setPermiteCancelamento(permiteCancelamento(segundaViaDTO));
				segundaViaDTO.setEnderecoEnvio(enderecoService.obtemEnderecoEnvio(segundaViaDTO));
			}

			if (segundaViaDTO.getUsuarioSolic().equals(documentoDTO.getCodCorretor())) {
				segundaViaDTO.setNomeUsuarioSolic(documentoDTO.getNomeCorretor());
			} else {
				segundaViaDTO.setNomeUsuarioSolic(
						colaboradoresService.obtemNomeColaborador(segundaViaDTO.getUsuarioSolic()));
			}

			// 04/04/2018 - T803758
			if (documentoDTO.getIndMultiItem() && !StringUtil.isNull(segundaViaDTO.getCodItem())) {
				if (isAutoFrota(documentoDTO)) {
					segundaViaDTO.setItem(mountAutoFrotaItemDesc(documentoDTO, segundaViaDTO));
				} else {
					segundaViaDTO.setItem(documentoDTO.getItem(segundaViaDTO.getCodItem()));
				}

			} else {
				segundaViaDTO.setCodItem(null);
			}
		}

		documentoDTO.setHistSegundaVia(segundaViaDTOList);

		return segundaViaDTOList;
	}

	private ItemApoliceDTO mountAutoFrotaItemDesc(DocumentoDTO documentoDTO, SegundaViaDTO segundaViaDTO) {
		ItemApoliceDTO itemToReturn = new ItemApoliceDTO();
		List<ItemApoliceDTO> itemsSolicitados = empacotadorRep.listItemsSegundaViaAUTF(segundaViaDTO.getId());
		if (itemsSolicitados != null && !itemsSolicitados.isEmpty()) {

			StringBuilder itemDesc = new StringBuilder();
			int aux = 0;

			for (ItemApoliceDTO i : documentoDTO.getListaItens()) {

				if (verificarSolicitacao(i, itemsSolicitados)) {

					if (aux > 0) {
						itemDesc.append(" - ");
					}
					itemDesc.append(i.getDescItem());
					aux++;
				}
			}

			itemToReturn.setDescItem(itemDesc.toString());
		} else {
			itemToReturn.setDescItem(OpcaoSolic.kitCompletoAUTF.getDescOpcao());
		}

		return itemToReturn;
	}

	private boolean verificarSolicitacao(ItemApoliceDTO docItem, List<ItemApoliceDTO> itemsSolicitados) {
		for (ItemApoliceDTO itemSolicitado : itemsSolicitados) {
			if (docItem.getNumCert().equals(itemSolicitado.getNumCert())
					&& docItem.getNumOper().equals(itemSolicitado.getNumOper())
					&& docItem.getIdeReg().equals(itemSolicitado.getIdeReg())) {
				return true;
			}
		}
		return false;
	}

	private boolean isAutoFrota(DocumentoDTO documentoDTO) {
		if (documentoDTO.getCodProduto() != null
				&& documentoDTO.getCodProduto().equals(Constants.AUTO_FROTA_COD_PRUDUTO)) {
			return true;
		}
		return false;
	}

	@Override
	public List<Lval> obtemMotivosSolic() {
		return parametrosRep.obtemListaValores("MOTSEVIA");
	}

	@SuppressWarnings("unused")
	@Override
	public List<OpcaoSolic> obtemOpcoesSolic(DocumentoDTO doc, UsuarioDTO usuario) throws ServiceException {

		List<OpcaoSolic> list = new ArrayList<OpcaoSolic>();

		if (doc.getSistemaOrigem().isPlataforma()) {
			if (doc.getNumEndosso() != null) { // PPKME-408-Nao permitir solicitar resumida no endosso
				Map<Integer, Integer> mapPlat = plataformaRep.verificaDocumento(doc);
				for (DownloadDocumentoDTO dowloadDoc : doc.getDocumentosDownload()) {
					Integer documento = dowloadDoc.getIdDocumento().intValue();
					for (Map.Entry<Integer, Integer> entry : mapPlat.entrySet()) {
						if (entry.getKey().equals(documento)) {
							switch (entry.getValue()) {
							case 22:
							case 24:
								list.add(OpcaoSolic.apoliceComplet);
								break;
							case 23:
								list.add(OpcaoSolic.apoliceResumida);
								break;
							case 4:
								list.add(OpcaoSolic.carne);
								break;
							case 28:
								list.add(OpcaoSolic.cartaoPlat);
								break;
							case 9:
								list.add(OpcaoSolic.contaMensal);
								break;
							case 55:
								list.add(OpcaoSolic.cartaoProtecaoGlobal);
								break;
							}
						}
					}
				}
			} else {
				list.addAll(plataformaRep.obtemOpcoesDocumentos(doc));
			}
		} else {
			switch (doc.getTipo()) {
			case apolice:

				if (doc.getCodProduto() != null && doc.getCodProduto().equals(Constants.AUTO_FROTA_COD_PRUDUTO)) {
					list.add(OpcaoSolic.kitCompletoAUTF);
				} else {
					list.add(OpcaoSolic.kitCompleto);
				}
				
				if ( !doc.getCodDocumento().equals("29") &&
					 !doc.getCodProduto().equals(Constants.AUTO_COD_PRUDUTO) &&
					 !doc.getCodProduto().equals(Constants.FIANCA_COD_PRUDUTO)) {
					list.add(OpcaoSolic.apolCartao);
				}

/*				if (!"29".equals(doc.getCodDocumento())) {
					list.add(OpcaoSolic.apolCartao);
				}
*/				
				break;
			case endosso:

				if (doc.getCodProduto() != null && doc.getCodProduto().equals(Constants.AUTO_FROTA_COD_PRUDUTO)) {
					list.add(OpcaoSolic.endossoAUTF);
				} else {
					list.add(OpcaoSolic.endosso);
				}

				if (permiteEndossoCartao(doc, usuario)) {
					list.add(OpcaoSolic.endossoCartao);
				}
				break;
			default:
				list.add(OpcaoSolic.padrao);
				break;
			}
		}

		return list;
	}

	@Override
	public boolean permiteEnvioAR(DocumentoDTO doc, UsuarioDTO usuario) {
		return doc.getSistemaOrigem().isAcsel() && !usuario.isCorretor()
				&& usuarioRep.permiteOperUsuario(usuario.getCodUsuario(), "354");
	}

	@Override
	public boolean permiteCorretor(String codCorretor) {
		String lista = parametrosRep.obtemVlrParametro("SEGUNDA_VIA", "CORRETOR_PILOTO");

		if (StringUtil.isNull(lista))
			return true;

		StringTokenizer tok = new StringTokenizer(lista, ";");
		while (tok.hasMoreTokens()) {
			String cod = tok.nextToken();
			if (cod.equals(codCorretor)) {
				return true;
			}
		}

		return false;
	}

	private boolean permiteCancelamento(SegundaViaDTO s) {
		return (StatusDocumento.pendente.equals(s.getStatus()));
	}

	private boolean permiteEndossoCartao(DocumentoDTO doc, UsuarioDTO usuario) {
		return !usuario.isCorretor() && StringUtil.in(doc.getTipoEndosso(), "M")
				&& usuarioRep.permiteOperUsuario(usuario.getCodUsuario(), "354");
	}

	@Override
	public String reprocessDocument(DocumentoDTO doc, Long codDocumento) throws Exception {
		return plataformaRep.reprocessDocument(doc, codDocumento);
	}

	@Override
	public List<DocumentoRecriar> listaDocument(Date dataInicio) {
		return plataformaRep.listaDocument(dataInicio);
	}

}