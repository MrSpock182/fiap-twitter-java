package br.com.tokiomarine.acsel.repository;

import java.util.List;

import javax.inject.Inject;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.CadServicos;
import br.com.tokiomarine.acsel.domain.acx.GrpParamAcsel;
import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.domain.acx.ParamAcsel;

public class ParametrosRepository{

	@Inject
	BaseAcxDAO base;

	public List<Lval> obtemListaValores(String tipoLval){

		@SuppressWarnings("unchecked")
		List<Lval> lista = base.getSession().createCriteria(Lval.class)
		                                    .add(Restrictions.eq("tipoLval", tipoLval))
		                                    .addOrder(Order.asc("descrip"))  
		                                    .list();

		return lista;
	}

	public Lval obtemLval(String tipoLval, String codLval){

		Lval lval = (Lval) base.getSession().createCriteria(Lval.class)
						.add(Restrictions.eq("tipoLval", tipoLval))
						.add(Restrictions.eq("codLval", codLval))
						.uniqueResult();
		return lval;
	}

	public List<GrpParamAcsel> obtemGrupos(){

		@SuppressWarnings("unchecked")
		List<GrpParamAcsel> lista = base.getSession().createCriteria(GrpParamAcsel.class).list();

		return lista;
	}

	public List<ParamAcsel> obtemParametrosGrupo(Integer grupoId){

		@SuppressWarnings("unchecked")
		List<ParamAcsel> lista = base.getSession().createCriteria(ParamAcsel.class).add(Restrictions.eq("idGrpParamAcsel", grupoId)).list();
		return lista;
	}

	public ParamAcsel atualizaParam(ParamAcsel param){
		return (ParamAcsel) base.merge(param);
	}

	public void insereParam(ParamAcsel param){
		base.persist(param);
	}

	public void removeParam(ParamAcsel param){
		ParamAcsel paramAcsel = (ParamAcsel) base.getSession().createCriteria(ParamAcsel.class)
				.add(Restrictions.eq("idGrpParamAcsel", param.getIdGrpParamAcsel()))
				.add(Restrictions.eq("codParametro", param.getCodParametro())).uniqueResult();
		base.getSession().delete(paramAcsel);
	}

	public String obtemVlrParametro(String grupo, String param){
		ParamAcsel paramAcsel = (ParamAcsel) base.getSession().createCriteria(ParamAcsel.class)
				.createAlias("grpParametro", "g")
				.add(Restrictions.eq("g.codGrpParametro", grupo))
				.add(Restrictions.eq("codParametro", param)).uniqueResult();
		if (paramAcsel == null)
			return null;
		else
			return paramAcsel.getVlrParametro();
	}

	public CadServicos obtemServico(String nomeServico){
		return (CadServicos) base.getSession().createCriteria(CadServicos.class)
				.add(Restrictions.eq("codServico", nomeServico)).uniqueResult();
	}

}
