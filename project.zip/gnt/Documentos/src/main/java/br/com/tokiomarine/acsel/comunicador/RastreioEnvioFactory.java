package br.com.tokiomarine.acsel.comunicador;

import java.util.HashMap;
import java.util.Map;

import br.com.tokiomarine.acsel.comunicador.mail.Comprova;

public class RastreioEnvioFactory {

	private static final String COMPROVA = "comprova";
	private static Map<String, RastreioEnvio> tiposRastreioFlyweight;
	
	static {
		tiposRastreioFlyweight = new HashMap<String, RastreioEnvio>();
		tiposRastreioFlyweight.put(COMPROVA, new Comprova());
	}
	
	public static RastreioEnvio getRastreio() {
		return tiposRastreioFlyweight.get(COMPROVA);
	}

}
