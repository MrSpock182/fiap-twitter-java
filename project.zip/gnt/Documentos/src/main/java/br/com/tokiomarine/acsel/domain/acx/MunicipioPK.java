package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class MunicipioPK implements Serializable {

	private static final long serialVersionUID = 1L;


	private String codPais;
	private String codEstado;
	private String codCiudad;
	private String codMunicipio;
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodCiudad() {
		return codCiudad;
	}
	public void setCodCiudad(String codCiudad) {
		this.codCiudad = codCiudad;
	}
	public String getCodMunicipio() {
		return codMunicipio;
	}
	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codCiudad == null) ? 0 : codCiudad.hashCode());
		result = prime * result + ((codMunicipio == null) ? 0 : codMunicipio.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MunicipioPK other = (MunicipioPK) obj;
		if (codMunicipio == null) {
			if (other.codMunicipio != null)
				return false;
		} else if (!codCiudad.equals(other.codCiudad))
			return false;
		if (codEstado == null) {
			if (other.codEstado != null)
				return false;
		} else if (!codEstado.equals(other.codEstado))
			return false;
		return true;
	}
}
