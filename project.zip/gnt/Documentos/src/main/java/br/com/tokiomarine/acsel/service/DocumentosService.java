package br.com.tokiomarine.acsel.service;

import java.util.List;

import br.com.tokiomarine.acsel.dto.BuscaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.DownloadDocumentoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface DocumentosService {

	List<DocumentoDTO> buscaDocumentos(BuscaDocumentosDTO dadosBusca) throws ServiceException;

	void populaDetalhes(DocumentoDTO doc) throws ServiceException;
	List<DownloadDocumentoDTO> segundaViaConsulta(DocumentoDTO doc) throws ServiceException;

}