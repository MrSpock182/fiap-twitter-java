package br.com.tokiomarine.acsel.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class EstatisticaAgendamentoDTO {
	
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataEnvio;
	private Long total;
	private Long enviado;	
	private Long naoEnviado;
	private Long pendente;
	private Long finalizado;
	private Long errado;
	
	public Date getDataEnvio() {
		return dataEnvio;
	}

	public void setDataEnvio(Date dataEnvio) {
		this.dataEnvio = dataEnvio;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public Long getEnviado() {
		return enviado;
	}

	public void setEnviado(Long enviado) {
		this.enviado = enviado;
	}

	public Long getNaoEnviado() {
		return naoEnviado;
	}

	public void setNaoEnviado(Long naoEnviado) {
		this.naoEnviado = naoEnviado;
	}

	public Long getPendente() {
		return pendente;
	}

	public void setPendente(Long pendente) {
		this.pendente = pendente;
	}

	public Long getFinalizado() {
		return finalizado;
	}

	public void setFinalizado(Long finalizado) {
		this.finalizado = finalizado;
	}

	public Long getErrado() {
		return errado;
	}

	public void setErrado(Long errado) {
		this.errado = errado;
	}


}
