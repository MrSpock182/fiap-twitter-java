package br.com.tokiomarine.acsel.service;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.dto.AgendamentoComunicacaoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface ValidaAgendamentoService {

	boolean validaAgendamento(AgendamentoEnvio envio) throws ServiceException;

	void incluiErro(AgendamentoEnvio envio, String msgErro);
	
	void validaAgendamentoComunicacaoDTO(AgendamentoComunicacaoDTO agendamento) throws ServiceException;

	//void incluiAviso(AgendamentoEnvio envio, String msgErro);

}