package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
public class BlackListResource {
	
	private String id, email, dateValidate;
	private Boolean blackList;
	
	public static class BlackListResourceBuilder {
		public BlackListResourceBuilder blackList(Integer blackListInteger) {
			if(blackListInteger == null) return this;
			if(blackListInteger == 1) this.blackList = false;
			if(blackListInteger == 0) this.blackList = true;
			return this;
		}
	}
	
	public Boolean isBlackList() {
		return blackList != null && blackList.booleanValue();
	}
		
}
