package br.com.tokiomarine.acsel.util;

public class Constants {
	
	public static final String AUTO_FROTA_COD_PRUDUTO = "AUTF";
	public static final String AUTO_COD_PRUDUTO = "AUTO";	
	public static final String FIANCA_COD_PRUDUTO = "FIAN";
}


