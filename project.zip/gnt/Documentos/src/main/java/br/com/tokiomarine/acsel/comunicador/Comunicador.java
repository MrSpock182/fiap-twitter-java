/* 
 * Copyright (C) 2017 Tokio Marine - T803520 | @diegolirio
 * Contrato para comunicacao 
 */
package br.com.tokiomarine.acsel.comunicador;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.exception.ServiceException;

/**
 * @author Diego Lírio diegolirio
 * @see GNTMail
 * @since 1.3
 */
public interface Comunicador {

	void enviar(AgendamentoEnvio agendamentoEnvio) throws ServiceException;
	
}
