package br.com.tokiomarine.acsel.dto;

import java.util.List;

public class ItemApoliceDTO {

	private String codItem;
	private String descItem;
	private Long idePol;
	private Long numCert;
	private Long numOper;
	private Long ideReg;
	private List<DownloadDocumentoDTO> documentosDownload;

	public String getCodItem() {
		return codItem;
	}
	public void setCodItem(String codItem) {
		this.codItem = codItem;
	}
	public String getDescItem() {
		return descItem;
	}
	public void setDescItem(String descItem) {
		this.descItem = descItem;
	}
	public Long getIdePol() {
		return idePol;
	}
	public void setIdePol(Long idePol) {
		this.idePol = idePol;
	}
	public Long getNumCert() {
		return numCert;
	}
	public void setNumCert(Long numCert) {
		this.numCert = numCert;
	}
	public Long getNumOper() {
		return numOper;
	}
	public Long getIdeReg() {
		return ideReg;
	}
	public void setIdeReg(Long ideReg) {
		this.ideReg = ideReg;
	}
	public void setNumOper(Long numOper) {
		this.numOper = numOper;
	}
	public List<DownloadDocumentoDTO> getDocumentosDownload() {
		return documentosDownload;
	}
	public void setDocumentosDownload(List<DownloadDocumentoDTO> documentosDownload) {
		this.documentosDownload = documentosDownload;
	}
	public DownloadDocumentoDTO getDocumentoDownload(Long codDocumento){
		for (DownloadDocumentoDTO documento : documentosDownload) {
			if (documento.getIdDocumento().equals(codDocumento))
				return documento;
		}
		return null;
	}
}
