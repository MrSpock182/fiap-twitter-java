/* 
 * Copyright (C) 2017 Tokio Marine - T803520 | @diegolirio
 * Contrato para comunicacao 
 */
package br.com.tokiomarine.acsel.util;

/**
 * @author Diego Lírio
 * @since 1.3
 * Template para pegar valor conforme ambiente
 */
public abstract class AmbienteTemplate {

	private static String ambiente = VariaveisAmbienteUtil.getAmbienteDetectado();

	private static final String LOCAL = "LOCAL";
	private static final String DESENVOLVIMENTO = "DESENVOLVIMENTO";
	private static final String DESENV = "DESENV";
	private static final String ACEITE = "ACEITE";
	private static final String HOMOLOGACAO = "HOMOLOGACAO";
	private static final String PRODUCAO = "PRODUCAO";

	public String getEnv() {
		if (LOCAL.equals(ambiente) || DESENVOLVIMENTO.equals(ambiente) || DESENV.equals(ambiente))
			return this.getDev();
		if (ACEITE.equals(ambiente) || HOMOLOGACAO.equals(ambiente))
			return this.getAceite();
		if (PRODUCAO.equals(ambiente))
			return this.getProducao();
		return this.getProducao();
	}

	protected abstract String getProducao();

	protected abstract String getAceite();

	protected abstract String getDev();

}
