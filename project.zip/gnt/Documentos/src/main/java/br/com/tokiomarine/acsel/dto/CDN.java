package br.com.tokiomarine.acsel.dto;

import br.com.tokiomarine.acsel.type.Aplicacao;
import br.com.tokiomarine.acsel.util.VariaveisAmbienteUtil;

public class CDN {

	public CDN() {
		publico = VariaveisAmbienteUtil.getCdnPublico();
		restrito = VariaveisAmbienteUtil.getCdnRestrito();
		versao = Aplicacao.cdnVersao.value();
	}

	private final String publico;
	private final String restrito;
	private final String versao;

	public String getPublico() {
		return publico;
	}

	public String getRestrito() {
		return restrito;
	}

	public String getVersao() {
		return versao;
	}

}
