package br.com.tokiomarine.acsel.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.domain.acx.CadEmail;
import br.com.tokiomarine.acsel.domain.acx.CadServicos;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.service.EmailService;
import br.com.tokiomarine.infra.componente.email.dto.Anexo;
import br.com.tokiomarine.infra.componente.email.dto.EmailHTML;
import br.com.tokiomarine.infra.componente.email.exception.EnvioDeEmailException;
import br.com.tokiomarine.infra.componente.email.exception.RemetenteInvalidoException;

@Stateless(name = "EmailService")
@Local(value = EmailService.class)
public class EmailServiceImpl implements EmailService{
	
	private static Logger logger = LogManager.getLogger(EmailServiceImpl.class);
	
	public void enviaEmail(CadServicos servico, String emailHTML, Anexo anexo, String destinatario) throws ServiceException{
		try {
			String from = "";
			List<String> destinatarios = new ArrayList<String>();
			List<String> destinatariosCopia = new ArrayList<String>();
			List<String> destinatariosCopiaOculta = new ArrayList<String>();

			for (CadEmail email : servico.getEmails()){
				if (email.getTipoEmail().equals("From")){
					from = email.getEmail();
				} else if (email.getTipoEmail().equals("To")){
					destinatarios.add(email.getEmail());
				} else if (email.getTipoEmail().equals("Cc")){
					destinatariosCopia.add(email.getEmail());
				} else if (email.getTipoEmail().equals("Cco")){
					destinatariosCopiaOculta.add(email.getEmail());
				}
			}
			
			if(destinatario != null) {
				destinatarios.add(destinatario);
			}

			if (destinatarios.isEmpty()){
				throw new ServiceException("Nenhum e-mail válido foi informado");
			}

			if (from.isEmpty()){
				throw new ServiceException("E-mail do remetente não foi informado");
			}

			EmailHTML email = new EmailHTML(servico.getChamada(),
					emailHTML, from, destinatarios, destinatariosCopia, destinatariosCopiaOculta);

			if (anexo != null){
				email.setAnexo(anexo);
			}

			email.enviar();

		} catch(ServiceException s){
			throw s;
		}
		  catch (RemetenteInvalidoException | EnvioDeEmailException e) {
			throw new ServiceException(e.getMessage());
		} catch (Exception e){
			logger.error("Erro ao enviar e-mail", e);
			throw new ServiceException("Erro ao enviar e-mail");
		}
	}

}
