
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retColaboradorPorMatricula complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retColaboradorPorMatricula">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cargo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="centroCusto" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoCargo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoCargoLegado" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoDepartamento" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoSituacao" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoTipoColaborador" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dataAdmissao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataDemissao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="departamento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="descricaoSituacao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="descricaoTipoColaborador" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="diretoria" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localComercial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="matricula" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="matriculaSuperior" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeSuperior" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="predioComercial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retColaboradorPorMatricula", propOrder = {
    "cargo",
    "centroCusto",
    "codigoCargo",
    "codigoCargoLegado",
    "codigoDepartamento",
    "codigoSituacao",
    "codigoTipoColaborador",
    "dataAdmissao",
    "dataDemissao",
    "departamento",
    "descricaoSituacao",
    "descricaoTipoColaborador",
    "diretoria",
    "email",
    "localComercial",
    "matricula",
    "matriculaSuperior",
    "nome",
    "nomeSuperior",
    "predioComercial"
})
public class RetColaboradorPorMatricula {

    protected String cargo;
    protected int centroCusto;
    protected int codigoCargo;
    protected int codigoCargoLegado;
    protected int codigoDepartamento;
    protected int codigoSituacao;
    protected int codigoTipoColaborador;
    protected String dataAdmissao;
    protected String dataDemissao;
    protected String departamento;
    protected String descricaoSituacao;
    protected String descricaoTipoColaborador;
    protected String diretoria;
    protected String email;
    protected String localComercial;
    protected Integer matricula;
    protected Integer matriculaSuperior;
    protected String nome;
    protected String nomeSuperior;
    protected String predioComercial;

    /**
     * Obt�m o valor da propriedade cargo.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * Define o valor da propriedade cargo.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCargo(String value) {
        this.cargo = value;
    }

    /**
     * Obt�m o valor da propriedade centroCusto.
     *
     */
    public int getCentroCusto() {
        return centroCusto;
    }

    /**
     * Define o valor da propriedade centroCusto.
     *
     */
    public void setCentroCusto(int value) {
        this.centroCusto = value;
    }

    /**
     * Obt�m o valor da propriedade codigoCargo.
     *
     */
    public int getCodigoCargo() {
        return codigoCargo;
    }

    /**
     * Define o valor da propriedade codigoCargo.
     *
     */
    public void setCodigoCargo(int value) {
        this.codigoCargo = value;
    }

    /**
     * Obt�m o valor da propriedade codigoCargoLegado.
     *
     */
    public int getCodigoCargoLegado() {
        return codigoCargoLegado;
    }

    /**
     * Define o valor da propriedade codigoCargoLegado.
     *
     */
    public void setCodigoCargoLegado(int value) {
        this.codigoCargoLegado = value;
    }

    /**
     * Obt�m o valor da propriedade codigoDepartamento.
     *
     */
    public int getCodigoDepartamento() {
        return codigoDepartamento;
    }

    /**
     * Define o valor da propriedade codigoDepartamento.
     *
     */
    public void setCodigoDepartamento(int value) {
        this.codigoDepartamento = value;
    }

    /**
     * Obt�m o valor da propriedade codigoSituacao.
     *
     */
    public int getCodigoSituacao() {
        return codigoSituacao;
    }

    /**
     * Define o valor da propriedade codigoSituacao.
     *
     */
    public void setCodigoSituacao(int value) {
        this.codigoSituacao = value;
    }

    /**
     * Obt�m o valor da propriedade codigoTipoColaborador.
     *
     */
    public int getCodigoTipoColaborador() {
        return codigoTipoColaborador;
    }

    /**
     * Define o valor da propriedade codigoTipoColaborador.
     *
     */
    public void setCodigoTipoColaborador(int value) {
        this.codigoTipoColaborador = value;
    }

    /**
     * Obt�m o valor da propriedade dataAdmissao.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDataAdmissao() {
        return dataAdmissao;
    }

    /**
     * Define o valor da propriedade dataAdmissao.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDataAdmissao(String value) {
        this.dataAdmissao = value;
    }

    /**
     * Obt�m o valor da propriedade dataDemissao.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDataDemissao() {
        return dataDemissao;
    }

    /**
     * Define o valor da propriedade dataDemissao.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDataDemissao(String value) {
        this.dataDemissao = value;
    }

    /**
     * Obt�m o valor da propriedade departamento.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDepartamento() {
        return departamento;
    }

    /**
     * Define o valor da propriedade departamento.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDepartamento(String value) {
        this.departamento = value;
    }

    /**
     * Obt�m o valor da propriedade descricaoSituacao.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDescricaoSituacao() {
        return descricaoSituacao;
    }

    /**
     * Define o valor da propriedade descricaoSituacao.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDescricaoSituacao(String value) {
        this.descricaoSituacao = value;
    }

    /**
     * Obt�m o valor da propriedade descricaoTipoColaborador.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDescricaoTipoColaborador() {
        return descricaoTipoColaborador;
    }

    /**
     * Define o valor da propriedade descricaoTipoColaborador.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDescricaoTipoColaborador(String value) {
        this.descricaoTipoColaborador = value;
    }

    /**
     * Obt�m o valor da propriedade diretoria.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDiretoria() {
        return diretoria;
    }

    /**
     * Define o valor da propriedade diretoria.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDiretoria(String value) {
        this.diretoria = value;
    }

    /**
     * Obt�m o valor da propriedade email.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getEmail() {
        return email;
    }

    /**
     * Define o valor da propriedade email.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Obt�m o valor da propriedade localComercial.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLocalComercial() {
        return localComercial;
    }

    /**
     * Define o valor da propriedade localComercial.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLocalComercial(String value) {
        this.localComercial = value;
    }

    /**
     * Obt�m o valor da propriedade matricula.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getMatricula() {
        return matricula;
    }

    /**
     * Define o valor da propriedade matricula.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setMatricula(Integer value) {
        this.matricula = value;
    }

    /**
     * Obt�m o valor da propriedade matriculaSuperior.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getMatriculaSuperior() {
        return matriculaSuperior;
    }

    /**
     * Define o valor da propriedade matriculaSuperior.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setMatriculaSuperior(Integer value) {
        this.matriculaSuperior = value;
    }

    /**
     * Obt�m o valor da propriedade nome.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Obt�m o valor da propriedade nomeSuperior.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeSuperior() {
        return nomeSuperior;
    }

    /**
     * Define o valor da propriedade nomeSuperior.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeSuperior(String value) {
        this.nomeSuperior = value;
    }

    /**
     * Obt�m o valor da propriedade predioComercial.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getPredioComercial() {
        return predioComercial;
    }

    /**
     * Define o valor da propriedade predioComercial.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setPredioComercial(String value) {
        this.predioComercial = value;
    }

}
