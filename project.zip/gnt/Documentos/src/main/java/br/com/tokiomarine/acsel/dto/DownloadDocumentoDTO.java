package br.com.tokiomarine.acsel.dto;

import java.io.Serializable;

public class DownloadDocumentoDTO implements Serializable {

	private static final long serialVersionUID = 8372165766985091217L;

	private Long idDocumento;
	private String descDocumento;
	private String urlDocumento;
	private Long  idepol;
	private Integer  numEndosso;

	public DownloadDocumentoDTO() {}

	public DownloadDocumentoDTO(Long idDocumento, String descDocumento, String urlDocumento,
			                    Long  idepol, Integer  numEndosso) {
		super();
		this.idDocumento = idDocumento;
		this.descDocumento = descDocumento;
		this.urlDocumento = urlDocumento;
		this.idepol = idepol;
		this.numEndosso = numEndosso;
	}

	public Long getIdDocumento() {
		return idDocumento;
	}
	public void setIdDocumento(Long idDocumento) {
		this.idDocumento = idDocumento;
	}
	public String getDescDocumento() {
		return descDocumento;
	}
	public void setDescDocumento(String descDocumento) {
		this.descDocumento = descDocumento;
	}
	public String getUrlDocumento() {
		return urlDocumento;
	}
	public void setUrlDocumento(String urlDocumento) {
		this.urlDocumento = urlDocumento;
	}
	public Long getIdepol() {
		return idepol;
	}
	public void setIdepol(Long idepol) {
		this.idepol = idepol;
	}
	public Integer getNumEndosso() {
		return numEndosso;
	}
	public void setNumEndosso(Integer numEndosso) {
		this.numEndosso = numEndosso;
	}
}
