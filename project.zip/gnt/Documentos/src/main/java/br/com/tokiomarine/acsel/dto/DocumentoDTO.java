package br.com.tokiomarine.acsel.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.tokiomarine.acsel.type.FormaEnvio;
import br.com.tokiomarine.acsel.type.Sistema;
import br.com.tokiomarine.acsel.type.StatusDocumento;
import br.com.tokiomarine.acsel.type.TipoDestino;
import br.com.tokiomarine.acsel.type.TipoDocumento;

@SuppressWarnings("rawtypes")
public class DocumentoDTO implements Serializable, Comparable {

	private static final long serialVersionUID = -5213446548208398011L;

	private Long id;
	private TipoDocumento tipo;
	private String codDocumento;
	private String descDocumento;
	private String descProduto;
	private String codCliente;
	private String nomeCliente;
	private Date dataGeracao;
	private Date dataEnvio;
	private String status;
	private String ramo;
	private Long numApolice;
	private Integer numEndosso;
	private Integer numNegocio;
	private String codPacote;
	private String descPacote;
	private EnderecoDTO enderecoEnvio;
	private String emailEnvio;
	private Date dataEnvioEmail;
	private String codCompanhia;
	private String nomeCompanhia;
	private String codCorretor;
	private String nomeCorretor;
	private String tipoDestino;
	private String indMultiItem;
	private EnderecoDTO enderecoCorretor;
	private List<EnderecoDTO> enderecosCliente;
	private boolean indSolicitado = false;
	private String formaEnvio;
	private String tipoEnvio;
	private String tipoEndosso;
	private String descEndosso;
	private String tipoOper;
	private Long idePol;
	private Long numCert;
	private Long numOper;
	private Long numItem;
	private Long seqAgendamento;
	private String codModProd;
	private Sistema sistemaOrigem;
	private SegundaViaDTO ultimaSolicitacao;
	private List<DownloadDocumentoDTO> documentosDownload;
	private List<ItemApoliceDTO> listaItens;
	private List<SegundaViaDTO> histSegundaVia;
	private String codItem;
	private String tipoApoliceEndosso;
	private String codProduto;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public TipoDocumento getTipo() {
		return tipo;
	}
	public void setTipo(TipoDocumento tipo) {
		this.tipo = tipo;
	}
	public String getCodDocumento() {
		return codDocumento;
	}
	public void setCodDocumento(String codDocumento) {
		this.codDocumento = codDocumento;
	}
	public String getDescDocumento() {
		return descDocumento;
	}
	public String getDescProduto() {
		return descProduto;
	}
	public void setDescProduto(String descProduto) {
		this.descProduto = descProduto;
	}
	public void setDescDocumento(String descDocumento) {
		this.descDocumento = descDocumento;
	}
	public String getCodCliente() {
		return codCliente;
	}
	public void setCodCliente(String codCliente) {
		this.codCliente = codCliente;
	}
	public String getNomeCliente() {
		return nomeCliente;
	}
	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}
	public Date getDataGeracao() {
		return dataGeracao;
	}
	public void setDataGeracao(Date dataGeracao) {
		this.dataGeracao = dataGeracao;
	}
	public Date getDataEnvio() {
		return dataEnvio;
	}
	public void setDataEnvio(Date dataEnvio) {
		this.dataEnvio = dataEnvio;
	}
	public StatusDocumento getStatus() {
		return StatusDocumento.get(status);
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRamo() {
		return ramo;
	}
	public void setRamo(String ramo) {
		this.ramo = ramo;
	}
	public Long getNumApolice() {
		return numApolice;
	}
	public void setNumApolice(Long numApolice) {
		this.numApolice = numApolice;
	}
	public Integer getNumEndosso() {
		return numEndosso;
	}
	public void setNumEndosso(Integer numEndosso) {
		this.numEndosso = numEndosso;
	}
	public Integer getNumNegocio() {
		return numNegocio;
	}
	public void setNumNegocio(Integer numNegocio) {
		this.numNegocio = numNegocio;
	}
	public String getCodPacote() {
		return codPacote;
	}
	public void setCodPacote(String codPacote) {
		this.codPacote = codPacote;
	}
	public String getDescPacote() {
		return descPacote;
	}
	public void setDescPacote(String descPacote) {
		this.descPacote = descPacote;
	}
	public EnderecoDTO getEnderecoEnvio() {
		return enderecoEnvio;
	}
	public void setEnderecoEnvio(EnderecoDTO enderecoEnvio) {
		this.enderecoEnvio = enderecoEnvio;
	}
	public String getEmailEnvio() {
		return emailEnvio;
	}
	public void setEmailEnvio(String emailEnvio) {
		this.emailEnvio = emailEnvio;
	}
	public Date getDataEnvioEmail() {
		return dataEnvioEmail;
	}
	public void setDataEnvioEmail(Date dataEnvioEmail) {
		this.dataEnvioEmail = dataEnvioEmail;
	}
	public String getCodCompanhia() {
		return codCompanhia;
	}
	public void setCodCompanhia(String codCompanhia) {
		this.codCompanhia = codCompanhia;
	}
	public String getNomeCompanhia() {
		return nomeCompanhia;
	}
	public void setNomeCompanhia(String nomeCompanhia) {
		this.nomeCompanhia = nomeCompanhia;
	}
	public String getCodCorretor() {
		return codCorretor;
	}
	public void setCodCorretor(String codCorretor) {
		this.codCorretor = codCorretor;
	}
	public String getNomeCorretor() {
		return nomeCorretor;
	}
	public void setNomeCorretor(String nomeCorretor) {
		this.nomeCorretor = nomeCorretor;
	}
	public TipoDestino getTipoDestino() {
		return TipoDestino.get(tipoDestino);
	}
	public void setTipoDestino(String tipoDestino) {
		this.tipoDestino = tipoDestino;
	}
	public Boolean getIndMultiItem() {
		return indMultiItem != null && indMultiItem.equals("S");
	}
	public void setIndMultiItem(String indMultiItem) {
		this.indMultiItem = indMultiItem;
	}
	public FormaEnvio getFormaEnvio() {
		if(formaEnvio.length() > 2)
		{
			return FormaEnvio.get(formaEnvio.substring(formaEnvio.length() - 2));
		}
		if (formaEnvio.length() < 2) {
			return FormaEnvio.get("0" + formaEnvio);
		}
		return FormaEnvio.get(formaEnvio);
	}
	public void setFormaEnvio(String formaEnvio) {
		this.formaEnvio = formaEnvio;
	}
	public String getTipoEnvio() {
		return tipoEnvio;
	}
	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}
	public EnderecoDTO getEnderecoCorretor() {
		return enderecoCorretor;
	}
	public void setEnderecoCorretor(EnderecoDTO enderecoCorretor) {
		this.enderecoCorretor = enderecoCorretor;
	}
	public List<EnderecoDTO> getEnderecosCliente() {
		return enderecosCliente;
	}
	public void setEnderecosCliente(List<EnderecoDTO> enderecosCliente) {
		this.enderecosCliente = enderecosCliente;
	}
	public boolean isIndSolicitado() {
		return indSolicitado;
	}
	public void setIndSolicitado(boolean indSolicitado) {
		this.indSolicitado = indSolicitado;
	}
	public List<SegundaViaDTO> getHistSegundaVia() {
		return histSegundaVia;
	}
	public void setHistSegundaVia(List<SegundaViaDTO> histSegundaVia) {
		this.histSegundaVia = histSegundaVia;
	}
	public Sistema getSistemaOrigem() {
		return sistemaOrigem;
	}
	public void setSistemaOrigem(Sistema sistemaOrigem) {
		this.sistemaOrigem = sistemaOrigem;
	}
	public String getTipoEndosso() {
		return tipoEndosso;
	}
	public void setTipoEndosso(String tipoEndosso) {
		this.tipoEndosso = tipoEndosso;
	}
	public String getDescEndosso() {
		return descEndosso;
	}
	public void setDescEndosso(String descEndosso) {
		this.descEndosso = descEndosso;
	}
	public String getTipoOper() {
		return tipoOper;
	}
	public void setTipoOper(String tipoOper) {
		this.tipoOper = tipoOper;
	}
	public Long getIdePol() {
		return idePol;
	}
	public void setIdePol(Long idePol) {
		this.idePol = idePol;
	}
	public Long getNumCert() {
		return numCert;
	}
	public void setNumCert(Long numCert) {
		this.numCert = numCert;
	}
	public Long getNumOper() {
		return numOper;
	}
	public void setNumOper(Long numOper) {
		this.numOper = numOper;
	}
	public Long getNumItem() {
		return numItem;
	}
	public void setNumItem(Long numItem) {
		this.numItem = numItem;
	}
	public Long getSeqAgendamento() {
		return seqAgendamento;
	}
	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}
	public String getCodModProd() {
		return codModProd;
	}
	public void setCodModProd(String codModProd) {
		this.codModProd = codModProd;
	}
	public List<DownloadDocumentoDTO> getDocumentosDownload() {
		return documentosDownload;
	}
	public void setDocumentosDownload(List<DownloadDocumentoDTO> documentosDownload) {
		this.documentosDownload = documentosDownload;
	}
	public void setUltimaSolicitacao(SegundaViaDTO ultimaSolicitacao) {
		this.ultimaSolicitacao = ultimaSolicitacao;
	}
	public SegundaViaDTO getUltimaSolicitacao(){
		return this.ultimaSolicitacao;
	}
	public List<ItemApoliceDTO> getListaItens() {
		if (this.listaItens == null){
			this.listaItens = new ArrayList<ItemApoliceDTO>();
		}
		return listaItens;
	}
	public void setListaItens(List<ItemApoliceDTO> listaItens) {
		this.listaItens = listaItens;
	}
	public ItemApoliceDTO getItem(String codItem){
		for (ItemApoliceDTO itemApoliceDTO : listaItens) {
			if (itemApoliceDTO.getCodItem().equals(codItem)) {
				return itemApoliceDTO;				
			}
		}
		return null;
	}
	public DownloadDocumentoDTO getDocumentoDownload(Long codDocumento){
		for (DownloadDocumentoDTO documento : documentosDownload) {
			if (documento.getIdDocumento().equals(codDocumento))
				return documento;
		}
		return null;
	}
	public String getCodItem() {
		return codItem;
	}
	public void setCodItem(String codItem) {
		this.codItem = codItem;
	}
	public String getTipoApoliceEndosso() {
		return tipoApoliceEndosso;
	}
	public void setTipoApoliceEndosso(String tipoApoliceEndosso) {
		this.tipoApoliceEndosso = tipoApoliceEndosso;
	}
	public String getCodProduto() {
		return codProduto;
	}
	public void setCodProduto(String codProduto) {
		this.codProduto = codProduto;
	}
	
	@Override
	public int compareTo(Object object) {
		DocumentoDTO outro = (DocumentoDTO) object;
		return this.dataGeracao.compareTo(outro.dataGeracao);
	}

}
