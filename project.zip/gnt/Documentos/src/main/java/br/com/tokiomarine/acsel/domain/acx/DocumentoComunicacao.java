package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DOCUMENTOS_COMUNICACAO")
public class DocumentoComunicacao {

	@Id
	@Column(name="CD_DOCUMENTO")
	private Long codDocumento;

	@Column(name="DS_DOCUMENTO")
	private String descDocumento;

	@Column(name="DT_ATUALIZACAO")
	private Date dtAtualizacao;

	@Column(name="NM_USUARIO_ATUALIZACAO")
	private String nomeUsuarioAtualizacao;

	public Long getCodDocumento() {
		return codDocumento;
	}

	public void setCodDocumento(Long codDocumento) {
		this.codDocumento = codDocumento;
	}

	public String getDescDocumento() {
		return descDocumento;
	}

	public void setDescDocumento(String descDocumento) {
		this.descDocumento = descDocumento;
	}

	public Date getDtAtualizacao() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}

	public String getNomeUsuarioAtualizacao() {
		return nomeUsuarioAtualizacao;
	}

	public void setNomeUsuarioAtualizacao(String nomeUsuarioAtualizacao) {
		this.nomeUsuarioAtualizacao = nomeUsuarioAtualizacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((codDocumento == null) ? 0 : codDocumento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentoComunicacao other = (DocumentoComunicacao) obj;
		if (codDocumento == null) {
			if (other.codDocumento != null)
				return false;
		} else if (!codDocumento.equals(other.codDocumento))
			return false;
		return true;
	}

}