package br.com.tokiomarine.acsel.comunicador.mail;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject; 
import javax.inject.Named;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.comunicador.ComunicadorEnvioTemplate;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoAnexo;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComCopia;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.dto.AnexoEmail;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "GNTMail")
@Local(value = GNTMail.class)
@Named("gntMail")
public class GNTMail extends ComunicadorEnvioTemplate {

	private static Logger logger = LogManager.getLogger(GNTMail.class);

	@Inject
	TokioMail tokioMail;

	@Inject
	BodyMail bodyMail;

	public GNTMail() {}
	
	@Override
	protected String geraMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException {
		return this.bodyMail.getBody(agendamentoEnvio);
	}

	@Override
	protected void enviarMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException {
		try {
			List<String> destinatarios = new ArrayList<String>();
			for (AgendamentoDestinatario email : agendamentoEnvio.getAgendamento().getDestinatariosValidos()) {
				destinatarios.add(email.getDestinatario());
			}

			List<String> destinatariosCopia = new ArrayList<String>();
			List<String> destinatariosOculto = new ArrayList<String>();
			
			if (!StringUtil.isNull(agendamentoEnvio.getCaixaDepto())) {
				if (agendamentoEnvio.getCaixaDepto().toUpperCase().contains("@TOKIOMARINE.COM.BR")) {
					destinatariosCopia.add(agendamentoEnvio.getCaixaDepto());
				}
			}
			
			
			if (agendamentoEnvio.getAgendamento().getComCopias() != null  && agendamentoEnvio.getAgendamento().getComCopias().size() > 0) {
				for (AgendamentoComCopia agendamentoComCopia : agendamentoEnvio.getAgendamento().getComCopias()) {
					if (agendamentoComCopia.getCopiaOculta().equals("S") ) {
						destinatariosOculto.add(agendamentoComCopia.getDestinatario());
					} else {
						destinatariosCopia.add(agendamentoComCopia.getDestinatario());
					}
				}
			}
			
			if (destinatarios.isEmpty())
				throw new ServiceException("Nenhum e-mail válido foi informado");

			if (agendamentoEnvio.contemAnexos()) {
				List<AnexoEmail> anexos = new ArrayList<>();
				for (AgendamentoAnexo anexo : agendamentoEnvio.getAgendamentoAnexos()) {
					anexos.add(AnexoEmail.builder().nome(anexo.getNome()).binario(anexo.getArquivoBase64()).build());
				}
				logger.info("Enviando Email com Anexos...");
				this.tokioMail.sendMailHtmlAttach(agendamentoEnvio.getTitulo(),
						agendamentoEnvio.getAgendamento().getMensagemEnviada(), agendamentoEnvio.getRemetente(),
						destinatarios.toArray(new String[destinatarios.size()]),
						destinatariosCopia.toArray(new String[destinatariosCopia.size()]),
						destinatariosOculto.toArray(new String[destinatariosOculto.size()]),
						anexos.toArray(new AnexoEmail[anexos.size()]),
						agendamentoEnvio.getAgendamento().getSeqAgendamento());
				return;
			}
 
			logger.info("Enviando Email...");
			this.tokioMail.sendMailHtml(agendamentoEnvio.getTitulo(),
					agendamentoEnvio.getAgendamento().getMensagemEnviada(), agendamentoEnvio.getRemetente(),
					destinatarios.toArray(new String[destinatarios.size()]),
					destinatariosCopia.toArray(new String[destinatariosCopia.size()]),
					destinatariosOculto.toArray(new String[destinatariosOculto.size()]),					
					agendamentoEnvio.getAgendamento().getSeqAgendamento());

		} catch (ServiceException s) {
			throw s;
		} catch (Exception e) {
			String msg = e == null ? "Erro ao enviar e-mail" : e.getMessage();
			logger.error("Erro ao enviar e-mail " + msg, e);
			throw new ServiceException(msg);
		}
	}

	/***
	 * Esse metodo envia email simples apenas a um destinatario e com uma mensagem.
	 * @throws ServiceException
	 */
	public void enviarMensagem(String destinatario, String codigo, String template) throws ServiceException {
		try {
			List<String> destinatarios = new ArrayList<String>();
			destinatarios.add(destinatario);
			
			List<String> cc = new ArrayList<String>();
			if (destinatarios.isEmpty()) {
				throw new ServiceException("Nenhum e-mail válido foi informado");
			}
				
			StringBuilder sb = new StringBuilder();
			sb.append("<h1>Prezado,</h1>");
			sb.append("<p>Segue informações para uso do GNT referente ao documento de código: " + codigo + " </p>");
			sb.append("<p>" + template + "</p>");
			sb.append("<br/>");
			sb.append("<h1>RESTful API Service</h1>");
			sb.append("Dev: http://srvacx01d:8080/acx/documentos-rest/comunicacao/agendamento?envia=S</p>");
			sb.append("Act: https://servicos-aceiteint.tokiomarine.com.br/acx/documentos-rest/comunicacao/agendamento?envia=S</p>");
			sb.append("Prod: https://servicos-int.tokiomarine.com.br/acx/documentos-rest/comunicacao/agendamento?envia=S</p>");
			sb.append("<br/>");
			sb.append("<p>Para maiores informações acesse nossa documentação:</p>");
			sb.append("http://gitlab.tokiomarine.com.br/gestao-de-apolices/gnt/wikis/home");
			
			this.tokioMail.sendMailHtml("Template GNT", sb.toString(), 
					                    "no-reply@tokiomarine.com.br", 
					                    destinatarios.toArray(new String[destinatarios.size()]), 
					                    cc.toArray(new String[cc.size()]),
					                    cc.toArray(new String[cc.size()]),
					                    0L);
			
		} catch (ServiceException s) {
			throw s;
		} catch (Exception e) {
			String msg = e == null ? "Erro ao enviar e-mail" : e.getMessage();
			logger.error("Erro ao enviar e-mail " + msg, e);
			throw new ServiceException(msg);
		}
	}
	
}
