package br.com.tokiomarine.acsel.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoSistemaOrigem;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoSistemaOrigemService;
import br.com.tokiomarine.acsel.service.ParametrosService;

@Stateless(name="ModeloComunicacaoSistemaOrigemService")
@Local(value=ModeloComunicacaoSistemaOrigemService.class)
public class ModeloComunicacaoSistemaOrigemServiceImpl implements ModeloComunicacaoSistemaOrigemService {

	@Inject
	ParametrosService paramsService;
	
	@Override
	public Collection<ModeloComunicacaoSistemaOrigem> findAll() {
		Collection<ModeloComunicacaoSistemaOrigem> list = new ArrayList<>();
		List<Lval> obtemListaValores = this.paramsService.obtemListaValores("GNT_SIOR");
		for (Lval lval : obtemListaValores) {
			list.add(ModeloComunicacaoSistemaOrigem.builder().codigo(lval.getCodLval()).descricao(lval.getDescrip()).build());
		}
		return list;
	}

}
