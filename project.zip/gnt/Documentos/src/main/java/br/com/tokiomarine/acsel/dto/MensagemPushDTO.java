package br.com.tokiomarine.acsel.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class MensagemPushDTO {

	private String value;

	@JsonInclude(Include.NON_EMPTY)
	private Map<String, String> key = new HashMap<String,String>();

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Map<String, String> getKey() {
		return key;
	}

	public void setKey(Map<String, String> key) {
		this.key = key;
	}
}
