package br.com.tokiomarine.acsel.service.impl;

import java.util.Date;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.comunicador.Comunicador;
import br.com.tokiomarine.acsel.comunicador.ComunicadorFactory;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.dto.AgendamentoComunicacaoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.AgendamentoComunicacaoRepository;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.AgendamentoComunicacaoService;
import br.com.tokiomarine.acsel.service.EnvioComunicacaoService;
import br.com.tokiomarine.acsel.service.MensagemParserService;
import br.com.tokiomarine.acsel.service.ValidaAgendamentoService;
import br.com.tokiomarine.acsel.type.StatusAgendamento;
import br.com.tokiomarine.acsel.util.StringUtil;
import br.com.tokiomarine.seguradora.arquitetura.framework.queue.QueueManager;

@Stateless(name = "EnvioComunicacaoService")
@Local(value = EnvioComunicacaoService.class)
public class EnvioComunicacaoServiceImpl implements EnvioComunicacaoService{

	private static Logger logger = LogManager.getLogger(EnvioComunicacaoServiceImpl.class);
	
	@Inject
	AgendamentoComunicacaoService agendamentoService;
	 
	/*
	 * OBSOLETO
	 */
	//@Inject
	//EmailParserService emailService;

	//@Inject
	//private TokioMail tokioMail;
	
	@Inject
	MensagemParserService mensagemService;
	@Inject
	ValidaAgendamentoService validaAgendamento;
	@Inject
	AgendamentoComunicacaoRepository agendamentoDao;
	@Inject
	ParametrosRepository parametrosDao;

	@Inject
	private ComunicadorFactory comunicadorFactory;


	@Override
	public boolean solicitaEnvio(Long seqAgendamento) throws ServiceException{
		if (seqAgendamento == null){
			logger.info("O código do agendamento deve ser informado");
			throw new ServiceException("O código do agendamento deve ser informado");
		}

		AgendamentoComunicacao agendamento = agendamentoService.obtemAgendamento(seqAgendamento);

		if (StringUtil.in(agendamento.getStatusAgendamento(), StatusAgendamento.pendente.getValue(), StatusAgendamento.finalizado.getValue(), StatusAgendamento.enviado.getValue())){
			throw new ServiceException("Envio de e-mail não disponível para esse agendamento");
		}

		AgendamentoEnvio envio = incluiAgendamento(agendamento,null);

		boolean valido = validaAgendamento.validaAgendamento(envio);

		if (valido){
			if ( !agendamento.getStatusAgendamento().equals(StatusAgendamento.piloto.getValue()) ) {
				agendamento.setStatusAgendamento(StatusAgendamento.pendente.getValue());
				agendamentoDao.atualizaAgendamento(envio.getAgendamento());
				enviaFila(envio);
			}
		} else{
			agendamento.setStatusAgendamento(StatusAgendamento.erro.getValue());
			agendamentoDao.atualizaAgendamento(envio.getAgendamento());
		}
		return valido;
	}

	/***
	 * Metodo chama a verificação dos parametros do documento AgendamentoComunicacaoDTO.
	 */
	@Override
	public void validaAgendamentoDTO(AgendamentoComunicacaoDTO agendamento) throws ServiceException {
		validaAgendamento.validaAgendamentoComunicacaoDTO(agendamento);
	}
	
	@Override
	public void solicitaReenvio(Long seqAgendamento, String usuario) throws ServiceException {
		if (seqAgendamento == null){
			throw new ServiceException("O código do agendamento deve ser informado");
		}

		AgendamentoComunicacao agendamento = agendamentoService.obtemAgendamento(seqAgendamento);

		if (!agendamento.getStatusAgendamento().equals(StatusAgendamento.enviado.getValue())){
			throw new ServiceException("Reenvio de e-mail não disponível para esse agendamento");
		}

		for (AgendamentoEnvio envio : agendamento.getEnvios()){
			if (envio.getStatusEnvio().equals(StatusAgendamento.pendente.getValue())){
				throw new ServiceException("Já existe uma solicitação de reenvio pendente");
			}
		}

		AgendamentoEnvio envio = incluiAgendamento(agendamento,usuario);
		enviaFila(envio);
	}

	@Override
	public void reprocessaEnvio(Long seqAgendamento) throws ServiceException{
		if (seqAgendamento == null){
			throw new ServiceException("O código do agendamento deve ser informado");
		}

		AgendamentoEnvio envio = agendamentoDao.obtemEnvioPendente(seqAgendamento);

		if (envio != null){
			enviaFila(envio);
		}
	}

	@Override
	public void enviaAgendamento(Long envioId) throws ServiceException{

		AgendamentoEnvio env = agendamentoDao.obtemEnvioAgendado(envioId);
		
		if (env == null){
			try {Thread.sleep(2000);} catch (Exception e) {}
			env = agendamentoDao.obtemEnvioAgendado(envioId);
			if (env == null){
				throw new ServiceException("Não foi encontrado agendamento pendente para o id " + envioId);
			}
		}
		
//		System.out.println(env.getAgendamento().getModelo().getPadrao().getFormatacaoPadrao());
		
		boolean reenvio = (env.getAgendamento().getQuantidadeEnvios() > 0);
//08-2018		logger.info("Enviando agendamento. Seq Env: "+ env.getSeqEnvio());
//08-2018		logger.info("Enviando...");
		try {
			Comunicador comunicador = comunicadorFactory.getComunicador(env.getAgendamentoModeloCanalComunicacao()); 	
			comunicador.enviar(env);
			
			env.setStatusEnvio(StatusAgendamento.enviado.getValue());
			env.setDtEnvio(new Date());

		} catch (ServiceException s) {
			validaAgendamento.incluiErro(env, s.getMessage());
			logger.error(s.getMessage());
		} catch (Exception e){
			validaAgendamento.incluiErro(env, "Erro ao enviar agendamento: " + e.getMessage());
			logger.error(e.getMessage());
		}
 
		agendamentoDao.atualizaAgendamentoEnvio(env);
		if (!reenvio){
			env.getAgendamento().setDtEnvioOriginal(env.getDtEnvio());
			env.getAgendamento().setStatusAgendamento(env.getStatusEnvio());
			agendamentoDao.atualizaAgendamento(env.getAgendamento());
		}
	}

	private AgendamentoEnvio incluiAgendamento(AgendamentoComunicacao agendamento, String usuario) throws ServiceException{
		AgendamentoEnvio envio = new AgendamentoEnvio();
		envio.setAgendamento(agendamento);
		envio.setCaixaDepto(agendamento.getModelo().getEmailCaixaDept());
		
		if (agendamento.getEmailRemetente() != null && !agendamento.getEmailRemetente().trim().equals("")) {
			envio.setRemetente(agendamento.getEmailRemetente());
		} else {
			envio.setRemetente(agendamento.getModelo().getEmailRemetente());			
		}
		
		envio.setDtSolicEnvio(new Date());
		envio.setUsuarioInclusao(usuario);
		envio.setDtInclusao(new Date());
		envio.setStatusEnvio(StatusAgendamento.pendente.getValue());
		mensagemService.geraTitulo(envio);

		return agendamentoDao.incluiAgendamentoEnvio(envio);
	}

	private void enviaFila(AgendamentoEnvio env) throws ServiceException{
		try {
			QueueManager.getInstance().send(parametrosDao.obtemVlrParametro("JMS_FILAS", "JMS.FILA.EMAIL"), env.getSeqEnvio().toString());
		} catch (Exception e) {
			logger.info("Erro Agendamento: " + env.getAgendamento().getSeqAgendamento(), e);			
			throw new ServiceException("Erro ao enviar o agendamento para a fila: " + e.getMessage());
		}
	}
	
//	private void enviaSMS(AgendamentoEnvio env) throws ServiceException{
//		try {
//
//			Map<String, String> mensagens = env.getAgendamento().getMensagens();
//			String url = parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "URL_SMS_ENVIO");
//			String chave = parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "SMS_API_KEY");
//
//			for (AgendamentoDestinatario cel : env.getAgendamento().getDestinatariosValidos()){
//
//				ClientRequest request = new ClientRequest(url);
//
//				MultipartFormDataOutput formParameters = new MultipartFormDataOutput();
//
//				formParameters.addFormData("apikey", chave, MediaType.TEXT_PLAIN_TYPE);
//				formParameters.addFormData("ntc", "55"+cel.getDestinatario(), MediaType.TEXT_PLAIN_TYPE);
//				formParameters.addFormData("mensagem", mensagens.get("mensagem"), MediaType.TEXT_PLAIN_TYPE);
//				formParameters.addFormData("id", "SQ_AGENDAMENTO=" + env.getAgendamento().getSeqAgendamento().toString(), MediaType.TEXT_PLAIN_TYPE);
//
//				request.body(MediaType.MULTIPART_FORM_DATA_TYPE, formParameters);
//
//				ClientResponse<String> response = request.post(String.class);
//
//				if (response.getResponseStatus().equals(Status.OK)){
//					env.setCodRetornoEnvio(response.getEntity());
//				} else{
//					logger.error("Erro ao acessar serviço de envio de SMS: " + response.getEntity());
//					throw new ServiceException("Erro ao acessar serviço de envio de SMS: " + response.getResponseStatus());
//				}
//			}
//
//		} catch (Exception e){
//			logger.error("Erro ao enviar SMS", e);
//			throw new ServiceException("Erro ao enviar SMS");
//		}
//	}

//	private void enviaPush(AgendamentoEnvio env) throws ServiceException{
//		try {
//
//			for (AgendamentoDestinatario dest : env.getAgendamento().getDestinatariosValidos()){
//
//				PushNotificationDTO push = new PushNotificationDTO();
//
//				push.setFinalidade("");
//				push.setDestinatario(dest.getDestinatario());
//				push.setTitulo(env.getTitulo());
//
//				Map<String, String> mensagens = env.getAgendamento().getMensagens();
//
//				push.setChamada(mensagens.get("chamada"));
//
//				MensagemPushDTO key = new MensagemPushDTO();
//
//				for (ParametroModelo param : env.getAgendamento().getModelo().getParametros()){
//					if (param.getIndExibeLista().equals("S")){
//						key.getKey().put(param.getNomeExibicao(), env.getAgendamento().getValorParametro(param.getParametro().getNomeParametro()));
//					}
//				}
//
//				if (key.getKey().isEmpty()){
//					push.setMensagem(mensagens.get("mensagem"));
//					push.setMensagemKey(null);
//				} else{
//					push.setMensagem(null);
//					key.setValue(mensagens.get("mensagem"));
//					push.setMensagemKey(key);
//				}
//
//				ClientRequest request = new ClientRequest(parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "URL_SERVICE_SEND"));
//
//				MultivaluedMap<String, String> headers = request.getHeaders();
//				headers.putSingle("user-token", parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "USER_TOKEN"));
//
//				ClientResponse<RetornoPushNotificationDTO> response =
//						request.body(MediaType.APPLICATION_JSON_TYPE, push).post(RetornoPushNotificationDTO.class);
//
//				RetornoPushNotificationDTO dadosRetorno = response.getEntity();
//
//				if (dadosRetorno.getData() != null){
//					if (dadosRetorno.getData().getErros() != null && !dadosRetorno.getData().getErros().isEmpty()){
//						for (String msgErro : dadosRetorno.getData().getErros()){
//							validaAgendamento.incluiErro(env, msgErro);
//						}
//					}
//				} else if (!StringUtil.isNull(dadosRetorno.getBusinessException())){
//					validaAgendamento.incluiErro(env, dadosRetorno.getBusinessException());
//				} else{
//					throw new ServiceException("Retorno inválido ao enviar notificação");
//				}
//			}
//
//		} catch(ServiceException s){
//			throw s;
//		} catch (Exception e){
//			logger.error("Erro ao enviar push notification", e);
//			throw new ServiceException("Erro ao enviar push notification");
//		}
//	}

//	private void enviaEmail(AgendamentoEnvio env) throws ServiceException{
//		try {
//			List<String> destinatarios = new ArrayList<String>();
//			List<String> destinatariosCopia = new ArrayList<String>();
//
//			for (AgendamentoDestinatario email : env.getAgendamento().getDestinatariosValidos()){
//				destinatarios.add(email.getDestinatario());
//			}
//
//			if (!StringUtil.isNull(env.getCaixaDepto())){
//				if (env.getCaixaDepto().toUpperCase().contains("@TOKIOMARINE.COM.BR")){
//					destinatariosCopia.add(env.getCaixaDepto());
//				}
//			}
//
//			if (destinatarios.isEmpty()){
//				throw new ServiceException("Nenhum e-mail válido foi informado");
//			}
//
//			// OBSOLETO
//			//EmailHTML email = new EmailHTML(
//			//		env.getTitulo(), env.getAgendamento().getMensagemEnviada(), env.getRemetente(), destinatarios, destinatariosCopia);
//			//email.enviar();  
//   
//			boolean emailComAnexo = env.getAgendamento().getAnexos() != null;
//			
//			if(emailComAnexo == true) { 
//				
//				List<AnexoEmail> anexos = new ArrayList<>();
//				for (AgendamentoAnexo anexo : env.getAgendamentoAnexos()) {
//					anexos.add(AnexoEmail.builder().nome(anexo.getNome()).binario(anexo.getArquivoBase64()).build());
//				}
//				
//				this.tokioMail.sendMailHtmlAttach(env.getTitulo(), 
//												  env.getAgendamento().getMensagemEnviada(), 
//												  env.getRemetente(), 
//												  destinatarios.toArray(new String[destinatarios.size()]), 
//												  destinatariosCopia.toArray(new String[destinatariosCopia.size()]),
//												  anexos.toArray(new AnexoEmail[anexos.size()])); 				
//				return;
//			}
//			
//			this.tokioMail.sendMailHtml(env.getTitulo(), 
//									    env.getAgendamento().getMensagemEnviada(), 
//									    env.getRemetente(), 
//									    destinatarios.toArray(new String[destinatarios.size()]), 
//									    destinatariosCopia.toArray(new String[destinatariosCopia.size()])); 
//			
//		} catch(ServiceException s){ 
//			throw s;
////		} catch (RemetenteInvalidoException | EnvioDeEmailException e) {
////			throw new ServiceException(e.getMessage());
//		} catch (Exception e){
//			logger.error("Erro ao enviar e-mail", e);
//			throw new ServiceException("Erro ao enviar e-mail");
//		}
//	}

}
