package br.com.tokiomarine.acsel.repository;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoParametro;
import br.com.tokiomarine.acsel.dto.BuscaAgendamentoDTO;
import br.com.tokiomarine.acsel.dto.ParametroComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.ResumoAgendamentoDTO;
import br.com.tokiomarine.acsel.util.StringUtil;

public class AgendamentoComunicacaoRepository{

	@Inject
	BaseAcxDAO base;

	@SuppressWarnings("unchecked")
	public List<AgendamentoComunicacao> buscaAgendamentos(BuscaAgendamentoDTO busca) {
		Criteria crit = base.getSession().createCriteria(AgendamentoComunicacao.class,"aa");

		if (busca.getDataIni() != null && busca.getDataFim() != null){
			Calendar dataFim = Calendar.getInstance();
			dataFim.setTime(busca.getDataFim());
			dataFim.add(Calendar.DAY_OF_YEAR, 1);
			crit.add(Restrictions.or(Restrictions.between("dtEnvioOriginal", busca.getDataIni(), dataFim.getTime()),
					Restrictions.between("dtAgendamento", busca.getDataIni(), dataFim.getTime())));
		}

		if (busca.getCodModelo() != null){
			crit.add(Restrictions.eq("modelo.codModelo",busca.getCodModelo()));
		}
		if (busca.getSeqAgendamento() != null){
			crit.add(Restrictions.eq("seqAgendamento",busca.getSeqAgendamento()));
		}
		if (!StringUtil.isNull(busca.getTipoEnvio())){
			crit.add(Restrictions.eq("tipoEnvio", busca.getTipoEnvio()));
		}	
		if (!StringUtil.isNull(busca.getDestinatario())){
			crit.createAlias("destinatarios", "e").add(Restrictions.eq("e.destinatario", busca.getDestinatario()));
		}
		
		if (!StringUtil.isNull(busca.getCpfCnpj())){
			Long retiraZero = Long.parseLong(busca.getCpfCnpj());
			crit.createAlias("destinatarios", "e").add(Restrictions.eq("e.cpfCnpj", retiraZero.toString()));
		}		
	
		crit.setFetchMode("envios", FetchMode.JOIN);

		if (busca.getParametros() != null){
			for (ParametroComunicacaoDTO param : busca.getParametros()) {
				if (!StringUtil.isNull(param.getValorParametro()))
						filtraParametro(crit, param.getCodParametro(),param.getValorParametro().replaceFirst("^0+(?!$)", ""));
			}
		} 

		crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		crit.setMaxResults(1000);
		return crit.list();
	}

	// GNT-99 - Necessidade do parametro [MENSAGEM_GENERICA] com mais de 4.000 caracteres
	private void filtraParametro(Criteria crit, Long codParametro, String valorParametro) {
		DetachedCriteria dc = DetachedCriteria.forClass(AgendamentoParametro.class,"ab")
				.add(Property.forName("ab.agendamento.seqAgendamento").eqProperty("aa.seqAgendamento"))
			    .add(Restrictions.eq("parametro.codParametro", codParametro))
			    // .add(Restrictions.eq("valorParametro", valorParametro))
			    .add(Restrictions.eq("dsValorParametro", valorParametro))
			    .setProjection(Projections.id());
		crit.add(Subqueries.exists(dc));
	}

	public AgendamentoComunicacao obtemAgendamento(Long id){
		return base.findById(AgendamentoComunicacao.class, id);
	}

	public AgendamentoEnvio obtemAgendamentoEnvio(Long id){
		return base.findById(AgendamentoEnvio.class, id);
	}

	public AgendamentoComunicacao incluiAgendamento(AgendamentoComunicacao agendamento) {
		base.persist(agendamento);
		base.flush();
		return agendamento;
	}

	public AgendamentoComunicacao atualizaAgendamento(AgendamentoComunicacao agendamento) {
		AgendamentoComunicacao agend = (AgendamentoComunicacao) base.merge(agendamento);
		base.flush();
		return agend;
	}

	public AgendamentoEnvio atualizaAgendamentoEnvio(AgendamentoEnvio agendamentoEnvio) {
		AgendamentoEnvio env = (AgendamentoEnvio) base.merge(agendamentoEnvio);
		base.flush();
		return env;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public AgendamentoEnvio incluiAgendamentoEnvio(AgendamentoEnvio agendamentoEnvio){
		base.persist(agendamentoEnvio);
		base.flush();
		return agendamentoEnvio;
	}

	public AgendamentoErro incluiAgendamentoErro(AgendamentoErro agendamentoErro){
		base.persist(agendamentoErro);
		return agendamentoErro;
	}

	public AgendamentoEnvio obtemEnvioAgendado(Long seqEnvio){
		return (AgendamentoEnvio) base.getSession().createCriteria(AgendamentoEnvio.class)
				.add(Restrictions.eq("statusEnvio", "PND"))
				.add(Restrictions.eq("seqEnvio", seqEnvio))
				.uniqueResult();
	}

	public AgendamentoEnvio obtemEnvioPendente(Long seqAgendamento){
		return (AgendamentoEnvio) base.getSession().createCriteria(AgendamentoEnvio.class)
				.add(Restrictions.eq("statusEnvio", "PND"))
				.add(Restrictions.eq("agendamento.seqAgendamento", seqAgendamento))
				.uniqueResult();
	}

	public AgendamentoEnvio obtemUltimoEnvio(Long seqAgendamento){
		@SuppressWarnings("unchecked")
		List<AgendamentoEnvio> lista = base.getSession().createCriteria(AgendamentoEnvio.class)
				.add(Restrictions.eq("agendamento.seqAgendamento", seqAgendamento))
				.addOrder(Order.desc("dtSolicEnvio"))
				.list();

		if (lista != null && !lista.isEmpty()){
			return lista.get(0);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<AgendamentoErro> obtemErros(Long id) {
		return base.getSession().createCriteria(AgendamentoErro.class)
				.add(Restrictions.eq("agendamento.seqEnvio", id))
				.list();
	}

	@SuppressWarnings("unchecked")
	public List<AgendamentoComunicacao> buscaAgendamentosDia(Long idModelo, Date dataRef){

		Criteria crit = base.getSession().createCriteria(AgendamentoComunicacao.class,"aa");

		Calendar dataIni = Calendar.getInstance();
		dataIni.setTime(dataRef);
		dataIni.set(Calendar.HOUR_OF_DAY, 0);
		dataIni.set(Calendar.MINUTE, 0);
		dataIni.set(Calendar.SECOND, 0);
		dataIni.set(Calendar.MILLISECOND, 0);

		Calendar dataFim = Calendar.getInstance();
		dataFim.setTime(dataIni.getTime());
		dataFim.add(Calendar.DAY_OF_YEAR, 1);

		crit.add(Restrictions.eq("modelo.codModelo", idModelo));
		crit.add(Restrictions.between("dtAgendamento", dataIni.getTime(), dataFim.getTime()));

		return crit.list();
	}

	@SuppressWarnings("unchecked")
	public List<ResumoAgendamentoDTO> obtemResumoDia(Date dataRef){

		String sql =

			" SELECT m.nm_modelo_comunicacao \"nomeModelo\"," +
			"        m.cd_tipo_modelo \"tipoModelo\"," +
			"        m.nm_sistema_origem \"nomeSistema\"," +
			"        SUM(CASE WHEN c.id_situacao_agendamento = 'ENV' THEN 1 ELSE 0 END) \"qtdEnviados\"," +
			"        SUM(CASE WHEN c.id_situacao_agendamento IN ('NEV','PND') THEN 1 ELSE 0 END) \"qtdNaoEnviados\"," +
			"        SUM(CASE WHEN c.id_situacao_agendamento = 'ERR' THEN 1 ELSE 0 END) \"qtdErro\"" +
			" FROM   modelo_comunicacao      m" +
			" LEFT   JOIN agendamento_comunicacao c" +
			" ON     m.cd_modelo_comunicacao = c.cd_modelo_comunicacao" +
			" AND    trunc(c.dt_agendamento) = trunc(:dataRef)" +
			" AND    c.id_envia_comunic = 'S'" +
			" WHERE  m.id_situacao = 'S'" +
			" GROUP  BY m.nm_modelo_comunicacao," +
			"           m.cd_tipo_modelo," +
			"           m.nm_sistema_origem," +
			"           TRUNC(c.dt_agendamento)";

			return base.getSession().createSQLQuery(sql)
					.addScalar("nomeModelo")
					.addScalar("tipoModelo")
					.addScalar("nomeSistema")
					.addScalar("qtdEnviados", StandardBasicTypes.INTEGER)
					.addScalar("qtdNaoEnviados", StandardBasicTypes.INTEGER)
					.addScalar("qtdErro", StandardBasicTypes.INTEGER)
					.setResultTransformer(Transformers.aliasToBean(ResumoAgendamentoDTO.class))
					.setParameter("dataRef", dataRef)
					.list();
	}
	
	public Date obtemDataDeEnvio(Long idereg) {
		String sql = "SELECT DT_ENVIO FROM AGENDAMENTO_ENVIO WHERE CD_SEQUENCIA_AGENDAMENTO = (SELECT ID_COMUNICACAO FROM I_ESPELHO_EMP WHERE IDEREG = :IDEREG)";
		return (Date) base.getSession().createSQLQuery(sql)
				.setParameter("IDEREG", idereg)
				.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<String> listaEmailsDestinatariosAgendamentoDoc(Long idereg) {
		String sql = "SELECT DS_DESTINATARIO FROM AGENDAMENTO_COMUNICACAO_DEST where cd_sequencia_agendamento = (SELECT ID_COMUNICACAO FROM I_ESPELHO_EMP WHERE IDEREG = :IDEREG)";
		return base.getSession().createSQLQuery(sql)
				.setParameter("IDEREG", idereg)
				.list();
	}
	
	public boolean existAgendamento(Long codModelo) {
		Criteria criteria = base.getSession().createCriteria(AgendamentoComunicacao.class);
		criteria.setProjection(Projections.rowCount())
		        .createAlias("modelo", "m")
				.add(Restrictions.eq("m.codModelo", codModelo));
		long contador = (Long) criteria.uniqueResult();	
		if (contador > 0) {
			return true;
		} else {
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public List<AgendamentoComunicacao> buscaAgendamentosPiloto(){
		Criteria criteria = base.getSession().createCriteria(AgendamentoComunicacao.class);
		criteria.add(Restrictions.eq("statusAgendamento", "PIL"));
		return criteria.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<AgendamentoComunicacao> buscaAgendamentosPiloto(String codigo, Date dataAgendamento){
		Calendar calendar = Calendar.getInstance(new Locale("pt", "BR"));
		calendar.setTime(dataAgendamento);
		calendar.add(Calendar.DATE, 1);

		Criteria criteria = base.getSession().createCriteria(AgendamentoComunicacao.class);
		criteria.createAlias("modelo", "modelo");
		criteria.add(Restrictions.ge("dtAgendamento", dataAgendamento));
		criteria.add(Restrictions.lt("dtAgendamento", calendar.getTime()));
		criteria.add(Restrictions.eq("modelo.codigo", codigo));		
		criteria.add(Restrictions.eq("statusAgendamento", "PIL"));		
		return criteria.list();
	}
	
	
	
}
