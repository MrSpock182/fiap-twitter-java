package br.com.tokiomarine.acsel.repository;

import java.math.BigDecimal;
import java.util.List;

import javax.inject.Inject;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import br.com.tokiomarine.acsel.dao.BaseSsvDAO;
import br.com.tokiomarine.acsel.dto.BuscaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.EnderecoDTO;
import br.com.tokiomarine.acsel.util.StringUtil;

public class DocumentoSSVRepository{

	@Inject
	BaseSsvDAO base;

	@SuppressWarnings("unchecked")
	public List<DocumentoDTO> buscaDocumentos(BuscaDocumentosDTO busca){

		String sql =
				" SELECT T1.ID_DOCTO_FISCO \"id\"," +
				"        T0.CD_DOCTO       \"codDocumento\"," +
				"        DECODE(T0.CD_DOCTO," +
                "              'DOC03000'," +
                "              (SELECT MAX(CT.DS_MODEL_CARTA)" +
                "               FROM   EMP0073_CARTA CT, EMP0039_HISTO_RGIST_TEXTO HRT" +
                "               WHERE  T1.ID_DOCTO_FISCO = HRT.ID_DOCTO_FISCO" +
                "               AND    HRT.ID_MODEL_CARTA = CT.ID_MODEL_CARTA)," +
                "               TRIM(T0.DS_DOCTO)) \"descDocumento\"," +
				"        lpad(T1.CD_CLIEN,8,'0') \"codCliente\"," +
				"        T2.NM_CLIEN       \"nomeCliente\"," +
				"        T6.DT_DISTR       \"dataGeracao\"," +
				"        T6.DT_INCLS       \"dataEnvio\"," +
				"        decode(T1.CD_APOLI,0,NULL,T1.CD_APOLI) \"numApolice\"," +
				"        decode(T1.CD_ENDOS,0,NULL,T1.CD_ENDOS) \"numEndosso\"," +
				"        T1.CD_NGOCO       \"numNegocio\"," +
				"        T7.CD_PACTE       \"codPacote\"," +
				"        T7.DS_PACTE       \"descPacote\"," +
				"        T1.CD_CIA_SGDRA   \"codCompanhia\"," +
				"        DECODE(T1.CD_CIA_SGDRA," +
				"               3,'Tokio Marine Seguradora S.A.'," +
				"               7,'Real Tokio Marine Vida e Previdência S.A.') \"nomeCompanhia\"," +
				"        lpad(T1.CD_CRTOR_SEGUR,6,'0') \"codCorretor\"," +
				"        decode(T1.CD_RCPTR_PACTE,1,'S',2,'C','L') \"tipoDestino\"," +
				"        '01' \"formaEnvio\"," +
				"        DECODE(T6.CD_SITUC_DISTR," +
				"               0, 'P'," +
				"               1, 'E') \"status\"" +
				" FROM   EMP0036_HISTO_PACTE_FISCO T8," +
				"        EMP0052_PACTE             T7," +
				"        EMP0032_HISTO_DISTR       T6," +
				"        EMP0054_RCPTR_PACTE       T5," +
				"        EMP0077_CLIEN_SISTM       T2," +
				"        EMP0033_HISTO_DOCTO_FISCO T1," +
				"        EMP0018_DOCTO             T0" +
				" WHERE  T1.ID_PACTE_FISCO = T6.ID_PACTE_FISCO" +
				" AND    T1.ID_PACTE_FISCO = T8.ID_PACTE_FISCO" +
				" AND    T8.CD_PACTE       = T7.CD_PACTE" +
				" AND    T8.DT_INICO_VIGEN_PACTE = T7.DT_INICO_VIGEN_PACTE" +
				" AND    T0.CD_DOCTO = T1.CD_DOCTO" +
				" AND    T1.CD_RCPTR_PACTE = T5.CD_RCPTR_PACTE" +
				" AND    T1.CD_CIA_SGDRA <> 7" +
				" AND    T1.IC_SEGDA_VIA = 'N'" +
				" AND    T0.CD_DOCTO NOT IN ('DOC00400', 'DOC00480', 'DOC00490', 'DOC00415', 'DOC00461', 'DOC00410', 'DOC00470')" +
				" AND    T1.CD_CLIEN = T2.CD_CLIEN" +
				" AND    T6.SG_SISTM_ORIGM = T2.SG_SISTM_ORIGM_CLIEN" +
				" AND    T6.DT_DISTR BETWEEN :dataIni AND :dataFim" +
				(StringUtil.isNull(busca.getCodCorretor()) ? "":" AND lpad(T1.CD_CRTOR_SEGUR,6,'0') = :codCorretor") +
				(busca.getListaClientes() == null || busca.getListaClientes().isEmpty() ? "":" AND  T1.CD_CLIEN IN (:codCliente)") +
				(busca.getApolice() == null ? "" : " AND  T1.CD_APOLI = :numApolice") +
				(busca.getNumEndosso() == null ? "" : " AND  T1.CD_ENDOS = :numEndosso") +
				(busca.getNegocio() == null ? "" : " AND  T1.CD_NGOCO = :numNegocio") +
				" ORDER  BY T0.CD_DOCTO, T6.DT_DISTR";

		Query q = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("codDocumento")
				.addScalar("descDocumento")
				.addScalar("codCliente")
				.addScalar("nomeCliente")
				.addScalar("dataGeracao")
				.addScalar("dataEnvio")
				.addScalar("numApolice", StandardBasicTypes.LONG)
				.addScalar("numNegocio", StandardBasicTypes.INTEGER)
				.addScalar("numEndosso", StandardBasicTypes.INTEGER)
				.addScalar("codPacote")
				.addScalar("descPacote")
				.addScalar("codCompanhia", StandardBasicTypes.STRING)
				.addScalar("nomeCompanhia")
				.addScalar("codCorretor")
				.addScalar("tipoDestino", StandardBasicTypes.STRING)
				.addScalar("formaEnvio")
				.addScalar("status");

		q.setParameter("dataIni", busca.getDataIni());
		q.setParameter("dataFim", busca.getDataFim());

		if (busca.getListaClientes() != null && !busca.getListaClientes().isEmpty())
			q.setParameterList("codCliente", busca.getListaClientes());
		if (busca.getApolice() != null)
			q.setParameter("numApolice", busca.getApolice());
		if (busca.getNumEndosso() != null)
			q.setParameter("numEndosso", busca.getNumEndosso());
		if (busca.getNegocio() != null)
			q.setParameter("numNegocio", busca.getNegocio());
		if (!StringUtil.isNull(busca.getCodCorretor())){
			q.setParameter("codCorretor", busca.getCodCorretor());
		}

		q.setResultTransformer(Transformers.aliasToBean(DocumentoDTO.class));
		List<DocumentoDTO> list = q.list();
		return list;

//		return q.list();
	}

	@SuppressWarnings("unchecked")
	public List<DocumentoDTO> obtemCartaoAssociado(DocumentoDTO documento){
        String sql =
                " SELECT CAR.ID_DOCTO_FISCO \"id\"," +
                "        CAR.CD_DOCTO \"codDocumento\"," +
                "        lpad(CAR.CD_CLIEN,8,'0') \"codCliente\"" +
                " FROM   EMP0033_HISTO_DOCTO_FISCO EMP," +
                "        EMP0033_HISTO_DOCTO_FISCO CAR" +
                " WHERE  CAR.CD_DOCTO IN ('DOC00480','DOC00490','DOC02007')" +
                " AND EMP.CD_NGOCO = :negocio" +
                " AND EMP.CD_ENDOS = :endosso" +
//                " AND    EMP.ID_DOCTO_FISCO = :idDocto" +
                " AND    EMP.CD_DOCTO NOT IN ('DOC00415')" +
                " AND    CAR.CD_APOLI = EMP.CD_APOLI" +
                " AND    CAR.IC_SEGDA_VIA = 'N'" +
                " AND    CAR.CD_ENDOS = EMP.CD_ENDOS";

        Query q = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("codDocumento")
				.addScalar("codCliente");

		q.setParameter("negocio", documento.getNumNegocio());
		q.setParameter("endosso", documento.getNumEndosso());
		q.setResultTransformer(Transformers.aliasToBean(DocumentoDTO.class));
		List<DocumentoDTO> lista = q.list();
		for (int i=0; i < lista.size(); i++) {
			lista.get(i).setNumApolice(documento.getNumApolice());
			lista.get(i).setNumNegocio(documento.getNumNegocio());
			lista.get(i).setNumEndosso(documento.getNumEndosso());
		}
		
		
		return lista;

//		return q.list();
	}

	public EnderecoDTO obtemEnderecoEnvio(DocumentoDTO doc){

		String sql =
			" SELECT TRIM(SUBSTR(D.DS_RGIST_VARVL,41,40))     \"logradouro\"," +
			"        LTRIM(SUBSTR(D.DS_RGIST_VARVL,81,5),'0') \"numero\"," +
			"        TRIM(SUBSTR(D.DS_RGIST_VARVL,86,15))     \"complemento\"," +
			"        TRIM(SUBSTR(D.DS_RGIST_VARVL,101,15))    \"bairro\"," +
			"        TRIM(SUBSTR(D.DS_RGIST_VARVL,116,9))     \"cep\"," +
			"        TRIM(SUBSTR(D.DS_RGIST_VARVL,125,15))    \"cidade\"," +
			"        TRIM(SUBSTR(D.DS_RGIST_VARVL,140,2))     \"estado\"" +
			" FROM   EMP0037_HISTO_RGIST_DOCTO d" +
			" WHERE  D.ID_DOCTO_FISCO = :idDocto" +
			" AND    D.CD_SBSEC = DECODE(:tipoDestino,'S','SUB00100', 'C','SUB00200')";

		return (EnderecoDTO) base.getSession().createSQLQuery(sql)
				.setResultTransformer(Transformers.aliasToBean(EnderecoDTO.class))
				.setParameter("idDocto", doc.getId())
				.setParameter("tipoDestino", doc.getTipoDestino().getValue())
				.setMaxResults(1)
				.uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	public Long buscaridDoctoFisco(Long apolice, Integer numEndosso, Integer negocio) {
		Long retorno = 0L;
		StringBuilder sql = new StringBuilder("SELECT T1.ID_DOCTO_FISCO FROM EMP0033_HISTO_DOCTO_FISCO T1 WHERE T1.CD_APOLI = :numApolice AND T1.IC_SEGDA_VIA = 'N'");
		
		if (numEndosso != null) {
			sql.append(" AND  T1.CD_ENDOS = :numEndosso");
		}
		
		if (negocio != null) {
			sql.append(" AND  T1.CD_NGOCO = :negocio");
		}
		
		sql.append(" ORDER BY CD_ENDOS DESC");
		
		Query q = base.getSession().createSQLQuery(sql.toString());
		q.setParameter("numApolice", apolice);
		
		if (numEndosso != null) {
			q.setParameter("numEndosso", numEndosso);			
		}
		
		if (negocio != null) {
			q.setParameter("negocio", negocio);			
		}
		
		//BigDecimal result = (BigDecimal) q.uniqueResult();
		List<BigDecimal> result = q.list();
		
		
		if(result != null) {
			if(result.size() > 0) {
				//retorno = result.longValue();
				retorno = result.get(0).longValue();				
			}
		}
		
		return retorno;
	}


}
