package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "MODELO_COMUNICACAO_PARAM")
public class ParametroModelo {

	@Id
	@Column(name="CD_MODELO_COM_PARAM")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="modeloParamGenerator")
	@SequenceGenerator(name = "modeloParamGenerator", sequenceName = "SQ_MODELO_COMUNIC_PARAM",allocationSize=1)
	private Long idModeloParam;

	@ManyToOne
	@JoinColumn(name="CD_MODELO_COMUNICACAO", referencedColumnName="CD_MODELO_COMUNICACAO")
	private ModeloComunicacao modelo;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CD_PARAMETRO", referencedColumnName="CD_PARAMETRO")
	private ParametroComunicacao parametro;

	@Column(name="ID_EXIBE_LISTA")
	private String indExibeLista;

	@Column(name="NM_LISTA")
	private String nomeExibicao;

	@Column(name="CD_SEQUENCIA")
	private Integer cdSequencia;

	@Column(name="NM_FORMATACAO")
	private String formatacao;

	@Column(name="DT_INCLUSAO")
	private Date dataInclusao;

	@Column(name="NM_USUARIO_INCLUSAO")
	private String nomeUsuarioInclusao;

	@Column(name="DT_ATUALIZACAO")
	private Date dataAtualizacao;

	@Column(name="NM_USUARIO_ATUALIZACAO")
	private String nomeUsuarioAtualizacao;

	public Long getIdModeloParam() {
		return idModeloParam;
	}

	public void setIdModeloParam(Long idModeloParam) {
		this.idModeloParam = idModeloParam;
	}

	public ModeloComunicacao getModelo() {
		return modelo;
	}

	public void setModelo(ModeloComunicacao modelo) {
		this.modelo = modelo;
	}

	public ParametroComunicacao getParametro() {
		return parametro;
	}

	public void setParametro(ParametroComunicacao parametro) {
		this.parametro = parametro;
	}

	public String getIndExibeLista() {
		return indExibeLista;
	}

	public void setIndExibeLista(String indExibeLista) {
		this.indExibeLista = indExibeLista;
	}

	public String getNomeExibicao() {
		return nomeExibicao;
	}

	public void setNomeExibicao(String nomeExibicao) {
		this.nomeExibicao = nomeExibicao;
	}

	public Integer getCdSequencia() {
		return cdSequencia;
	}

	public void setCdSequencia(Integer cdSequencia) {
		this.cdSequencia = cdSequencia;
	}

	public String getFormatacao() {
		return formatacao;
	}

	public void setFormatacao(String formatacao) {
		this.formatacao = formatacao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public String getNomeUsuarioAtualizacao() {
		return nomeUsuarioAtualizacao;
	}

	public void setNomeUsuarioAtualizacao(String nomeUsuarioAtualizacao) {
		this.nomeUsuarioAtualizacao = nomeUsuarioAtualizacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idModeloParam == null) ? 0 : idModeloParam.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		ParametroModelo other = (ParametroModelo) obj;
		if (idModeloParam == null) {
			if (other.idModeloParam != null)
				return false;
		} else if (!idModeloParam.equals(other.idModeloParam)){
			return false;
		}

		return true;
	}

}