
package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "MODELO_COMUNICACAO_PERFIL")
public class PerfilModeloComunicacao {
	
	@Id
	@Column(name="CD_MODELO_COM_PERFIL")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="modeloComPerfilGenerator")
	@SequenceGenerator(name = "modeloComPerfilGenerator", sequenceName = "SEQ_MODELO_COM_PERFIL", allocationSize=1)
	private Integer idPerfil;
	
	@Column(name="COD_LOGIN")	
	private String codLogin;
	
	@Column(name="COD_PERFIL")	
	private String codPerfil;
	
	@Column(name="DT_INCLUSAO")
	private Date dtInclusao;

	@Column(name="NM_USUARIO_INCLUSAO")
	private String nomeUsuarioInclusao;

	public Integer getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(Integer idPerfil) {
		this.idPerfil = idPerfil;
	}

	public String getCodLogin() {
		return codLogin;
	}

	public void setCodLogin(String codLogin) {
		this.codLogin = codLogin;
	}

	public String getCodPerfil() {
		return codPerfil;
	}

	public void setCodPerfil(String codPerfil) {
		this.codPerfil = codPerfil;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}


}
