package br.com.tokiomarine.acsel.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class PushNotificationDTO {

	private String finalidade;
	private String destinatario;
	private String titulo;

	@JsonInclude(Include.NON_NULL)
	private String mensagem;

	//@JsonProperty("mensagem")
	@JsonInclude(Include.NON_NULL)
	private MensagemPushDTO mensagemKey;

	private String chamada;

	private Integer dataDeValidade;

	public String getFinalidade() {
		return finalidade;
	}

	public void setFinalidade(String finalidade) {
		this.finalidade = finalidade;
	}

	public String getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public MensagemPushDTO getMensagemKey() {
		return mensagemKey;
	}

	public void setMensagemKey(MensagemPushDTO mensagemKey) {
		this.mensagemKey = mensagemKey;
	}

	public String getChamada() {
		return chamada;
	}

	public void setChamada(String chamada) {
		this.chamada = chamada;
	}

	public Integer getDataDeValidade() {
		return dataDeValidade;
	}

	public void setDataDeValidade(Integer dataDeValidade) {
		this.dataDeValidade = dataDeValidade;
	}
}
