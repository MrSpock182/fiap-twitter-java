package br.com.tokiomarine.acsel.repository;

import javax.inject.Inject;

import org.hibernate.criterion.Restrictions;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.Intermediario;

public class CorretorRepository{

	@Inject
	BaseAcxDAO base;

	public Intermediario obtemCorretorInterCli(String codInterCli){

		Intermediario corretor = (Intermediario) base.getSession().createCriteria(Intermediario.class)
				.add(Restrictions.eq("codInterCli", codInterCli))
				.uniqueResult();

		return corretor;
	}
}
