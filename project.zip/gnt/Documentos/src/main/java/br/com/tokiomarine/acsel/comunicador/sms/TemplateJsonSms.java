package br.com.tokiomarine.acsel.comunicador.sms;

import br.com.tokiomarine.acsel.comunicador.TemplateJson;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;

public class TemplateJsonSms extends TemplateJson {

	private String corretorCpfCnpj;

	public String getCorretorCpfCnpj() {
		return corretorCpfCnpj;
	}

	public void setCorretorCpfCnpj(String corretorCpfCnpj) {
		this.corretorCpfCnpj = corretorCpfCnpj;
	}

	public TemplateJsonSms(String modeloCodigo, ModeloComunicacaoDTO dto) {
		super(modeloCodigo, dto);
		this.setCorretorCpfCnpj("99999999");
	}

}
