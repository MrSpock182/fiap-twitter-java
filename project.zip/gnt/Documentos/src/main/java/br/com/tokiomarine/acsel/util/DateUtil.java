package br.com.tokiomarine.acsel.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public final class DateUtil {

	private DateUtil() {}

	private static SimpleDateFormat dataSemHora = new SimpleDateFormat("dd/MM/yyyy");

	private static SimpleDateFormat dataCompleta = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	private static SimpleDateFormat dataPOMxml = new SimpleDateFormat("dd-MM-yyyy HH:mm");

	private static SimpleDateFormat ano = new SimpleDateFormat("yyyy");

	private static SimpleDateFormat mes = new SimpleDateFormat("MM");

	private static SimpleDateFormat diaDoMes = new SimpleDateFormat("dd");


	public static synchronized String formataSemHora(Date date) {

		Calendar cal = date2calendar(date);

		if (cal == null) { return ""; }

		return dataSemHora.format(cal.getTime());
	}

	public static synchronized String formataSemHora(Calendar cal) {

		if (cal == null) { return ""; }

		return dataSemHora.format(cal.getTime());
	}

	public static Long minutosEmMilisegundos(Integer minutos) {

		return 60L * 1000 * minutos;

	}

	public static synchronized String formataComMes(Date date) {

		if (date == null) { return ""; }

		return mes.format(date);
	}

	public static synchronized String formataComAno(Date date) {

		if (date == null) { return ""; }

		return ano.format(date);
	}

	public static synchronized String formataCompleta(Date date) {

		if (date == null) { return ""; }

		return dataCompleta.format(date);
	}

	public static synchronized String dataDeInicioDoServidor() {

		java.lang.management.RuntimeMXBean rb = java.lang.management.ManagementFactory.getRuntimeMXBean();

		return dataCompleta.format(rb.getStartTime());
	}

	public static synchronized String getDiaDoMes() {

		Calendar hoje = new GregorianCalendar();

		return diaDoMes.format(hoje.getTime());

	}

	public static synchronized GregorianCalendar date2calendar(Date data) {

		Calendar cal = new GregorianCalendar();

		cal.setTime(data);

		return (GregorianCalendar) cal;
	}

	public static synchronized String getDataNumerica(String data) {

		String resultado = "";
		try {
			Date dataDoPOM = dataPOMxml.parse(data);
			resultado = String.valueOf(dataDoPOM.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return resultado;

	}

}
