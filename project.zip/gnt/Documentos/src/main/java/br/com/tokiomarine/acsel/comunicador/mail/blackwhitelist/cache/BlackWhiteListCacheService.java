package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.cache;

import br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.BlackListResource;

public interface BlackWhiteListCacheService {

	BlackListResource getBlackList(String destino) throws HazelcastURLException;

}
