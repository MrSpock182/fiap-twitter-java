package br.com.tokiomarine.acsel.service.impl;

import java.util.HashMap;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ModeloComunicacaoRepository;
import br.com.tokiomarine.acsel.service.MensagemParserService;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "MensagemParserService")
@Local(value = MensagemParserService.class)
public class MensagemParserServiceImpl implements MensagemParserService{

	private static Logger logger = LogManager.getLogger(MensagemParserServiceImpl.class);

	@Inject
	ModeloComunicacaoRepository modeloDao;

	private ModeloComunicacao modelo;
	private HashMap<String, String> parametros;

	public MensagemParserServiceImpl() throws ServiceException {
		parametros = new HashMap<String,String>();
	}


	public void geraMensagem(AgendamentoEnvio envio) throws ServiceException {

		AgendamentoComunicacao agend = envio.getAgendamento();
		this.modelo = agend.getModelo();

		this.parametros.clear();

		for (ParametroModelo param : modelo.getParametros()){
			this.parametros.put(param.getParametro().getNomeParametro(), agend.getValorParametro(param.getParametro().getNomeParametro()));
		}

		HashMap<String, String> parametros = new HashMap<String,String>();

		for (TextoModeloComunicacao texto : modelo.getTextos()){

			if (texto.getTextoComunicacao().getTipoTexto().equals("P")){
				parametros.put("chamada", formataTexto(texto.getTexto()));
			} else{
				parametros.put("mensagem", formataTexto(texto.getTexto()));
			}
		}

		try {
			envio.getAgendamento().setMensagemEnviada(StringUtil.serialize(parametros));
		} catch (JsonProcessingException e) {
			logger.error("Erro ao formatar mensagem", e);
			throw new ServiceException("Erro ao formatar mensagem");
		}
	}


	public void geraTitulo(AgendamentoEnvio envio) throws ServiceException{
		try{

			AgendamentoComunicacao agend = envio.getAgendamento();

			this.modelo = agend.getModelo();

			this.parametros.clear();

			for (ParametroModelo param : modelo.getParametros()){
				this.parametros.put(param.getParametro().getNomeParametro(), agend.getValorParametro(param.getParametro().getNomeParametro()));
			}

			envio.setTitulo(formataTexto(modelo.getTituloModelo()));

		} catch (ServiceException s){
			throw s;
		} catch (Exception e){
			logger.error("Erro ao formatar título da mensagem", e);
			throw new ServiceException("Erro ao formatar título da mensagem");
		}
	}

	private String formataTexto(String texto) throws ServiceException{

		String txtRetorno = texto;

		String[] vars = StringUtils.substringsBetween(texto, "[", "]");

		if (vars != null){
			for(String var : vars){
					if (this.parametros.containsKey(var)){
						String valor = this.parametros.get(var);
						if (valor == null){
						throw new ServiceException("Parâmetro " + var + " não informado");
					}
						txtRetorno = txtRetorno.replace("["+var+"]", valor);
				}
			}
		}
		return txtRetorno;
	}
}
