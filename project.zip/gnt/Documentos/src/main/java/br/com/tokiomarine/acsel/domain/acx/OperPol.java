package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.tokiomarine.acsel.util.StringUtil;

@Entity
@IdClass(OperPolPK.class)
@Table(name = "OPER_POL")
public class OperPol implements Serializable{

	private static final long serialVersionUID = -5489822107321368792L;

	// IDEPOL, NUMCERT, NUMOPER
	@Id
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "IDEPOL",referencedColumnName = "IDEPOL")
	private Poliza poliza;

	@Id
	@Column(name = "NUMCERT")
	private Long numCert;
	@Id
	@Column(name = "NUMOPER")
	private Long numOper;

	@Column(name = "TIPOOP")
	private String tipoOp;
	@Column(name = "FECMOV")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecMov;
	@Column(name = "MTOOPER")
	private BigDecimal mtoOper;
	@Column(name = "MTOOPERANU")
	private BigDecimal mtoOperAnu;
	@Column(name = "FECANUL")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecAnul;
	@Column(name = "INDANUL")
	private String indAnul;
	@Column(name = "NUMOPERANU")
	private Long numOperAnu;
	@Column(name = "NUMENDOSO")
	private Long numEndoso;
	@Column(name = "NUMOPERREACTIV")
	private Long numOperReactiv;
	@Column(name = "CODMOTVANUL")
	private String codMotvAnul;
	@Column(name = "FECINIVALID")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecIniValid;
	@Column(name = "FECFINVALID")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecFinValid;
	@Column(name = "TPSOLEND")
	private String tpSolEnd;
	@Column(name = "CODMOTVEND")
	private String codMotVend;
	@Column(name = "ENDOFI")
	private String endofi;
	@Column(name = "IDECONTAB")
	private Long ideContab;
	@Column(name = "CODCANAL")
	private String codCanal;
	@Column(name = "MTOOPERMONEDA")
	private BigDecimal mtoOperMoneda;
	@Column(name = "TASACAMBIO")
	private BigDecimal tasacambio;
	@Column(name = "LocalCap")
	private String LocalCap;
	@Column(name = "INDPROCESSO")
	private String indProcesso;
	@Column(name = "FECDIARIA")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecDiaria;
	@Column(name = "SEQARQ")
	private Long seqArq;
	@Column(name = "CodOfiCOM")
	private String codOfiCom;
	@Column(name = "CODAGECOB")
	private String codAgeCob;
	@Column(name = "INDCOBJUD")
	private String indCobJud;
	@Column(name = "DTCOBJUD")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtCobJud;
	@Column(name = "FECPROP")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecProp;
	@Column(name = "TPEND")
	private String tpEnd;
	@Column(name = "IDEPROP")
	private Long ideProp;
	@Column(name = "INDPENDNUMDEF")
	private String indPendNumDef;
	@Column(name = "IDEFACTVG")
	private Long ideFactVg;
	@Column(name = "NUMOPERCOMPL")
	private Long numOperCompl;
	@Column(name = "SEQARQIMP")
	private String seqArqImp;
	@Column(name = "TEXTMOTVANUL")
	private String textMotvAnul;

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(insertable=false, updatable=false,name="IDEPOL", referencedColumnName="IDEPOL"),
		@JoinColumn(insertable=false, updatable=false,name="NUMCERT", referencedColumnName="NUMCERT"),
		@JoinColumn(insertable=false, updatable=false,name="NUMOPER", referencedColumnName="NUMOPER")
	})
	private OperPolCli operPolCli;

	public String getTipoOp() {
		return tipoOp;
	}

	public void setTipoOp(String tipoOp) {
		this.tipoOp = tipoOp;
	}

	public Poliza getPoliza() {
		return poliza;
	}

	public void setPoliza(Poliza poliza) {
		this.poliza = poliza;
	}

	public Long getNumCert() {
		return numCert;
	}

	public void setNumCert(Long numCert) {
		this.numCert = numCert;
	}

	public Long getNumOper() {
		return numOper;
	}

	public void setNumOper(Long numOper) {
		this.numOper = numOper;
	}

	public Date getFecMov() {
		return fecMov;
	}

	public void setFecMov(Date fecMov) {
		this.fecMov = fecMov;
	}

	public BigDecimal getMtoOper() {
		if (mtoOper == null) {
			mtoOper = new BigDecimal(0);
		}

		return mtoOper;
	}

	public void setMtoOper(BigDecimal mtoOper) {
		this.mtoOper = mtoOper;
	}

	public BigDecimal getMtoOperAnu() {
		if (mtoOperAnu == null) {
			mtoOperAnu = new BigDecimal(0);
		}

		return mtoOperAnu;
	}

	public void setMtoOperAnu(BigDecimal mtoOperAnu) {
		this.mtoOperAnu = mtoOperAnu;
	}

	public Date getFecAnul() {
		return fecAnul;
	}

	public void setFecAnul(Date fecAnul) {
		this.fecAnul = fecAnul;
	}

	public String getIndAnul() {
		return indAnul;
	}

	public void setIndAnul(String indAnul) {
		this.indAnul = indAnul;
	}

	public Long getNumOperAnu() {
		return numOperAnu;
	}

	public void setNumOperAnu(Long numOperAnu) {
		this.numOperAnu = numOperAnu;
	}

	public Long getNumEndoso() {
		return numEndoso;
	}

	public void setNumEndoso(Long numEndoso) {
		this.numEndoso = numEndoso;
	}

	public Long getNumOperReactiv() {
		return numOperReactiv;
	}

	public void setNumOperReactiv(Long numOperReactiv) {
		this.numOperReactiv = numOperReactiv;
	}

	public String getCodMotvAnul() {
		return codMotvAnul;
	}

	public void setCodMotvAnul(String codMotvAnul) {
		this.codMotvAnul = codMotvAnul;
	}

	public Date getFecIniValid() {
		return fecIniValid;
	}

	public void setFecIniValid(Date fecIniValid) {
		this.fecIniValid = fecIniValid;
	}

	public Date getFecFinValid() {
		return fecFinValid;
	}

	public void setFecFinValid(Date fecFinValid) {
		this.fecFinValid = fecFinValid;
	}

	public String getTpSolEnd() {
		return tpSolEnd;
	}

	public void setTpSolEnd(String tpSolEnd) {
		this.tpSolEnd = tpSolEnd;
	}

	public String getCodMotVend() {
		return codMotVend;
	}

	public void setCodMotVend(String codMotVend) {
		this.codMotVend = codMotVend;
	}

	public String getEndofi() {
		return endofi;
	}

	public void setEndofi(String endofi) {
		this.endofi = endofi;
	}

	public Long getIdeContab() {
		return ideContab;
	}

	public void setIdeContab(Long ideContab) {
		this.ideContab = ideContab;
	}

	public String getCodCanal() {
		return codCanal;
	}

	public void setCodCanal(String codCanal) {
		this.codCanal = codCanal;
	}

	public BigDecimal getMtoOperMoneda() {
		if (mtoOperMoneda == null) {
			mtoOperMoneda = new BigDecimal(0);
		}

		return mtoOperMoneda;
	}

	public void setMtoOperMoneda(BigDecimal mtoOperMoneda) {
		this.mtoOperMoneda = mtoOperMoneda;
	}

	public BigDecimal getTasacambio() {

		return StringUtil.formataTaxa(tasacambio);
	}

	public void setTasacambio(BigDecimal tasacambio) {

		if (tasacambio == null) {
			tasacambio = new BigDecimal(0);
		}

		this.tasacambio = StringUtil.formataTaxa(tasacambio);
	}

	public String getLocalCap() {
		return LocalCap;
	}

	public void setLocalCap(String LocalCap) {
		this.LocalCap = LocalCap;
	}

	public String getIndProcesso() {
		return indProcesso;
	}

	public void setIndProcesso(String indProcesso) {
		this.indProcesso = indProcesso;
	}

	public Date getFecDiaria() {
		return fecDiaria;
	}

	public void setFecDiaria(Date fecDiaria) {
		this.fecDiaria = fecDiaria;
	}

	public Long getSeqArq() {
		return seqArq;
	}

	public void setSeqArq(Long seqArq) {
		this.seqArq = seqArq;
	}

	public String getCodOfiCom() {
		return codOfiCom;
	}

	public void setCodOfiCom(String codOfiCom) {
		this.codOfiCom = codOfiCom;
	}

	public String getCodAgeCob() {
		return codAgeCob;
	}

	public void setCodAgeCob(String codAgeCob) {
		this.codAgeCob = codAgeCob;
	}

	public String getIndCobJud() {
		return indCobJud;
	}

	public void setIndCobJud(String indCobJud) {
		this.indCobJud = indCobJud;
	}

	public Date getDtCobJud() {
		return dtCobJud;
	}

	public void setDtCobJud(Date dtCobJud) {
		this.dtCobJud = dtCobJud;
	}

	public Date getFecProp() {
		return fecProp;
	}

	public void setFecProp(Date fecProp) {
		this.fecProp = fecProp;
	}

	public String getTpEnd() {
		return tpEnd;
	}

	public void setTpEnd(String tpEnd) {
		this.tpEnd = tpEnd;
	}

	public Long getIdeProp() {
		return ideProp;
	}

	public void setIdeProp(Long ideProp) {
		this.ideProp = ideProp;
	}

	public String getIndPendNumDef() {
		return indPendNumDef;
	}

	public void setIndPendNumDef(String indPendNumDef) {
		this.indPendNumDef = indPendNumDef;
	}

	public Long getIdeFactVg() {
		return ideFactVg;
	}

	public void setIdeFactVg(Long ideFactVg) {
		this.ideFactVg = ideFactVg;
	}

	public Long getNumOperCompl() {
		return numOperCompl;
	}

	public void setNumOperCompl(Long numOperCompl) {
		this.numOperCompl = numOperCompl;
	}

	public String getSeqArqImp() {
		return seqArqImp;
	}

	public void setSeqArqImp(String seqArqImp) {
		this.seqArqImp = seqArqImp;
	}

	public String getTextMotvAnul() {
		return textMotvAnul;
	}

	public void setTextMotvAnul(String textMotvAnul) {
		this.textMotvAnul = textMotvAnul;
	}

	public OperPolCli getOperPolCli() {
		return operPolCli;
	}

	public void setOperPolCli(OperPolCli operPolCli) {
		this.operPolCli = operPolCli;
	}

	@Override
	public String toString() {
		return "OperPol [poliza=" + poliza + ", numCert=" + numCert + ", numOper=" + numOper + ", tipoOp=" + tipoOp + ", fecMov=" + fecMov + ", mtoOper=" + mtoOper + ", mtoOperAnu=" + mtoOperAnu + ", fecAnul=" + fecAnul + ", indAnul=" + indAnul + ", numOperAnu=" + numOperAnu + ", numEndoso=" + numEndoso + ", numOperReactiv=" + numOperReactiv + ", codMotvAnul=" + codMotvAnul + ", fecIniValid=" + fecIniValid + ", fecFinValid=" + fecFinValid + ", tpSolEnd=" + tpSolEnd + ", codMotVend=" + codMotVend + ", endofi=" + endofi + ", ideContab=" + ideContab + ", codCanal=" + codCanal + ", mtoOperMoneda=" + mtoOperMoneda + ", tasacambio=" + tasacambio + ", LocalCap=" + LocalCap + ", indProcesso=" + indProcesso + ", fecDiaria=" + fecDiaria + ", seqArq=" + seqArq + ", codOfiCom=" + codOfiCom + ", codAgeCob=" + codAgeCob + ", indCobJud=" + indCobJud + ", dtCobJud=" + dtCobJud + ", fecProp=" + fecProp + ", tpEnd=" + tpEnd + ", ideProp=" + ideProp + ", indPendNumDef=" + indPendNumDef + ", ideFactVg=" + ideFactVg + ", numOperCompl=" + numOperCompl + ", seqArqImp=" + seqArqImp + ", textMotvAnul=" + textMotvAnul + "]";
	}
}
