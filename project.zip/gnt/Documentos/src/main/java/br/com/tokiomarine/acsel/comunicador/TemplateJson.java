package br.com.tokiomarine.acsel.comunicador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.ParametroComunicacaoDTO;

public abstract class TemplateJson {

	private String codigo;
	private List<Map<String, String>> destinatariosDetalhes;
	private String tipoEnvio;
	private List<Map<String, String>> parametros;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public List<Map<String, String>> getDestinatariosDetalhes() {
		return destinatariosDetalhes;
	}

	public void setDestinatariosDetalhes(List<Map<String, String>> destinatariosDetalhes) {
		this.destinatariosDetalhes = destinatariosDetalhes;
	}

	public String getTipoEnvio() {
		return tipoEnvio;
	}

	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}

	public List<Map<String, String>> getParametros() {
		return parametros;
	}

	public void setParametros(List<Map<String, String>> parametros) {
		this.parametros = parametros;
	}

	public TemplateJson(String modeloCodigo, ModeloComunicacaoDTO dto) {
		this.setCodigo(modeloCodigo);
		this.setTipoEnvio("CORRETOR");

		List<Map<String, String>> listDestinatarios = new ArrayList<>();
		Map<String, String> destinatarios = new HashMap<>();
		destinatarios.put("destino", "gnt@tokiomarine.com.br");
		destinatarios.put("cpfCnpj", "99999999");
		listDestinatarios.add(destinatarios);
		this.setDestinatariosDetalhes(listDestinatarios);

		List<Map<String, String>> listParam = new ArrayList<>();
		for (ParametroComunicacaoDTO param : dto.getParametros()) {
			Map<String, String> parametros = new HashMap<>();
			parametros.put("valorParametro", "VALOR DESEJADO PARA INFORMAÇÃO");
			parametros.put("nomeParametro", param.getNomeParametro());
			listParam.add(parametros);
		}

		this.setParametros(listParam);
	}

}
