package br.com.tokiomarine.acsel.comunicador;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.comunicador.mail.ValidaEmail;
import br.com.tokiomarine.acsel.comunicador.push.ValidaPush;
import br.com.tokiomarine.acsel.comunicador.sms.ValidaSms;
import br.com.tokiomarine.acsel.type.TipoModelo;

@Stateless(name = "ValidadorDestinoFactory")
public final class ValidadorDestinoFactory {

	@Inject
	private ValidaEmail validaEmail;
	@Inject
	private ValidaSms validaSms;
	@Inject
	private ValidaPush validaPush;
	
	// TODO: Analisar: aplicar OCP
	public ValidadorDestino getValidador(TipoModelo canalComunicacao) {
		ValidadorDestino validador = canalComunicacao.getValidador();
		if(validador != null) return validador;
		if(canalComunicacao == TipoModelo.email) 
			return this.validaEmail;
		if(canalComunicacao == TipoModelo.sms)
			return this.validaSms;
		if(canalComunicacao == TipoModelo.push)
			return this.validaPush;		
		throw new RuntimeException("Canal de Comunicação inválido");
	}

}
