package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.cache;

import lombok.Getter;

public class HazelcastURLException extends Exception {

	private static final long serialVersionUID = 1L;

	@Getter
	private String message;

	public HazelcastURLException(String message) {
		this.message = message;
	}

}
