package br.com.tokiomarine.acsel.service;

import java.util.List;

import br.com.tokiomarine.acsel.domain.acx.CadServicos;
import br.com.tokiomarine.acsel.domain.acx.GrpParamAcsel;
import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.domain.acx.ParamAcsel;

public interface ParametrosService {

	List<Lval> obtemListaValores(String tipoLval);

	Lval obtemLval(String tipoLval, String codLval);

	List<GrpParamAcsel> obtemGrupos();

	List<ParamAcsel> obtemParametrosGrupo(Integer grupoId);

	ParamAcsel atualizaParam(ParamAcsel param);

	void insereParam(ParamAcsel param);

	void removeParam(ParamAcsel param);

	String obtemVlrParametro(String grupo, String param);

	CadServicos obtemServico(String codServico);

}