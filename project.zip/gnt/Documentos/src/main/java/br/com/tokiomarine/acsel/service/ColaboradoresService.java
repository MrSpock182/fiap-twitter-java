package br.com.tokiomarine.acsel.service;

import java.util.List;

import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.ws.col.dto.LocalTrabalho;
import br.com.tokiomarine.acsel.ws.col.dto.RetColaboradorPorLocal;

public interface ColaboradoresService {

	List<LocalTrabalho> obtemLocaisTrabalho();

	List<RetColaboradorPorLocal> obtemColaboradores(String localTrabalho);

	String obtemColaborador(String matricula) throws ServiceException;

	String obtemNomeColaborador(String matricula);

}