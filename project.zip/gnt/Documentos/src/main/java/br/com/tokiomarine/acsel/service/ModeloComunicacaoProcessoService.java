package br.com.tokiomarine.acsel.service;

import java.util.Collection;

import br.com.tokiomarine.acsel.dto.ModeloComunicacaoProcesso;

public interface ModeloComunicacaoProcessoService {

	Collection<ModeloComunicacaoProcesso> findAll();
	
}
