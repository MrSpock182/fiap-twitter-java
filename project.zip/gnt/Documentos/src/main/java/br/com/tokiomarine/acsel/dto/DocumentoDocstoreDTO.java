package br.com.tokiomarine.acsel.dto;

public class DocumentoDocstoreDTO {
	
	private String docstoreId;
	private String url;
	private Integer cdDocumento;
	private String dsDocumento;
	
	public String getDocstoreId() {
		return docstoreId;
	}
	public void setDocstoreId(String docstoreId) {
		this.docstoreId = docstoreId;
	}
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getCdDocumento() {
		return cdDocumento;
	}

	public void setCdDocumento(Integer cdDocumento) {
		this.cdDocumento = cdDocumento;
	}

	public void findIdDocstore() {
		if(url != null && !url.contains("StorageRetrieve")) {
			this.docstoreId = url.substring(url.lastIndexOf('/') + 1);
		}
	}
	public String getDsDocumento() {
		return dsDocumento;
	}
	public void setDsDocumento(String dsDocumento) {
		this.dsDocumento = dsDocumento;
	}
	
}
