package br.com.tokiomarine.acsel.service.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.jboss.resteasy.client.ClientRequest;
import org.jboss.resteasy.client.ClientResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowagie.text.pdf.PdfReader;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.CategEndosso;
import br.com.tokiomarine.acsel.domain.acx.Cliente;
import br.com.tokiomarine.acsel.domain.acx.DocumentoDigital;
import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.domain.acx.OperPol;
import br.com.tokiomarine.acsel.domain.acx.Tercero;
import br.com.tokiomarine.acsel.domain.plt.Segurado;
import br.com.tokiomarine.acsel.dto.BuscaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDigitalDTO;
import br.com.tokiomarine.acsel.dto.DownloadDocumentoDTO;
import br.com.tokiomarine.acsel.dto.EmailDataEnvioDTO;
import br.com.tokiomarine.acsel.dto.ItemApoliceDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaConsultaDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaResponseDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ApoliceRepository;
import br.com.tokiomarine.acsel.repository.ClienteRepository;
import br.com.tokiomarine.acsel.repository.CorretorRepository;
import br.com.tokiomarine.acsel.repository.DocumentoDigitalRepository;
import br.com.tokiomarine.acsel.repository.DocumentoSSVRepository;
import br.com.tokiomarine.acsel.repository.DocumentosPlatRepository;
import br.com.tokiomarine.acsel.repository.EmpacotadorRepository;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.repository.SegundaViaSSVRepository;
import br.com.tokiomarine.acsel.service.AgendamentoComunicacaoService;
import br.com.tokiomarine.acsel.service.DocumentosService;
import br.com.tokiomarine.acsel.service.EnderecosService;
import br.com.tokiomarine.acsel.service.SegundaViaService;
import br.com.tokiomarine.acsel.type.Sistema;
import br.com.tokiomarine.acsel.type.TipoDocumento;
import br.com.tokiomarine.acsel.util.Constants;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "DocumentosService")
@Local(value = DocumentosService.class)
public class DocumentosServiceImpl implements DocumentosService {

	@Inject
	DocumentoSSVRepository documentoSSVDao;
	@Inject
	SegundaViaSSVRepository segundaViaSSVDao;
	@Inject
	ClienteRepository clienteDao;
	@Inject
	CorretorRepository corretorDao;
	@Inject
	EnderecosService enderecoService;
	@Inject
	SegundaViaService segundaViaService;
	@Inject
	EmpacotadorRepository empacotadorDao;
	@Inject
	DocumentosPlatRepository plataformaDao;
	@Inject
	DocumentoDigitalRepository documentoDigitalDao;
	@Inject
	AgendamentoComunicacaoService agendamentoService;
	@Inject
	ApoliceRepository apoliceDao;
	@Inject
	ParametrosRepository parametrosDao;

	private String URL_DOC;
	private String URL_CARTAO;

	@SuppressWarnings("unchecked")
	@Override
	public List<DocumentoDTO> buscaDocumentos(BuscaDocumentosDTO dadosBusca) throws ServiceException{

		if (dadosBusca.getTipoBusca().equals("C")){

			dadosBusca.setRamo("");
			dadosBusca.setApolice(null);
			dadosBusca.setNegocio(null);
			dadosBusca.setNumEndosso(null);

			buscaCliente(dadosBusca);

		} else{
			dadosBusca.setListaClientes(null);
			dadosBusca.setListaClientesPlataforma(null);
			if (StringUtil.isNull(dadosBusca.getRamo()) && dadosBusca.getNumEndosso() == null && dadosBusca.getNegocio() == null ){
				throw new ServiceException("Informe os dados de busca");
			}
			if (!StringUtil.isNull(dadosBusca.getRamo()) && dadosBusca.getApolice() == null){
				throw new ServiceException("Informe o número da apólice");
			}
			if (StringUtil.isNull(dadosBusca.getRamo()) && dadosBusca.getApolice() != null){
				throw new ServiceException("Informe o ramo da apólice");
			}
			if (dadosBusca.getNumEndosso() == null && dadosBusca.getNegocio() == null){
				if (StringUtil.in(dadosBusca.getRamo(), "820", "930")){
					throw new ServiceException("Por favor, informe também o número do negócio ou o número do endosso");
				}
			}
		}
		
		List<DocumentoDTO> toReturn;
		List<DocumentoDTO> documentos = busca(dadosBusca);
		if(documentos != null && !documentos.isEmpty()) {
			toReturn = verifyDuplicatedDocs(documentos);
			Collections.sort(toReturn);
		} else {
			toReturn = new ArrayList<DocumentoDTO>();
		}

		return toReturn;
	}

	private List<DocumentoDTO> verifyDuplicatedDocs(List<DocumentoDTO> documentos) {
		List<DocumentoDTO> toReturn = new ArrayList<DocumentoDTO>();
		for(DocumentoDTO d1 : documentos) {
			if(!verifyInList(d1, toReturn)) {
				toReturn.add(d1);
			}
		}
		return toReturn;
	}

	private boolean verifyInList(DocumentoDTO d1, List<DocumentoDTO> toReturn) {
		boolean alreadyInList = false;
		for(DocumentoDTO d2 : toReturn) {
			if( d1.getNumEndosso() == null && d2.getNumEndosso() == null ) {
				alreadyInList = verifySameApol(d1, d2);
			} else if( d1.getNumEndosso() != null 
					&& d2.getNumEndosso() != null 
					&& d1.getNumEndosso().equals(d2.getNumEndosso())) {
				alreadyInList = verifySameApol(d1, d2);
			} 
			if(alreadyInList) {
				return true;
			}
		}
		return alreadyInList;
	}

	private boolean verifySameApol(DocumentoDTO d1, DocumentoDTO d2) {
		if( d1.getNumApolice() != null 
			&& d2.getNumApolice() != null
			&& d1.getRamo() != null 
			&& d2.getRamo() != null
			&& d1.getNumApolice().equals(d2.getNumApolice()) 
		    && d1.getRamo().equals(d2.getRamo())) {
			
			if(d1.getSistemaOrigem() != Sistema.acsel || d2.getSistemaOrigem() != Sistema.acsel) {
				return true;
			} else {
				if(d1.getIdePol().equals(d2.getIdePol())) {
					return true;
				}
			}
			
		}
		return false;
	}

	private void buscaCliente(BuscaDocumentosDTO dadosBusca) throws ServiceException{
		if (StringUtil.isNull(dadosBusca.getCpf()) && StringUtil.isNull(dadosBusca.getCnpj())){
			throw new ServiceException("Informe os dados de busca");
		}

		List<Cliente> clientes = clienteDao.obtemClientesNumID(dadosBusca.getNumDocumento(), dadosBusca.getDvDocumento());
		List<Segurado> clientesPlataforma = plataformaDao.buscaSegurados(dadosBusca.getNumDocumentoSemFilial(), dadosBusca.getNumFilial(), Long.parseLong(dadosBusca.getDvDocumento()));

		if ((clientes == null || clientes.isEmpty()) && (clientesPlataforma == null || clientesPlataforma.isEmpty())){
			throw new ServiceException("Cliente não encontrado. Revise as informações e tente novamente.");
		} else{
			List<String> cli = new ArrayList<String>();
			for (Cliente c : clientes){
				if (c.getCodCliente() != null  && !c.getCodCliente().trim().equals("") &&  !Integer.valueOf(c.getCodCliente().trim()).equals(0)) {
					cli.add(c.getCodCliente());					
				}
			}
			dadosBusca.setListaClientes(cli);

			List<Long> seg = new ArrayList<Long>();
			for (Segurado s : clientesPlataforma){
				seg.add(s.getCdSegurado());
			}
			dadosBusca.setListaClientesPlataforma(seg);
		}
	}

	private List<DocumentoDTO> busca(BuscaDocumentosDTO dadosBusca) throws ServiceException{
		List<DocumentoDTO> lista = new ArrayList<DocumentoDTO>();

		if (dadosBusca.getListaClientes() == null || !dadosBusca.getListaClientes().isEmpty()){
			// busca documentos no Acsel
			List<DocumentoDTO> listaAcsel = empacotadorDao.buscaDocumentos(dadosBusca);

			for (DocumentoDTO doc :listaAcsel){
				doc.setSistemaOrigem(Sistema.acsel);
				obtemDadosAdicionais(doc);
				lista.add(doc);
			}
		}

		if (dadosBusca.getNegocio() == null && (dadosBusca.getListaClientesPlataforma() == null || !dadosBusca.getListaClientesPlataforma().isEmpty())){
			// busca documentos no Plataforma
			List<DocumentoDTO> listaPlataforma = plataformaDao.buscaDocumentos(dadosBusca);

			for (DocumentoDTO doc :listaPlataforma){
				doc.setSistemaOrigem(Sistema.plat);
				obtemDadosAdicionais(doc);
				lista.add(doc);
			}
		}
		
		if (!dadosBusca.isSomenteApolice() && (dadosBusca.getListaClientes() == null || !dadosBusca.getListaClientes().isEmpty())){
			// busca documentos no SSV
			List<DocumentoDTO> listaSSV = documentoSSVDao.buscaDocumentos(dadosBusca);

			for (DocumentoDTO doc : listaSSV){
				if(!verifyInList(doc, lista)) {
					doc.setSistemaOrigem(Sistema.ssv);
					obtemDadosAdicionais(doc);
					if (StringUtil.isNull(dadosBusca.getRamo()) || doc.getRamo().equals(dadosBusca.getRamo())){
						lista.add(doc);
					}
				}
			}
		}

		return lista;
	}

	private void obtemDadosAdicionais(DocumentoDTO doc){

		obtemTipoDocumento(doc);

		if (doc.getSistemaOrigem().isAcsel()){
			if (doc.getFormaEnvio()!=null && doc.getFormaEnvio().envioEmail()){
				if(doc.getCodItem().equals("40") || Constants.AUTO_FROTA_COD_PRUDUTO.equals(doc.getCodProduto())) {
					EmailDataEnvioDTO emailData = agendamentoService.obtemDataEnvioEmail(doc.getId());
					List<String> emails = emailData.getEmailsDestinatarios();
					if (emails != null && !emails.isEmpty()) {
						doc.setEmailEnvio(emails.get(emails.size() - 1));
					}
					doc.setDataEnvioEmail(emailData.getDataEnvio());
				} else {
					for(DocumentoDigital digital : documentoDigitalDao.obtemDocumentoDigital(doc.getIdePol(), doc.getNumCert(), doc.getNumOper())){
						doc.setEmailEnvio(digital.getEmailTo());
						doc.setDataEnvioEmail(digital.getDataEnvioEmail());
					};
				}
			}

		} else if (doc.getSistemaOrigem().isSSV() && doc.getTipo().equals(TipoDocumento.endosso)){
			OperPol operPol = apoliceDao.obtemOperPol(doc.getNumApolice(), doc.getNumEndosso(), doc.getCodCliente(), doc.getNumNegocio());

			if (operPol != null){
				doc.setDescProduto(operPol.getPoliza().getProducto().getDescProd());

				CategEndosso categEndosso = operPol.getOperPolCli().getCategEndosso();
				if (categEndosso != null){
					doc.setTipoEndosso(categEndosso.getCodigo());
					doc.setDescEndosso(categEndosso.getDescEmpacotador().toUpperCase());
				}

				doc.setRamo(operPol.getPoliza().getPolizaCli().getCodRamoCli());
			}
		}
		
		atualizaDescricaoDocumento(doc);
	}

	@Override
	public void populaDetalhes(DocumentoDTO doc) throws ServiceException{

		if (doc.getSistemaOrigem().isPlataforma()){
			
			plataformaDao.populaDetalhes(doc);
			doc.setEnderecosCliente(plataformaDao.obtemEnderecos(doc.getCodCliente()));
			doc.setEnderecoCorretor(plataformaDao.obtemEnderecoCorretor(doc.getCodCorretor()));
			doc.setListaItens(plataformaDao.buscaItens(doc));
			verificaEnvioEmail(doc);
			populaDocumentos(doc);
			
		} else{
			Tercero corretor = corretorDao.obtemCorretorInterCli(doc.getCodCorretor()).getTercero();
			doc.setNomeCorretor(corretor.getNomTer());
			doc.setEnderecoCorretor(enderecoService.obtemEndereco(corretor));

			Tercero cliente = clienteDao.obtemClienteCodCliente(doc.getCodCliente()).getTercero();
			doc.setEnderecosCliente(enderecoService.obtemEnderecos(cliente));
			
			if (doc.getIndMultiItem()){
				if(doc.getCodProduto() != null && doc.getCodProduto().equals(Constants.AUTO_FROTA_COD_PRUDUTO)) {
					doc.setListaItens(apoliceDao.buscaItensAutoFrota(doc.getIdePol(), doc.getNumEndosso() != null ? doc.getNumEndosso() : 0));
				} else { 
					doc.setNumItem(doc.getNumCert());
					doc.setListaItens(apoliceDao.buscaItens(doc.getId(), doc.getNumNegocio()));
					if (doc.getCodProduto().equals(Constants.AUTO_COD_PRUDUTO)) {
						if (doc.getListaItens() != null && doc.getListaItens().size() > 0) {
							doc.setIdePol(doc.getListaItens().get(0).getIdePol());
							doc.setNumCert(doc.getListaItens().get(0).getNumCert());
							doc.setNumOper(doc.getListaItens().get(0).getNumOper());
							doc.setId(doc.getListaItens().get(0).getIdeReg());
							doc.setListaItens(new ArrayList<ItemApoliceDTO>());
						}
					}
					
				}
			}
			
			List<DownloadDocumentoDTO> listDownload = segundaViaConsulta(doc);
			if (listDownload != null && listDownload.size() > 0) {
				doc.setDocumentosDownload(listDownload);				
			} else {
				if (doc.getTipo().equals(TipoDocumento.apolice) || doc.getTipo().equals(TipoDocumento.endosso)){

					URL_DOC = parametrosDao.obtemVlrParametro("SEGUNDA_VIA", "URL_DOCUMENTO");
					URL_CARTAO = parametrosDao.obtemVlrParametro("SEGUNDA_VIA", "URL_CARTAO");

					doc.setDocumentosDownload(new ArrayList<DownloadDocumentoDTO>());

					if (doc.getIndMultiItem()){
						
						if(doc.getCodProduto() != null && doc.getCodProduto().equals(Constants.AUTO_FROTA_COD_PRUDUTO)) {
							
							DownloadDocumentoDTO docUrl = new DownloadDocumentoDTO(1L, doc.getTipo().getDescricao(), geraLinkAutoFrota(doc.getIdePol(), doc.getNumEndosso() != null ? doc.getNumEndosso() : 0 , URL_DOC), null, null);
							doc.getDocumentosDownload().add(docUrl);

							DownloadDocumentoDTO docUrlCartao = new DownloadDocumentoDTO(2L, "CARTÃO", geraLinkAutoFrota(doc.getIdePol(), doc.getNumEndosso() != null ? doc.getNumEndosso() : 0, URL_CARTAO), null, null);
							doc.getDocumentosDownload().add(docUrlCartao);
							
						} else { 

							DownloadDocumentoDTO docUrl = new DownloadDocumentoDTO(1L, doc.getTipo().getDescricao(), "", null, null);
							doc.getDocumentosDownload().add(docUrl);
							DownloadDocumentoDTO docUrlCartao = new DownloadDocumentoDTO(2L, "CARTÃO", "", null, null);
							doc.getDocumentosDownload().add(docUrlCartao);
		
							for (ItemApoliceDTO item : doc.getListaItens()){
		
								item.setDocumentosDownload(new ArrayList<DownloadDocumentoDTO>());
								
								DownloadDocumentoDTO docItemUrl = new DownloadDocumentoDTO(1L, doc.getTipo().getDescricao(), geraLink(item.getIdePol(), item.getNumCert(), item.getNumOper(), URL_DOC), null, null);
								item.getDocumentosDownload().add(docItemUrl);

								DownloadDocumentoDTO docItemUrlCartao = new DownloadDocumentoDTO(2L, "CARTÃO", geraLink(item.getIdePol(), item.getNumCert(), item.getNumOper(), URL_CARTAO), null, null);
								item.getDocumentosDownload().add(docItemUrlCartao);
							}
						}
					} else{

						DownloadDocumentoDTO docUrl = new DownloadDocumentoDTO(1L, doc.getTipo().getDescricao(), geraLink(doc.getIdePol(), doc.getNumCert(), doc.getNumOper(), URL_DOC), null, null);
						doc.getDocumentosDownload().add(docUrl);

						if (!(StringUtil.in(doc.getCodModProd(), "00041","00042"))){
							DownloadDocumentoDTO docUrlCartao = new DownloadDocumentoDTO(2L, "CARTÃO", geraLink(doc.getIdePol(), doc.getNumCert(), doc.getNumOper(), URL_CARTAO), null, null);
							doc.getDocumentosDownload().add(docUrlCartao);
						}
					}
				}
			}
			doc.setEnderecoEnvio(enderecoService.obtemEnderecoEnvio(doc));
		}

		if (doc.getListaItens() != null && !doc.getListaItens().isEmpty()){
			doc.setIndMultiItem("S");
		} else{
			doc.setIndMultiItem("N");
		}

		segundaViaService.obtemSolicitacoes(doc);
	}

	@SuppressWarnings("unchecked")
	@Override	
	public List<DownloadDocumentoDTO> segundaViaConsulta(DocumentoDTO doc) throws ServiceException {
		SegundaViaConsultaDTO segundaViaConsultaDTO = new SegundaViaConsultaDTO();
		segundaViaConsultaDTO.setIdepol(doc.getIdePol());
		segundaViaConsultaDTO.setNumcert(doc.getNumCert() != null ? doc.getNumCert() : 0L);
		segundaViaConsultaDTO.setNumoper(doc.getNumOper() != null ? doc.getNumOper() : 0L);
		segundaViaConsultaDTO.setNumendosso(doc.getNumEndosso() != null ? doc.getNumEndosso() : 0L);
		ObjectMapper mapper = new ObjectMapper();
		String content;
		try {
			content = mapper.writeValueAsString(segundaViaConsultaDTO);
		} catch (JsonProcessingException e) {
			throw new ServiceException("Erro de Conversão Json");
		}
		
		String uri = parametrosDao.obtemVlrParametro("SEGUNDA_VIA", "URL_CONSULTA");
		try {
			URL url = new URL(uri);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Content-Type", "application/json");			
			connection.setDoOutput(true);			
		    connection.setDoInput (true);
			connection.setRequestMethod("POST");

			connection.connect();
		    DataOutputStream output = new DataOutputStream(connection.getOutputStream());
		    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));

		    writer.write(content);
		    writer.close();
		    
			/* Send the request data.*/
			output.writeBytes(content);
			output.flush();
			output.close();			

		    /* Get response data.*/
		    DataInputStream input = new DataInputStream (connection.getInputStream());
		    BufferedReader br = new BufferedReader(new InputStreamReader(input, "UTF-8"));
	        String response = br.readLine();
	        SegundaViaResponseDTO segundaViaResponseDTO =  mapper.readValue(response, SegundaViaResponseDTO.class);	        
		    connection.disconnect();
		    
			List<DownloadDocumentoDTO> list = new ArrayList<DownloadDocumentoDTO>();
			Collections.sort(segundaViaResponseDTO.getDocumentos());
			for (int y=0; y < segundaViaResponseDTO.getDocumentos().size(); y++) {
				DownloadDocumentoDTO downloadDocumentoDTO = new DownloadDocumentoDTO();
				downloadDocumentoDTO.setIdDocumento(Long.valueOf(y+1));
				
				downloadDocumentoDTO.setDescDocumento(segundaViaResponseDTO.getDocumentos().get(y).getDescricao());
				if (doc.getNumEndosso() != null && doc.getNumEndosso().equals(0) && segundaViaResponseDTO.getDocumentos().get(y).getDescricao().equals("Apólice Completa")) {
					downloadDocumentoDTO.setDescDocumento("Endosso");
				}
				
				downloadDocumentoDTO.setUrlDocumento(segundaViaResponseDTO.getDocumentos().get(y).getUrl());
				downloadDocumentoDTO.setIdepol(doc.getIdePol());
				downloadDocumentoDTO.setNumEndosso(doc.getNumEndosso() != null ? doc.getNumEndosso() : 0);
				list.add(downloadDocumentoDTO);
			}
			return list;
		} catch (MalformedURLException e) {
		    e.printStackTrace();			
			throw new ServiceException("URL da Consulta Inválido");
		} catch (IOException e) {
			return null;
		}
	}
	

	private void verificaEnvioEmail(DocumentoDTO doc) {
		
		if (doc.getSeqAgendamento() != null && doc.getSeqAgendamento() > 0){
			AgendamentoComunicacao agend = agendamentoService.obtemAgendamentoCompleto(doc.getSeqAgendamento());
			if (agend != null){
				doc.setDataEnvioEmail(agend.getDtEnvioOriginal());
			} else{
				doc.setDataEnvioEmail(null);
			}
		}
		
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	private void populaDocumentos(DocumentoDTO doc) throws ServiceException {
		
		List<DocumentoDigitalDTO> documentosDigitais = plataformaDao.listaDocumentosDownload(doc.getRamo(), doc.getNumApolice(), doc.getNumEndosso());
		
		if (documentosDigitais != null && !documentosDigitais.isEmpty()){
			
			List<DownloadDocumentoDTO> downloads = new ArrayList<DownloadDocumentoDTO>();
			
			for(DocumentoDigitalDTO documentoDigital : documentosDigitais) {
				String urlDocumento = null;
				if(documentoDigital.getDsUrlArquivo() != null){

					if(isDocOk(documentoDigital.getDsUrlArquivo())) {
						urlDocumento = documentoDigital.getDsUrlArquivo();
					} else {
						try{
							urlDocumento = plataformaDao.reprocessDocument(doc, documentoDigital.getCodDocumento());
						}catch (Exception e) {
							urlDocumento = documentoDigital.getDsUrlArquivo();
						}
					}

				} else {

					if(isDocOk(documentoDigital.getDsUrlDocstore())) {
						urlDocumento = documentoDigital.getDsUrlDocstore(); 
					}else {
						try{
							urlDocumento = plataformaDao.reprocessDocument(doc, documentoDigital.getCodDocumento());
						}catch (Exception e) {
							urlDocumento = documentoDigital.getDsUrlDocstore(); 
						}
					}

				}
				downloads.add(new DownloadDocumentoDTO(documentoDigital.getCodDocumento(),
													   documentoDigital.getDescDocumento(),
													   urlDocumento,
													   doc.getNumApolice(), 
													   doc.getNumEndosso()));
			}
			
			doc.setDocumentosDownload(downloads);
		} 
	}
 
	private boolean isDocOk(String urlDocumento) {

		try {
			ClientRequest request = new ClientRequest(urlDocumento);
			ClientResponse<byte[]> response = request.post(byte[].class);
			byte[] arquivo = response.getEntity();
			PdfReader pdf = new PdfReader(arquivo);
			if(pdf.getFileLength() < 4000) {
				return false;
			}
			@SuppressWarnings("unchecked")
			Map<String, String> info = pdf.getInfo();
		    if(info.isEmpty()) {
		    	return false;
		    }
		} catch (Exception e) {
			return true;
		}
		return true;

	}

	private String geraLink(Long idePol, Long numCert, Long numOper, String baseURL){
		StringBuilder sb = new StringBuilder(baseURL);
		sb.append("?");
		sb.append("idepol=");
		sb.append(idePol);
		sb.append("&");
		sb.append("numCert=");
		sb.append(numCert);
		sb.append("&");
		sb.append("numOper=");
		sb.append(numOper);
		return sb.toString();
	}
	
	private String geraLinkAutoFrota(Long idePol, Integer numEndosso, String baseURL) {
		StringBuilder sb = new StringBuilder(baseURL);
		sb.append("?");
		sb.append("idepol=");
		sb.append(idePol);
		sb.append("&");
		sb.append("numEndosso=");
		sb.append(numEndosso);
		return sb.toString();
	}

	private void atualizaDescricaoDocumento(DocumentoDTO doc){

		String oper = null;
		String descDocumento = null;
		
		if (!StringUtil.isNull(doc.getTipoOper())){
			Lval l = parametrosDao.obtemLval("TIPOOPER", doc.getTipoOper());
			if (l != null){
				oper = l.getDescrip();
			} else{
				oper = doc.getTipoOper();
			}
		}

		if (
			doc.getTipo().equals(TipoDocumento.endosso) &&
			!StringUtil.isNull(doc.getDescEndosso()) && 
			!doc.getDescEndosso().toUpperCase().startsWith("ENDOSSO") &&
			!doc.getDescEndosso().toUpperCase().startsWith("ENDOSO")
		){
			descDocumento = "ENDOSSO DE " + doc.getDescEndosso();
		} else if (!StringUtil.isNull(oper)){
			descDocumento = oper;
		}

		if (descDocumento == null){
			descDocumento = doc.getDescDocumento();
		}
		doc.setDescDocumento(descDocumento.toUpperCase());
	}

	private void obtemTipoDocumento(DocumentoDTO doc){

		if (doc.getSistemaOrigem().isSSV()){
			if (doc.getNumApolice() != null && doc.getNumApolice() > 0 &&
					doc.getNumEndosso() != null && doc.getNumEndosso() > 0){
				doc.setTipo(TipoDocumento.endosso);
			} else{
				doc.setTipo(TipoDocumento.dual);
			}
		}
		else if (doc.getSistemaOrigem().isPlataforma()){
			if (doc.getNumEndosso() != null && doc.getNumEndosso() > 0){
				doc.setTipo(TipoDocumento.endosso);
			} else{
				doc.setTipo(TipoDocumento.apolice);
			}
		} else{
			if (StringUtil.in(doc.getTipoOper(), "EMI", "EMC", "CAV")){
				doc.setTipo(TipoDocumento.apolice);
			} else if (StringUtil.in(doc.getTipoOper(), "ECO", "ECA", "ESM", "ERE")){
				doc.setTipo(TipoDocumento.endosso);
			} else if (StringUtil.in(doc.getTipoOper(), "PEC")){
				doc.setTipo(TipoDocumento.pec);
			}
		}
	}
}
