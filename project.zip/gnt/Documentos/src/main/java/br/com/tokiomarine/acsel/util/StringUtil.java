package br.com.tokiomarine.acsel.util;

import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class StringUtil {

	private static DecimalFormat duasCasasDecimais = new DecimalFormat("####.##");

	public static synchronized String formataNumeroComDuasCasasDecimais(Double numero) {

		if (numero == null) { return ""; }

		return duasCasasDecimais.format(numero);
	}

	public static String lpad(String valueToPad, String filler, int size) {
        StringBuilder builder = new StringBuilder();

        if (valueToPad==null) valueToPad = filler;

        while (builder.length() + valueToPad.length() < size) {
            builder.append(filler);
        }
        builder.append(valueToPad);
        return builder.toString();
    }

    public static String rpad(String valueToPad, String filler, int size) {
        while (valueToPad.length() < size) {
            valueToPad = valueToPad+filler;
        }
        return valueToPad;
    }

    public static String substr(String str, int posInicial, int tamanhoMaximo){
    	return StringUtils.substring(str, posInicial, tamanhoMaximo);
    }

	public static synchronized String removeSeparadores(String texto) {

		String[] separadores = {".", "/"};
		String[] brancos = {"",""};

		return StringUtils.replaceEach(texto, separadores, brancos);
	}

	public static BigDecimal formataTaxa(BigDecimal taxa) {

		if (taxa==null) taxa = new BigDecimal(0);

		DecimalFormat df = new DecimalFormat("###.####");
	    df.setRoundingMode(RoundingMode.HALF_DOWN);

	    String valorString = df.format(taxa).replace(",",".");

	    BigDecimal valorBigDecimal = new BigDecimal(valorString);

	    return valorBigDecimal;
	}

	public static boolean in(String valor, String...lista){
		if (valor == null) return false;
		for (String s : lista){
			if (valor.equals(s))
				return true;
		}
		return false;
	}

	public static boolean isNull(String val){
		return (val == null || val.isEmpty());
	}

	public static String escapeXml(String texto){

        StringWriter stringWriter = new StringWriter((int) (texto.length() + (texto.length() * 0.1)));
        int len = texto.length();
        for (int i = 0; i < len; i++) {
             int c = texto.charAt(i);
             switch (c) {
				case 34:
					stringWriter.write(texto.charAt(i));
					//stringWriter.write("&quot;");
					break;
				case 38:
					stringWriter.write("&amp;");
					break;
				case 39:
					stringWriter.write(texto.charAt(i));
					//stringWriter.write("&apos;");
					break;
				case 60:
					stringWriter.write(texto.charAt(i));
					//stringWriter.write("&lt;");
					break;
				case 62:
					stringWriter.write(texto.charAt(i));
					//stringWriter.write("&gt;");
					break;
				default:
					stringWriter.write(texto.charAt(i));
					break;
				}
        }

        return stringWriter.toString();
	}

	public static String serialize(Object obj) throws JsonProcessingException{
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(obj);
	}

	public static Object deserialize(String json) throws JsonParseException, JsonMappingException, IOException{
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(json, Object.class);
	}

}
