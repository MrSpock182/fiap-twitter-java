package br.com.tokiomarine.acsel.flags;

public class Projeto {

	private static boolean FASE2 = false;

	public static String listar() {
		return "Projeto [FASE2] = " + FASE2;
	}

	public static boolean isFASE2() {
		return FASE2;
	}

	public static void setFASE2(boolean fASE2) {
		FASE2 = fASE2;
	}

}
