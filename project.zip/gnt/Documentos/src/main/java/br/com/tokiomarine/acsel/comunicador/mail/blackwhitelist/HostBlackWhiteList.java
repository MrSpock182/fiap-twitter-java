package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist;

import javax.ejb.Stateless;

import br.com.tokiomarine.acsel.util.AmbienteTemplate;

@Stateless(name = "HostBlackWhiteList")
public class HostBlackWhiteList extends AmbienteTemplate {

	private static final String HOST_DEV = "http://proxymail-dev.tokiomarine.com.br";
	private static final String HOST_ACT = "http://proxymail-aceite.tokiomarine.com.br";
	private static final String HOST_PROD = "http://proxymail.tokiomarine.com.br";
	
	@Override
	protected String getProducao() {
		return HOST_PROD;
	}

	@Override
	protected String getAceite() {
		return HOST_ACT;
	}

	@Override
	protected String getDev() {
		return HOST_DEV;
	}

}
