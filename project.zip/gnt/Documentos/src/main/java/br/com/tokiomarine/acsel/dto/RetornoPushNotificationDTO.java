package br.com.tokiomarine.acsel.dto;

public class RetornoPushNotificationDTO {

	private DadosRetornoPushNotificationDTO data;
	private String businessException;

	public DadosRetornoPushNotificationDTO getData() {
		return data;
	}
	public void setData(DadosRetornoPushNotificationDTO data) {
		this.data = data;
	}
	public String getBusinessException() {
		return businessException;
	}
	public void setBusinessException(String businessException) {
		this.businessException = businessException;
	}
}
