package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CATEG_ENDOSSO")
public class CategEndosso {

	@Id
	@Column(name="CODIGO")	private String codigo;

	@Column(name="DESCRICAO")	private String descricao;

	@Column(name="DESC_EMPACOTADOR")	private String descEmpacotador;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getDescEmpacotador() {
		return descEmpacotador;
	}

	public void setDescEmpacotador(String descEmpacotador) {
		this.descEmpacotador = descEmpacotador;
	}

}