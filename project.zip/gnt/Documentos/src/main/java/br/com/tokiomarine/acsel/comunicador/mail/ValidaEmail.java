package br.com.tokiomarine.acsel.comunicador.mail;

import java.util.Date;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.comunicador.ValidadorDestino;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.AgendamentoErroService;
import br.com.tokiomarine.infra.componente.email.util.EmailValidator;

@Stateless(name = "ValidaEmail")
@Local(value = ValidaEmail.class)
@Named("validaEmail")
public class ValidaEmail implements ValidadorDestino {
	
	private static Logger logger = LogManager.getLogger(ValidaEmail.class);

	@Inject
	private AgendamentoErroService agendamentoErroRepositoryService; 
	
	@Inject
	private ParametrosRepository parametrosRep;	
	
//	@Inject
//	private BlackWhiteListService blackWhiteListService;	
	
	@Override
	public void executa(AgendamentoEnvio agendamentoEnvio) {
		this.validaEmails(agendamentoEnvio);
	}

	private void validaEmails(AgendamentoEnvio envio) {
		for (AgendamentoDestinatario email : envio.getAgendamento().getDestinatarios()){
			if (!EmailValidator.validate(email.getDestinatario())){
				this.incluiAviso(envio, "O e-mail " + email.getDestinatario() + " é inválido");
				continue;
			} 
			if (!"S".equals(this.parametrosRep.obtemVlrParametro("PUSH_NOTIFICATION", "ENVIA_EMAIL_EXTERNO")) && !email.getDestinatario().toUpperCase().contains("@TOKIOMARINE.COM.BR")){
				this.incluiAviso(envio, "O envio de e-mail externo à Tokio Marine não está habilitado");
				continue;
			}
//			BlackListResource blackList = this.blackWhiteListService.getBlackList(email.getDestinatario());
//			if(blackList.isBlackList()) {
//				this.incluiAviso(envio, String.format("O e-mail %s está na Black-List", email.getDestinatario()));
//				continue;				
//			}
			email.setIndValido("S"); 
		}
		logger.info("ValidaEmails OK");
	}	

	public void incluiAviso(AgendamentoEnvio envio, String msgErro){
		AgendamentoErro erro = AgendamentoErro.builder().dtErro(new Date()).descErro(msgErro).agendamento(envio).build();
		this.agendamentoErroRepositoryService.save(erro);
	}	
	
	
}
