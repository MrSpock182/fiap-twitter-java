package br.com.tokiomarine.acsel.service.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jboss.resteasy.client.ClientRequest;
import org.jboss.resteasy.client.ClientResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.ColaboradoresService;
import br.com.tokiomarine.acsel.util.StringUtil;
import br.com.tokiomarine.acsel.ws.col.ColaboradorWs;
import br.com.tokiomarine.acsel.ws.col.ColaboradorWsService;
import br.com.tokiomarine.acsel.ws.col.dto.LocalTrabalho;
import br.com.tokiomarine.acsel.ws.col.dto.RetColaboradorPorLocal;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetColaboradoresPorLocalWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetornoWS;

@Stateless(name = "ColaboradoresService")
@Local(value = ColaboradoresService.class)
public class ColaboradoresServiceImpl implements ColaboradoresService {

	private static Logger logger = LogManager.getLogger(ColaboradoresServiceImpl.class);

	@Inject
	ParametrosRepository parametrosRep;

	@Override
	public List<LocalTrabalho> obtemLocaisTrabalho(){
		RetornoWS ret = getColaboradorWs().getLocaisTrabalho();
		return ret.getLocaisTrabalho();
	}

	@Override
	public List<RetColaboradorPorLocal> obtemColaboradores(String localTrabalho){
		RetGetColaboradoresPorLocalWS ret = getColaboradorWs().getColaboradoresPorLocalTrabalho(localTrabalho);
		return ret.getColaboradores();
	}

	private ColaboradorWs getColaboradorWs(){
		ColaboradorWsService ws;
		try {
			String param = parametrosRep.obtemVlrParametro("SEGUNDA_VIA", "URL_COL");
			if (!StringUtil.isNull(param)){
				ws = new ColaboradorWsService(new URL(param));
			} else{
				ws = new ColaboradorWsService();
			}
		} catch (MalformedURLException e) {
			ws = new ColaboradorWsService();
		}
		return ws.getColaboradorWsPort();
	}

	@Override
	public String obtemColaborador(String matricula) throws ServiceException{

		try {
			ClientRequest request = new ClientRequest(parametrosRep.obtemVlrParametro("SEGUNDA_VIA", "URL_MATRICULA") + matricula);
			ClientResponse<String> response = request.get(String.class);

			if(response.getResponseStatus().getStatusCode() != 200){
				logger.error("Usuário " + matricula + " não encontrado");
				throw new ServiceException("Usuário " + matricula + " não encontrado");
			}

			return (String) response.getEntity();

		} catch (Exception e) {
			  logger.error("Erro ao buscar o usuário " + matricula + " no AD", e);
			  throw new ServiceException("Erro ao buscar o usuário " + matricula + " no AD", e);
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public String obtemNomeColaborador(String matricula){
		String nome = matricula;

		try {
			String json = obtemColaborador(matricula);

			ObjectMapper mapper = new ObjectMapper();

			Map<String,Object> userData = mapper.readValue(json, Map.class);

			if (((Integer) userData.get("count")) > 0){
				userData = (Map<String, Object>) userData.get("0");
				userData = (Map<String, Object>) userData.get("displayname");
				if (((Integer) userData.get("count")) > 0){
					nome = (String) userData.get("0");
				}
			}

		} catch (Exception e) {
			  logger.error("Erro ao buscar nome do usuário", e);
		}

		return nome;
	}
}
