package br.com.tokiomarine.acsel.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import br.com.tokiomarine.acsel.dao.BaseSsvDAO;
import br.com.tokiomarine.acsel.domain.ssv.SolicitacaoSegundaVia;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;

public class SegundaViaSSVRepository {

	@Inject
	BaseSsvDAO base;

	@SuppressWarnings("unchecked")
	public List<SegundaViaDTO> buscaSegundaVia(Long idDocto){
		List<SegundaViaDTO> lista = new ArrayList<SegundaViaDTO>();

		String sql =
				" SELECT S.ID_DOCTO_FISCO \"id\"," +
		        "        S.DT_HORA_SOLCT \"dataSolic\"," +
				"        S.NM_SOLTT \"usuarioSolic\"," +
				"        DECODE(S.CD_SITUC_SOLCT," +
				"               0, 'P'," +
				"               1, 'E'," +
				"               2, 'C') \"status\"," +
				"        decode(S.CD_CLASS_DESTN,1,'S',2,'C','L') \"tipoDestino\"," +
				"        'Kit Completo' \"opcaoSolic\"," +
				"        S.ID_ENDER_CLIEN \"numEndereco\"," +
				"        S.NM_USR_DEST \"usuarioLocal\"," +
				"        S.NM_LOCAL_DEST \"destinoLocal\"" +
				" FROM   EMP0062_SOLCT_SEGDA_VIA_DOCTO S" +
				" WHERE  S.ID_DOCTO_FISCO = :idDocto " +
				" ORDER  BY S.DT_HORA_SOLCT DESC";

		lista = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("dataSolic")
				.addScalar("usuarioSolic")
				.addScalar("status")
				.addScalar("tipoDestino")
				.addScalar("numEndereco", StandardBasicTypes.INTEGER)
				.addScalar("usuarioLocal", StandardBasicTypes.STRING)
				.addScalar("destinoLocal", StandardBasicTypes.STRING)
				.addScalar("opcaoSolic", StandardBasicTypes.STRING)
				.setResultTransformer(Transformers.aliasToBean(SegundaViaDTO.class))
				.setParameter("idDocto", idDocto)
				.list();

		return lista;
	}

	public SolicitacaoSegundaVia buscaSolicitacao(Long id, Date dataHora){
		return (SolicitacaoSegundaVia) base.getSession().createCriteria(SolicitacaoSegundaVia.class)
				.add(Restrictions.eq("idDoctoFisco", id))
				.add(Restrictions.eq("dtHoraSolct", dataHora))
				.uniqueResult();
	}

	public void solicitaSegundaVia(SolicitacaoSegundaVia solic){
		base.persist(solic);
	}

	public SolicitacaoSegundaVia atualizaSegundaVia(SolicitacaoSegundaVia solic){
		return (SolicitacaoSegundaVia) base.merge(solic);
	}

}
