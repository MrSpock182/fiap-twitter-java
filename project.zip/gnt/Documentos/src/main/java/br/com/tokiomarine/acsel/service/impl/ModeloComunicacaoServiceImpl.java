package br.com.tokiomarine.acsel.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.tokiomarine.acsel.comunicador.mail.GNTMail;
import br.com.tokiomarine.acsel.domain.acx.DocumentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ImagemComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.PadraoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.PerfilModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.TextoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.ParametroComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.UsuarioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ModeloComunicacaoRepository;
import br.com.tokiomarine.acsel.service.EmailParserService;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoService;
import br.com.tokiomarine.acsel.service.ParametrosService;
import br.com.tokiomarine.acsel.type.TipoModelo;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "ModeloComunicacaoService")
@Local(value = ModeloComunicacaoService.class)
public class ModeloComunicacaoServiceImpl implements ModeloComunicacaoService {

	@Inject
	ModeloComunicacaoRepository modeloDao;

	@Inject
	EmailParserService emailService;

	@Inject
	ParametrosService parametrosService;

	@Inject
	GNTMail gntMail;

	@Inject
	public List<ModeloComunicacao> obtemModelos() throws ServiceException {
		return modeloDao.obtemModelos();
	}

	@Override
	public List<PadraoComunicacao> obtemPadroes() throws ServiceException {
		return modeloDao.obtemPadroes();
	}

	@Override
	public ModeloComunicacao obtemModelo(Long id) throws ServiceException {
		return modeloDao.obtemModelo(id);
	}
	
	@Override
	public ModeloComunicacao obtemModelo(String codigo) throws ServiceException {
		 return modeloDao.obtemModelo(codigo);
	}
	

	@Override
	public ModeloComunicacaoDTO obtemModeloComunicacaoDTO(ModeloComunicacao modelo) throws ServiceException {
		ModeloComunicacaoDTO dto = new ModeloComunicacaoDTO();
		dto.setCodigoModelo(modelo.getCodModelo());
		dto.setParametros(new ArrayList<ParametroComunicacaoDTO>());

		for (ParametroModelo param : modelo.getParametros()) {
			ParametroComunicacaoDTO paramDTO = new ParametroComunicacaoDTO();
			paramDTO.setNomeParametro(param.getParametro().getNomeParametro());
			dto.getParametros().add(paramDTO);
		}

		return dto;
	}

	@Override
	public List<DocumentoComunicacao> obtemDocumentos() throws ServiceException {
		return modeloDao.obtemDocumentos();
	}

	@Override
	public List<TextoComunicacao> obtemTextos(String tipoModelo) throws ServiceException {
		return modeloDao.obtemTextos(tipoModelo);
	}

	@Override
	public List<ImagemComunicacao> obtemImagens() throws ServiceException {
		return modeloDao.obtemImagens();
	}

	@Override
	public List<ParametroComunicacao> obtemParametrosDisponiveis(Long idModelo) throws ServiceException {
		return modeloDao.obtemParametrosDisponiveis(idModelo);
	}

	@Override
	public List<ParametroComunicacaoDTO> obtemParametrosConsulta(ModeloComunicacao modelo) throws ServiceException {
		List<ParametroComunicacaoDTO> listaParam = new ArrayList<ParametroComunicacaoDTO>();

		if (modelo != null) {
			for (ParametroModelo param : modeloDao.obtemParametrosConsulta(modelo.getCodModelo())) {
				ParametroComunicacaoDTO p = new ParametroComunicacaoDTO();
				p.setCodParametro(param.getParametro().getCodParametro());
				p.setDescParametro(param.getParametro().getDescParametro());
				listaParam.add(p);
			}
		} else {
			for (ParametroComunicacao param : modeloDao.obtemParametrosConsulta()) {
				ParametroComunicacaoDTO p = new ParametroComunicacaoDTO();
				p.setCodParametro(param.getCodParametro());
				p.setDescParametro(param.getDescParametro());
				listaParam.add(p);
			}
		}

		return listaParam;
	}

	@Override
	public ParametroComunicacao obtemParametroComunicacao(Long id) throws ServiceException {
		return modeloDao.obtemParametroComunicacao(id);
	}

	@Override
	public TextoComunicacao obtemTextoComunicacao(Long id) throws ServiceException {
		return modeloDao.obtemTextoComunicacao(id);
	}

	@Override
	public DocumentoComunicacao obtemDocumento(Long docId) {
		return modeloDao.obtemDocumento(docId);
	}

	@Override
	public void removeTexto(Long id, UsuarioDTO usuario) throws ServiceException {
		TextoModeloComunicacao texto = modeloDao.obtemTexto(id);
		texto.setNomeUsuarioAtualizacao(usuario.getCodUsuario());
		texto.setDataAtualizacao(new Date());
		texto.setTipoMovimento("E");
		texto.setDtFinalVigencia(texto.getDataAtualizacao());
		modeloDao.atualizaTexto(texto);
		modeloDao.removeTexto(id);
	}

	@Override
	public void removeParametro(Long id) throws ServiceException {
		modeloDao.removeParametro(id);
	}

	@Override
	public void incluiTextoComunicacao(ModeloComunicacao modelo, TextoComunicacao texto, UsuarioDTO usuario)
			throws ServiceException {
		TextoModeloComunicacao txtModelo = new TextoModeloComunicacao();
		txtModelo.setModelo(modelo);
		txtModelo.setTextoComunicacao(texto);
		txtModelo.setNomeUsuarioInclusao(usuario.getCodUsuario());
		txtModelo.setDtInclusao(new Date());
		txtModelo.setTipoMovimento("I");
		txtModelo.setDtInicioVigencia(txtModelo.getDtInclusao());
		modelo.getTextos().add(txtModelo);
		modeloDao.atualizaModelo(modelo);
	}

	@Override
	public void incluiParametroComunicacao(ModeloComunicacao modelo, ParametroComunicacao param, UsuarioDTO usuario)
			throws ServiceException {
		ParametroModelo paramModelo = new ParametroModelo();
		paramModelo.setModelo(modelo);
		paramModelo.setParametro(param);
		paramModelo.setIndExibeLista("N");
		paramModelo.setNomeUsuarioInclusao(usuario.getCodUsuario());
		paramModelo.setDataInclusao(new Date());
		modelo.getParametros().add(paramModelo);
		modeloDao.atualizaModelo(modelo);
	}

	@Override
	public void incluiNovoParametroComunicacao(ParametroComunicacao param, UsuarioDTO usuario) throws ServiceException {
		param.setNomeParametro(param.getNomeParametro().trim().toUpperCase());
		ParametroComunicacao parametroComunicacao = modeloDao.obtemParametroNome(param.getNomeParametro());
		if (parametroComunicacao != null) {
			return;
		}

		param.setDtInclusao(new Date());
		param.setNomeUsuarioInclusao(usuario.getCodUsuario());
		modeloDao.atualizaParametroComunicacao(param);
	}

	@Override
	public ModeloComunicacao atualizaModelo(ModeloComunicacao mod) throws ServiceException {
		ModeloComunicacao modelo = obtemModelo(mod.getCodModelo());

		modelo.setNomeModelo(mod.getNomeModelo());
		modelo.setDescricaoModelo(mod.getDescricaoModelo());
		modelo.setPiloto(mod.getPiloto());
		modelo.setRastreiaEnvio(mod.getRastreiaEnvio());
		modelo.setEmailCopia(mod.getEmailCopia());

		/*
		 * modelo.setNomeSistemaOrigem(mod.getNomeSistemaOrigem());
		 * modelo.setProcesso(mod.getProcesso());
		 * if(StringUtils.isEmpty(modelo.getNomeSistemaOrigem())) { throw new
		 * ServiceException("Sistema de Origem Obrigatório!!!"); }
		 */
		if (!StringUtil.isNull(mod.getTituloModelo())) {
			modelo.setTituloModelo(mod.getTituloModelo());
		}

		if (!StringUtil.isNull(mod.getProcesso())) {
			modelo.setProcesso(mod.getProcesso());
			modelo.setCodigo(mod.getCodigo());
		}

		modelo.setEmailCaixaDept(mod.getEmailCaixaDept());
		modelo.setEmailRemetente(mod.getEmailRemetente());
		modelo.setSituacaoModelo(mod.getSituacaoModelo());

		if (mod.getCodPadrao() != null) {
			PadraoComunicacao padrao = modeloDao.obtemPadrao(mod.getCodPadrao());
			modelo.setPadrao(padrao);
		}

		if (mod.getCodImagem() != null) {
			ImagemComunicacao img = modeloDao.obtemImagem(mod.getCodImagem());
			modelo.setImagem(img);
		} else if (modelo.getCodImagem() != null) {
			modelo.setImagem(null);
		}

		modelo.setDtAtualizacao(new Date());
		modelo.setNomeUsuarioAtualizacao(mod.getNomeUsuarioAtualizacao());
		modelo.setDestinoMensagem(mod.getDestinoMensagem());
		modelo.setRastreiaEnvio(mod.getRastreiaEnvio());
		modelo.setEmailResponsavel(mod.getEmailResponsavel());
		return modeloDao.atualizaModelo(modelo);
	}

	@Override
	public ModeloComunicacao incluiModelo(ModeloComunicacao mod) throws ServiceException {
		String codGerado = mod.getCodigo().trim().toUpperCase();

		ModeloComunicacao modeloComunicacao = modeloDao.obtemModelo(codGerado);
		if (modeloComunicacao != null) {
			throw new ServiceException("Código do Modelo Já Existe!!!");
		}

		if (StringUtils.isEmpty(mod.getNomeSistemaOrigem())) {
			throw new ServiceException("Sistema de Origem Obrigatório!!!");
		}

		if (mod.getCodPadrao() != null) {
			PadraoComunicacao padrao = modeloDao.obtemPadrao(mod.getCodPadrao());
			mod.setPadrao(padrao);
		}

		if (mod.getCodImagem() != null) {
			ImagemComunicacao img = modeloDao.obtemImagem(mod.getCodImagem());
			mod.setImagem(img);
		}

		if (!mod.getCanalComunicacao().equals(TipoModelo.email)) {
			mod.setTextos(new ArrayList<TextoModeloComunicacao>());
			int numSeq = 1;
			for (TextoComunicacao texto : modeloDao.obtemTextos(mod.getCanalComunicacao().getValue())) {
				TextoModeloComunicacao txtModelo = new TextoModeloComunicacao();
				txtModelo.setModelo(mod);
				txtModelo.setTextoComunicacao(texto);
				txtModelo.setNomeUsuarioInclusao(mod.getNomeUsuarioInclusao());
				txtModelo.setDtInclusao(new Date());
				txtModelo.setNumSequencia(numSeq++);
				mod.getTextos().add(txtModelo);
			}
		}
		mod.setStatus("PENDENTE");
		mod.setTituloModelo(mod.getNomeModelo());
		mod.setCodigo(codGerado);
		return modeloDao.atualizaModelo(mod);
	}

	@Override
	public void atualizaTextos(List<TextoModeloComunicacao> textos, UsuarioDTO usuario) throws ServiceException {
		Long idModelo = null;

		for (TextoModeloComunicacao txt : textos) {
			TextoModeloComunicacao textoAtualizado = modeloDao.obtemTexto(txt.getIdTexto());
			if (textoAtualizado.getTextoComunicacao().getTipoTexto().equals("I")) {
				ImagemComunicacao img = modeloDao.obtemImagem(Long.parseLong(txt.getTexto()));
				textoAtualizado.setImagem(img);
			}

			if (!StringUtil.in(textoAtualizado.getTextoComunicacao().getTipoTexto(), "I", "D", "V")) {
				textoAtualizado.setTexto(txt.getTexto());
			} else {
				textoAtualizado.setTexto("");
			}
			textoAtualizado.setNumSequencia(txt.getNumSequencia());

			textoAtualizado.setNomeUsuarioAtualizacao(usuario.getCodUsuario());
			textoAtualizado.setDataAtualizacao(new Date());
			textoAtualizado.setTipoMovimento("A");
			idModelo = textoAtualizado.getModelo().getCodModelo();
			modeloDao.atualizaTexto(textoAtualizado);
		}

		String strResult = verificaParametros(textos, idModelo);
		if (strResult != null && strResult.length() > 0) {
			throw new ServiceException(strResult.toString());
		}

	}

	@Override
	public void atualizaParametros(List<ParametroModelo> parametros, UsuarioDTO usuario) throws ServiceException {
		for (ParametroModelo param : parametros) {
			ParametroModelo parametroAtualizado = modeloDao.obtemParametro(param.getIdModeloParam());
			if (param.getIndExibeLista() == null) {
				param.setIndExibeLista("N");
			}

			parametroAtualizado.setIndExibeLista(param.getIndExibeLista());
			if ("S".equals(parametroAtualizado.getIndExibeLista())) {
				parametroAtualizado.setCdSequencia(param.getCdSequencia());
				parametroAtualizado.setNomeExibicao(param.getNomeExibicao());
			} else {
				parametroAtualizado.setCdSequencia(null);
				parametroAtualizado.setNomeExibicao("");
			}

			parametroAtualizado.setNomeUsuarioAtualizacao(usuario.getCodUsuario());
			parametroAtualizado.setDataAtualizacao(new Date());

			modeloDao.atualizaParametro(parametroAtualizado);
		}
	}

	@Override
	public String obtemEmailFormatado(Integer id) throws ServiceException {
		try {

			ModeloComunicacao modelo = obtemModelo(id.longValue());

			return emailService.geraEmail(modelo, null);

		} catch (Exception e) {
			throw new ServiceException("Erro ao formatar modelo", e);
		}

	}

	@Override
	public String obtemEmailFormatado(Integer id, String datAlteracao) throws ServiceException {
		try {

			ModeloComunicacao modelo = obtemModelo(id.longValue());
			List<TextoModeloComunicacao> txtHistorico = modeloDao.obtemHistorico(id.longValue(), datAlteracao);
			return emailService.geraEmail(modelo, txtHistorico);
		} catch (Exception e) {
			throw new ServiceException("Erro ao formatar modelo", e);
		}

	}

	private String verificaParametros(List<TextoModeloComunicacao> textos, Long idModelo) {
		String[] paramsNome = null;
		List<String> cadParams = new ArrayList<String>();
		List<String> modeloParams = new ArrayList<String>();

		for (TextoModeloComunicacao textoModeloComunicacao : textos) {
			if (StringUtils.isNotEmpty(textoModeloComunicacao.getTexto())) {
				paramsNome = StringUtils.substringsBetween(textoModeloComunicacao.getTexto(), "[", "]");
				if (paramsNome != null && paramsNome.length > 0) {
					for (String nomeParam : paramsNome) {
						ParametroComunicacao parametroComunicacao = modeloDao.obtemParametroNome(nomeParam);
						if (parametroComunicacao == null) {
							cadParams.add(nomeParam);
						} else {
							ParametroModelo parametroModelo = modeloDao.obtemParametro(idModelo,
									parametroComunicacao.getCodParametro());
							if (parametroModelo == null) {
								modeloParams.add(nomeParam);
							}
						}
					}
				}
			}
		}

		StringBuilder strResult = new StringBuilder();
		if (!cadParams.isEmpty()) {
			strResult.append("Cadastrar Parametros: ");
			for (int i = 0; i < cadParams.size(); i++) {
				if (i != 0) {
					strResult.append(", ");
				}
				strResult.append(cadParams.get(i));
			}
		}

		if (!modeloParams.isEmpty()) {
			if (!cadParams.isEmpty()) {
				strResult.append(". ");
			}
			strResult.append("Cadastrar Parametros no Modelo: ");

			for (int i = 0; i < modeloParams.size(); i++) {
				if (i != 0) {
					strResult.append(", ");
				}
				strResult.append(modeloParams.get(i));
			}
		}
		return strResult.toString();
	}

	@Override
	public List<TextoModeloComunicacao> obtemDataHistorico(Integer id) throws ServiceException {
		List<TextoModeloComunicacao> dataHistoricos = modeloDao.dataHistorico(id.longValue());
		if (dataHistoricos != null && dataHistoricos.size() > 0) {
			return dataHistoricos;
		}

		return null;
	}

	@Override
	public String proximoCodigo(String prefixo) {
		String ultimoCodigo = modeloDao.proximoCodigo(prefixo);
		Integer maxNumero = 0;
		if (ultimoCodigo != null && !ultimoCodigo.equals("")) {
			maxNumero = Integer.parseInt(ultimoCodigo.substring(9));
		}
		maxNumero++;
		return prefixo + org.apache.commons.lang3.StringUtils.leftPad(maxNumero.toString(), 4, '0');
	}

	@Override
	public List<ModeloComunicacao> obtemModelosInativos(String perfil, String codUsuario) throws ServiceException {
		PerfilModeloComunicacao perfilModeloComunicacao = modeloDao.obtemPerfil(codUsuario, perfil);
		if (perfilModeloComunicacao == null) {
			throw new ServiceException("Usuário: " + codUsuario + ". Não cadastrado no perfil: " + perfil);
		}
		return modeloDao.obtemModelosInativos(perfil);
	}

	@Override
	public void aprovarModelo(ModeloComunicacao mod) throws ServiceException {
		ModeloComunicacao modelo = obtemModelo(mod.getCodModelo());
		if (mod.getStatus().equals(modeloDao.STATUS_RECUSADO)
				&& (mod.getMotivo() == null || mod.getMotivo().equals(""))) {
			throw new ServiceException("Motivo da reprovação é obrigatório");
		}

		if (!mod.getStatus().equals(modeloDao.STATUS_RECUSADO)) {
			mod.setMotivo("");
		}

		if (mod.getStatus().equals(modeloDao.STATUS_ATIVADO)) {
			modelo.setSituacaoModelo("S");
		}
		modelo.setStatus(mod.getStatus());
		modelo.setMotivo(mod.getMotivo());
		modelo.setDtAtualizacao(new Date());
		modelo.setNomeUsuarioAtualizacao(mod.getNomeUsuarioAtualizacao());
		modeloDao.atualizaModelo(modelo);
	}

	@Override
	public List<String> listaAcoes(String perfil) {
		List<String> list = new ArrayList<String>();

		if (perfil.equals(modeloDao.PERFIL_APROVAR)) {
			list.add(modeloDao.STATUS_APROVADO);
			list.add(modeloDao.STATUS_RECUSADO);
		} else if (perfil.equals(modeloDao.PERFIL_ADMIN)) {
			list.add(modeloDao.STATUS_APROVAR);
			list.add(modeloDao.STATUS_ATIVADO);
		}
		return list;
	}

	@Override
	public void removeModelo(Long codModelo, UsuarioDTO usuario) throws ServiceException {

		ModeloComunicacao modelo = obtemModelo(codModelo);

		if (modelo.getSituacaoModelo().equals("S")) {
			throw new ServiceException("Modelo está ativo.\nNão pode ser excluído");
		}

		modelo.setNomeUsuarioAtualizacao(usuario.getCodUsuario());
		modelo.setDtAtualizacao(new Date());
		modelo.setTipoMovimento("E");
		modelo.setDtFinalVigencia(modelo.getDtAtualizacao());
		modeloDao.atualizaModelo(modelo);

		if (modelo.getTextos() != null && modelo.getTextos().size() > 0) {
			for (TextoModeloComunicacao texto : modelo.getTextos()) {
				texto.setNomeUsuarioAtualizacao(usuario.getCodUsuario());
				texto.setDataAtualizacao(new Date());
				texto.setTipoMovimento("E");
				texto.setDtFinalVigencia(texto.getDataAtualizacao());
				modeloDao.atualizaTexto(texto);
				modeloDao.removeTexto(texto.getIdTexto());
			}
		}

		if (modelo.getParametros() != null && modelo.getParametros().size() > 0) {
			for (ParametroModelo parametro : modelo.getParametros()) {
				modeloDao.removeParametro(parametro.getIdModeloParam());
			}
		}
		modeloDao.removeModelo(modelo);
	}

	public void enviarEmailModelo(String destinatario, String codigo, String template) throws ServiceException {
		gntMail.enviarMensagem(destinatario, codigo, template);
	}


}
