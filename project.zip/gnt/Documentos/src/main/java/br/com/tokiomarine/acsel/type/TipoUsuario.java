package br.com.tokiomarine.acsel.type;

public enum TipoUsuario {

	interno,
	corretor;

	TipoUsuario(String value) {
		this.value = value;
	}

	TipoUsuario() {}

	private String value;

	public String getValue() {
		if (value != null) {
			return value;
		} else {
			return this.name();
		}
	}
}
