package br.com.tokiomarine.acsel.service;

import java.util.List;

import br.com.tokiomarine.acsel.domain.acx.Tercero;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.EnderecoDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;

public interface EnderecosService {

	List<EnderecoDTO> obtemEnderecos(Tercero tercero);

	EnderecoDTO obtemEndereco(Tercero tercero);

	EnderecoDTO obtemEnderecoEnvio(DocumentoDTO doc);

	EnderecoDTO obtemEnderecoEnvio(SegundaViaDTO segundaVia);

}