package br.com.tokiomarine.acsel.type;

public enum StatusAgendamento {


	naoenviado("NEV", "NÃO ENVIADO"),
	pendente("PND", "PENDENTE"),
	finalizado("FIN", "FINALIZADO"),
	erro("ERR", "ERRO"),
	enviado("ENV", "ENVIADO"),
	piloto("PIL", "PILOTO");

	private String value;
	private String descricao;

	StatusAgendamento(String value, String desc) {
		this.value = value;
		this.descricao = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDescricao() {
		return descricao;
	}

	public static StatusAgendamento get(String status){
		for (StatusAgendamento tipo : StatusAgendamento.values()){
			if (tipo.value.equals(status)){
				return tipo;
			}
		}
		return null;
	}
}
