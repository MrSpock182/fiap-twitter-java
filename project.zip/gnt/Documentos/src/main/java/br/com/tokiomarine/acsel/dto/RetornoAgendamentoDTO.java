package br.com.tokiomarine.acsel.dto;

public class RetornoAgendamentoDTO {

	private Long seqAgendamento;
	private Integer codigoRetorno;
	private String mensagemRetorno;

	public Long getSeqAgendamento() {
		return seqAgendamento;
	}
	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}
	public Integer getCodigoRetorno() {
		return codigoRetorno;
	}
	public void setCodigoRetorno(Integer codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}
	public String getMensagemRetorno() {
		return mensagemRetorno;
	}
	public void setMensagemRetorno(String mensagemRetorno) {
		this.mensagemRetorno = mensagemRetorno;
	}
}
