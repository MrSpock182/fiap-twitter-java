package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@IdClass(TerceroEnderecosPK.class)
@Table(name = "TERCERO_ENDERECOS")
public class TerceroEnderecos {

	@Id
	@Column(name="TIPOID")	private String tipoId;
	@Id
	@Column(name="NUMID")	private Long numId;
	@Id
	@Column(name="DVID")	private String dvId;
	@Id
	@Column(name="NUMEND")	private Long numEnd;

	@Column(name="ENDERECO")	private String endereco;
	@Column(name="NUMLOGRAD")	private String numLograd;
	@Column(name="COMPLOGRAD")	private String compLograd;
	@Column(name="CODPAIS")	private String codPais;
	@Column(name="CODESTADO")	private String codEstado;
	@Column(name="CODCIUDAD")	private String codCiudad;
	@Column(name="CODMUNICIPIO")	private String codMunicipio;

	@ManyToOne
	@JoinColumns({
        @JoinColumn(updatable=false,insertable=false, name = "CODPAIS", referencedColumnName = "CODPAIS" ),
        @JoinColumn(updatable=false,insertable=false, name = "CODESTADO", referencedColumnName = "CODESTADO"),
        @JoinColumn(updatable=false,insertable=false, name = "CODCIUDAD", referencedColumnName = "CODCIUDAD" )})
	private Ciudad ciudad;

	@ManyToOne
	@JoinColumns({
        @JoinColumn(updatable=false,insertable=false, name = "CODPAIS", referencedColumnName = "CODPAIS" ),
        @JoinColumn(updatable=false,insertable=false, name = "CODESTADO", referencedColumnName = "CODESTADO"),
        @JoinColumn(updatable=false,insertable=false, name = "CODCIUDAD", referencedColumnName = "CODCIUDAD" ),
        @JoinColumn(updatable=false,insertable=false, name = "CODMUNICIPIO", referencedColumnName = "CODMUNICIPIO" )})
	private Municipio municipio;

	@Column(name="ZIP")	private String zip;
	@Column(name="USUARIO_RESP_INC")	private String usuarioRespInc;
	@Column(name="DTINCLUSAO")	private Date dtInclusao;

	public String getTipoId() {
		return tipoId;
	}
	public void setTipoId(String tipoId) {
		this.tipoId = tipoId;
	}
	public Long getNumId() {
		return numId;
	}
	public void setNumId(Long numId) {
		this.numId = numId;
	}
	public String getDvId() {
		return dvId;
	}
	public void setDvId(String dvId) {
		this.dvId = dvId;
	}
	public Long getNumEnd() {
		return numEnd;
	}
	public void setNumEnd(Long numEnd) {
		this.numEnd = numEnd;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getNumLograd() {
		return numLograd;
	}
	public void setNumLograd(String numLograd) {
		this.numLograd = numLograd;
	}
	public String getCompLograd() {
		return compLograd;
	}
	public void setCompLograd(String compLograd) {
		this.compLograd = compLograd;
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodCiudad() {
		return codCiudad;
	}
	public void setCodCiudad(String codCiudad) {
		this.codCiudad = codCiudad;
	}
	public String getCodMunicipio() {
		return codMunicipio;
	}
	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}
	public Ciudad getCiudad() {
		return ciudad;
	}
	public void setCiudad(Ciudad ciudad) {
		this.ciudad = ciudad;
	}
	public Municipio getMunicipio() {
		return municipio;
	}
	public void setMunicipio(Municipio municipio) {
		this.municipio = municipio;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getUsuarioRespInc() {
		return usuarioRespInc;
	}
	public void setUsuarioRespInc(String usuarioRespInc) {
		this.usuarioRespInc = usuarioRespInc;
	}
	public Date getDtInclusao() {
		return dtInclusao;
	}
	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

}