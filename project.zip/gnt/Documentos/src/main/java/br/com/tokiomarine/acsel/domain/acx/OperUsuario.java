package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="OPER_USUARIO")
public class OperUsuario implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CODUSR")	private String codUsuario;

	@Column(name="CODGRPUSR")	private String codGrupoUsuario;
	@Column(name="CODOPER")	private String codOperacao;
	@Column(name="INDRAMO")	private String indRamo;
	@Column(name="PASSWORD")	private String password;

	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public String getCodGrupoUsuario() {
		return codGrupoUsuario;
	}
	public void setCodGrupoUsuario(String codGrupoUsuario) {
		this.codGrupoUsuario = codGrupoUsuario;
	}
	public String getCodOperacao() {
		return codOperacao;
	}
	public void setCodOperacao(String codOperacao) {
		this.codOperacao = codOperacao;
	}
	public String getIndRamo() {
		return indRamo;
	}
	public void setIndRamo(String indRamo) {
		this.indRamo = indRamo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}