package br.com.tokiomarine.acsel.builders;

import java.util.Date;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.type.StatusAgendamento;
import br.com.tokiomarine.acsel.util.StringUtil;

public class AgendamentoComunicacaoBuilder {

	private ModeloComunicacao modelo;
	private Date dtAgendamento;
	private String indEnviaComunicacao;
	private String statusAgendamento;
	private String tipoEnvio;
	private String rastreiaEnvio;
	private String emailRemetente;

	public static AgendamentoComunicacaoBuilder builder() {
		return new AgendamentoComunicacaoBuilder();
	}
	
	public AgendamentoComunicacao build() {
		AgendamentoComunicacao agendamento = new AgendamentoComunicacao();
		agendamento.setModelo(modelo);
		agendamento.setDtAgendamento(dtAgendamento);
		agendamento.setIndEnviaComunicacao(indEnviaComunicacao);
		agendamento.setStatusAgendamento(statusAgendamento);
		agendamento.setTipoEnvio(tipoEnvio);
		agendamento.setRastreiaEnvio(rastreiaEnvio);
		agendamento.setEmailRemetente(emailRemetente);
		return agendamento;
	}
	
	private String getIndEnviaComunicacao(String indEnviaComunicacao) {
		return StringUtil.isNull(indEnviaComunicacao) ? "S" : indEnviaComunicacao;
	}

	public AgendamentoComunicacaoBuilder modelo(ModeloComunicacao modelo) {
		this.modelo = modelo;
		return this;
	}

	public AgendamentoComunicacaoBuilder dtAgendamento(Date dtAgendamento) {
		this.dtAgendamento = dtAgendamento;
		return this;
	}

	public AgendamentoComunicacaoBuilder indEnviaComunicacao(String indEnviaComunicacao) {		
		this.indEnviaComunicacao = this.getIndEnviaComunicacao(indEnviaComunicacao);
		return this;
	}

	public AgendamentoComunicacaoBuilder statusAgendamento(String statusAgendamento) {
		this.statusAgendamento = statusAgendamento;
		return this;
	}
	
	public AgendamentoComunicacaoBuilder statusAgendamentoComunicacao(String indEnviaComunicacao) throws ServiceException {
		String indEnvCom = this.getIndEnviaComunicacao(indEnviaComunicacao);
		
		if ("S".equals(indEnvCom))
			if (this.modelo.getPiloto().equals("S")) {
				statusAgendamento = StatusAgendamento.piloto.getValue();
			} else {
				statusAgendamento = StatusAgendamento.naoenviado.getValue();				
			}
		else if("N".equals(indEnvCom)) {
			statusAgendamento = StatusAgendamento.finalizado.getValue();
		} else {
			throw new ServiceException("Indicador de envio de comunicação inválido");
		}
		
		return this;
	}

	public AgendamentoComunicacaoBuilder tipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
		return this;
	}

	public AgendamentoComunicacaoBuilder rastreiaEnvio(String rastreiaEnvio) {
		this.rastreiaEnvio = rastreiaEnvio;
		return this;
	}
	
	public AgendamentoComunicacaoBuilder emailRemetente(String emailRemetente) {
		this.emailRemetente = emailRemetente;
		return this;
	}
	
	

}
