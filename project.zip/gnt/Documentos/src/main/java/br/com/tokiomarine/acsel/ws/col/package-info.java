@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.col.tokiomarine.com.br/")
package br.com.tokiomarine.acsel.ws.col;
