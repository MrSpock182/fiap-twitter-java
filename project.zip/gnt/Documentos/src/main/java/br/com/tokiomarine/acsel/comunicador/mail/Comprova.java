package br.com.tokiomarine.acsel.comunicador.mail;

import javax.ejb.Stateless;

import br.com.tokiomarine.acsel.comunicador.RastreioEnvio;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.type.TipoModelo;

@Stateless(name="Comprova")
public class Comprova implements RastreioEnvio {

	private static final String COMPROVA_PONTO_COM = ".comprova.com";

	@Override
	public AgendamentoComunicacao addRastreio(AgendamentoComunicacao agendamentoComunicacao) { 
		if(TipoModelo.email == agendamentoComunicacao.getModeloCanalComunicacao()) {
			for (AgendamentoDestinatario ad : agendamentoComunicacao.getDestinatarios()) {
				ad.setDestinatario(ad.getDestinatario().concat(COMPROVA_PONTO_COM));
			}
		}
		return agendamentoComunicacao; 
	}

}
