package br.com.tokiomarine.acsel.service.impl;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.dto.ConsultaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDocstoreDTO;
import br.com.tokiomarine.acsel.dto.DocumentoImpressaoDTO;
import br.com.tokiomarine.acsel.repository.ConsultaDocumentosPlatRepository;
import br.com.tokiomarine.acsel.service.ConsultaDocumentosService;

@Stateless(name = "ConsultaDocumentosService")
@Local(value = ConsultaDocumentosService.class)
public class ConsultaDocumentosImpl implements ConsultaDocumentosService {
	
	@Inject
	ConsultaDocumentosPlatRepository consultaDocumentosPlatDao;

	@Override
	public ConsultaDocumentosDTO listaDocumentos(ConsultaDocumentosDTO consulta) {
		
		List<DocumentoDocstoreDTO> docs = consultaDocumentosPlatDao.listaDocumentos(consulta.getCdRamoProdutoTmsr(), consulta.getCdApoliceTmsr(), consulta.getCdEndossoTmsr(), consulta.getCdDocumento());
		if(docs != null && !docs.isEmpty()) {
			for(DocumentoDocstoreDTO url : docs) {
				url.findIdDocstore();
			}
			consulta.setDocumentos(docs);
		}
		
		return consulta;
	}

	@Override
	public List<DocumentoImpressaoDTO> listaDocumentosDisponiveis() {
		return consultaDocumentosPlatDao.listaDocumentosDisponiveis();
	}

}
