package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class AgendamentoParametroPK implements Serializable{

	private static final long serialVersionUID = -1305313054616170576L;

	private AgendamentoComunicacao agendamento;
	private ParametroComunicacao parametro;

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}
	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}

	public ParametroComunicacao getParametro() {
		return parametro;
	}
	public void setParametro(ParametroComunicacao parametro) {
		this.parametro = parametro;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((agendamento == null) ? 0 : agendamento.hashCode());
		result = prime * result
				+ ((parametro == null) ? 0 : parametro.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgendamentoParametroPK other = (AgendamentoParametroPK) obj;
		if (agendamento == null) {
			if (other.agendamento != null)
				return false;
		} else if (parametro == null) {
			if (other.parametro != null)
				return false;
		} else if (!agendamento.equals(other.agendamento)){
			return false;
		} else if (!parametro.equals(other.parametro)){
			return false;
		}

		return true;
	}

}