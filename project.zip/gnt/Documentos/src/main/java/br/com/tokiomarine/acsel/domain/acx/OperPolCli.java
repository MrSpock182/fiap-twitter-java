package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "OPER_POL_CLI")
public class OperPolCli implements Serializable{

	private static final long serialVersionUID = 3002388680850194397L;

	// IDEPOL, NUMCERT, NUMOPER
	@Id
	@OneToOne
	@JoinColumns({
		@JoinColumn(name = "IDEPOL",referencedColumnName = "IDEPOL"),
		@JoinColumn(name = "NUMCERT",referencedColumnName = "NUMCERT"),
		@JoinColumn(name = "NUMOPER",referencedColumnName = "NUMOPER"),
	})
	private OperPol operPol;

	@Column(name = "CODPLANFRAC")
	private String codPlanFrac;
	@Column(name = "MODPLANFRAC")
	private String modPlanFrac;
	@Column(name = "FECULTFACT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecUltFact;
	@Column(name = "PCTCOMISESP")
	private BigDecimal pctComisEsp;
	@Column(name = "DTBASCALC")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtBascAlc;
	@Column(name = "INDFUNC")
	private String indFunc;
	@Column(name = "MATAUTTEC")
	private String matAutTec;
	@Column(name = "MATAUTNEG")
	private String matAutNeg;
	@Column(name = "LOCRES")
	private String locRes;
	@Column(name = "TIPOCTAMES")
	private String tipoCtaMes;
	@Column(name = "DTVCTPRIPARC")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtVctPriParc;
	@Column(name = "NOMERESP")
	private String nomeResp;
	@Column(name = "CODCENAPE")
	private String codCenape;
	@Column(name = "CODCENAPEFUNC")
	private String codCenapeFunc;
	@Column(name = "TPRENOV")
	private String tpRenov;
	@Column(name = "DIAPAGFAT")
	private String diaPagFat;
	@Column(name = "TIPOCOBUNI")
	private String tipoCobUni;
	@Column(name = "DIAFECHFAT")
	private String diaFechFat;
	@Column(name = "INDCAPBAN")
	private String indCapBan;
	@Column(name = "INDNEGESP")
	private String indNegEsp;
	@Column(name = "INDCONDESTIP")
	private String indCondEstip;
	@Column(name = "ORIMODRESID")
	private String oriModResid;
	@Column(name = "TIPSUPLEND")
	private String tipSuplEnd;
	@Column(name = "INDRESSEG")
	private String indResseg;
	@Column(name = "TPALT")
	private String tpAlt;
	@Column(name = "LOCALCAPMF")
	private String localCapMf;
	@Column(name = "CODAGENCIAMF")
	private String codAgenciaMf;
	@Column(name = "INDPARCALT")
	private String indParcAlt;
	@Column(name = "CODCENAPVENDA")
	private String codCenapVenda;
	@Column(name = "TPENDOSSORIG")
	private String tpEndossOrig;
	@Column(name = "CD_TABL_PRCO_AUTO")
	private String cdTablPrcoAuto;
	@Column(name = "CD_IDNTF_CNTRL_BNUS")
	private String cdIdntfCntrlBnus;
	@Column(name = "NR_LAUDO_VSTR")
	private String nrLaudoVstr;
	@Column(name = "TP_EXCLU")
	private String tpExclu;
	@Column(name = "DT_INICIO_VIGEN")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtInicioVigen;
	@Column(name = "INDREALCOR")
	private String indRealCor;
	@Column(name = "CD_IDNTF_BNUS_TKMR")
	private String cdIdntfBnusTkmr;
	@Column(name = "CD_IDADE_SEG")
	private String cdIdadeSeg;
	@Column(name = "NM_DUT_VEICU")
	private String nmDutVeicu;
	@Column(name = "INDISEFRQSIN")
	private String indIseFrqSin;
	@Column(name = "DT_REFER_QBR")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtReferQbr;
	@Column(name = "CD_TIPO_SEGUR")
	private String cdTipoSegur;
	@Column(name = "ID_CLAUSULA_SINISTRO")
	private String idClausulaSinistro;
	@Column(name = "ID_CLAUSULA_RENOVACAO")
	private String idClausulaRenovacao;
	@Column(name = "NO_PROPOSTA_VC")
	private String noPropostaVc;
	@Column(name = "ID_ENDOSSO_FULL")
	private String idEndossoFull;
	@Column(name = "ID_CANC_RESTITUICAO")
	private String idCancRestituicao;
	@Column(name = "DT_REFER_FRQ_VIDR")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtReferFrqVidr;
	@Column(name = "ID_CLAU_ISEN_PRIM_PARC")
	private String idClauIsenPrimParc;
	@Column(name = "DT_CALCULO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtCalculo;
	@Column(name = "DT_INI_VIG_ORIG")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtIniVigOrig;
	@Column(name = "DT_FIM_VIG_ORIG")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtFimVigOrig;
	@Column(name = "DT_INSUMO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtInsumo;
	@Column(name = "TP_PRODUTO")
	private String tpProduto;
	@Column(name = "TPCOMERC")
	private String tpComerc;
	@Column(name = "CD_SUBSCRITOR")
	private String cdSubscritor;
	@Column(name = "INDCOMSUPACELERADA")
	private String indComSupAcelerada;
	@Column(name = "PC_IS_TABEL_MERCD")
	private BigDecimal pcIsTabelMercd;
	@Column(name = "PC_REDUTOR")
	private BigDecimal pcRedutor;
	@Column(name = "CD_USUARIO_VENDA")
	private BigDecimal cdUsuarioVenda;
	@Column(name = "ID_AUTORIZA_EMAIL")
	private String idAutorizaEmail;
	@Column(name = "ID_TIPO_ENVIO")
	private String idTipoEnvio;
	@Column(name = "CODESTADO")
	private String codEstado;
	@Column(name = "ID_AUTORIZA_SMS")
	private String idAutorizaSms;
	@Column(name = "CODMODPROD")
	private String codModProd;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(insertable=false, updatable=false, name = "TPALT",referencedColumnName = "CODIGO")
	@NotFound(action = NotFoundAction.IGNORE)
	private CategEndosso categEndosso;

	@Column(name = "INDPEP")
	private String indPep;// PLD

	public String getIndPep() {
		return indPep;
	}

	public void setIndPep(String indPep) {
		this.indPep = indPep;
	}

	public String getCodPlanFrac() {
		return codPlanFrac;
	}

	public void setCodPlanFrac(String codPlanFrac) {
		this.codPlanFrac = codPlanFrac;
	}

	public String getModPlanFrac() {
		return modPlanFrac;
	}

	public void setModPlanFrac(String modPlanFrac) {
		this.modPlanFrac = modPlanFrac;
	}

	public Date getFecUltFact() {
		return fecUltFact;
	}

	public void setFecUltFact(Date fecUltFact) {
		this.fecUltFact = fecUltFact;
	}

	public BigDecimal getPctComisEsp() {
		return pctComisEsp;
	}

	public void setPctComisEsp(BigDecimal pctComisEsp) {
		this.pctComisEsp = pctComisEsp;
	}

	public Date getDtBascAlc() {
		return dtBascAlc;
	}

	public void setDtBascAlc(Date dtBascAlc) {
		this.dtBascAlc = dtBascAlc;
	}

	public String getIndFunc() {
		return indFunc;
	}

	public void setIndFunc(String indFunc) {
		this.indFunc = indFunc;
	}

	public String getMatAutTec() {
		return matAutTec;
	}

	public void setMatAutTec(String matAutTec) {
		this.matAutTec = matAutTec;
	}

	public String getMatAutNeg() {
		return matAutNeg;
	}

	public void setMatAutNeg(String matAutNeg) {
		this.matAutNeg = matAutNeg;
	}

	public String getLocRes() {
		return locRes;
	}

	public void setLocRes(String locRes) {
		this.locRes = locRes;
	}

	public String getTipoCtaMes() {
		return tipoCtaMes;
	}

	public void setTipoCtaMes(String tipoCtaMes) {
		this.tipoCtaMes = tipoCtaMes;
	}

	public Date getDtVctPriParc() {
		return dtVctPriParc;
	}

	public void setDtVctPriParc(Date dtVctPriParc) {
		this.dtVctPriParc = dtVctPriParc;
	}

	public String getNomeResp() {
		return nomeResp;
	}

	public void setNomeResp(String nomeResp) {
		this.nomeResp = nomeResp;
	}

	public String getCodCenape() {
		return codCenape;
	}

	public void setCodCenape(String codCenape) {
		this.codCenape = codCenape;
	}

	public String getCodCenapeFunc() {
		return codCenapeFunc;
	}

	public void setCodCenapeFunc(String codCenapeFunc) {
		this.codCenapeFunc = codCenapeFunc;
	}

	public String getTpRenov() {
		return tpRenov;
	}

	public void setTpRenov(String tpRenov) {
		this.tpRenov = tpRenov;
	}

	public String getDiaPagFat() {
		return diaPagFat;
	}

	public void setDiaPagFat(String diaPagFat) {
		this.diaPagFat = diaPagFat;
	}

	public String getTipoCobUni() {
		return tipoCobUni;
	}

	public void setTipoCobUni(String tipoCobUni) {
		this.tipoCobUni = tipoCobUni;
	}

	public String getDiaFechFat() {
		return diaFechFat;
	}

	public void setDiaFechFat(String diaFechFat) {
		this.diaFechFat = diaFechFat;
	}

	public String getIndCapBan() {
		return indCapBan;
	}

	public void setIndCapBan(String indCapBan) {
		this.indCapBan = indCapBan;
	}

	public String getIndNegEsp() {
		return indNegEsp;
	}

	public void setIndNegEsp(String indNegEsp) {
		this.indNegEsp = indNegEsp;
	}

	public String getIndCondEstip() {
		return indCondEstip;
	}

	public void setIndCondEstip(String indCondEstip) {
		this.indCondEstip = indCondEstip;
	}

	public String getOriModResid() {
		return oriModResid;
	}

	public void setOriModResid(String oriModResid) {
		this.oriModResid = oriModResid;
	}

	public String getTipSuplEnd() {
		return tipSuplEnd;
	}

	public void setTipSuplEnd(String tipSuplEnd) {
		this.tipSuplEnd = tipSuplEnd;
	}

	public String getIndResseg() {
		return indResseg;
	}

	public void setIndResseg(String indResseg) {
		this.indResseg = indResseg;
	}

	public String getTpAlt() {
		return tpAlt;
	}

	public void setTpAlt(String tpAlt) {
		this.tpAlt = tpAlt;
	}

	public String getLocalCapMf() {
		return localCapMf;
	}

	public void setLocalCapMf(String localCapMf) {
		this.localCapMf = localCapMf;
	}

	public String getCodAgenciaMf() {
		return codAgenciaMf;
	}

	public void setCodAgenciaMf(String codAgenciaMf) {
		this.codAgenciaMf = codAgenciaMf;
	}

	public String getIndParcAlt() {
		return indParcAlt;
	}

	public void setIndParcAlt(String indParcAlt) {
		this.indParcAlt = indParcAlt;
	}

	public String getCodCenapVenda() {
		return codCenapVenda;
	}

	public void setCodCenapVenda(String codCenapVenda) {
		this.codCenapVenda = codCenapVenda;
	}

	public String getTpEndossOrig() {
		return tpEndossOrig;
	}

	public void setTpEndossOrig(String tpEndossOrig) {
		this.tpEndossOrig = tpEndossOrig;
	}

	public String getCdTablPrcoAuto() {
		return cdTablPrcoAuto;
	}

	public void setCdTablPrcoAuto(String cdTablPrcoAuto) {
		this.cdTablPrcoAuto = cdTablPrcoAuto;
	}

	public String getCdIdntfCntrlBnus() {
		return cdIdntfCntrlBnus;
	}

	public void setCdIdntfCntrlBnus(String cdIdntfCntrlBnus) {
		this.cdIdntfCntrlBnus = cdIdntfCntrlBnus;
	}

	public String getNrLaudoVstr() {
		return nrLaudoVstr;
	}

	public void setNrLaudoVstr(String nrLaudoVstr) {
		this.nrLaudoVstr = nrLaudoVstr;
	}

	public String getTpExclu() {
		return tpExclu;
	}

	public void setTpExclu(String tpExclu) {
		this.tpExclu = tpExclu;
	}

	public Date getDtInicioVigen() {
		return dtInicioVigen;
	}

	public void setDtInicioVigen(Date dtInicioVigen) {
		this.dtInicioVigen = dtInicioVigen;
	}

	public String getIndRealCor() {
		return indRealCor;
	}

	public void setIndRealCor(String indRealCor) {
		this.indRealCor = indRealCor;
	}

	public String getCdIdntfBnusTkmr() {
		return cdIdntfBnusTkmr;
	}

	public void setCdIdntfBnusTkmr(String cdIdntfBnusTkmr) {
		this.cdIdntfBnusTkmr = cdIdntfBnusTkmr;
	}

	public String getCdIdadeSeg() {
		return cdIdadeSeg;
	}

	public void setCdIdadeSeg(String cdIdadeSeg) {
		this.cdIdadeSeg = cdIdadeSeg;
	}

	public String getNmDutVeicu() {
		return nmDutVeicu;
	}

	public void setNmDutVeicu(String nmDutVeicu) {
		this.nmDutVeicu = nmDutVeicu;
	}

	public String getIndIseFrqSin() {
		return indIseFrqSin;
	}

	public void setIndIseFrqSin(String indIseFrqSin) {
		this.indIseFrqSin = indIseFrqSin;
	}

	public Date getDtReferQbr() {
		return dtReferQbr;
	}

	public void setDtReferQbr(Date dtReferQbr) {
		this.dtReferQbr = dtReferQbr;
	}

	public String getCdTipoSegur() {
		return cdTipoSegur;
	}

	public void setCdTipoSegur(String cdTipoSegur) {
		this.cdTipoSegur = cdTipoSegur;
	}

	public String getIdClausulaSinistro() {
		return idClausulaSinistro;
	}

	public void setIdClausulaSinistro(String idClausulaSinistro) {
		this.idClausulaSinistro = idClausulaSinistro;
	}

	public String getIdClausulaRenovacao() {
		return idClausulaRenovacao;
	}

	public void setIdClausulaRenovacao(String idClausulaRenovacao) {
		this.idClausulaRenovacao = idClausulaRenovacao;
	}

	public String getNoPropostaVc() {
		return noPropostaVc;
	}

	public void setNoPropostaVc(String noPropostaVc) {
		this.noPropostaVc = noPropostaVc;
	}

	public String getIdEndossoFull() {
		return idEndossoFull;
	}

	public void setIdEndossoFull(String idEndossoFull) {
		this.idEndossoFull = idEndossoFull;
	}

	public String getIdCancRestituicao() {
		return idCancRestituicao;
	}

	public void setIdCancRestituicao(String idCancRestituicao) {
		this.idCancRestituicao = idCancRestituicao;
	}

	public Date getDtReferFrqVidr() {
		return dtReferFrqVidr;
	}

	public void setDtReferFrqVidr(Date dtReferFrqVidr) {
		this.dtReferFrqVidr = dtReferFrqVidr;
	}

	public String getIdClauIsenPrimParc() {
		return idClauIsenPrimParc;
	}

	public void setIdClauIsenPrimParc(String idClauIsenPrimParc) {
		this.idClauIsenPrimParc = idClauIsenPrimParc;
	}

	public Date getDtCalculo() {
		return dtCalculo;
	}

	public void setDtCalculo(Date dtCalculo) {
		this.dtCalculo = dtCalculo;
	}

	public Date getDtIniVigOrig() {
		return dtIniVigOrig;
	}

	public void setDtIniVigOrig(Date dtIniVigOrig) {
		this.dtIniVigOrig = dtIniVigOrig;
	}

	public Date getDtFimVigOrig() {
		return dtFimVigOrig;
	}

	public void setDtFimVigOrig(Date dtFimVigOrig) {
		this.dtFimVigOrig = dtFimVigOrig;
	}

	public Date getDtInsumo() {
		return dtInsumo;
	}

	public void setDtInsumo(Date dtInsumo) {
		this.dtInsumo = dtInsumo;
	}

	public String getTpProduto() {
		return tpProduto;
	}

	public void setTpProduto(String tpProduto) {
		this.tpProduto = tpProduto;
	}

	public String getTpComerc() {
		return tpComerc;
	}

	public void setTpComerc(String tpComerc) {
		this.tpComerc = tpComerc;
	}

	public String getCdSubscritor() {
		return cdSubscritor;
	}

	public void setCdSubscritor(String cdSubscritor) {
		this.cdSubscritor = cdSubscritor;
	}

	public String getIndComSupAcelerada() {
		return indComSupAcelerada;
	}

	public void setIndComSupAcelerada(String indComSupAcelerada) {
		this.indComSupAcelerada = indComSupAcelerada;
	}

	public BigDecimal getPcIsTabelMercd() {
		return pcIsTabelMercd;
	}

	public void setPcIsTabelMercd(BigDecimal pcIsTabelMercd) {
		this.pcIsTabelMercd = pcIsTabelMercd;
	}

	public BigDecimal getPcRedutor() {
		return pcRedutor;
	}

	public void setPcRedutor(BigDecimal pcRedutor) {
		this.pcRedutor = pcRedutor;
	}

	public BigDecimal getCdUsuarioVenda() {
		return cdUsuarioVenda;
	}

	public void setCdUsuarioVenda(BigDecimal cdUsuarioVenda) {
		this.cdUsuarioVenda = cdUsuarioVenda;
	}

	public String getIdAutorizaEmail() {
		return idAutorizaEmail;
	}

	public void setIdAutorizaEmail(String idAutorizaEmail) {
		this.idAutorizaEmail = idAutorizaEmail;
	}

	public String getIdTipoEnvio() {
		return idTipoEnvio;
	}

	public void setIdTipoEnvio(String idTipoEnvio) {
		this.idTipoEnvio = idTipoEnvio;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getIdAutorizaSms() {
		return idAutorizaSms;
	}

	public void setIdAutorizaSms(String idAutorizaSms) {
		this.idAutorizaSms = idAutorizaSms;
	}

	public OperPol getOperPol() {
		return operPol;
	}

	public void setOperPol(OperPol operPol) {
		this.operPol = operPol;
	}

	public CategEndosso getCategEndosso() {
		return categEndosso;
	}

	public void setCategEndosso(CategEndosso categEndosso) {
		this.categEndosso = categEndosso;
	}

	public String getCodModProd() {
		return codModProd;
	}

	public void setCodModProd(String codModProd) {
		this.codModProd = codModProd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((operPol == null) ? 0 : operPol.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OperPolCli other = (OperPolCli) obj;
		if (operPol == null) {
			if (other.operPol != null)
				return false;
		} else if (!operPol.equals(other.operPol))
			return false;
		return true;
	}
}
