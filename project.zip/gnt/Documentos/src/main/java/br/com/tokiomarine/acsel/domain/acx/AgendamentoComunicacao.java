package br.com.tokiomarine.acsel.domain.acx;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import br.com.tokiomarine.acsel.comunicador.RastreioEnvio;
import br.com.tokiomarine.acsel.comunicador.RastreioEnvioFactory;
import br.com.tokiomarine.acsel.type.StatusAgendamento;
import br.com.tokiomarine.acsel.type.TipoModelo;
import br.com.tokiomarine.acsel.util.StringUtil;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "AGENDAMENTO_COMUNICACAO")
public class AgendamentoComunicacao {

	@Id
	@Column(name="CD_SEQUENCIA_AGENDAMENTO")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="agendamentoGenerator")
	@SequenceGenerator(name = "agendamentoGenerator", sequenceName = "SQ_AGENDAMENTO_COMUNICACAO",allocationSize=1)
	private Long seqAgendamento;

	@ManyToOne
	@JoinColumn(name="CD_MODELO_COMUNICACAO", referencedColumnName="CD_MODELO_COMUNICACAO")
	private ModeloComunicacao modelo;

	@Column(name="ID_ENVIA_COMUNIC")
	private String indEnviaComunicacao;

	@Column(name="DT_AGENDAMENTO")
	private Date dtAgendamento;

	@Column(name="DT_ENVIO_ORIGINAL")
	private Date dtEnvioOriginal;

	@Column(name="ID_SITUACAO_AGENDAMENTO")
	private String statusAgendamento;

	@Column(name="DS_MSG_ENVIADA")
	private String mensagemEnviada;
	
	@Column(name="COD_CORRETOR")
	private String	codCorretor;

	@Column(name="DS_CORRETOR_CPFCNPJ")
	private String corretorCpfCnpj;	
	
	@Column(name="DS_TIPO_ENVIO")
	private String tipoEnvio;	
	
	@OneToMany(mappedBy="agendamento", cascade=CascadeType.ALL)
	@OrderBy("seqDestinatario")
	private List<AgendamentoDestinatario> destinatarios;

	@OneToMany(mappedBy="agendamento", cascade=CascadeType.ALL)
	private List<AgendamentoParametro> parametros;

	@OneToMany(mappedBy="agendamento", cascade=CascadeType.ALL)
	private List<AgendamentoDocumento> documentos;

	@OneToMany(mappedBy="agendamento", cascade=CascadeType.ALL)
	private List<AgendamentoEnvio> envios;

	@OneToMany(mappedBy="agendamento", cascade=CascadeType.ALL)
	private List<AgendamentoAnexo> anexos;
	
	@OneToMany(mappedBy="agendamento", cascade=CascadeType.ALL)
	private List<AgendamentoListDocumentos> listDoc;
	
	@OneToMany(mappedBy="agendamento", cascade=CascadeType.ALL)
	@OrderBy("seqCopia")
	private List<AgendamentoComCopia> comCopias;
	
	@Column(name="DS_REMETENTE_OPCIONAL")	
	private String emailRemetente;
	
	@Getter @Setter
	@Column(name="DS_RASTREIA_ENVIO")
	private String rastreiaEnvio;	

	public Long getSeqAgendamento() {
		return seqAgendamento;
	}

	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}

	public ModeloComunicacao getModelo() {
		return modelo;
	}

	public void setModelo(ModeloComunicacao modelo) {
		this.modelo = modelo;
	}

	public String getIndEnviaComunicacao() {
		return indEnviaComunicacao;
	}

	public void setIndEnviaComunicacao(String indEnviaComunicacao) {
		this.indEnviaComunicacao = indEnviaComunicacao;
	}

	public Date getDtAgendamento() {
		return dtAgendamento;
	}

	public void setDtAgendamento(Date dtAgendamento) {
		this.dtAgendamento = dtAgendamento;
	}

	public Date getDtEnvioOriginal() {
		return dtEnvioOriginal;
	}

	public void setDtEnvioOriginal(Date dtEnvioOriginal) {
		this.dtEnvioOriginal = dtEnvioOriginal;
	}

	public String getStatusAgendamento() {
		return statusAgendamento;
	}

	public void setStatusAgendamento(String statusAgendamento) {
		this.statusAgendamento = statusAgendamento;
	}

	public String getMensagemEnviada() {
		return mensagemEnviada;
	}

	public void setMensagemEnviada(String mensagemEnviada) {
		this.mensagemEnviada = mensagemEnviada;
	}

	public String getTipoEnvio() {
		return tipoEnvio;
	}

	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}

	public List<AgendamentoDestinatario> getDestinatarios() {
		return destinatarios;
	}

	public void setDestinatarios(List<AgendamentoDestinatario> destinatarios) {
		this.destinatarios = destinatarios;
		if( (this.modelo.sempreRastreia()) || (this.modelo.definidoRastreioNoAgendamento() && "S".equals(this.rastreiaEnvio)) ) {
			this.addRastreioEnvio();
		}			
	}

	private void addRastreioEnvio() {
		RastreioEnvio rastreioEnvio = RastreioEnvioFactory.getRastreio();  
		rastreioEnvio.addRastreio(this);
	}

	public List<AgendamentoParametro> getParametros() {
		return parametros;
	}

	public void setParametros(List<AgendamentoParametro> parametros) {
		this.parametros = parametros;
	}

	public List<AgendamentoDocumento> getDocumentos() {
		return documentos;
	}

	public void setDocumentos(List<AgendamentoDocumento> documentos) {
		this.documentos = documentos;
	}
	
	public List<AgendamentoListDocumentos> getListDoc() {
		return listDoc;
	}

	public void setListDoc(List<AgendamentoListDocumentos> listDoc) {
		this.listDoc = listDoc;
	}

	public List<AgendamentoEnvio> getEnvios() {
		return envios;
	}

	public void setEnvios(List<AgendamentoEnvio> envios) {
		this.envios = envios;
	}
	
	public List<AgendamentoAnexo> getAnexos() {
		return anexos;
	}

	public void setAnexos(List<AgendamentoAnexo> anexos) {
		this.anexos = anexos;
	}
	
	public String getCodCorretor() {
		return codCorretor;
	}

	public void setCodCorretor(String codCorretor) {
		this.codCorretor = codCorretor;
	}
	
	public String getCorretorCpfCnpj() {
		return corretorCpfCnpj;
	}

	public void setCorretorCpfCnpj(String corretorCpfCnpj) {
		this.corretorCpfCnpj = corretorCpfCnpj;
	}
	
	public String getEmailRemetente() {
		return emailRemetente;
	}

	public void setEmailRemetente(String emailRemetente) {
		this.emailRemetente = emailRemetente;
	}
	
	public List<AgendamentoComCopia> getComCopias() {
		return comCopias;
	}

	public void setComCopias(List<AgendamentoComCopia> comCopias) {
		this.comCopias = comCopias;
	}

	public void addParametro(AgendamentoParametro param){
		if (this.getParametros() == null){
			this.setParametros(new ArrayList<AgendamentoParametro>());
		}
		for (AgendamentoParametro p : this.getParametros()){
			if (p.getParametro().equals(param.getParametro())){
				p.setValorParametro(param.getValorParametro());
				return;
			}
		}
		this.getParametros().add(param);
	}

	public void addDocumento(AgendamentoDocumento doc){
		if (this.getDocumentos() == null){
			this.setDocumentos(new ArrayList<AgendamentoDocumento>());
		}
		for (AgendamentoDocumento d : this.getDocumentos()){
			if (d.getDocumento().equals(doc.getDocumento())){
				if (!StringUtil.isNull(doc.getIndEnviaEmail())){
					d.setIndEnviaEmail(doc.getIndEnviaEmail());
				}
				d.setUrlArquivo(doc.getUrlArquivo());
				d.setDtAtualizacao(new Date());
				return;
			}
		}
		this.getDocumentos().add(doc);
	}
	
	public void addListDoc(AgendamentoListDocumentos listDoc){
		if (this.getListDoc() == null){
			this.setListDoc(new ArrayList<AgendamentoListDocumentos>());
		}
		
		if (listDoc.getSeqListaDocumentos() != null) {
			for (AgendamentoListDocumentos agendamentoListDocumentos : this.getListDoc()){
				if (agendamentoListDocumentos.getSeqListaDocumentos().equals(listDoc.getSeqListaDocumentos())){
					if (!StringUtil.isNull(listDoc.getIndEnviaEmail())){
						agendamentoListDocumentos.setIndEnviaEmail(listDoc.getIndEnviaEmail());
					}
					agendamentoListDocumentos.setUrlArquivo(listDoc.getUrlArquivo());
					agendamentoListDocumentos.setDtAtualizacao(new Date());
					return;
				}
			}
		}
		this.getListDoc().add(listDoc);
	}
	
	public void  addComCopia (AgendamentoComCopia comCopia) {
		if (this.getComCopias() == null) {
			this.setComCopias(new ArrayList<AgendamentoComCopia>());
		}
		
		for (AgendamentoComCopia agendamentoComCopia : this.getComCopias() ) {
			if (agendamentoComCopia.getSeqCopia().equals(comCopia.getSeqCopia())) {
				agendamentoComCopia.setDestinatario(comCopia.getDestinatario());
				return;
			}
		}
		this.getComCopias().add(comCopia);
	}
	

	public void addDestinatario(AgendamentoDestinatario dest){
		if (this.getDestinatarios() == null){
			this.setDestinatarios(new ArrayList<AgendamentoDestinatario>());
		}
		for (AgendamentoDestinatario e : this.getDestinatarios()){
			if (e.getSeqDestinatario().equals(dest.getSeqDestinatario())){
				e.setDestinatario(dest.getDestinatario());
				return;
			}
		}
		this.getDestinatarios().add(dest);
	}

	public int getQuantidadeEnvios(){
		int envios = 0;
		for (AgendamentoEnvio envio : this.getEnvios()){
			if (envio.getStatusEnvio().equals(StatusAgendamento.enviado.getValue())) envios++;
		}
		return envios;
	}

	public String getTituloComunicacao(){
		for (AgendamentoEnvio envio : this.getEnvios()){
			if (!StringUtil.isNull(envio.getTitulo())){
				return envio.getTitulo();
			}
		}
		if (!StringUtil.isNull(this.getModelo().getTituloModelo())){
			return this.getModelo().getTituloModelo();
		}
		return this.getModelo().getNomeModelo();
	}

	public String getValorParametro(String nomeParam){
		if (this.getParametros() != null && this.getParametros().size() > 0 ) {
			for (AgendamentoParametro p : this.getParametros()){
				if (p.getParametro().getNomeParametro().equals(nomeParam)){
					return p.getValorParametro();
				}
			}
		}
		return null;
	}

	@Transient
	public StatusAgendamento getStatus(){
		return StatusAgendamento.get(this.statusAgendamento);
	}

	@Transient
	@SuppressWarnings("unchecked")
	public Map<String, String> getMensagens(){
		Map<String, String> mapMsg = null;
		try {
			if (!StringUtil.isNull(this.getMensagemEnviada())){
				mapMsg = (Map<String, String>) StringUtil.deserialize(this.getMensagemEnviada());
			}
		} catch (Exception e) {}
		return mapMsg;
	}

	@Transient
	public String formataDestinatarios(){
		String destString = "";
		for (AgendamentoDestinatario dest : this.getDestinatarios()){
			destString = destString + dest.getDestinatario() + ";";
		}
		return destString;
	}

	@Transient
	public List<AgendamentoDestinatario> getDestinatariosValidos() {
		List<AgendamentoDestinatario> lista = new ArrayList<AgendamentoDestinatario>();
		if (getDestinatarios() != null){
			for (AgendamentoDestinatario dest : getDestinatarios()){
				if (dest.getIndValido().equals("S")) 
					lista.add(dest);
			}
		}
		return lista;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((seqAgendamento == null) ? 0 : seqAgendamento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgendamentoComunicacao other = (AgendamentoComunicacao) obj;
		if (seqAgendamento == null) {
			if (other.seqAgendamento != null)
				return false;
		} else if (!seqAgendamento.equals(other.seqAgendamento))
			return false;
		return true;
	}

	public TipoModelo getModeloCanalComunicacao() {
		return this.modelo.getCanalComunicacao();
	}

}