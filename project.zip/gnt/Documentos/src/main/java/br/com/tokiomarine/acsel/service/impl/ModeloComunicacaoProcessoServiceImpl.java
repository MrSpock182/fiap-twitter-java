package br.com.tokiomarine.acsel.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoProcesso;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoProcessoService;
import br.com.tokiomarine.acsel.service.ParametrosService;

@Stateless(name="ModeloComunicacaoProcessoService")
@Local(value=ModeloComunicacaoProcessoService.class)
public class ModeloComunicacaoProcessoServiceImpl implements ModeloComunicacaoProcessoService {

	@Inject
	ParametrosService paramsService;
	
	@Override
	public Collection<ModeloComunicacaoProcesso> findAll() {
		Collection<ModeloComunicacaoProcesso> list = new ArrayList<>();
		List<Lval> obtemListaValores = this.paramsService.obtemListaValores("GNT_PROC");
		for (Lval lval : obtemListaValores) {
			list.add(ModeloComunicacaoProcesso.builder().codigo(lval.getCodLval()).descricao(lval.getDescrip()).build());
		}
		return list;
	}

}
