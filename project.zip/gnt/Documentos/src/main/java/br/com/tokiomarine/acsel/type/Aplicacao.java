package br.com.tokiomarine.acsel.type;

/**
 * Informacoes gerais do sistema
 *
 * @author Fernando Boaglio
 */
public enum Aplicacao {

	encodingPadrao("UTF-8"),
	variavelAmbiente("tokiomarine.infra.AMBIENTE"),
	cdnPublico("tokiomarine.infra.CDN_PUBLICO"),
	cdnRestrito("tokiomarine.infra.CDN_RESTRITO"),
	cdnVersao("3.3.4");

	Aplicacao(String value) {
		this.value = value;
	}

	Aplicacao(Integer number) {
		this.number = number;
	}

	private String value;
	private Integer number;

	public String value() {
		return value;
	}

	public Integer number() {
		return number;
	}
}
