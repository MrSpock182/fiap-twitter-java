package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.cache;

import javax.ejb.Local;
import javax.ejb.Stateless;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;

import br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.BlackListResource;

@Stateless(name = "BlackWhiteListCacheClient")
@Local(value = BlackWhiteListCacheClient.class)
public class BlackWhiteListCacheClient implements BlackWhiteListCacheService {
	
	private IMap<String, Integer> imapEmails;
	private String hzEnv = System.getProperty("HAZELCAST_URL");
	private String hzName = System.getProperty("HAZELCAST_NAME");
	private String hzPassword = System.getProperty("HAZELCAST_PASSWORD");
	
	
	@Override
	public BlackListResource getBlackList(String destino) throws HazelcastURLException {
		if(hzEnv == null) {
			throw new HazelcastURLException("URL Hazelcast encontra-se null");  
		} 
		imapEmails = this.iMapEmailsSingleton();
		Integer blackWhite = imapEmails.get(destino);
		BlackListResource blackListResource = BlackListResource.builder().email(destino).blackList(blackWhite).build();
		return blackListResource;
	}	
	
	private HazelcastInstance hazelcastInstance() {
		String[] hzAddress = hzEnv.split(";");
		ClientConfig clientConfig = new ClientConfig();
		clientConfig.getGroupConfig().setName(hzName).setPassword(hzPassword);
		for (String address : hzAddress) {
			clientConfig.getNetworkConfig().addAddress(address);
		}
		return HazelcastClient.newHazelcastClient(clientConfig);		
	}
	
	private IMap<String, Integer> iMapEmailsSingleton() {
		if(this.imapEmails == null) 
			this.imapEmails = this.hazelcastInstance().getMap("emails");
		return this.imapEmails;
	}
	
}
