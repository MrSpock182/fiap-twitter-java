package br.com.tokiomarine.acsel.dto;

import java.util.Date;
import java.util.List;

import br.com.tokiomarine.acsel.type.TipoDestino;

public class SolicSegundaViaDTO {

	private String tipoDestino;
	private Long numEndereco;
	private String motivo;
	private Integer opcao;
	private String local;
	private String colaborador;
	private String andarLocalTrabalho;
	private Date dataSolic;
	private DocumentoDTO documento;
	private Boolean indEnvioAR = false;
	private UsuarioDTO usuarioSolic;
	private List<String> listaItens;
	private List<String> listaDocumentos;

	public TipoDestino getTipoDestino() {
		return TipoDestino.get(tipoDestino);
	}
	public void setTipoDestino(String tipoDestino) {
		this.tipoDestino = tipoDestino;
	}
	public Long getNumEndereco() {
		return numEndereco;
	}
	public void setNumEndereco(Long numEndereco) {
		this.numEndereco = numEndereco;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	public Integer getOpcao() {
		return opcao;
	}
	public void setOpcao(Integer opcao) {
		this.opcao = opcao;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getColaborador() {
		return colaborador;
	}
	public void setColaborador(String colaborador) {
		this.colaborador = colaborador;
	}
	public String getAndarLocalTrabalho() {
		return andarLocalTrabalho;
	}
	public void setAndarLocalTrabalho(String andarLocalTrabalho) {
		this.andarLocalTrabalho = andarLocalTrabalho;
	}
	public Date getDataSolic() {
		return dataSolic;
	}
	public void setDataSolic(Date dataSolic) {
		this.dataSolic = dataSolic;
	}
	public DocumentoDTO getDocumento() {
		return documento;
	}
	public void setDocumento(DocumentoDTO documento) {
		this.documento = documento;
	}
	public Boolean getIndEnvioAR() {
		return indEnvioAR;
	}
	public void setIndEnvioAR(Boolean indEnvioAR) {
		this.indEnvioAR = indEnvioAR;
	}
	public UsuarioDTO getUsuarioSolic() {
		return usuarioSolic;
	}
	public void setUsuarioSolic(UsuarioDTO usuarioSolic) {
		this.usuarioSolic = usuarioSolic;
	}
	public List<String> getListaItens() {
		return listaItens;
	}
	public void setListaItens(List<String> listaItens) {
		this.listaItens = listaItens;
	}
	public List<String> getListaDocumentos() {
		return listaDocumentos;
	}
	public void setListaDocumentos(List<String> listaDocumentos) {
		this.listaDocumentos = listaDocumentos;
	}
}
