package br.com.tokiomarine.acsel.service;

import java.util.List;

import br.com.tokiomarine.acsel.domain.acx.DocumentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ImagemComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.PadraoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.TextoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.ParametroComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.UsuarioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface ModeloComunicacaoService {

	List<ModeloComunicacao> obtemModelos() throws ServiceException;

	List<PadraoComunicacao> obtemPadroes() throws ServiceException;

	ModeloComunicacao obtemModelo(Long id) throws ServiceException;
	
	ModeloComunicacao obtemModelo(String codigo) throws ServiceException;
	
	ModeloComunicacaoDTO obtemModeloComunicacaoDTO(ModeloComunicacao modelo) throws ServiceException;

	List<DocumentoComunicacao> obtemDocumentos() throws ServiceException;

	List<TextoComunicacao> obtemTextos(String tipoModelo) throws ServiceException;

	List<ImagemComunicacao> obtemImagens() throws ServiceException;

	List<ParametroComunicacao> obtemParametrosDisponiveis(Long idModelo) throws ServiceException;

	List<ParametroComunicacaoDTO> obtemParametrosConsulta(ModeloComunicacao modelo) throws ServiceException;

	ParametroComunicacao obtemParametroComunicacao(Long id) throws ServiceException;

	TextoComunicacao obtemTextoComunicacao(Long id) throws ServiceException;

	DocumentoComunicacao obtemDocumento(Long docId);

	void removeTexto(Long id, UsuarioDTO usuario) throws ServiceException;

	void removeParametro(Long id) throws ServiceException;

	void incluiTextoComunicacao(ModeloComunicacao modelo, TextoComunicacao texto, UsuarioDTO usuario) throws ServiceException;

	void incluiParametroComunicacao(ModeloComunicacao modelo, ParametroComunicacao param, UsuarioDTO usuario) throws ServiceException;
	
	void incluiNovoParametroComunicacao(ParametroComunicacao param, UsuarioDTO usuario) throws ServiceException;

	ModeloComunicacao atualizaModelo(ModeloComunicacao mod) throws ServiceException;

	ModeloComunicacao incluiModelo(ModeloComunicacao mod) throws ServiceException;

	void atualizaTextos(List<TextoModeloComunicacao> textos, UsuarioDTO usuario) throws ServiceException;

	void atualizaParametros(List<ParametroModelo> parametros, UsuarioDTO usuario) throws ServiceException;

	String obtemEmailFormatado(Integer id) throws ServiceException;
	
	String obtemEmailFormatado(Integer id, String datAlteracao) throws ServiceException;	
	
	List<TextoModeloComunicacao> obtemDataHistorico(Integer id) throws ServiceException;
	
	String proximoCodigo(String prefixo);
	
	List<ModeloComunicacao> obtemModelosInativos(String perfil, String codUsuario) throws ServiceException;
	
	void aprovarModelo(ModeloComunicacao mod) throws ServiceException;
	
	List<String> listaAcoes(String perfil) throws ServiceException;
	
	void removeModelo(Long codModelo, UsuarioDTO usuario) throws ServiceException;
	
	void enviarEmailModelo(String destinatario, String codigo, String template) throws ServiceException;
}