
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retConsultaDadoFuncionarioWS complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retConsultaDadoFuncionarioWS">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="funcionario" type="{http://ws.col.tokiomarine.com.br/}retDadoFuncionario" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retConsultaDadoFuncionarioWS", propOrder = {
    "funcionario"
})
public class RetConsultaDadoFuncionarioWS {

    protected RetDadoFuncionario funcionario;

    /**
     * Obt�m o valor da propriedade funcionario.
     *
     * @return
     *     possible object is
     *     {@link RetDadoFuncionario }
     *
     */
    public RetDadoFuncionario getFuncionario() {
        return funcionario;
    }

    /**
     * Define o valor da propriedade funcionario.
     *
     * @param value
     *     allowed object is
     *     {@link RetDadoFuncionario }
     *
     */
    public void setFuncionario(RetDadoFuncionario value) {
        this.funcionario = value;
    }

}
