package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.springframework.web.client.RestTemplate;

@Stateless(name = "BlackWhiteListRestServiceClientImpl")
@Local(value = BlackWhiteListRestServiceClientImpl.class)
class BlackWhiteListRestServiceClientImpl implements BlackWhiteListRestServiceClient {

	@Inject 
	private HostBlackWhiteList hostBlackWhiteList;
	
	@Override
	public BlackListResource getBlackList(String destino) {
		String url = this.getFullURL(String.format("/arquitetura/SmtpProxyServer/v1/email-black-white-list/%s", destino));
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.getForObject(url, BlackListResource.class);
	}
	
	private String getFullURL(String path) {
		 return this.hostBlackWhiteList.getEnv()+path;
	}

}