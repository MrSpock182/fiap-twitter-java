package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.cache.BlackWhiteListCacheClient;
import br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.cache.HazelcastURLException;

@Stateless(name = "BlackWhiteListServiceImpl")
@Local(value = BlackWhiteListServiceImpl.class)
public class BlackWhiteListServiceImpl implements BlackWhiteListService {

	private static Logger logger = LogManager.getLogger(BlackWhiteListServiceImpl.class);
	
	@Inject
	private BlackWhiteListCacheClient blackWhiteListCacheClient; 

	@Inject
	private BlackWhiteListRestServiceClient blackWhiteListRestServiceClient; 	
	
	@Override
	public BlackListResource getBlackList(String destino) {
		try {
			BlackListResource blackList = blackWhiteListCacheClient.getBlackList(destino);
			if(blackList.getBlackList() != null) 
				return blackList;
		} catch (HazelcastURLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return blackWhiteListRestServiceClient.getBlackList(destino);
	}

}
