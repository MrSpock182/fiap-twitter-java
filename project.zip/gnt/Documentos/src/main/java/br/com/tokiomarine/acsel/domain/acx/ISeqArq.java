package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import br.com.tokiomarine.acsel.util.StringUtil;

@Entity
@Table(name = "I_SEQ_ARQ")
public class ISeqArq implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SEQARQ") private String seqArq;
	@Column(name="DTPROC")	private Date dtProc;
	@Column(name="CODITEM")	private String codItem;
	@Column(name="ORIARQ")	private Long oriArq;
	@Column(name="DTEXTRAC")	private Date dtExtrac;
	@Column(name="DTENVIO")	private Date dtEnvio;
	@Column(name="QTDREG")	private Long qtdReg;
	@Column(name="QTDSUCESSO")	private Long qtdSucesso;
	@Column(name="STATUS")	private String status;
	@Column(name="NOMTABELA")	private String nomTabela;
	@Column(name="AUDSID")	private Long audSid;
	@Column(name="QTDPROCESSADO")	private Long qtdProcessado;
	@Column(name="QTDNPROCESSADO")	private Long qtdNProcessado;

	public String getSeqArq() {
		return StringUtil.lpad(seqArq, "0", 7);
	}
	public void setSeqArq(String seqArq) {
		this.seqArq = seqArq;
	}
	public Date getDtProc() {
		return dtProc;
	}
	public void setDtProc(Date dtProc) {
		this.dtProc = dtProc;
	}
	public String getCodItem() {
		return StringUtil.lpad(codItem, "0", 2);
	}
	public void setCodItem(String codItem) {
		this.codItem = codItem;
	}
	public Long getOriArq() {
		return oriArq;
	}
	public void setOriArq(Long oriArq) {
		this.oriArq = oriArq;
	}
	public Date getDtExtrac() {
		return dtExtrac;
	}
	public void setDtExtrac(Date dtExtrac) {
		this.dtExtrac = dtExtrac;
	}
	public Date getDtEnvio() {
		return dtEnvio;
	}
	public void setDtEnvio(Date dtEnvio) {
		this.dtEnvio = dtEnvio;
	}
	public Long getQtdReg() {
		return qtdReg;
	}
	public void setQtdReg(Long qtdReg) {
		this.qtdReg = qtdReg;
	}
	public Long getQtdSucesso() {
		return qtdSucesso;
	}
	public void setQtdSucesso(Long qtdSucesso) {
		this.qtdSucesso = qtdSucesso;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNomTabela() {
		return nomTabela;
	}
	public void setNomTabela(String nomTabela) {
		this.nomTabela = nomTabela;
	}
	public Long getAudSid() {
		return audSid;
	}
	public void setAudSid(Long audSid) {
		this.audSid = audSid;
	}
	public Long getQtdProcessado() {
		return qtdProcessado;
	}
	public void setQtdProcessado(Long qtdProcessado) {
		this.qtdProcessado = qtdProcessado;
	}
	public Long getQtdNProcessado() {
		return qtdNProcessado;
	}
	public void setQtdNProcessado(Long qtdNProcessado) {
		this.qtdNProcessado = qtdNProcessado;
	}




}