package br.com.tokiomarine.acsel.comunicador.mail;

import javax.ejb.Stateless;

import br.com.tokiomarine.acsel.util.AmbienteTemplate;

@Stateless(name = "ProxyMail")
public class ProxyMail extends AmbienteTemplate {
	
	private static final String PROXY_ACEITE = "proxymail-aceite.tokiomarine.com.br";
	private static final String PROXY_DEV = "proxymail-dev.tokiomarine.com.br";
	private static final String PROXY_PRODUCAO = "proxymail.tokiomarine.com.br";

	@Override
	protected String getProducao() {
		return PROXY_PRODUCAO;
	}

	@Override
	protected String getAceite() {
		return PROXY_ACEITE;
	}

	@Override
	protected String getDev() {
		return PROXY_DEV;
	}
	
}
