package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@IdClass(AgendamentoDocumentoPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_DOC")
public class AgendamentoDocumento {

	@Id
	@ManyToOne
	@JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
	private AgendamentoComunicacao agendamento;

	@Id
	@ManyToOne
	@JoinColumn(name="CD_DOCUMENTO", referencedColumnName="CD_DOCUMENTO")
	private DocumentoComunicacao documento;

	@Column(name="DS_URL_ARQUIVO")
	private String urlArquivo;

	@Column(name="ID_ENVIA_EMAIL")
	private String indEnviaEmail;

	@Column(name="DT_ATUALIZACAO")
	private Date dtAtualizacao;

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}

	public DocumentoComunicacao getDocumento() {
		return documento;
	}

	public void setDocumento(DocumentoComunicacao documento) {
		this.documento = documento;
	}

	public String getUrlArquivo() {
		return urlArquivo;
	}

	public void setUrlArquivo(String urlArquivo) {
		this.urlArquivo = urlArquivo;
	}

	public String getIndEnviaEmail() {
		return indEnviaEmail;
	}

	public void setIndEnviaEmail(String indEnviaEmail) {
		this.indEnviaEmail = indEnviaEmail;
	}

	public Date getDtAtualizacao() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}


}