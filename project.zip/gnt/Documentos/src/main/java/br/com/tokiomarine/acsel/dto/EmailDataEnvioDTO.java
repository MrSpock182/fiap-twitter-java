package br.com.tokiomarine.acsel.dto;

import java.util.Date;
import java.util.List;

public class EmailDataEnvioDTO {
	
	private List<String> emailsDestinatarios;
	private Date dataEnvio;
	
	public List<String> getEmailsDestinatarios() {
		return emailsDestinatarios;
	}
	public void setEmailsDestinatarios(List<String> emailsDestinatarios) {
		this.emailsDestinatarios = emailsDestinatarios;
	}
	public Date getDataEnvio() {
		return dataEnvio;
	}
	public void setDataEnvio(Date dataEnvio) {
		this.dataEnvio = dataEnvio;
	}
	
}
