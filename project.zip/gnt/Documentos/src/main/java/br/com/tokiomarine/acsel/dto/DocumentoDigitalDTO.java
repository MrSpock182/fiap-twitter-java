package br.com.tokiomarine.acsel.dto;

import java.util.Date;

public class DocumentoDigitalDTO {
	
	private Date dataEnvio;
	private Long codDocumento;
	private String descDocumento;
	private String dsUrlArquivo;
	private String dsUrlDocstore;
	
	public Date getDataEnvio() {
		return dataEnvio;
	}
	public void setDataEnvio(Date dataEnvio) {
		this.dataEnvio = dataEnvio;
	}
	public Long getCodDocumento() {
		return codDocumento;
	}
	public void setCodDocumento(Long codDocumento) {
		this.codDocumento = codDocumento;
	}
	public String getDescDocumento() {
		return descDocumento;
	}
	public void setDescDocumento(String descDocumento) {
		this.descDocumento = descDocumento;
	}
	public String getDsUrlArquivo() {
		return dsUrlArquivo;
	}
	public void setDsUrlArquivo(String dsUrlArquivo) {
		this.dsUrlArquivo = dsUrlArquivo;
	}
	public String getDsUrlDocstore() {
		return dsUrlDocstore;
	}
	public void setDsUrlDocstore(String dsUrlDocstore) {
		this.dsUrlDocstore = dsUrlDocstore;
	}
	
}
