package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TEXTO_COMUNICACAO")
public class TextoComunicacao {

	@Id
	@Column(name="CD_TEXTO")
	private Long codTexto;

	@Column(name="NM_TEXTO")
	private String nomeTexto;

	@Column(name="CD_TIPO_MODELO")
	private String tipoModelo;

	@Column(name="DS_TEXTO")
	private String descTexto;

	@Column(name="TIP_TEXTO")
	private String tipoTexto;

	@Column(name="DS_FORMATACAO_TEXTO")
	private String formatacao;


	public Long getCodTexto() {
		return codTexto;
	}

	public void setCodTexto(Long codTexto) {
		this.codTexto = codTexto;
	}

	public String getNomeTexto() {
		return nomeTexto;
	}

	public void setNomeTexto(String nomeTexto) {
		this.nomeTexto = nomeTexto;
	}

	public String getTipoModelo() {
		return tipoModelo;
	}

	public void setTipoModelo(String tipoModelo) {
		this.tipoModelo = tipoModelo;
	}

	public String getDescTexto() {
		return descTexto;
	}

	public void setDescTexto(String descTexto) {
		this.descTexto = descTexto;
	}

	public String getTipoTexto() {
		return tipoTexto;
	}

	public void setTipoTexto(String tipoTexto) {
		this.tipoTexto = tipoTexto;
	}

	public String getFormatacao() {
		return formatacao;
	}

	public void setFormatacao(String formatacao) {
		this.formatacao = formatacao;
	}
}