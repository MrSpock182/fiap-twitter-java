package br.com.tokiomarine.acsel.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.acsel.builders.AgendamentoComunicacaoBuilder;
import br.com.tokiomarine.acsel.builders.AgendamentoDestinatarioBuilder;
import br.com.tokiomarine.acsel.comunicador.sms.GNTSms;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoAnexo;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComCopia;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDocumento;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoListDocumentos;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoParametro;
import br.com.tokiomarine.acsel.domain.acx.DocumentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroComunicacao;
import br.com.tokiomarine.acsel.dto.AgendamentoComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.AnexoEmail;
import br.com.tokiomarine.acsel.dto.BuscaAgendamentoDTO;
import br.com.tokiomarine.acsel.dto.ComCopiaDTO;
import br.com.tokiomarine.acsel.dto.DocumentoComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.EmailDataEnvioDTO;
import br.com.tokiomarine.acsel.dto.ListDocComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.ParametroComunicacaoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.AgendamentoComunicacaoRepository;
import br.com.tokiomarine.acsel.repository.ModeloComunicacaoRepository;
import br.com.tokiomarine.acsel.service.AgendamentoComunicacaoService;
import br.com.tokiomarine.acsel.service.EnvioComunicacaoService;
import br.com.tokiomarine.acsel.service.ValidaAgendamentoService;
import br.com.tokiomarine.acsel.type.StatusAgendamento;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "AgendamentoComunicacaoService")
@Local(value = AgendamentoComunicacaoService.class)
public class AgendamentoComunicacaoServiceImpl implements AgendamentoComunicacaoService {

	@Inject
	ValidaAgendamentoService validaAgendamento;

	@Inject
	ModeloComunicacaoRepository modeloDao;

	@Inject
	AgendamentoComunicacaoRepository agendamentoDao;
	
	@Inject
	GNTSms gntSms;

	@EJB
	EnvioComunicacaoService envioService;

	@Override
	public List<AgendamentoComunicacao> buscaAgendamentos(BuscaAgendamentoDTO busca) throws ServiceException {
		return agendamentoDao.buscaAgendamentos(busca);
	}

	@Override
	public AgendamentoComunicacao obtemAgendamento(Long id) {
		return agendamentoDao.obtemAgendamento(id);
	}

	@Override
	public AgendamentoComunicacao obtemAgendamentoCompleto(Long id) {
		AgendamentoComunicacao agend = agendamentoDao.obtemAgendamento(id);
		if (agend == null) return null;
		
		Hibernate.initialize(agend.getDocumentos());
		Hibernate.initialize(agend.getDestinatarios());
		Hibernate.initialize(agend.getEnvios());
		Hibernate.initialize(agend.getParametros());
		Hibernate.initialize(agend.getAnexos());
		return agend;
	}

	@Override
	public List<AgendamentoErro> obtemErros(Long id) {
		return agendamentoDao.obtemErros(id);
	}

	private boolean validaAgendamento(AgendamentoComunicacaoDTO agendamento) throws ServiceException {
		if (agendamento.getCodigoModelo() == null && agendamento.getCodigo() == null) {
			throw new ServiceException("Código do modelo não informado");
		}

		if (agendamento.getDestinatarios() != null && agendamento.getDestinatariosDetalhes() != null) {
			throw new ServiceException(
					"Utilizado os dois atributos (destinatario e destinatarioDetalhes). Por favor utilize somente destinatarioDetalhes!");
		}

		if (agendamento.getCodigoModelo() != null && agendamento.getCodigo() != null) {
			throw new ServiceException(
					"Utilizado os dois atributos (codigoModelo e codigo). Por favor utilize somente codigo!");
		}

		// Caso não tenha todos os parametros envia uma exception.
		envioService.validaAgendamentoDTO(agendamento);

		return true;
	}

	private ModeloComunicacao findModeloByCodigoModelo(Long codigoModelo) throws ServiceException {
		ModeloComunicacao modelo = modeloDao.obtemModelo(codigoModelo);
		if (modelo == null) {
			throw new ServiceException(String.format("Modelo (%s) não encontrado", codigoModelo));
		}
		if (modelo.getSituacaoModelo().equals("N")) {
			throw new ServiceException("Modelo inativo");
		}
		return modelo;
	}

	private ModeloComunicacao findModeloByCodigo(String codigo) throws ServiceException {
		ModeloComunicacao modelo = modeloDao.obtemModelo(codigo);

		if (modelo == null) {
			throw new ServiceException(String.format("Modelo (%s) não encontrado", codigo));
		}

		if (modelo.getSituacaoModelo().equals("N")) {
			throw new ServiceException("Modelo inativo");
		}

		return modelo;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public AgendamentoComunicacao incluiAgendamento(AgendamentoComunicacaoDTO agendamentoDTO) throws ServiceException {

		this.validaAgendamento(agendamentoDTO);
		ModeloComunicacao modelo = null;
		
		if (agendamentoDTO.getCodigo() != null) {
			modelo = this.findModeloByCodigo(agendamentoDTO.getCodigo());
		} else if (agendamentoDTO.getCodigoModelo() != null) {
			modelo = this.findModeloByCodigoModelo(agendamentoDTO.getCodigoModelo());
		}

		AgendamentoComunicacao agendamento = AgendamentoComunicacaoBuilder.builder().modelo(modelo)
				.dtAgendamento(new Date()).indEnviaComunicacao(agendamentoDTO.getIndEnviaComunicacao())
				.statusAgendamentoComunicacao(agendamentoDTO.getIndEnviaComunicacao())
				.tipoEnvio(agendamentoDTO.getTipoEnvio()).rastreiaEnvio(agendamentoDTO.getRastreiaEnvio())
				.emailRemetente(agendamentoDTO.getEmailRemetente())
				.build();

		agendamento.setIndEnviaComunicacao(agendamento.getIndEnviaComunicacao());
		agendamento.setCodCorretor(agendamentoDTO.getCodCorretor());

		if(modelo.getTipoModelo().equalsIgnoreCase("SMS")) {
			//VERIFICA SE O TAMANHO DO SMS É MAIOR QUE 150
			incluiParametros(agendamento, agendamentoDTO.getParametros());
			gntSms.verificarMensagem(agendamento);
		}
		
		agendamentoDao.incluiAgendamento(agendamento);

		agendamento.setDestinatarios(this.getAgendamentoDestinatarios(agendamento, agendamentoDTO));

		if (agendamentoDTO.getParametros() != null)
			incluiParametros(agendamento, agendamentoDTO.getParametros());

		if (agendamentoDTO.getDocumentos() != null)
			incluiDocumentos(agendamento, agendamentoDTO.getDocumentos());

		if (agendamentoDTO.getAnexos() != null) {
			agendamento.setAnexos(this.getListaAgendamentoAnexo(agendamento, agendamentoDTO.getAnexos()));
		}
		
		if (agendamentoDTO.getListDoc() != null) {
			incluiListDoc(agendamento, agendamentoDTO.getListDoc());
		}
		
		if (agendamentoDTO.getComCopias() != null) {
			incluiComCopia(agendamento, agendamentoDTO.getComCopias());
		}

		agendamentoDao.atualizaAgendamento(agendamento);

		return agendamento;
	}

	private List<AgendamentoAnexo> getListaAgendamentoAnexo(AgendamentoComunicacao agendamento,
			List<AnexoEmail> anexos) {
		List<AgendamentoAnexo> anexosDomain = new ArrayList<>();
		for (AnexoEmail anexoEmail : anexos) {
			AgendamentoAnexo anexo = AgendamentoAnexo.builder().agendamento(agendamento)
					.arquivoBase64(anexoEmail.getFileBase64()).nome(anexoEmail.getNome())
					.id(anexos.indexOf(anexoEmail) + 1L).build();
			anexosDomain.add(anexo);
		}
		return anexosDomain;
	}

	private List<AgendamentoDestinatario> getAgendamentoDestinatarios(AgendamentoComunicacao agendamento,
			AgendamentoComunicacaoDTO agendamentoDTO) throws ServiceException {
		List<AgendamentoDestinatario> destinatarios = new ArrayList<>();

		// pega da lista de destino somente de email
		if (agendamentoDTO.getDestinatarios() != null) {
			for (int i = 0; i <= agendamentoDTO.getDestinatarios().size() - 1; i++) {
				if (StringUtil.isNull(agendamentoDTO.getDestinatarios().get(i)))
					continue;
				AgendamentoDestinatario agendDest = new AgendamentoDestinatario();
				agendDest.setAgendamento(agendamento);
				agendDest.setSeqDestinatario(i + 1);
				agendDest.setDestinatario(agendamentoDTO.getDestinatarios().get(i));
				agendDest.setIndValido("N");
				destinatarios.add(agendDest);
			}
			return destinatarios;
		}

		// pega da lista de Destinos detalhadas (DestinatarioDetalhe) com email, cpfCnpj
		// e outros ....
		if (agendamentoDTO.getDestinatariosDetalhes() != null) {
			AgendamentoDestinatarioBuilder builder = AgendamentoDestinatarioBuilder.builder();
			// for (Destinatario dest : agendamentoDTO.getDestinatariosDetalhes()) {
			for (int i = 0; i <= agendamentoDTO.getDestinatariosDetalhes().size() - 1; i++) {
				AgendamentoDestinatario destinatario = builder.agendamento(agendamento).seqDestinatario(i + 1)
						.destino(agendamentoDTO.getDestinatariosDetalhes().get(i).getDestino())
						.cpfCnpj(agendamentoDTO.getDestinatariosDetalhes().get(i).getCpfCnpj()).indValido("N").build();
				destinatarios.add(destinatario);
			}
			return destinatarios;
		}
		throw new ServiceException("Nenhum modelo de destinatario foi encontrado!!!");
	}

	@Override
	public void atualizaAgendamento(AgendamentoComunicacaoDTO agendamentoDTO) throws ServiceException {
		if (agendamentoDTO.getSeqAgendamento() == null) {
			throw new ServiceException("O código do agendamento deve ser informado");
		}

		AgendamentoComunicacao agendamento = obtemAgendamento(agendamentoDTO.getSeqAgendamento());

		if (agendamento == null) {
			throw new ServiceException("Agendamento não encontrado");
		}

		if (StringUtil.in(agendamento.getStatusAgendamento(), StatusAgendamento.enviado.getValue())) {
			throw new ServiceException("Status do agendamento não permite alterações");
		}

		if (StringUtil.in(agendamentoDTO.getIndEnviaComunicacao(), "S", "N"))
			agendamento.setIndEnviaComunicacao(agendamentoDTO.getIndEnviaComunicacao());

		if (agendamentoDTO.getDestinatarios() != null) {
			incluiDestinatarios(agendamento, agendamentoDTO.getDestinatarios());
		}

		if (agendamentoDTO.getDocumentos() != null) {
			incluiDocumentos(agendamento, agendamentoDTO.getDocumentos());
		}

		if (agendamentoDTO.getParametros() != null) {
			incluiParametros(agendamento, agendamentoDTO.getParametros());
		}

		agendamento.setRastreiaEnvio(agendamentoDTO.getRastreiaEnvio());

		agendamentoDao.atualizaAgendamento(agendamento);
	}

	@Override
	public void atualizaAgendamento(AgendamentoComunicacao agendamentoComunicacao) {
		agendamentoDao.atualizaAgendamento(agendamentoComunicacao);
	}

	private void incluiDestinatarios(AgendamentoComunicacao agendamento, List<String> destinatarios)
			throws ServiceException {
		int i = 0;
		for (String dest : destinatarios) {

			if (!StringUtil.isNull(dest)) {
				AgendamentoDestinatario agendDest = new AgendamentoDestinatario();
				agendDest.setAgendamento(agendamento);
				agendDest.setSeqDestinatario(++i);
				agendDest.setDestinatario(dest);
				agendDest.setIndValido("N");
				agendamento.addDestinatario(agendDest);
			}
		}
	}

	private void incluiParametros(AgendamentoComunicacao agendamento, List<ParametroComunicacaoDTO> parametros)
			throws ServiceException {
		
		if (parametros != null && parametros.size() > 0) {
			for (ParametroComunicacaoDTO parametro : parametros) {

				ParametroComunicacao param = modeloDao.obtemParametroNome(parametro.getNomeParametro());
				if (param == null) {
					throw new ServiceException("Parâmetro " + parametro.getNomeParametro() + " não encontrado");
				}

				AgendamentoParametro paramAgend = new AgendamentoParametro();

				paramAgend.setAgendamento(agendamento);
				paramAgend.setParametro(param);
				paramAgend.setValorParametro(parametro.getValorParametro());

				agendamento.addParametro(paramAgend);
			}
		}
	}

	private void incluiDocumentos(AgendamentoComunicacao agendamento, List<DocumentoComunicacaoDTO> documentos)
			throws ServiceException {
		
		for (DocumentoComunicacaoDTO documento : documentos) {

			DocumentoComunicacao doc = modeloDao.obtemDocumento(documento.getCodDocumento());
			if (doc == null) {
				throw new ServiceException("Documento " + documento.getCodDocumento() + " não encontrado");
			}

			AgendamentoDocumento docAgend = new AgendamentoDocumento();

			docAgend.setAgendamento(agendamento);
			docAgend.setDocumento(doc);
			docAgend.setIndEnviaEmail(documento.getIndEnviaEmail());
			docAgend.setUrlArquivo(documento.getUrlDocumento());

			agendamento.addDocumento(docAgend);
		}
	}
	
	private void incluiListDoc(AgendamentoComunicacao agendamento, List<ListDocComunicacaoDTO> listDoc)
			throws ServiceException {
		for (ListDocComunicacaoDTO listDocComunicacaoDTO : listDoc) {
			AgendamentoListDocumentos agendamentoListDocumentos = new AgendamentoListDocumentos();
			agendamentoListDocumentos.setAgendamento(agendamento);
			agendamentoListDocumentos.setNomeDocumento(listDocComunicacaoDTO.getNomeDocumento());
			agendamentoListDocumentos.setUrlArquivo(listDocComunicacaoDTO.getUrlDocumento());
			agendamentoListDocumentos.setIndEnviaEmail(listDocComunicacaoDTO.getIndEnviaEmail());
			agendamento.addListDoc(agendamentoListDocumentos);
		}
	}
	
	private void incluiComCopia(AgendamentoComunicacao agendamento, List<ComCopiaDTO> comCopias) 
			throws ServiceException {
		int i = 0;
		for (ComCopiaDTO comCopiaDTO : comCopias) {
			AgendamentoComCopia agendamentoComCopia = new AgendamentoComCopia();
			agendamentoComCopia.setAgendamento(agendamento);
			agendamentoComCopia.setSeqCopia( ++i);
			agendamentoComCopia.setDestinatario(comCopiaDTO.getDestino());
			agendamentoComCopia.setIndValido("N");
			if (comCopiaDTO.getCpfCnpj() != null) {
				agendamentoComCopia.setCpfCnpj(comCopiaDTO.getCpfCnpj());
			}
			
			if (comCopiaDTO.getCopiaOculta() != null) {
				agendamentoComCopia.setCopiaOculta(comCopiaDTO.getCopiaOculta());
			} else {
				agendamentoComCopia.setCopiaOculta("N");
			}
			
			agendamento.addComCopia(agendamentoComCopia);
		}
	}

	@Override
	public EmailDataEnvioDTO obtemDataEnvioEmail(Long idereg) {
		EmailDataEnvioDTO retorno = new EmailDataEnvioDTO();
		retorno.setDataEnvio(agendamentoDao.obtemDataDeEnvio(idereg));
		retorno.setEmailsDestinatarios(agendamentoDao.listaEmailsDestinatariosAgendamentoDoc(idereg));
		return retorno;
	}

	@Override
	public boolean existAgendamento(Long codModelo) {
		return agendamentoDao.existAgendamento(codModelo);
	}

	@Override
	public List<AgendamentoComunicacao> buscaAgendamentosPiloto() throws ServiceException {
		return agendamentoDao.buscaAgendamentosPiloto();
	}

	@Override
	public List<AgendamentoComunicacao> buscaAgendamentosPiloto(String codigo, Date dataAgendamento) {
		return agendamentoDao.buscaAgendamentosPiloto(codigo, dataAgendamento);
	}

}
