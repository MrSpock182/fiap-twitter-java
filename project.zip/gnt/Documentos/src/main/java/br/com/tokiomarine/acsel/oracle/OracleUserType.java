package br.com.tokiomarine.acsel.oracle;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.driver.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

/**
 * Autor: Rafael Barbosa Corsini
 * Area: Sistemas Institucionais e Financeiros
 * Fone: (55) (11) 3265-7421
 * VOIP: (2) 7421
 **/


public class OracleUserType {

	private String typeName;
	private String typeTableName;
	private Connection connection;
	private List<Object> attributes;
	private List<Object> listAttributes;
	private StructDescriptor structDescriptor;
	private ArrayDescriptor arrayDescriptorTable;

	public OracleUserType() {
		super();
	}

	public OracleUserType(String typeName,String typeTableName,Connection connection,List<Object> attributes) throws SQLException {
		super();
		this.typeName = typeName;
		this.typeTableName = typeTableName;
		this.connection = connection.unwrap(OracleConnection.class);
		this.attributes = attributes;
		this.listAttributes = new ArrayList<Object>();
	}

	public OracleUserType(String typeName,Connection connection) throws SQLException {
		super();
		this.typeName = typeName;
		this.connection = connection.unwrap(OracleConnection.class);
		this.attributes = new ArrayList<Object>();
		this.listAttributes = new ArrayList<Object>();

	}

	public OracleUserType(String typeName,String typeTableName,Connection connection) throws SQLException {
		super();
		this.typeName 		= typeName;
		this.typeTableName 	= typeTableName;
		this.connection 	= connection.unwrap(OracleConnection.class);
		this.attributes 	= new ArrayList<Object>();
		this.listAttributes = new ArrayList<Object>();
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getTypeTableName() {
		return typeTableName;
	}

	public void setTypeTableName(String typeTableName) {
		this.typeTableName = typeTableName;
	}

	public List<Object> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<Object> attributes) {
		this.attributes = attributes;
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public StructDescriptor getStructDescriptor() {
		return structDescriptor;
	}

	public void setStructDescriptor(StructDescriptor structDescriptor) {
		this.structDescriptor = structDescriptor;
	}

	public ArrayDescriptor getArrayDescriptorTable() {
		return arrayDescriptorTable;
	}

	public void setArrayDescriptorTable(ArrayDescriptor arrayDescriptorTable) {
		this.arrayDescriptorTable = arrayDescriptorTable;
	}

	public void addAttribute(String value) {
		this.attributes.add(value);
	}

	public void addAttribute(Date value) {
		this.attributes.add(value);
	}

	public void addAttribute(Long value) {
		this.attributes.add(value);
	}

	public void addAttribute(Integer value) {
		this.attributes.add(value);
	}

	public void addAttribute(int value) {
		this.attributes.add(value);
	}

	public void addAttribute(int index,String value) {
		this.attributes.add(index,index);
	}

	public void addAttribute(int index,int value) {
		this.attributes.add(index,index);
	}

	public List<Object> getListAttributes() {
		return listAttributes;
	}

	public void setListAttributes(List<Object> listAttributes) {
		this.listAttributes = listAttributes;
	}

	public void addRow() throws SQLException {

		setStructDescriptor(StructDescriptor.createDescriptor(this.getTypeName().toUpperCase(),this.getConnection()));
		this.listAttributes.add(new STRUCT(structDescriptor,connection,this.getAttributes().toArray()));

		this.attributes = new ArrayList<Object>();
	}

	public Object get() throws SQLException {

		setStructDescriptor(StructDescriptor.createDescriptor(this.getTypeName().toUpperCase(),this.getConnection()));

		return new STRUCT(this.getStructDescriptor(),this.getConnection(),this.getAttributes().toArray());

	}

	public ARRAY getArray() throws SQLException {

		setArrayDescriptorTable(ArrayDescriptor.createDescriptor(this.getTypeTableName().toUpperCase(),this.getConnection()));

		return new ARRAY(this.getArrayDescriptorTable(),this.getConnection(),this.getListAttributes().toArray());

	}
}

