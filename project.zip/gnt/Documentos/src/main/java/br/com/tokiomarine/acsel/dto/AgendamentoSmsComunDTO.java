package br.com.tokiomarine.acsel.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown=true)
public class AgendamentoSmsComunDTO {
	
	private Long seqAgendamento;
	
	private String statusAgendamento;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataEnvio;
	
	private String codRetornoEnvio;
	
	private String modelo;
	
	private String tipoModelo;	

	public Long getSeqAgendamento() {
		return seqAgendamento;
	}

	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}

	public String getStatusAgendamento() {
		return statusAgendamento;
	}

	public void setStatusAgendamento(String statusAgendamento) {
		this.statusAgendamento = statusAgendamento;
	}

	public Date getDataEnvio() {
		return dataEnvio;
	}

	public void setDataEnvio(Date dataEnvio) {
		this.dataEnvio = dataEnvio;
	}

	public String getCodRetornoEnvio() {
		return codRetornoEnvio;
	}

	public void setCodRetornoEnvio(String codRetornoEnvio) {
		this.codRetornoEnvio = codRetornoEnvio;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getTipoModelo() {
		return tipoModelo;
	}

	public void setTipoModelo(String tipoModelo) {
		this.tipoModelo = tipoModelo;
	}

}
