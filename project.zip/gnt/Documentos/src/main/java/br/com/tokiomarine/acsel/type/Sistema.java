package br.com.tokiomarine.acsel.type;

public enum Sistema {

	acsel("ACSEL"),
	ssv("SSV"),
	plat("PLATAFORMA");

	Sistema(String value) {
		this.value = value;
	}

	Sistema() {}

	private String value;

	public String getValue() {
		if (value != null) {
			return value;
		} else {
			return this.name();
		}
	}

	public boolean isAcsel(){
		return (this.equals(acsel));
	}

	public boolean isSSV(){
		return (this.equals(ssv));
	}

	public boolean isPlataforma(){
		return (this.equals(plat));
	}

}
