package br.com.tokiomarine.acsel.dto;

public class ListDocComunicacaoDTO {
	
	private Long seqAgendamento;
	private String nomeDocumento;
	private String urlDocumento;
	private String indEnviaEmail;

	public Long getSeqAgendamento() {
		return seqAgendamento;
	}

	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}

	public String getNomeDocumento() {
		return nomeDocumento;
	}

	public void setNomeDocumento(String nomeDocumento) {
		this.nomeDocumento = nomeDocumento;
	}

	public String getUrlDocumento() {
		return urlDocumento;
	}

	public void setUrlDocumento(String urlDocumento) {
		this.urlDocumento = urlDocumento;
	}

	public String getIndEnviaEmail() {
		return indEnviaEmail;
	}

	public void setIndEnviaEmail(String indEnviaEmail) {
		this.indEnviaEmail = indEnviaEmail;
	}

}
