package br.com.tokiomarine.acsel.dto;

public class DocumentoTemplateDTO {

	private String seqAgendamento;
	private Integer codDocumento;
	private String urlDocumento;
	private String indEnviaEmail;

	public DocumentoTemplateDTO() {
		seqAgendamento = null;
		codDocumento = 1;
		urlDocumento = "https://portal.tokiomarine.com.br/docstore-services/rest/download-anexo/xxx";
		indEnviaEmail = "S";
	}

	public String getSeqAgendamento() {
		return seqAgendamento;
	}

	public Integer getCodDocumento() {
		return codDocumento;
	}

	public String getUrlDocumento() {
		return urlDocumento;
	}

	public String getIndEnviaEmail() {
		return indEnviaEmail;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codDocumento == null) ? 0 : codDocumento.hashCode());
		result = prime * result + ((indEnviaEmail == null) ? 0 : indEnviaEmail.hashCode());
		result = prime * result + ((seqAgendamento == null) ? 0 : seqAgendamento.hashCode());
		result = prime * result + ((urlDocumento == null) ? 0 : urlDocumento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentoTemplateDTO other = (DocumentoTemplateDTO) obj;
		if (codDocumento == null) {
			if (other.codDocumento != null)
				return false;
		} else if (!codDocumento.equals(other.codDocumento))
			return false;
		if (indEnviaEmail == null) {
			if (other.indEnviaEmail != null)
				return false;
		} else if (!indEnviaEmail.equals(other.indEnviaEmail))
			return false;
		if (seqAgendamento == null) {
			if (other.seqAgendamento != null)
				return false;
		} else if (!seqAgendamento.equals(other.seqAgendamento))
			return false;
		if (urlDocumento == null) {
			if (other.urlDocumento != null)
				return false;
		} else if (!urlDocumento.equals(other.urlDocumento))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DocumentoTemplateDTO [seqAgendamento=" + seqAgendamento + ", codDocumento=" + codDocumento
				+ ", urlDocumento=" + urlDocumento + ", indEnviaEmail=" + indEnviaEmail + "]";
	}

}
