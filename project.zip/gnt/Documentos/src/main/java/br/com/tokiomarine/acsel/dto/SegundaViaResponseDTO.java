package br.com.tokiomarine.acsel.dto;

import java.util.List;

public class SegundaViaResponseDTO {
	
	Long codigo;
	String descricao;
	List<SegundaViaDocumentoDTO> documentos;
	

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public List<SegundaViaDocumentoDTO> getDocumentos() {
		return documentos;
	}

	public void setDocumentos(List<SegundaViaDocumentoDTO> documentos) {
		this.documentos = documentos;
	}

}
