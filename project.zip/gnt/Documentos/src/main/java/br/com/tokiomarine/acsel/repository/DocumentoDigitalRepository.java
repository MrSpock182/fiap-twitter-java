package br.com.tokiomarine.acsel.repository;

import java.util.List;

import javax.inject.Inject;

import org.hibernate.criterion.Restrictions;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.DocumentoDigital;

public class DocumentoDigitalRepository{

	@Inject
	BaseAcxDAO base;

	public List<DocumentoDigital> obtemDocumentoDigital(Long idePol, Long numCert, Long numOper){

		@SuppressWarnings("unchecked")
		List<DocumentoDigital> doc = base.getSession().createCriteria(DocumentoDigital.class)
			.add(Restrictions.eq("idePol", idePol))
			.add(Restrictions.eq("numCert", numCert))
			.add(Restrictions.eq("numOper", numOper))
			.list();

		return doc;
	}
}
