package br.com.tokiomarine.acsel.service;

import java.util.List;

import br.com.tokiomarine.acsel.dto.ConsultaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoImpressaoDTO;

public interface ConsultaDocumentosService {

	ConsultaDocumentosDTO listaDocumentos(ConsultaDocumentosDTO consulta);

	List<DocumentoImpressaoDTO> listaDocumentosDisponiveis();

}
