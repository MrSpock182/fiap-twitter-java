
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de localTrabalho complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="localTrabalho">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoPredio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "localTrabalho", propOrder = {
    "nome",
    "tipoPredio"
})
public class LocalTrabalho {

    protected String nome;
    protected String tipoPredio;

    /**
     * Obt�m o valor da propriedade nome.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Obt�m o valor da propriedade tipoPredio.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTipoPredio() {
        return tipoPredio;
    }

    /**
     * Define o valor da propriedade tipoPredio.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTipoPredio(String value) {
        this.tipoPredio = value;
    }

}
