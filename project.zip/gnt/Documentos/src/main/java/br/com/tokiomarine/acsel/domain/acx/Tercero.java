package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@IdClass(TerceroPK.class)
@Table(name = "TERCERO")
public class Tercero {

	@Id
	@Column(name="TIPOID")	private String tipoId;
	@Id
	@Column(name="NUMID")	private Long numId;
	@Id
	@Column(name="DVID")	private String dvId;

	@Column(name="NOMTER")	private String nomTer;
	@Column(name="APETER")	private String apeTer;
	@Column(name="CODPAIS")	private String codPais;
	@Column(name="CODESTADO")	private String codEstado;
	@ManyToOne
	@JoinColumns({
        @JoinColumn(updatable=false,insertable=false, name = "CODPAIS", referencedColumnName = "CODPAIS" ),
        @JoinColumn(updatable=false,insertable=false, name = "CODESTADO", referencedColumnName = "CODESTADO"),
        @JoinColumn(updatable=false,insertable=false, name = "CODCIUDAD", referencedColumnName = "CODCIUDAD" )})
	private Ciudad ciudad;

	@ManyToOne
	@JoinColumns({
        @JoinColumn(updatable=false,insertable=false, name = "CODPAIS", referencedColumnName = "CODPAIS" ),
        @JoinColumn(updatable=false,insertable=false, name = "CODESTADO", referencedColumnName = "CODESTADO"),
        @JoinColumn(updatable=false,insertable=false, name = "CODCIUDAD", referencedColumnName = "CODCIUDAD" ),
        @JoinColumn(updatable=false,insertable=false, name = "CODMUNICIPIO", referencedColumnName = "CODMUNICIPIO" )})
	private Municipio municipio;
	@Column(name="DIREC")	private String direc;
	@Column(name="TELEF1")	private String telef1;
	@Column(name="TELEF2")	private String telef2;
	@Column(name="TELEF3")	private String telef3;
	@Column(name="FAX")	private String fax;
	@Column(name="TELEX")	private String telex;
	@Column(name="ZIP")	private String zip;
	@Column(name="INDNACIONAL")	private String indNacional;
	@Column(name="STSTER")	private String stsTer;
	@Column(name="FECSTS")	@Temporal(TemporalType.TIMESTAMP)	private Date fecSts;
	@Column(name="NUMCTAAUX")	private String numCtaaux;
	@Column(name="TIPOTER")	private String tipoTer;
	@Column(name="FECLISTANEGRA")	@Temporal(TemporalType.TIMESTAMP)	private Date fecListaNegra;
	@Column(name="CODLISTANEGRA")	private String codListaNegra;
	@Column(name="ORIGEM")	private Long origem;
	@Column(name="KEYFONETICA1")	private String keyFonetica1;
	@Column(name="KEYFONETICA2")	private String keyFonetica2;
	@Column(name="KEYFONETICA3")	private String keyFonetica3;
	@Column(name="KEYFONETICA4")	private String keyFonetica4;
	@Column(name="NUMDEPENDIR")	private Long numDependIr;
	@Column(name="CODMUNICFIS")	private Long codMunicFis;
	@Column(name="INSCINSS")	private String inscInss;
	@Column(name="INSCMUNICIPAL")	private String inscMunicipal;
	@Column(name="NUMCONVISS")	private String numConvIss;
	@Column(name="CLASCONTRIBINSS")	private Long clasContribInss;
	@Column(name="ENDFISCODESTADO")	private String endFisCodEstado;
	@Column(name="ENDFISCODCIUDAD")	private String endFisCodCiudad;
	@Column(name="ENDFISCODMUNICIPIO")	private String endFisCodMunicipio;
	@Column(name="ENDFISLOGRADOURO")	private String endFisLogradouro;
	@Column(name="ENDFISCEP")	private String endfiscep;
	@Column(name="DTINCLUSAO")	@Temporal(TemporalType.TIMESTAMP)	private Date dtInclusao;
	@Column(name="DTALTERACAO")	@Temporal(TemporalType.TIMESTAMP)	private Date dtAlTerAcao;
	@Column(name="INSCESTADUAL")	private String inscestadual;
	@Column(name="COMPLOGRAD")	private String compLograd;
	@Column(name="DDDTELEF1")	private Long dddTelef1;
	@Column(name="COMPLTELEF1")	private String compltelef1;
	@Column(name="DDDTELEF2")	private Long dddTelef2;
	@Column(name="COMPLTELEF2")	private String compltelef2;
	@Column(name="DDDTELEF3")	private Long dddTelef3;
	@Column(name="COMPLTELEF3")	private String compltelef3;
	@Column(name="DDDFAX")	private Long dddFax;
	@Column(name="COMPLFAX")	private String complFax;
	@Column(name="ENDERECO")	private String endereco;
	@Column(name="NUMTELEF1")	private Long numTelef1;
	@Column(name="NUMTELEF2")	private Long numTelef2;
	@Column(name="NUMTELEF3")	private Long numTelef3;
	@Column(name="NUMFAX")	private Long numFax;
	@Column(name="SITE")	private String site;
	@Column(name="ENDFISNUMLOGRAD")	private Long endFisNumLograd;
	@Column(name="ENDFISCOMPLOGRAD")	private String endFisCompLograd;
	@Column(name="NUMDEPIR")	private Long numDepir;
	@Column(name="INDRECOLHEINSS")	private String indRecolheInss;
	@Column(name="DTINIINSS")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIniInss;
	@Column(name="ENDFISCODPAIS")	private String endFisCodPais;
	@Column(name="TIPOPESS")	private String tipoPess;
	@Column(name="INDMUNICPRES")	private String indMunicPres;
	@Column(name="INSCMUNICIPALPREST")	private String inscMunicipalPrest;
	@Column(name="CODMUNICFISQN")	private Long codMunicFisqn;
	@Column(name="NUMLOGRAD")	private String numLograd;
	@Column(name="IND_ISEN_IMP")	private String indIsenImp;
	@Column(name="NUMTELEF0800")	private String numTelef0800;
	@Column(name="CODCNAE")	private String codCnae;

	@OneToMany
	@JoinColumns({
        @JoinColumn(name = "TIPOID", referencedColumnName = "TIPOID" ),
        @JoinColumn(name = "NUMID", referencedColumnName = "NUMID"),
        @JoinColumn(name = "DVID", referencedColumnName = "DVID" )})
	private List<TerceroEnderecos> terceroEnderecos;

	public String getTipoId() {
		return tipoId;
	}
	public void setTipoId(String tipoId) {
		this.tipoId = tipoId;
	}
	public Long getNumId() {
		return numId;
	}
	public void setNumId(Long numId) {
		this.numId = numId;
	}
	public String getDvId() {
		return dvId;
	}
	public void setDvId(String dvId) {
		this.dvId = dvId;
	}
	public String getNomTer() {
		return nomTer;
	}
	public void setNomTer(String nomTer) {
		this.nomTer = nomTer;
	}
	public String getApeTer() {
		return apeTer;
	}
	public void setApeTer(String apeTer) {
		this.apeTer = apeTer;
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public Ciudad getCiudad() {
		return ciudad;
	}
	public void setCiudad(Ciudad ciudad) {
		this.ciudad = ciudad;
	}
	public Municipio getMunicipio() {
		return municipio;
	}
	public void setMunicipio(Municipio municipio) {
		this.municipio = municipio;
	}
	public String getDirec() {
		return direc;
	}
	public void setDirec(String direc) {
		this.direc = direc;
	}
	public String getTelef1() {
		return telef1;
	}
	public void setTelef1(String telef1) {
		this.telef1 = telef1;
	}
	public String getTelef2() {
		return telef2;
	}
	public void setTelef2(String telef2) {
		this.telef2 = telef2;
	}
	public String getTelef3() {
		return telef3;
	}
	public void setTelef3(String telef3) {
		this.telef3 = telef3;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getTelex() {
		return telex;
	}
	public void setTelex(String telex) {
		this.telex = telex;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getIndNacional() {
		return indNacional;
	}
	public void setIndNacional(String indNacional) {
		this.indNacional = indNacional;
	}
	public String getStsTer() {
		return stsTer;
	}
	public void setStsTer(String stsTer) {
		this.stsTer = stsTer;
	}
	public Date getFecSts() {
		return fecSts;
	}
	public void setFecSts(Date fecSts) {
		this.fecSts = fecSts;
	}
	public String getNumCtaaux() {
		return numCtaaux;
	}
	public void setNumCtaaux(String numCtaaux) {
		this.numCtaaux = numCtaaux;
	}
	public String getTipoTer() {
		return tipoTer;
	}
	public void setTipoTer(String tipoTer) {
		this.tipoTer = tipoTer;
	}
	public Date getFecListaNegra() {
		return fecListaNegra;
	}
	public void setFecListaNegra(Date fecListaNegra) {
		this.fecListaNegra = fecListaNegra;
	}
	public String getCodListaNegra() {
		return codListaNegra;
	}
	public void setCodListaNegra(String codListaNegra) {
		this.codListaNegra = codListaNegra;
	}
	public Long getOrigem() {
		return origem;
	}
	public void setOrigem(Long origem) {
		this.origem = origem;
	}
	public String getKeyFonetica1() {
		return keyFonetica1;
	}
	public void setKeyFonetica1(String keyFonetica1) {
		this.keyFonetica1 = keyFonetica1;
	}
	public String getKeyFonetica2() {
		return keyFonetica2;
	}
	public void setKeyFonetica2(String keyFonetica2) {
		this.keyFonetica2 = keyFonetica2;
	}
	public String getKeyFonetica3() {
		return keyFonetica3;
	}
	public void setKeyFonetica3(String keyFonetica3) {
		this.keyFonetica3 = keyFonetica3;
	}
	public String getKeyFonetica4() {
		return keyFonetica4;
	}
	public void setKeyFonetica4(String keyFonetica4) {
		this.keyFonetica4 = keyFonetica4;
	}
	public Long getNumDependIr() {
		return numDependIr;
	}
	public void setNumDependIr(Long numDependIr) {
		this.numDependIr = numDependIr;
	}
	public Long getCodMunicFis() {
		return codMunicFis;
	}
	public void setCodMunicFis(Long codMunicFis) {
		this.codMunicFis = codMunicFis;
	}
	public String getInscInss() {
		return inscInss;
	}
	public void setInscInss(String inscInss) {
		this.inscInss = inscInss;
	}
	public String getInscMunicipal() {
		return inscMunicipal;
	}
	public void setInscMunicipal(String inscMunicipal) {
		this.inscMunicipal = inscMunicipal;
	}
	public String getNumConvIss() {
		return numConvIss;
	}
	public void setNumConvIss(String numConvIss) {
		this.numConvIss = numConvIss;
	}
	public Long getClasContribInss() {
		return clasContribInss;
	}
	public void setClasContribInss(Long clasContribInss) {
		this.clasContribInss = clasContribInss;
	}
	public String getEndFisCodEstado() {
		return endFisCodEstado;
	}
	public void setEndFisCodEstado(String endFisCodEstado) {
		this.endFisCodEstado = endFisCodEstado;
	}
	public String getEndFisCod() {
		return endFisCodCiudad;
	}
	public void setEndFisCod(String endFisCodCiudad) {
		this.endFisCodCiudad = endFisCodCiudad;
	}
	public String getEndFisCodMunicipio() {
		return endFisCodMunicipio;
	}
	public void setEndFisCodMunicipio(String endFisCodMunicipio) {
		this.endFisCodMunicipio = endFisCodMunicipio;
	}
	public String getEndFisLogradouro() {
		return endFisLogradouro;
	}
	public void setEndFisLogradouro(String endFisLogradouro) {
		this.endFisLogradouro = endFisLogradouro;
	}
	public String getEndfiscep() {
		return endfiscep;
	}
	public void setEndfiscep(String endfiscep) {
		this.endfiscep = endfiscep;
	}
	public Date getDtInclusao() {
		return dtInclusao;
	}
	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}
	public Date getDtAlTerAcao() {
		return dtAlTerAcao;
	}
	public void setDtAlTerAcao(Date dtAlTerAcao) {
		this.dtAlTerAcao = dtAlTerAcao;
	}
	public String getInscestadual() {
		return inscestadual;
	}
	public void setInscestadual(String inscestadual) {
		this.inscestadual = inscestadual;
	}
	public String getCompLograd() {
		return compLograd;
	}
	public void setCompLograd(String compLograd) {
		this.compLograd = compLograd;
	}
	public Long getDddTelef1() {
		return dddTelef1;
	}
	public void setDddTelef1(Long dddTelef1) {
		this.dddTelef1 = dddTelef1;
	}
	public String getCompltelef1() {
		return compltelef1;
	}
	public void setCompltelef1(String compltelef1) {
		this.compltelef1 = compltelef1;
	}
	public Long getDddTelef2() {
		return dddTelef2;
	}
	public void setDddTelef2(Long dddTelef2) {
		this.dddTelef2 = dddTelef2;
	}
	public String getCompltelef2() {
		return compltelef2;
	}
	public void setCompltelef2(String compltelef2) {
		this.compltelef2 = compltelef2;
	}
	public Long getDddTelef3() {
		return dddTelef3;
	}
	public void setDddTelef3(Long dddTelef3) {
		this.dddTelef3 = dddTelef3;
	}
	public String getCompltelef3() {
		return compltelef3;
	}
	public void setCompltelef3(String compltelef3) {
		this.compltelef3 = compltelef3;
	}
	public Long getDddFax() {
		return dddFax;
	}
	public void setDddFax(Long dddFax) {
		this.dddFax = dddFax;
	}
	public String getComplFax() {
		return complFax;
	}
	public void setComplFax(String complFax) {
		this.complFax = complFax;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public Long getNumTelef1() {
		return numTelef1;
	}
	public void setNumTelef1(Long numTelef1) {
		this.numTelef1 = numTelef1;
	}
	public Long getNumTelef2() {
		return numTelef2;
	}
	public void setNumTelef2(Long numTelef2) {
		this.numTelef2 = numTelef2;
	}
	public Long getNumTelef3() {
		return numTelef3;
	}
	public void setNumTelef3(Long numTelef3) {
		this.numTelef3 = numTelef3;
	}
	public Long getNumFax() {
		return numFax;
	}
	public void setNumFax(Long numFax) {
		this.numFax = numFax;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public Long getEndFisNumLograd() {
		return endFisNumLograd;
	}
	public void setEndFisNumLograd(Long endFisNumLograd) {
		this.endFisNumLograd = endFisNumLograd;
	}
	public String getEndFisCompLograd() {
		return endFisCompLograd;
	}
	public void setEndFisCompLograd(String endFisCompLograd) {
		this.endFisCompLograd = endFisCompLograd;
	}
	public Long getNumDepir() {
		return numDepir;
	}
	public void setNumDepir(Long numDepir) {
		this.numDepir = numDepir;
	}
	public String getIndRecolheInss() {
		return indRecolheInss;
	}
	public void setIndRecolheInss(String indRecolheInss) {
		this.indRecolheInss = indRecolheInss;
	}
	public Date getDtIniInss() {
		return dtIniInss;
	}
	public void setDtIniInss(Date dtIniInss) {
		this.dtIniInss = dtIniInss;
	}
	public String getEndFisCodPais() {
		return endFisCodPais;
	}
	public void setEndFisCodPais(String endFisCodPais) {
		this.endFisCodPais = endFisCodPais;
	}
	public String getTipoPess() {
		return tipoPess;
	}
	public void setTipoPess(String tipoPess) {
		this.tipoPess = tipoPess;
	}
	public String getIndMunicPres() {
		return indMunicPres;
	}
	public void setIndMunicPres(String indMunicPres) {
		this.indMunicPres = indMunicPres;
	}
	public String getInscMunicipalPrest() {
		return inscMunicipalPrest;
	}
	public void setInscMunicipalPrest(String inscMunicipalPrest) {
		this.inscMunicipalPrest = inscMunicipalPrest;
	}
	public Long getCodMunicFisqn() {
		return codMunicFisqn;
	}
	public void setCodMunicFisqn(Long codMunicFisqn) {
		this.codMunicFisqn = codMunicFisqn;
	}
	public String getNumLograd() {
		return numLograd;
	}
	public void setNumLograd(String numLograd) {
		this.numLograd = numLograd;
	}
	public String getIndIsenImp() {
		return indIsenImp;
	}
	public void setIndIsenImp(String indIsenImp) {
		this.indIsenImp = indIsenImp;
	}
	public String getNumTelef0800() {
		return numTelef0800;
	}
	public void setNumTelef0800(String numTelef0800) {
		this.numTelef0800 = numTelef0800;
	}
	public String getCodCnae() {
		return codCnae;
	}
	public void setCodCnae(String codCnae) {
		this.codCnae = codCnae;
	}

	public List<TerceroEnderecos> getTerceroEnderecos() {
		return terceroEnderecos;
	}
	public void setTerceroEnderecos(List<TerceroEnderecos> terceroEnderecos) {
		this.terceroEnderecos = terceroEnderecos;
	}
	@Override
	public String toString() {
		return "Tercero [tipoId=" + tipoId + ", numId=" + numId + ", dvId="
				+ dvId + ", nomTer=" + nomTer + ", apeTer=" + apeTer
				+ ", codPais=" + codPais + ", codEstado=" + codEstado
				+ ", direc=" + direc + ", telef1=" + telef1 + ", telef2="
				+ telef2 + ", telef3=" + telef3 + ", fax=" + fax + ", telex="
				+ telex + ", zip=" + zip + ", indNacional=" + indNacional
				+ ", stsTer=" + stsTer + ", fecSts=" + fecSts + ", numCtaaux="
				+ numCtaaux + ", tipoTer=" + tipoTer + ", fecListaNegra="
				+ fecListaNegra + ", codListaNegra=" + codListaNegra
				+ ", origem=" + origem + ", keyFonetica1=" + keyFonetica1
				+ ", keyFonetica2=" + keyFonetica2 + ", keyFonetica3="
				+ keyFonetica3 + ", keyFonetica4=" + keyFonetica4
				+ ", numDependIr=" + numDependIr + ", codMunicFis="
				+ codMunicFis + ", inscInss=" + inscInss + ", inscMunicipal="
				+ inscMunicipal + ", numConvIss=" + numConvIss
				+ ", clasContribInss=" + clasContribInss + ", endFisCodEstado="
				+ endFisCodEstado + ", endFisCodCiudad=" + endFisCodCiudad
				+ ", endFisCodMunicipio=" + endFisCodMunicipio
				+ ", endFisLogradouro=" + endFisLogradouro + ", endfiscep="
				+ endfiscep + ", dtInclusao=" + dtInclusao + ", dtAlTerAcao="
				+ dtAlTerAcao + ", inscestadual=" + inscestadual
				+ ", compLograd=" + compLograd + ", dddTelef1=" + dddTelef1
				+ ", compltelef1=" + compltelef1 + ", dddTelef2=" + dddTelef2
				+ ", compltelef2=" + compltelef2 + ", dddTelef3=" + dddTelef3
				+ ", compltelef3=" + compltelef3 + ", dddFax=" + dddFax
				+ ", complFax=" + complFax + ", endereco=" + endereco
				+ ", numTelef1=" + numTelef1 + ", numTelef2=" + numTelef2
				+ ", numTelef3=" + numTelef3 + ", numFax=" + numFax + ", site="
				+ site + ", endFisNumLograd=" + endFisNumLograd
				+ ", endFisCompLograd=" + endFisCompLograd + ", numDepir="
				+ numDepir + ", indRecolheInss=" + indRecolheInss
				+ ", dtIniInss=" + dtIniInss + ", endFisCodPais="
				+ endFisCodPais + ", tipoPess=" + tipoPess + ", indMunicPres="
				+ indMunicPres + ", inscMunicipalPrest=" + inscMunicipalPrest
				+ ", codMunicFisqn=" + codMunicFisqn + ", numLograd="
				+ numLograd + ", indIsenImp=" + indIsenImp + ", numTelef0800="
				+ numTelef0800 + ", codCnae=" + codCnae + "]";
	}
}


