package br.com.tokiomarine.acsel.type;

public enum FormaEnvio {

	impresso("01", "1", "Correio (Resumo da Apólice, cartão do segurado e carnê de pagamento impressos)"),
	digital("02", "2", "E-mail (Resumo da Apólice, cartão do segurado e carnê de pagamento digitais)"),
	cartao("03", "3", "Correio + E-mail (Resumo da Apólice, carnê de pagamento digitais e cartão do segurado impresso)"),
	impressoDigitalEmail("04", "", "Correio (Resumo da Apólice, cartão do segurado e carnê de pagamento impressos)"),
	impressoDigital("05", "", "Correio (Resumo da Apólice, cartão do segurado e carnê de pagamento impressos)");

	private String value;
	private String valuePlat;
	private String descricao;

	FormaEnvio(String value, String valuePlat, String desc) {
		this.value = value;
		this.valuePlat = valuePlat;
		this.descricao = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDescricao() {
		return descricao;
	}

	public boolean documentoDigital(){
		return this.equals(digital) || this.equals(cartao);
	}

	public boolean envioEmail(){
		return !(this.equals(impresso));
	}

	public static FormaEnvio get(String formaEnvio){
		for (FormaEnvio tipo : FormaEnvio.values()){
			if (tipo.value.equals(formaEnvio)){
				return tipo;
			}
		}
		return null;
	}

	public static FormaEnvio getPlataforma(String formaEnvio){
		for (FormaEnvio tipo : FormaEnvio.values()){
			if (tipo.valuePlat.equals(formaEnvio)){
				return tipo;
			}
		}
		return null;
	}
}
