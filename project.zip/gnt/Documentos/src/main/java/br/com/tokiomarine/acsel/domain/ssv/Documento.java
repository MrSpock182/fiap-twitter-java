package br.com.tokiomarine.acsel.domain.ssv;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="EMP0018_DOCTO")
@IdClass(DocumentoPK.class)
public class Documento {
	/** Atributo que mapeia o campo CD_CLASS_DOCTO. */
	@Column(name="CD_CLASS_DOCTO",nullable=false)
	private String cdClassDocto;
	/** Atributo que mapeia o campo CD_DOCTO. */
	@Id
	@Column(name="CD_DOCTO",nullable=false)
	private String cdDocto;
	/** Atributo que mapeia o campo CD_EMPRE_IMP. */
	@Column(name="CD_EMPRE_IMP",nullable=false)
	private Long cdEmpreImp;
	/** Atributo que mapeia o campo CD_GRP_DOCTO. */
	@Column(name="CD_GRP_DOCTO")
	private Long cdGrpDocto;
	/** Atributo que mapeia o campo CD_SITUC_DOCTO. */
	@Column(name="CD_SITUC_DOCTO",nullable=false)
	private String cdSitucDocto;
	/** Atributo que mapeia o campo CD_USURO_ULTMA_ALTER. */
	@Column(name="CD_USURO_ULTMA_ALTER")
	private String cdUsuroUltmaAlter;
	/** Atributo que mapeia o campo DS_DOCTO. */
	@Column(name="DS_DOCTO",nullable=false)
	private String dsDocto;
	/** Atributo que mapeia o campo DT_FIM_VIGEN_DOCTO. */
	@Column(name="DT_FIM_VIGEN_DOCTO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtFimVigenDocto;
	/** Atributo que mapeia o campo DT_INICO_VIGEN_DOCTO. */
	@Id
	@Column(name="DT_INICO_VIGEN_DOCTO",nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtInicoVigenDocto;
	/** Atributo que mapeia o campo DT_ULTMA_ALTER. */
	@Column(name="DT_ULTMA_ALTER")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtUltmaAlter;
	/** Atributo que mapeia o campo IC_DOCTO_OFICL. */
	@Column(name="IC_DOCTO_OFICL",nullable=false)
	private String icDoctoOficl;
	/** Atributo que mapeia o campo NM_DEPTO_RESPV. */
	@Column(name="NM_DEPTO_RESPV")
	private String nmDeptoRespv;
	/** Atributo que mapeia o campo QT_VIA_DOCTO. */
	@Column(name="QT_VIA_DOCTO",nullable=false)
	private Long qtViaDocto;

	/** Atributo que guarda uma referência para o objeto que representa a PK da entidade. */
	@Transient
	private DocumentoPK pk = new DocumentoPK();

	/**
	 * Construtor da classe.
	 */
	public Documento() {
	}

	/** Retorna o objeto que representa a Primary-Key do registro no tabela do banco de dados relacional. */
	public Serializable getPk() {
		this.pk.cdDocto = this.cdDocto;
		this.pk.dtInicoVigenDocto = this.dtInicoVigenDocto;
		return this.pk;
	}

	/**
	 * Retorna o valor do atributo cdClassDocto, que representa o campo CD_CLASS_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public String getCdClassDocto() {
		return this.cdClassDocto;
	}

	/**
	 * Atribui o valor ao atributo cdClassDocto, que representa o campo CD_CLASS_DOCTO da tabela.
	 * @param cdClassDocto valor a ser atribuido.
	 */
	public void setCdClassDocto(String cdClassDocto) {
		this.cdClassDocto = cdClassDocto;
	}

	/**
	 * Retorna o valor do atributo cdDocto, que representa o campo CD_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public String getCdDocto() {
		return this.cdDocto;
	}

	/**
	 * Atribui o valor ao atributo cdDocto, que representa o campo CD_DOCTO da tabela.
	 * @param cdDocto valor a ser atribuido.
	 */
	public void setCdDocto(String cdDocto) {
		this.cdDocto = cdDocto;
	}

	/**
	 * Retorna o valor do atributo cdEmpreImp, que representa o campo CD_EMPRE_IMP da tabela.
	 * @return valor do atributo.
	 */
	public Long getCdEmpreImp() {
		return this.cdEmpreImp;
	}

	/**
	 * Atribui o valor ao atributo cdEmpreImp, que representa o campo CD_EMPRE_IMP da tabela.
	 * @param cdEmpreImp valor a ser atribuido.
	 */
	public void setCdEmpreImp(Long cdEmpreImp) {
		this.cdEmpreImp = cdEmpreImp;
	}

	/**
	 * Retorna o valor do atributo cdGrpDocto, que representa o campo CD_GRP_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public Long getCdGrpDocto() {
		return this.cdGrpDocto;
	}

	/**
	 * Atribui o valor ao atributo cdGrpDocto, que representa o campo CD_GRP_DOCTO da tabela.
	 * @param cdGrpDocto valor a ser atribuido.
	 */
	public void setCdGrpDocto(Long cdGrpDocto) {
		this.cdGrpDocto = cdGrpDocto;
	}

	/**
	 * Retorna o valor do atributo cdSitucDocto, que representa o campo CD_SITUC_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public String getCdSitucDocto() {
		return this.cdSitucDocto;
	}

	/**
	 * Atribui o valor ao atributo cdSitucDocto, que representa o campo CD_SITUC_DOCTO da tabela.
	 * @param cdSitucDocto valor a ser atribuido.
	 */
	public void setCdSitucDocto(String cdSitucDocto) {
		this.cdSitucDocto = cdSitucDocto;
	}

	/**
	 * Retorna o valor do atributo cdUsuroUltmaAlter, que representa o campo CD_USURO_ULTMA_ALTER da tabela.
	 * @return valor do atributo.
	 */
	public String getCdUsuroUltmaAlter() {
		return this.cdUsuroUltmaAlter;
	}

	/**
	 * Atribui o valor ao atributo cdUsuroUltmaAlter, que representa o campo CD_USURO_ULTMA_ALTER da tabela.
	 * @param cdUsuroUltmaAlter valor a ser atribuido.
	 */
	public void setCdUsuroUltmaAlter(String cdUsuroUltmaAlter) {
		this.cdUsuroUltmaAlter = cdUsuroUltmaAlter;
	}

	/**
	 * Retorna o valor do atributo dsDocto, que representa o campo DS_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public String getDsDocto() {
		return this.dsDocto;
	}

	/**
	 * Atribui o valor ao atributo dsDocto, que representa o campo DS_DOCTO da tabela.
	 * @param dsDocto valor a ser atribuido.
	 */
	public void setDsDocto(String dsDocto) {
		this.dsDocto = dsDocto;
	}

	/**
	 * Retorna o valor do atributo dtFimVigenDocto, que representa o campo DT_FIM_VIGEN_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public Date getDtFimVigenDocto() {
		return this.dtFimVigenDocto;
	}

	/**
	 * Atribui o valor ao atributo dtFimVigenDocto, que representa o campo DT_FIM_VIGEN_DOCTO da tabela.
	 * @param dtFimVigenDocto valor a ser atribuido.
	 */
	public void setDtFimVigenDocto(Date dtFimVigenDocto) {
		this.dtFimVigenDocto = dtFimVigenDocto;
	}

	/**
	 * Retorna o valor do atributo dtInicoVigenDocto, que representa o campo DT_INICO_VIGEN_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public Date getDtInicoVigenDocto() {
		return this.dtInicoVigenDocto;
	}

	/**
	 * Atribui o valor ao atributo dtInicoVigenDocto, que representa o campo DT_INICO_VIGEN_DOCTO da tabela.
	 * @param dtInicoVigenDocto valor a ser atribuido.
	 */
	public void setDtInicoVigenDocto(Date dtInicoVigenDocto) {
		this.dtInicoVigenDocto = dtInicoVigenDocto;
	}

	/**
	 * Retorna o valor do atributo dtUltmaAlter, que representa o campo DT_ULTMA_ALTER da tabela.
	 * @return valor do atributo.
	 */
	public Date getDtUltmaAlter() {
		return this.dtUltmaAlter;
	}

	/**
	 * Atribui o valor ao atributo dtUltmaAlter, que representa o campo DT_ULTMA_ALTER da tabela.
	 * @param dtUltmaAlter valor a ser atribuido.
	 */
	public void setDtUltmaAlter(Date dtUltmaAlter) {
		this.dtUltmaAlter = dtUltmaAlter;
	}

	/**
	 * Retorna o valor do atributo icDoctoOficl, que representa o campo IC_DOCTO_OFICL da tabela.
	 * @return valor do atributo.
	 */
	public String getIcDoctoOficl() {
		return this.icDoctoOficl;
	}

	/**
	 * Atribui o valor ao atributo icDoctoOficl, que representa o campo IC_DOCTO_OFICL da tabela.
	 * @param icDoctoOficl valor a ser atribuido.
	 */
	public void setIcDoctoOficl(String icDoctoOficl) {
		this.icDoctoOficl = icDoctoOficl;
	}

	/**
	 * Retorna o valor do atributo nmDeptoRespv, que representa o campo NM_DEPTO_RESPV da tabela.
	 * @return valor do atributo.
	 */
	public String getNmDeptoRespv() {
		return this.nmDeptoRespv;
	}

	/**
	 * Atribui o valor ao atributo nmDeptoRespv, que representa o campo NM_DEPTO_RESPV da tabela.
	 * @param nmDeptoRespv valor a ser atribuido.
	 */
	public void setNmDeptoRespv(String nmDeptoRespv) {
		this.nmDeptoRespv = nmDeptoRespv;
	}

	/**
	 * Retorna o valor do atributo qtViaDocto, que representa o campo QT_VIA_DOCTO da tabela.
	 * @return valor do atributo.
	 */
	public Long getQtViaDocto() {
		return this.qtViaDocto;
	}

	/**
	 * Atribui o valor ao atributo qtViaDocto, que representa o campo QT_VIA_DOCTO da tabela.
	 * @param qtViaDocto valor a ser atribuido.
	 */
	public void setQtViaDocto(Long qtViaDocto) {
		this.qtViaDocto = qtViaDocto;
	}
}
