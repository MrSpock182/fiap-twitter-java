package br.com.tokiomarine.acsel.comunicador.mail;

import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.dto.AnexoEmail;
import br.com.tokiomarine.acsel.util.StackLogger;

@Stateless(name = "TokioMail")
@Local(value = Mail.class)
class TokioMail implements Mail {

	private static Logger logger = LogManager.getLogger(TokioMail.class);

	private static final String MAIL_HOST = "mail.host";
	 
	@Inject
	private ProxyMail proxyMail;
	
//	public void send(String subject, String message, String from, List<String> recipientsTO, List<String> recipientsCC) {
//		try {
//			MimeMessage mimeMessage = this.createMimeMessageProperties();
//		    
//			mimeMessage.setFrom(new InternetAddress(from));	
//		    
//			for (String emailTO : recipientsTO) 
//				mimeMessage.addRecipient(RecipientType.TO, new InternetAddress(emailTO));
//			for (String emailCc : recipientsCC) 
//				mimeMessage.addRecipients(RecipientType.CC, emailCc);
//			mimeMessage.setSentDate(new Date());
//			mimeMessage.setSubject(subject);		    
//		    
//		    mimeMessage.setText(message);
//		    
//		    Transport.send(mimeMessage);
//		} catch (MessagingException e) {
//			throw new RuntimeException(e);
//		} 
//	}
	
	public boolean sendMailHtml(String subject, String messageHtml, String from, String[] to, String[] cc, String[] ccOculto, Long seqAgendamento) {
		
		try {
			
			logger.error("Teste log error");
			
			MimeMessage mimeMessage = this.createMimeMessageProperties();
			mimeMessage.setFrom(new InternetAddress(from));
			
			for (String emailTO : to) 
				mimeMessage.addRecipient(RecipientType.TO, new InternetAddress(emailTO));
			for (String emailCc : cc) 
				mimeMessage.addRecipients(RecipientType.CC, emailCc);
			
			for (String emailCcOculto : ccOculto)
				mimeMessage.addRecipients(RecipientType.BCC, emailCcOculto);
				
			mimeMessage.setSentDate(new Date());
			mimeMessage.setSubject(subject);
			
			MimeBodyPart attachment0 = new MimeBodyPart();
			attachment0.setContent(messageHtml, "text/html; charset=UTF-8");
			
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(attachment0);
			mimeMessage.setContent(multipart);
			
			String messageID = mimeMessage.getMessageID();
			logger.info("Agendamento:" + seqAgendamento + ", Message ID:" + messageID);			
			return this.sendProxy(mimeMessage);
			
		} catch (MessagingException e) {
			logger.error(StackLogger.getMessage(e));
			
			//logger.info("ERRO:Agendamento:" + seqAgendamento + ", " + e.getMessage());			
			throw new RuntimeException(e);
		}
		

		//		EmailHTML emailHTML = new EmailHTML(subject, messageHtml, from, Arrays.asList(to));
		//		try {
		//			emailHTML.enviar();
		//		} catch (RemetenteInvalidoException | EnvioDeEmailException e) {
		//			throw new RuntimeException(e);
		//		}
		//		return true;
	}

	public boolean sendMailHtmlAttach(String subject, String messageHtml, String from, String[] to, String[] cc, String[] ccOculto, AnexoEmail[] anexos, Long seqAgendamento) {
		try {
			
			MimeMessage mimeMessage = this.createMimeMessageProperties();
			
			mimeMessage.setFrom(new InternetAddress(from));

			for (String emailTO : to) 
				mimeMessage.addRecipient(RecipientType.TO, new InternetAddress(emailTO));
			
			for (String emailCc : cc) 
				mimeMessage.addRecipients(RecipientType.TO, emailCc);
			
			for (String emailCcOculto : ccOculto)
				mimeMessage.addRecipients(RecipientType.BCC, emailCcOculto);
			
			mimeMessage.setSentDate(new Date());
			mimeMessage.setSubject(subject);
			
			MimeBodyPart attachment0 = new MimeBodyPart();
			attachment0.setContent(messageHtml, "text/html; charset=UTF-8");
			
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(attachment0);
			mimeMessage.setContent(multipart);

			
			for (AnexoEmail anexo : anexos) {
				String typeFile = getTypeFile(anexo.getNome()); 
				MimeBodyPart attachment1 = new MimeBodyPart();   
				attachment1.setDataHandler(new DataHandler(new ByteArrayDataSource(anexo.getBinario(), typeFile)));
				attachment1.setFileName(anexo.getNome());
				multipart.addBodyPart(attachment1);
			}
	        
			String messageID = mimeMessage.getMessageID();
			logger.info("Agendamento:" + seqAgendamento + ", Message ID:" + messageID);			
			return this.sendProxy(mimeMessage);
		} catch (MessagingException e) {
			logger.info("ERRO:Agendamento:" + seqAgendamento + ", " + e.getMessage());			
			throw new RuntimeException(e); 
		} 				
	}	
	
	private MimeMessage createMimeMessageProperties() {
		Properties props = new Properties();
		props.put(MAIL_HOST, this.proxyMail.getEnv());
		props.put("mail.debug", true); 
		props.put("mail.smtp.timeout", 15000);
		Session session = Session.getDefaultInstance(props);
		MimeMessage mimeMessage = new MimeMessage(session);
		return mimeMessage;
	}		

	private String getTypeFile(String fileName) {
		try {
			return "text/"+fileName.substring(fileName.length()-3, fileName.length());
		} catch (Exception e) {
			return "text/txt";
		}
	}	

	private boolean sendProxy(MimeMessage mimeMessage) throws MessagingException {
		try {
			Transport.send(mimeMessage);
//			System.out.println("Email enviado com sucesso!!!");
			return true;
		} catch (Exception e) {
			logger.error("Erro na comunicação com o Proxy: " + (e != null ? e.getMessage() : ""));
			throw new RuntimeException(e);
		}
	}
}
