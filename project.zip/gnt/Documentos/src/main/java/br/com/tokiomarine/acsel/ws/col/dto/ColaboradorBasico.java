
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de colaboradorBasico complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="colaboradorBasico">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cargo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="centroCusto" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="depto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ferias" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="matricula" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "colaboradorBasico", propOrder = {
    "cargo",
    "centroCusto",
    "depto",
    "ferias",
    "matricula",
    "nome"
})
@XmlSeeAlso({
    Colaborador.class
})
public class ColaboradorBasico {

    protected String cargo;
    protected Integer centroCusto;
    protected String depto;
    protected String ferias;
    protected Integer matricula;
    protected String nome;

    /**
     * Obt�m o valor da propriedade cargo.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * Define o valor da propriedade cargo.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCargo(String value) {
        this.cargo = value;
    }

    /**
     * Obt�m o valor da propriedade centroCusto.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getCentroCusto() {
        return centroCusto;
    }

    /**
     * Define o valor da propriedade centroCusto.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setCentroCusto(Integer value) {
        this.centroCusto = value;
    }

    /**
     * Obt�m o valor da propriedade depto.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDepto() {
        return depto;
    }

    /**
     * Define o valor da propriedade depto.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDepto(String value) {
        this.depto = value;
    }

    /**
     * Obt�m o valor da propriedade ferias.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFerias() {
        return ferias;
    }

    /**
     * Define o valor da propriedade ferias.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFerias(String value) {
        this.ferias = value;
    }

    /**
     * Obt�m o valor da propriedade matricula.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getMatricula() {
        return matricula;
    }

    /**
     * Define o valor da propriedade matricula.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setMatricula(Integer value) {
        this.matricula = value;
    }

    /**
     * Obt�m o valor da propriedade nome.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNome(String value) {
        this.nome = value;
    }

}
