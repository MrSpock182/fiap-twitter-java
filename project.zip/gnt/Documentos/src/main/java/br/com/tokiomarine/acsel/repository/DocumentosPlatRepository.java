package br.com.tokiomarine.acsel.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.hibernate.jdbc.ReturningWork;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import br.com.tokiomarine.acsel.dao.BasePlatDAO;
import br.com.tokiomarine.acsel.domain.plt.Segurado;
import br.com.tokiomarine.acsel.dto.BuscaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDigitalDTO;
import br.com.tokiomarine.acsel.dto.DocumentoRecriar;
import br.com.tokiomarine.acsel.dto.DocumentoRegravar;
import br.com.tokiomarine.acsel.dto.EnderecoDTO;
import br.com.tokiomarine.acsel.dto.ItemApoliceDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.type.FormaEnvio;
import br.com.tokiomarine.acsel.type.OpcaoSolic;
import br.com.tokiomarine.acsel.type.TipoDestino;
import br.com.tokiomarine.acsel.util.StringUtil;
import oracle.jdbc.OracleTypes;

@Stateless(name = "DocumentosPlatRepository")
public class DocumentosPlatRepository{

	private static final Logger LOGGER = Logger.getLogger(DocumentosPlatRepository.class.getName());

	@Inject
	BasePlatDAO base;

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<DocumentoDTO> buscaDocumentos(BuscaDocumentosDTO busca){

		String sql =
				"select distinct d.cd_segurado \"codCliente\", " +
				       "d.nm_segurado \"nomeCliente\", " +
				       "e.ds_produto \"descProduto\", " +
				       "decode(nvl(a.cd_endosso_tmsr,0), 0, 'APÓLICE', 'ENDOSSO') \"descDocumento\", " +
				       "a.cd_ramo_produto_tmsr \"ramo\", " +
				       "a.cd_apolice_tmsr \"numApolice\",	" +
				       "decode(a.cd_endosso_tmsr, 0, '', a.cd_endosso_tmsr) \"numEndosso\", " +
				       "'E' \"status\", " +
				       "nvl(a.dt_endosso, a.dt_emissao_apolice) \"dataGeracao\", " +
				       "trunc(b.dt_extracao) \"dataEnvio\", " +
				       "a.cd_corretor \"codCorretor\", " +
				       "b.id_tipo_apolice_endosso \"tipoApoliceEndosso\" " +
				"from v_histo_apolice a, " +
				       "apolice_documento_csf b, " +
				       "segurado d, " +
				       "produto e " +
				"where a.cd_local = b.cd_local " +
					   "and a.cd_ramo = b.cd_ramo " +
					   "and a.cd_apolice = b.cd_apolice " +
					   "and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0) " +
					   "and a.cd_segurado = d.cd_segurado " +
					   "and a.cd_produto = e.cd_produto " +
					   "and b.cd_documento in (1, 2, 15, 30, 107, 108, 109, 110) " +
					   "and b.id_forma_geracao in (1, 3) " +
//				   	   "and b.id_extracao = 'S' " +
					   (busca.isSomenteApolice() ? "and nvl(a.cd_endosso, 0) = 0 " : "") +
					   (StringUtil.isNull(busca.getCodCorretor()) ? "" : "and a.cd_corretor = :codCorretor ") +
					   (StringUtil.isNull(busca.getRamo()) ? "" : "and a.cd_ramo_produto_tmsr = LPAD(:codRamo,3,'0') ") +
					   (busca.getApolice() == null ? "" : "and a.cd_apolice_tmsr = :numApolice ") +
					   (busca.getNumEndosso() == null ? "" : "and a.cd_endosso_tmsr = :numEndosso ") +
					   (busca.getListaClientesPlataforma() == null ? "" : "and d.cd_segurado IN (:codCliente) ") +
					   "and trunc(nvl(a.dt_endosso, a.dt_emissao_apolice)) between :dataIni AND :dataFim " +
			    "union " +
					   "select d.cd_segurado \"codCliente\", " +
					   		"d.nm_segurado \"nomeCliente\", " +
					   		"e.ds_produto \"descProduto\", " +
					   		"decode(nvl(a.cd_endosso_tmsr,0), 0, 'APÓLICE', 'ENDOSSO') \"descDocumento\", " +
					   		"a.cd_ramo_produto_tmsr \"ramo\", " +
					   		"a.cd_apolice_tmsr \"numApolice\", " +
					   		"decode(a.cd_endosso_tmsr, 0, '', a.cd_endosso_tmsr) \"numEndosso\", " +
					   		"'E' \"status\", " +
					   		"nvl(a.dt_endosso, a.dt_emissao_apolice) \"dataGeracao\", " +
					   		"trunc(b.dt_extracao) \"dataEnvio\", " +
					   		"a.cd_corretor \"codCorretor\", " +
					   		"'RES' \"tipoApoliceEndosso\" " +
					    "from v_histo_apolice a, " +
					    	"solicitacao_apolice_resumida b, " +
					    	"segurado d, " +
					    	"produto e " +
					    "where a.cd_local = b.cd_local " +
					    	"and a.cd_ramo = b.cd_ramo " +
					    	"and a.cd_apolice = b.cd_apolice " +
					    	"and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0) " +
					    	"and a.cd_segurado = d.cd_segurado " +
					    	"and a.cd_produto = e.cd_produto " +
					    	"and b.id_segunda_via = 'N' " +
					    	"and b.id_extracao = 'S' " +
					    	(busca.isSomenteApolice() ? "and nvl(a.cd_endosso, 0) = 0 " : "") +
					    	(StringUtil.isNull(busca.getCodCorretor()) ? "" : "and a.cd_corretor = :codCorretor ") +
					    	(StringUtil.isNull(busca.getRamo()) ? "" : "and a.cd_ramo_produto_tmsr = LPAD(:codRamo,3,'0') ") +
					    	(busca.getApolice() == null ? "" : "and a.cd_apolice_tmsr = :numApolice ") +
					    	(busca.getNumEndosso() == null ? "" : "and a.cd_endosso_tmsr = :numEndosso ") +
					    	(busca.getListaClientesPlataforma() == null ? "" : "and d.cd_segurado IN (:codCliente) ") +
					    	"and trunc(nvl(a.dt_endosso, a.dt_emissao_apolice)) between :dataIni AND :dataFim " +
				"union " +
					    "select /*+index(b APDOIR_PK)*/ d.cd_segurado \"codCliente\", " +
					    	"d.nm_segurado \"nomeCliente\", " +
					    	"e.ds_produto \"descProduto\", " +
					    	"decode(nvl(a.cd_endosso_tmsr,0), 0, 'APÓLICE', 'ENDOSSO') \"descDocumento\", " +
					    	"a.cd_ramo_produto_tmsr \"ramo\", " +
					    	"a.cd_apolice_tmsr \"numApolice\", " +
					    	"decode(a.cd_endosso_tmsr, 0, '', a.cd_endosso_tmsr) \"numEndosso\", " +
					    	"'E' \"status\", " +
					    	"nvl(a.dt_endosso, a.dt_emissao_apolice) \"dataGeracao\", " +
					    	"MIN(trunc(b.dt_impressao)) \"dataEnvio\", " +
					    	"a.cd_corretor \"codCorretor\", " +
					   		"null \"tipoApoliceEndosso\" " +
					    "from v_histo_apolice a, " +
					    	"apolice_documento_impre_reali b, " +
					    	"apolice_documento_impressao c, " +
					    	"segurado d, " +
					    	"produto e " +
					    "where a.cd_local = b.cd_local " +
					    "and a.cd_ramo = b.cd_ramo " +
					    "and a.cd_apolice = b.cd_apolice " +
					    "and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0) " +
					    "and b.cd_local = c.cd_local " +
					    "and b.cd_ramo = c.cd_ramo " +
					    "and b.cd_apolice = c.cd_apolice " +
					    "and nvl(b.cd_endosso, 0) = nvl(c.cd_endosso, 0) " +
					    "and b.cd_documento = c.cd_documento " +
					    "and b.cd_sequencia = c.cd_sequencia " +
					    "and a.cd_segurado = d.cd_segurado " +
					    "and a.cd_produto = e.cd_produto " +
					    "and b.cd_documento in (1, 2, 15, 30, 107, 108, 109, 110) " +
					    (busca.isSomenteApolice() ? "and nvl(a.cd_endosso, 0) = 0 " : "" ) +
					    (StringUtil.isNull(busca.getCodCorretor()) ?"":" and a.cd_corretor = :codCorretor ") +
					    (StringUtil.isNull(busca.getRamo()) ?"":" and a.cd_ramo_produto_tmsr = LPAD(:codRamo,3,'0') ") +
					    (busca.getApolice() == null ?"":" and a.cd_apolice_tmsr = :numApolice ") +
					    (busca.getNumEndosso() == null ?"":" and a.cd_endosso_tmsr = :numEndosso ") +
					    (busca.getListaClientesPlataforma() == null || busca.getListaClientesPlataforma().isEmpty() ? "" : "and d.cd_segurado IN (:codCliente) ") +
					    "and trunc(nvl(a.dt_endosso, a.dt_emissao_apolice)) between :dataIni AND :dataFim " +
					    "group by d.cd_segurado,d.nm_segurado,e.ds_produto,a.cd_ramo_produto_tmsr,a.cd_apolice_tmsr, " +
						"a.cd_endosso_tmsr,nvl(a.dt_endosso, a.dt_emissao_apolice),a.cd_corretor " +
				"union " +
						"select d.cd_segurado \"codCliente\", " +
							"d.nm_segurado \"nomeCliente\", " +
							"e.ds_produto \"descProduto\", " +
							"decode(nvl(a.cd_endosso_tmsr,0), 0, 'APÓLICE', 'ENDOSSO') \"descDocumento\", " +
							"a.cd_ramo_produto_tmsr \"ramo\", " +
							"a.cd_apolice_tmsr \"numApolice\", " +
							"decode(a.cd_endosso_tmsr, 0, '', a.cd_endosso_tmsr) \"numEndosso\", " +
							"'E' \"status\", " +
							"nvl(a.dt_endosso, a.dt_emissao_apolice) \"dataGeracao\", " +
							"MIN(trunc(b.dt_envio_email)) \"dataEnvio\", " +
							"a.cd_corretor \"codCorretor\", " +
						   	"null \"tipoApoliceEndosso\" " +
						"from v_histo_apolice a, " +
							"apolice_documento_digital b, " +
							"apolice_documento_impressao c, " +
							"segurado d," +
							"produto e " +
					"where a.cd_local = c.cd_local " +
						"and a.cd_ramo = c.cd_ramo " +
						"and a.cd_apolice = c.cd_apolice " +
						"and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0) " +
						"and b.cd_local = c.cd_local " +
						"and b.cd_ramo = c.cd_ramo " +
						"and b.cd_apolice = c.cd_apolice " +
						"and nvl(b.cd_endosso, 0) = nvl(c.cd_endosso, 0) " +
						"and a.cd_segurado = d.cd_segurado " +
						"and a.cd_produto = e.cd_produto " +
						"and c.cd_documento in (1, 2, 15, 30, 107, 108, 109, 110) " +
						(busca.isSomenteApolice() ? "and nvl(a.cd_endosso, 0) = 0 " : "") +
						(StringUtil.isNull(busca.getCodCorretor()) ? "" : "and a.cd_corretor = :codCorretor ") +
						(StringUtil.isNull(busca.getRamo()) ? "" : "and a.cd_ramo_produto_tmsr = LPAD(:codRamo,3,'0') ") +
						(busca.getApolice() == null ? "" : "and a.cd_apolice_tmsr = :numApolice ") +
						(busca.getNumEndosso() == null ? "" : "and a.cd_endosso_tmsr = :numEndosso ") +
						(busca.getListaClientesPlataforma() == null || busca.getListaClientesPlataforma().isEmpty() ? "" : "and d.cd_segurado IN (:codCliente) ") +
						"and not exists ( SELECT 1 FROM apolice_documento_csf csf " +
					"where csf.cd_local = a.cd_local " +
						"and csf.cd_ramo = a.cd_ramo " +
						"and csf.cd_apolice = a.cd_apolice " +
						"and nvl(csf.cd_endosso, 0) = nvl(a.cd_endosso, 0) ) " +
						"and not exists ( SELECT 1 FROM solicitacao_apolice_resumida res " +
						"where res.cd_local = a.cd_local " +
						"and res.cd_ramo = a.cd_ramo " +
						"and res.cd_apolice = a.cd_apolice " +
						"and nvl(res.cd_endosso, 0) = nvl(a.cd_endosso, 0)) " +
						"and not exists ( SELECT 1 FROM apolice_documento_impre_reali rea " +
						"where rea.cd_local = a.cd_local " +
						"and rea.cd_ramo = a.cd_ramo " +
						"and rea.cd_apolice = a.cd_apolice " +
						"and nvl(rea.cd_endosso, 0) = nvl(a.cd_endosso, 0)) " +
						"and trunc(nvl(a.dt_endosso, a.dt_emissao_apolice)) between :dataIni AND :dataFim " +
						"group by d.cd_segurado,d.nm_segurado,e.ds_produto,a.cd_ramo_produto_tmsr,a.cd_apolice_tmsr, " +
						"a.cd_endosso_tmsr,nvl(a.dt_endosso, a.dt_emissao_apolice),a.cd_corretor ";

		Query q = base.getSession().createSQLQuery(sql)
				.addScalar("codCliente", StandardBasicTypes.STRING)
				.addScalar("nomeCliente")
				.addScalar("descProduto")
				.addScalar("descDocumento")
				.addScalar("ramo", StandardBasicTypes.STRING)
				.addScalar("numApolice", StandardBasicTypes.LONG)
				.addScalar("numEndosso", StandardBasicTypes.INTEGER)
				.addScalar("status", StandardBasicTypes.STRING)
				.addScalar("dataGeracao")
				.addScalar("dataEnvio")
				.addScalar("codCorretor", StandardBasicTypes.STRING)
				.addScalar("tipoApoliceEndosso", StandardBasicTypes.STRING);

		q.setParameter("dataIni", busca.getDataIni());
		q.setParameter("dataFim", busca.getDataFim());

		if (busca.getListaClientesPlataforma() != null && !busca.getListaClientesPlataforma().isEmpty())
			q.setParameterList("codCliente", busca.getListaClientesPlataforma());
		if (!StringUtil.isNull(busca.getRamo()))
			q.setParameter("codRamo", busca.getRamo());
		if (busca.getApolice() != null)
			q.setParameter("numApolice", busca.getApolice());
		if (busca.getNumEndosso() != null)
			q.setParameter("numEndosso", busca.getNumEndosso());
		if (!StringUtil.isNull(busca.getCodCorretor())){
			q.setParameter("codCorretor", busca.getCodCorretor());
		}

		q.setResultTransformer(Transformers.aliasToBean(DocumentoDTO.class));

		return q.list();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<Segurado> buscaSegurados(Long numId, Long numFilial, Long digito){
		return base.getSession().createCriteria(Segurado.class)
				.add(Restrictions.eq("nrCgcCpf", numId))
				.add(Restrictions.eq("nrEstabelecimento", numFilial))
				.add(Restrictions.eq("nrDigitoVerificador", digito))
				.list();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void populaDetalhes(final DocumentoDTO doc) throws ServiceException{

		String msg = base.getSession().doReturningWork(new ReturningWork<String>() {
			@Override
			public String execute(Connection con) throws SQLException {

				CallableStatement callable = con.prepareCall("BEGIN AMLP.PROD2024_010.PRC_RETORNA_DETALHES(:numRamo,:numApolice,:numEndosso,"
						+ ":retorno,:mensagem); END;");

				callable.setString("numRamo", doc.getRamo());
				callable.setString("numApolice", doc.getNumApolice().toString());
				callable.setString("numEndosso", doc.getNumEndosso() == null ? null : doc.getNumEndosso().toString());

				callable.registerOutParameter("retorno", OracleTypes.CURSOR);
				callable.registerOutParameter("mensagem", OracleTypes.VARCHAR);

				callable.execute();

				String mensagem = callable.getString("mensagem");

				if (StringUtil.isNull(mensagem)){
					ResultSet result = (ResultSet)callable.getObject("retorno");

					while (result.next()){
						doc.setDescProduto(result.getString("NOME_PRODUTO"));
						doc.setDataGeracao(result.getTimestamp("DATA_EMISSAO"));
						doc.setId(result.getLong("IDENTIFICADOR"));
						doc.setCodCorretor(result.getString("CD_CORRETOR"));
						doc.setNomeCorretor(result.getString("NM_CORRETOR"));
						doc.setNomeCompanhia(result.getString("SEGURADORA"));

						FormaEnvio formaEnvio = FormaEnvio.getPlataforma(result.getString("CD_TIPO_ENVIO_APOL"));
						if (formaEnvio != null){
							doc.setFormaEnvio(formaEnvio.getValue());
						}

						String tipoDestino = result.getString("CD_DESTINO_ENVIO");
						if (tipoDestino != null){
							if (tipoDestino.equals("1")){
								doc.setTipoDestino(TipoDestino.corretor.getValue());
							} else if (tipoDestino.equals("2")){
								doc.setTipoDestino(TipoDestino.segurado.getValue());
							} else if (tipoDestino.equals("3")){
								doc.setTipoDestino(TipoDestino.seguradoCorretor.getValue());
							}
						}

						doc.setEnderecoEnvio(new EnderecoDTO(0L, result.getString("END_ENVIO")));
						doc.setEmailEnvio(result.getString("EMAIL_ENVIO"));
						doc.setDataEnvioEmail(result.getTimestamp("DATA_ENVIO_EMAIL"));
						doc.setSeqAgendamento(result.getLong("ID_AGENDAMENTO"));
					}

					result.close();
				}
				return mensagem;

			}
		});

		if (!StringUtil.isNull(msg)){
			throw new ServiceException("Erro ao buscar detalhes do documento: " + msg);
		}
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<SegundaViaDTO> buscaSegundaVia(String cdRamo, Long cdApolice, Integer cdEndosso){
		List<SegundaViaDTO> lista = new ArrayList<SegundaViaDTO>();

		String sql = "select b.cd_sequencia \"id\"," +
					 "       nvl(b.dt_solicitacao_seg,b.dt_atualizacao) \"dataSolic\"," +
					 "       b.nm_usuario \"usuarioSolic\"," +
					 "       DECODE(b.id_extracao,'S','E','N','P','C','C') \"status\"," +
					 "       b.cd_aux_solicitante_impressao \"numEndereco\"," +
					 "       decode(b.id_tipo_apolice_endosso,'RES','Kit Completo - Resumida','Kit Completo') \"opcaoSolic\"," +
					 "       decode(b.id_solicitante_impressao,1,'S',2,'C','L') \"tipoDestino\"," +
					 "       b.ds_local_colaborador \"usuarioLocal\"," +
					 "       decode(b.id_solicitante_impressao," +
					 "              4, b.ds_local_envio || ' - ' || b.ds_local_andar,'') \"destinoLocal\"," +
					 "       b.cd_item_apolice \"codItem\"" +
					 "  from v_histo_apolice a, apolice_documento_csf b" +
					 " where a.cd_local = b.cd_local" +
					 "   and a.cd_ramo = b.cd_ramo" +
					 "   and a.cd_apolice = b.cd_apolice" +
					 "   and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0)" +
					 "   and b.cd_documento in (1, 2, 15, 30, 107, 108, 109, 110, 114)" +
					 "   and b.id_forma_geracao = 2" +
					 "   and a.cd_ramo_produto_tmsr = LPAD(:codRamo, 3, '0')" +
					 "   and a.cd_apolice_tmsr = :cdApolice" +
					 "   and nvl(a.cd_endosso_tmsr,0) = :cdEndosso" +
					 "   union " +
					 "select rownum \"id\"," +
					 "       b.dt_solicitacao \"dataSolic\"," +
					 "       b.nm_solicitacao \"usuarioSolic\"," +
					 "       DECODE(b.id_extracao,'S','E','N','P','C','C') \"status\"," +
					 "       1 \"numEndereco\"," +
					 "       'Kit Completo - Resumida' \"opcaoSolic\"," +
					 "       decode(b.id_solicitante_impressao,1,'S',2,'C','L') \"tipoDestino\"," +
					 "       null \"usuarioLocal\"," +
					 "       null \"destinoLocal\"," +
					 "       null \"codItem\"" +
					 "  from v_histo_apolice a, solicitacao_apolice_resumida b" +
					 " where a.cd_local = b.cd_local" +
					 "   and a.cd_ramo = b.cd_ramo" +
					 "   and a.cd_apolice = b.cd_apolice" +
					 "   and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0)" +
					 "   and b.id_segunda_via = 'S'" +
					 "   and a.cd_ramo_produto_tmsr = LPAD(:codRamo, 3, '0')" +
					 "   and a.cd_apolice_tmsr = :cdApolice" +
					 "   and nvl(a.cd_endosso_tmsr,0) = :cdEndosso" +
					 "   union " +
					 "select b.cd_sequencia \"id\"," +
					 "       nvl(b.dt_solicitacao_seg,b.dt_atualizacao) \"dataSolic\"," +
					 "       b.nm_usuario \"usuarioSolic\"," +
					 "       DECODE(b.id_extracao,'S','E','N','P','C','C') \"status\"," +
					 "       b.cd_aux_solicitante_impressao \"numEndereco\"," +
					 "       decode(b.cd_documento,6,'Somente Carnê',113,'Somente Cartão') \"opcaoSolic\"," +
					 "       decode(b.id_solicitante_impressao,1,'S',2,'C','L') \"tipoDestino\"," +
					 "       b.ds_local_colaborador \"usuarioLocal\"," +
					 "       decode(b.id_solicitante_impressao," +
					 "              4, b.ds_local_envio || ' - ' || b.ds_local_andar,'') \"destinoLocal\"," +
					 "       b.cd_item_apolice \"codItem\"" +
					 "  from v_histo_apolice a, apolice_documento_csf b" +
					 " where a.cd_local = b.cd_local" +
					 "   and a.cd_ramo = b.cd_ramo" +
					 "   and a.cd_apolice = b.cd_apolice" +
					 "   and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0)" +
					 "   and b.cd_documento in (6,113)" +
					 "   and b.id_forma_geracao = 2" +
					 "   and a.cd_ramo_produto_tmsr = LPAD(:codRamo, 3, '0')" +
					 "   and a.cd_apolice_tmsr = :cdApolice" +
					 "   and nvl(a.cd_endosso_tmsr,0) = :cdEndosso" +
					 "   and b.dt_solicitacao_seg is not null" +
                     "   and not exists (select 1" +
                     "                   from   apolice_documento_csf c" +
                     "                   where  c.cd_local = b.cd_local" +
                     "                   and    c.cd_ramo = b.cd_ramo" +
                     "                   and    c.cd_apolice = b.cd_apolice" +
                     "                   and    nvl(c.cd_endosso, 0) = nvl(b.cd_endosso, 0)" +
                     "                   and    c.id_forma_geracao = b.id_forma_geracao" +
                     "                   and    c.cd_documento in (1, 2, 15, 30, 107, 108, 109, 110, 114)" +
                     "                   and    trunc(c.dt_solicitacao_seg) = trunc(b.dt_solicitacao_seg)" +
                     "                   and    nvl(c.cd_item_apolice,0) = nvl(b.cd_item_apolice,0))" +
					 "   union " +
					 "select b.cd_sequencia \"id\"," +
					 "       nvl(b.dt_solicitacao_seg,b.dt_atualizacao) \"dataSolic\"," +
					 "       b.nm_usuario \"usuarioSolic\"," +
  					 "       DECODE(b.id_documento_impresso,'S', 'E','N', 'P','C', 'C') \"status\"," +
					 "       b.id_aux_solicitante_impressao \"numEndereco\"," +
					 "       decode(b.cd_documento,108,'Kit Completo - Resumida',110,'Kit Completo - Resumida','Kit Completo') \"opcaoSolic\"," +
					 "       decode(b.id_tipo_solicitante_impre,1,'S',2,'C','L') \"tipoDestino\"," +
					 "       b.ds_local_colaborador \"usuarioLocal\"," +
					 "       decode(b.id_tipo_solicitante_impre," +
					 "              4, b.ds_local_envio || '-' || b.ds_local_andar,'') \"destinoLocal\"," +
					 "       b.cd_item_apolice \"codItem\"" +
					 "  from v_histo_apolice               a," +
					 "       apolice_documento_impressao   b" +
					 " where a.cd_local = b.cd_local" +
					 "   and a.cd_ramo = b.cd_ramo" +
					 "   and a.cd_apolice = b.cd_apolice" +
					 "   and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0)" +
					 "   and b.id_2via = 'S'" +
					 "   and b.cd_documento in (1, 2, 15, 30, 107, 108, 109, 110, 114)" +
					 "   and a.cd_ramo_produto_tmsr = LPAD(:codRamo, 3, '0')" +
					 "   and a.cd_apolice_tmsr = :cdApolice" +
					 "   and nvl(a.cd_endosso_tmsr,0) = :cdEndosso" +
					 "   union " +
					 "select b.cd_sequencia \"id\"," +
					 "       nvl(b.dt_solicitacao_seg,b.dt_atualizacao) \"dataSolic\"," +
					 "       b.nm_usuario \"usuarioSolic\"," +
  					 "       DECODE(b.id_documento_impresso,'S', 'E','N', 'P','C', 'C') \"status\"," +
					 "       b.id_aux_solicitante_impressao \"numEndereco\"," +
					 "       decode(b.cd_documento,6,'Somente Carnê',113,'Somente Cartão') \"opcaoSolic\"," +
					 "       decode(b.id_tipo_solicitante_impre,1,'S',2,'C','L') \"tipoDestino\"," +
					 "       b.ds_local_colaborador \"usuarioLocal\"," +
					 "       decode(b.id_tipo_solicitante_impre," +
					 "              4, b.ds_local_envio || '-' || b.ds_local_andar,'') \"destinoLocal\"," +
					 "       b.cd_item_apolice \"codItem\"" +
					 "  from v_histo_apolice               a," +
					 "       apolice_documento_impressao   b" +
					 " where a.cd_local = b.cd_local" +
					 "   and a.cd_ramo = b.cd_ramo" +
					 "   and a.cd_apolice = b.cd_apolice" +
					 "   and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0)" +
					 "   and b.id_2via = 'S'" +
					 "   and b.cd_documento in (6,113)" +
					 "   and a.cd_ramo_produto_tmsr = LPAD(:codRamo, 3, '0')" +
					 "   and a.cd_apolice_tmsr = :cdApolice" +
					 "   and nvl(a.cd_endosso_tmsr,0) = :cdEndosso" +
					 "   and b.dt_solicitacao_seg is not null" +
					 "   and not exists (select 1" +
					 "                   from   apolice_documento_impressao c" +
					 "                   where  c.cd_local = b.cd_local" +
					 "                   and    c.cd_ramo = b.cd_ramo" +
					 "                   and    c.cd_apolice = b.cd_apolice" +
					 "                   and    nvl(c.cd_endosso, 0) = nvl(b.cd_endosso, 0)" +
					 "                   and    c.cd_documento in (1, 2, 15, 30, 107, 108, 109, 110, 114)" +
					 "                   and    trunc(c.dt_solicitacao_seg) = trunc(b.dt_solicitacao_seg))" +
					 " order by 2 desc, 1 desc";

		lista = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("dataSolic")
				.addScalar("usuarioSolic")
				.addScalar("status")
				.addScalar("numEndereco", StandardBasicTypes.INTEGER)
				.addScalar("opcaoSolic")
				.addScalar("tipoDestino", StandardBasicTypes.STRING)
				.addScalar("usuarioLocal")
				.addScalar("destinoLocal")
				.addScalar("codItem", StandardBasicTypes.STRING)
				.setResultTransformer(Transformers.aliasToBean(SegundaViaDTO.class))
				.setParameter("codRamo", cdRamo)
				.setParameter("cdApolice", cdApolice)
				.setParameter("cdEndosso", (cdEndosso == null ? 0 : cdEndosso))
				.list();

		return lista;

	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<EnderecoDTO> obtemEnderecos(final String codCliente) throws ServiceException{
		final List<EnderecoDTO> lista = new ArrayList<EnderecoDTO>();

		String ret = base.getSession().doReturningWork(new ReturningWork<String>() {
			@Override
			public String execute(Connection con) throws SQLException {

				CallableStatement callable = con.prepareCall("BEGIN AMLP.PROD2024_010.PRC_LISTA_ENDERECO_SEGURADO(:cdSegurado,:cdEndereco,"
						+ ":retorno,:mensagem); END;");

				callable.setString("cdSegurado", codCliente);
				callable.setString("cdEndereco", null);

				callable.registerOutParameter("retorno", OracleTypes.CURSOR);
				callable.registerOutParameter("mensagem", OracleTypes.VARCHAR);

				callable.execute();

				String mensagem = callable.getString("mensagem");

				if (StringUtil.isNull(mensagem)){
					ResultSet result = (ResultSet)callable.getObject("retorno");
					while (result.next()){
						EnderecoDTO end = new EnderecoDTO(result.getLong("CD_ENDERECO_SEGURADO"), result.getString("DS_ENDERECO_SEGURADO"));
						lista.add(end);
					}
					result.close();
				}
				return mensagem;
			}
		});

		if (!StringUtil.isNull(ret)){
			throw new ServiceException("Erro ao buscar endereços do segurado: " + ret);
		}

		return lista;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public EnderecoDTO obtemEnderecoCorretor(String cdCorretor){

		String sql =
				" select nvl(c.ds_ender_correspondencia,c.ds_endereco) || ' - ' ||" +
				"        nvl(c.nm_bairro_correspondencia,c.nm_bairro) || ' - ' ||" +
				"        nvl(c.nm_municipio_correspondencia,c.nm_municipio) || ' - ' ||" +
				"        nvl(c.id_unida_feder_correspondencia,c.id_unidade_federacao) || ' - ' ||" +
				"        nvl(c.id_cep_correspondencia,c.id_cep) \"enderecoFormatado\"" +
				" from   v_corretor c" +
				" where  c.cd_corretor = :codCorretor";

		return (EnderecoDTO) base.getSession().createSQLQuery(sql)
				.setResultTransformer(Transformers.aliasToBean(EnderecoDTO.class))
				.setParameter("codCorretor", cdCorretor)
				.setMaxResults(1)
				.uniqueResult();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public String solicitarSegundaVia(SolicSegundaViaDTO solic){
		return solicitarSegundaVia(solic,null);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public String solicitarSegundaVia(final SolicSegundaViaDTO solic, final String codItem){

		return base.getSession().doReturningWork(new ReturningWork<String>() {
			@Override
			public String execute(Connection con) throws SQLException {
				CallableStatement callable = con.prepareCall("BEGIN AMLP.PROD2024_010.PRC_SOLICITA_SEGUNDA_VIA(:ramo,:apolice,:endosso,:item,:documento,"
						+ ":destino,:solicitante,:impressao,:endereco,:tipoApolice,:tipoDestino,:nomeUsuario,:localUsuario,:andar,:usuario,:motivo,:mensagem); END;");

				callable.setString("ramo", solic.getDocumento().getRamo());
				callable.setString("apolice", solic.getDocumento().getNumApolice().toString());
				callable.setString("endosso", solic.getDocumento().getNumEndosso() == null ? null : solic.getDocumento().getNumEndosso().toString());

				if (codItem != null){
					callable.setString("item", codItem);
				} else{
					callable.setString("item", null);
				}

				callable.setString("documento", OpcaoSolic.getOpcao(solic.getOpcao()).getCodEmpacotador().isEmpty() ? null : OpcaoSolic.getOpcao(solic.getOpcao()).getCodEmpacotador());

				callable.setString("destino", solic.getTipoDestino().getPlataforma().isEmpty() ? "4" : solic.getTipoDestino().getPlataforma());

				if (TipoDestino.corretor.equals(solic.getTipoDestino())){
					callable.setString("solicitante", solic.getDocumento().getCodCorretor());
				} else if (TipoDestino.segurado.equals(solic.getTipoDestino())){
					callable.setString("solicitante", solic.getDocumento().getCodCliente());
				} else{
					callable.setString("solicitante", getCodFuncionario(con, solic.getUsuarioSolic().getIdUsuario()));
				}

				callable.setString("impressao", "S");

				callable.setString("endereco", solic.getNumEndereco() == null ? null : solic.getNumEndereco().toString());

				if (OpcaoSolic.apoliceResumida.equals(OpcaoSolic.getOpcao(solic.getOpcao()))){
					callable.setString("tipoApolice", "RES");
				} else{
					callable.setString("tipoApolice", "COM");
				}

				if (TipoDestino.corretor.equals(solic.getTipoDestino()) || TipoDestino.segurado.equals(solic.getTipoDestino())){
					callable.setString("tipoDestino", "COR");
				} else{
					callable.setString("tipoDestino", "LOC");
				}

				callable.setString("nomeUsuario", solic.getColaborador());
				callable.setString("localUsuario", solic.getLocal());
				callable.setString("andar", solic.getAndarLocalTrabalho());
				callable.setString("usuario", solic.getUsuarioSolic().getCodUsuario());
				callable.setString("motivo", solic.getMotivo());

				callable.registerOutParameter("mensagem", OracleTypes.VARCHAR);

				callable.execute();

				return callable.getString("mensagem");
			}

			private String getCodFuncionario(Connection con, String nmUsuarioSistema) throws SQLException{

				Statement stmt = null;
				String cdFuncionario = null;
				String query = "SELECT CD_FUNCIONARIO FROM FUNCIONARIO WHERE NM_USUARIO_SISTEMA = '" + nmUsuarioSistema + "'";
			    try {
			        stmt = con.createStatement();
			        ResultSet rs = stmt.executeQuery(query);
			        if(rs.next()) {
			        	cdFuncionario = rs.getString("CD_FUNCIONARIO");
			        }
			    } finally {
			        if (stmt != null) { stmt.close(); }
			    }
			    return cdFuncionario;
			}

		});
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<ItemApoliceDTO> buscaItens(final DocumentoDTO doc) throws ServiceException{

		final List<ItemApoliceDTO> lista = new ArrayList<ItemApoliceDTO>();

		String ret = base.getSession().doReturningWork(new ReturningWork<String>() {
			@Override
			public String execute(Connection con) throws SQLException {

				CallableStatement callable = con.prepareCall("BEGIN AMLP.PROD2024_010.PRC_LISTA_DETALHE_ITEM(:numRamo,:numApolice,:numEndosso,:item,"
						+ ":retorno,:mensagem); END;");

				callable.setString("numRamo", doc.getRamo());
				callable.setString("numApolice", doc.getNumApolice().toString());
				callable.setString("numEndosso", doc.getNumEndosso() == null ? null : doc.getNumEndosso().toString());
				callable.setString("item", null);

				callable.registerOutParameter("retorno", OracleTypes.CURSOR);
				callable.registerOutParameter("mensagem", OracleTypes.VARCHAR);

				callable.execute();

				String mensagem = callable.getString("mensagem");

				if (StringUtil.isNull(mensagem)){
					ResultSet result = (ResultSet)callable.getObject("retorno");
					while (result.next()){
						ItemApoliceDTO item = new ItemApoliceDTO();
						item.setCodItem(result.getString("CD_ITEM_APOLICE"));
						item.setDescItem(result.getString("DESCRICAO"));
						lista.add(item);
					}

					result.close();
				}
				return mensagem;
			}
		});

		if (!StringUtil.isNull(ret)){
			throw new ServiceException("Erro ao buscar itens da apólice: " + ret);
		}

		return lista;
	}


	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<OpcaoSolic> obtemOpcoesDocumentos(final DocumentoDTO doc) throws ServiceException{

		final List<OpcaoSolic> lista = new ArrayList<OpcaoSolic>();

		String ret = base.getSession().doReturningWork(new ReturningWork<String>() {
			@Override
			public String execute(Connection con) throws SQLException {
				CallableStatement callable = con.prepareCall("BEGIN AMLP.PROD2024_010.PRC_LISTA_DOCUMENTOS_TMSR(:numRamo,:numApolice,:numEndosso,:tipoOrigem,"
						+ ":retorno,:mensagem); END;");

				callable.setString("numRamo", doc.getRamo());
				callable.setString("numApolice", doc.getNumApolice().toString());
				callable.setString("numEndosso", doc.getNumEndosso() == null ? null : doc.getNumEndosso().toString());
				callable.setString("tipoOrigem", "");

				callable.registerOutParameter("retorno", OracleTypes.CURSOR);
				callable.registerOutParameter("mensagem", OracleTypes.VARCHAR);

				callable.execute();

				String mensagem = callable.getString("mensagem");


				if (StringUtil.isNull(mensagem)){

					HashMap<Integer, OpcaoSolic> mapOpcoes = new HashMap<Integer,OpcaoSolic>();

					ResultSet result = (ResultSet)callable.getObject("retorno");
					while (result.next()){

						Long codDocumento = result.getLong("DOCUMENTO");
						
						if (codDocumento != null){
							if (codDocumento.equals(22L)){
								mapOpcoes.put(1, OpcaoSolic.apoliceComplet);
							} else if (codDocumento.equals(23L)){
								mapOpcoes.put(2, OpcaoSolic.apoliceResumida);
							} else if (codDocumento.equals(4L)){
								mapOpcoes.put(3, OpcaoSolic.carne);
							} else if (codDocumento.equals(28L)){
								mapOpcoes.put(4, OpcaoSolic.cartaoPlat);
							} else if(codDocumento.equals(9L)){
								mapOpcoes.put(5, OpcaoSolic.contaMensal);
							}
							else if(codDocumento.equals(55L)){
								mapOpcoes.put(6, OpcaoSolic.cartaoProtecaoGlobal);
							}
						}
					}

					if (mapOpcoes.containsKey(1)) lista.add(mapOpcoes.get(1));
					if (mapOpcoes.containsKey(2)) lista.add(mapOpcoes.get(2));
					if (mapOpcoes.containsKey(3)) lista.add(mapOpcoes.get(3));
					if (mapOpcoes.containsKey(4)) lista.add(mapOpcoes.get(4));
					if (mapOpcoes.containsKey(5)) lista.add(mapOpcoes.get(5));
					if (mapOpcoes.containsKey(6)) lista.add(mapOpcoes.get(6));

					result.close();
				}
				return mensagem;
			}
		});

		if (!StringUtil.isNull(ret)){
			throw new ServiceException("Erro ao buscar opções do documento: " + ret);
		}

		return lista;
	}


	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<DocumentoDigitalDTO> listaDocumentosDownload(String cdRamoProdutoTmsr, Long cdApoliceTmsr, Integer cdEndossoTmsr) {
		List<DocumentoDigitalDTO> documentosRetorno = new ArrayList<DocumentoDigitalDTO>();
		//Busca os documentos digitais contidos na tabela do CSF
		StringBuilder sqlCsf = new StringBuilder().append( "select c.cd_documento   codDocumento, " +
															   "c.ds_documento   descDocumento, " +
															   "a.ds_url_arquivo dsUrlArquivo " +
														   "from apolice_documento_csf a, v_histo_apolice b, documento_impressao c " +
														   "where a.cd_local = b.cd_local " +
															   "and a.cd_ramo = b.cd_ramo " +
															   "and a.cd_apolice = b.cd_apolice " +
															   "and decode(a.cd_documento,2,(decode(a.id_tipo_apolice_endosso,'COM',109,2)),1,(decode(a.id_tipo_apolice_endosso,'COM',107,1)),a.cd_documento) = c.cd_documento " +
															   "and (a.ds_url_arquivo is not null) " +
															   "and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0) " +
															   "and b.cd_ramo_produto_tmsr = :cdRamoProdutoTmsr " +
															   "and b.cd_apolice_tmsr = :cdApoliceTmsr " +
															   "and nvl(b.cd_endosso_tmsr, 0) = nvl(:cdEndossoTmsr, 0)" );


		List<DocumentoDigitalDTO> documentosCsf = base.getSession().createSQLQuery(sqlCsf.toString())
													  .addScalar("codDocumento", StandardBasicTypes.LONG )
													  .addScalar("descDocumento", StandardBasicTypes.STRING )
													  .addScalar("dsUrlArquivo", StandardBasicTypes.STRING )
													  .setParameter("cdRamoProdutoTmsr", cdRamoProdutoTmsr)
													  .setParameter("cdApoliceTmsr", cdApoliceTmsr)
													  .setParameter("cdEndossoTmsr", cdEndossoTmsr != null ? cdEndossoTmsr : 0)
													  .setResultTransformer(Transformers.aliasToBean(DocumentoDigitalDTO.class))
													  .list();

		StringBuilder sqlDigital = new StringBuilder().append( "select b.cd_documento    codDocumento, " +
													        "c.ds_documento    descDocumento, " +
													        "nvl(b.ds_url_arquivo, b.ds_url_docstore)  dsUrlArquivo " +
													    "from apolice_documento_digital     a, " +
													        "apolice_documento_digital_arq b, " +
													        "documento_impressao           c, " +
													        "v_histo_apolice               d " +
													    "where a.cd_sequencia = b.cd_sequencia " +
														    "and b.cd_documento = c.cd_documento " +
														    "and a.cd_local = d.cd_local " +
														    "and a.cd_ramo = d.cd_ramo " +
														    "and a.cd_apolice = d.cd_apolice " +
														    "and (b.ds_url_arquivo is not null or b.ds_url_docstore is not null) " +
														    "and nvl(a.cd_endosso, 0) = nvl(d.cd_endosso, 0) " +
														    "and d.cd_ramo_produto_tmsr = :cdRamoProdutoTmsr " +
														    "and d.cd_apolice_tmsr = :cdApoliceTmsr " +
														    "and nvl(d.cd_endosso_tmsr, 0) = nvl(:cdEndossoTmsr, 0) " +
														    "and not exists(select 1 from  apolice_documento_csf aa " +
														    		   "where aa.cd_local = a.cd_local " +
																   "and aa.cd_ramo = a.cd_ramo " +
																   "and aa.cd_apolice = a.cd_apolice " +
																   "and nvl(aa.cd_endosso,0 ) = nvl(a.cd_endosso, 0) " +
																   "and aa.id_forma_geracao = 3 " +
																   "and decode(aa.cd_documento,2,(decode(aa.id_tipo_apolice_endosso,'COM',109,2)),1,(decode(aa.id_tipo_apolice_endosso,'COM',107,1)),aa.cd_documento) = b.cd_documento)");

		List<DocumentoDigitalDTO> documentosDigitais = base.getSession().createSQLQuery(sqlDigital.toString())
														   .addScalar("codDocumento", StandardBasicTypes.LONG )
														   .addScalar("descDocumento", StandardBasicTypes.STRING )
														   .addScalar("dsUrlArquivo", StandardBasicTypes.STRING )
														   .setParameter("cdRamoProdutoTmsr", cdRamoProdutoTmsr)
														   .setParameter("cdApoliceTmsr", cdApoliceTmsr)
														   .setParameter("cdEndossoTmsr", cdEndossoTmsr != null ? cdEndossoTmsr : 0)
														   .setResultTransformer(Transformers.aliasToBean(DocumentoDigitalDTO.class))
														   .list();

		HashMap<Long, Boolean> documentosMap = new HashMap<Long, Boolean>();

		if(documentosCsf != null && !documentosCsf.isEmpty())
		{
			for(DocumentoDigitalDTO docCsf : documentosCsf)
			{
				if ( !documentosMap.containsKey(docCsf.getCodDocumento()) ) {
					documentosRetorno.add(docCsf);
					documentosMap.put(docCsf.getCodDocumento(), true);
				}
			}
		}

		if(documentosDigitais != null && !documentosDigitais.isEmpty())
		{
			for(DocumentoDigitalDTO docDigital : documentosDigitais)
			{
				if(!documentosMap.containsKey(docDigital.getCodDocumento()))
				{
					documentosRetorno.add(docDigital);
				}
			}
		}
//		StringBuilder sql = new StringBuilder().append( "select b.cd_documento    codDocumento, " +
//												        "c.ds_documento    descDocumento, " +
//												        "nvl(b.ds_url_arquivo, b.ds_url_docstore)  dsUrlArquivo " +
//												   "from apolice_documento_digital     a, " +
//												        "apolice_documento_digital_arq b, " +
//												        "documento_impressao           c, " +
//												        "v_histo_apolice               d " +
//												  "where a.cd_sequencia = b.cd_sequencia " +
//												    "and b.cd_documento = c.cd_documento " +
//												    "and a.cd_local = d.cd_local " +
//												    "and a.cd_ramo = d.cd_ramo " +
//												    "and a.cd_apolice = d.cd_apolice " +
//												    "and (b.ds_url_arquivo is not null or b.ds_url_docstore is not null) " +
//												    "and nvl(a.cd_endosso, 0) = nvl(d.cd_endosso, 0) " +
//												    "and d.cd_ramo_produto_tmsr = :cdRamoProdutoTmsr " +
//												    "and d.cd_apolice_tmsr = :cdApoliceTmsr " +
//												    "and nvl(d.cd_endosso_tmsr, 0) = nvl(:cdEndossoTmsr, 0) " +
//
//													"UNION " +
//
//													"select a.cd_documento   codDocumento, " +
//													       "c.ds_documento   descDocumento, " +
//													       "a.ds_url_arquivo dsUrlArquivo " +
//													  "from apolice_documento_csf a, v_histo_apolice b, documento_impressao c " +
//													 "where a.cd_local = b.cd_local " +
//													   "and a.cd_ramo = b.cd_ramo " +
//													   "and a.cd_apolice = b.cd_apolice " +
//													   "and decode(a.cd_documento,2,(decode(a.id_tipo_apolice_endosso,'COM',109,2)),1,(decode(a.id_tipo_apolice_endosso,'COM',108,1)),a.cd_documento) = c.cd_documento " +
//													   "and (a.ds_url_arquivo is not null) " +
//													   "and nvl(a.cd_endosso, 0) = nvl(b.cd_endosso, 0) " +
//													   "and b.cd_ramo_produto_tmsr = :cdRamoProdutoTmsr " +
//													   "and b.cd_apolice_tmsr = :cdApoliceTmsr " +
//													   "and nvl(b.cd_endosso_tmsr, 0) = nvl(:cdEndossoTmsr, 0)");

		return documentosRetorno;

	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public String reprocessDocument(final DocumentoDTO doc, final Long codDocumento) throws Exception {
		String ret = null;
		try {
			ret = base.getSession().doReturningWork(new ReturningWork<String>() {

				String mensagem = null;
				String urlArquivo = null;

				@Override
				public String execute(Connection con) throws SQLException {

					CallableStatement callable = con.prepareCall("BEGIN AMLP.PROD2024_010.PRC_RECRIA_URL_ONLINE(:p_cd_ramo_tmsr, :p_cd_apolice_tmsr, "
							+ ":p_cd_endosso_tmsr, :p_cd_documento, :p_id_tipo_apolice_endosso, :p_ds_url_arquivo, :p_mens); END;");

					callable.setString("p_cd_ramo_tmsr", doc.getRamo());
					callable.setLong("p_cd_apolice_tmsr", doc.getNumApolice());
					callable.setLong("p_cd_endosso_tmsr", doc.getNumEndosso() != null ? doc.getNumEndosso() : 0);
					callable.setLong("p_cd_documento", codDocumento);
					callable.setString("p_id_tipo_apolice_endosso", doc.getTipoApoliceEndosso());

					callable.registerOutParameter("p_ds_url_arquivo", OracleTypes.VARCHAR);
					callable.registerOutParameter("p_mens", OracleTypes.VARCHAR);

					callable.execute();

					mensagem = callable.getString("p_mens");
					urlArquivo = callable.getString("p_ds_url_arquivo");

					if (!StringUtil.isNull(mensagem)){
						throw new SQLException("Erro ao buscar opções do documento: " + mensagem);
					}
					return urlArquivo;

				}

			});
		}catch (Exception e) {
			LOGGER.error("Erro ao invocar procedure: AMLP.PROD2024_010.PRC_RECRIA_URL_ONLINE. Parametros:"
							+ " p_cd_ramo_tmsr = " + doc.getRamo()
							+ ", p_cd_apolice_tmsr = " + doc.getNumApolice()
							+ ", p_cd_endosso_tmsr = " + doc.getNumEndosso()
							+ ", p_cd_documento = " + codDocumento
							+ ", p_id_tipo_apolice_endosso = " + doc.getTipoApoliceEndosso(), e);
			throw new Exception(e);
		}
		return ret;
	}


	@SuppressWarnings("unchecked")
	public List<DocumentoRecriar> listaDocument(Date dataInicio) {

		String strSQL = "select b.cd_ramo_produto_tmsr, b.cd_apolice_tmsr, b.cd_endosso_tmsr, a.cd_documento,a.id_tipo_apolice_endosso, a.ds_url_arquivo " +
                        "from apolice_documento_csf a, v_histo_apolice b where  a.cd_local = b.cd_local and a.cd_ramo = b.cd_ramo " +
			            "and a.cd_apolice = b.cd_apolice and nvl(a.cd_endosso,0) = nvl(b.cd_endosso,0) and  a.id_forma_geracao = 3 and  a.id_extracao = 'S'" +
			            "and trunc(a.dt_atualizacao) >= '01-MAR-2017' and trunc(a.dt_atualizacao) <= '31-MAI-2017' " +
			            "and a.cd_documento = 1 and a.ds_url_arquivo is not null";

		List<Object[]> lista = base.getSession().createSQLQuery(strSQL).list();
		if (lista == null || lista.size() == 0) {
			return null;
		}
		List<DocumentoRecriar> listRecriarr = new ArrayList<DocumentoRecriar>();

		for (Object[] objects : lista) {
			DocumentoRecriar doc = new DocumentoRecriar();
			doc.setRamo(objects[0].toString());
			doc.setNumApolice(Long.parseLong( objects[1].toString()));
			doc.setNumEndosso(Integer.parseInt(objects[2].toString()));
			doc.setCodDocumento(objects[3].toString());
			doc.setTipoApoliceEndosso(objects[4].toString());
			doc.setUrl(objects[5].toString());
			listRecriarr.add(doc);
		}
		return listRecriarr;
	}
	
	@SuppressWarnings("unchecked")
	public List<DocumentoRegravar> listaDocument() {
/*		String strSQL = "SELECT DISTINCT A.CD_RAMO, A.CD_APOLICE_TMSR NUM_APOLICE, B.CD_SEQUENCIA CD_SEQUENCIA_CSF, B.DS_URL_ARQUIVO URL_DOCUMENTO_CSF, " + 
        				"D.CD_SEQUENCIA_ARQ  CD_SEQUENCIA_DIGITAL, D.DS_URL_ARQUIVO URL_DOCUMENTO_DIGITAL " + 
				        "FROM V_HISTO_APOLICE A " + 
			            "JOIN APOLICE_DOCUMENTO_CSF B ON (B.CD_LOCAL = A.cd_local AND B.CD_RAMO = A.cd_ramo AND B.CD_APOLICE = A.cd_apolice AND NVL(B.CD_ENDOSSO,0) = NVL(A.CD_ENDOSSO,0)) " + 
			            "JOIN APOLICE_DOCUMENTO_DIGITAL C ON (C.CD_LOCAL = B.CD_LOCAL AND C.CD_RAMO = B.CD_RAMO AND C.CD_APOLICE = B.CD_APOLICE AND NVL(C.CD_ENDOSSO,0) = NVL(B.CD_ENDOSSO,0)) " + 
				        "JOIN APOLICE_DOCUMENTO_DIGITAL_ARQ D ON (D.CD_SEQUENCIA = C.CD_SEQUENCIA " +
				        "AND D.CD_DOCUMENTO = decode(B.cd_documento,2,(decode(B.id_tipo_apolice_endosso,'COM',109,2)),1,(decode(B.id_tipo_apolice_endosso,'COM',107,1)),B.cd_documento) " +
				        "AND D.DS_URL_ARQUIVO <> B.DS_URL_ARQUIVO) " + 
				        "WHERE A.DT_HISTORICO BETWEEN TO_DATE('01/03/2017', 'DD/MM/YYYY') AND TO_DATE('31/03/2018', 'DD/MM/YYYY') " + 
				        "AND B.DS_URL_ARQUIVO IS NOT NULL AND B.CD_DOCUMENTO = 1 AND B.ID_FORMA_GERACAO = 3";
//				        " AND A.cd_apolice_tmsr IN (944622, 944626)";
*/		
		
		
		String strSQL = "SELECT DISTINCT A.CD_RAMO, A.CD_APOLICE_TMSR NUM_APOLICE, B.CD_SEQUENCIA CD_SEQUENCIA_CSF, B.DS_URL_ARQUIVO URL_DOCUMENTO_CSF, " +
		                "D.CD_SEQUENCIA_ARQ  CD_SEQUENCIA_DIGITAL, D.DS_URL_ARQUIVO URL_DOCUMENTO_DIGITAL " + 
		                "FROM V_HISTO_APOLICE A " + 
		                "JOIN APOLICE_DOCUMENTO_CSF B ON (B.CD_LOCAL = A.cd_local AND B.CD_RAMO = A.cd_ramo AND B.CD_APOLICE = A.cd_apolice AND NVL(B.CD_ENDOSSO,0) = NVL(A.CD_ENDOSSO,0)) " + 
		                "JOIN APOLICE_DOCUMENTO_DIGITAL C ON (C.CD_LOCAL = B.CD_LOCAL AND C.CD_RAMO = B.CD_RAMO AND C.CD_APOLICE = B.CD_APOLICE AND NVL(C.CD_ENDOSSO,0) = NVL(B.CD_ENDOSSO,0)) " +
		                "JOIN APOLICE_DOCUMENTO_DIGITAL_ARQ D ON (D.CD_SEQUENCIA = C.CD_SEQUENCIA and D.DS_URL_ARQUIVO is not null AND " + 
		                "D.CD_DOCUMENTO = decode(B.cd_documento,2,(decode(B.id_tipo_apolice_endosso,'RES',110,2)),1,(decode(B.id_tipo_apolice_endosso,'RES',108,1)),B.cd_documento)) " + 
		                "AND D.DS_URL_ARQUIVO <> B.DS_URL_ARQUIVO " +
		                "WHERE A.DT_HISTORICO BETWEEN TO_DATE('01/03/2018', 'DD/MM/YYYY') AND TO_DATE('31/03/2018', 'DD/MM/YYYY') " +
		                "AND B.DS_URL_ARQUIVO IS NOT NULL AND B.CD_DOCUMENTO = 1 AND B.ID_FORMA_GERACAO = 3 " +
		                "and not exists (select '1' from APOLICE_DOCUMENTO_CSF bb " +
		                "where B.CD_LOCAL = bb.cd_local AND B.CD_RAMO = bb.cd_ramo AND B.CD_APOLICE = bb.cd_apolice AND NVL(B.CD_ENDOSSO,0) = NVL(bb.CD_ENDOSSO,0) " +
                        "and Bb.id_tipo_apolice_endosso = 'RES')";
		List<Object[]> lista = base.getSession().createSQLQuery(strSQL).list();
		if (lista == null || lista.size() == 0) {
			return null;
		}
		List<DocumentoRegravar> listRegravar = new ArrayList<DocumentoRegravar>();
		
		for (Object[] objects : lista) {
			DocumentoRegravar doc = new DocumentoRegravar();
			doc.setRamo(objects[0].toString());
			doc.setNumApolice(Long.parseLong( objects[1].toString()));
			doc.setCodDocumentoCsf(Long.parseLong(objects[2].toString()));
			doc.setUrlDocumentoCsf(objects[3].toString());
			doc.setCodDocumentoDigital(Long.parseLong(objects[4].toString()));
			doc.setUrlDocumentoDigital(objects[5].toString());
			listRegravar.add(doc);
		}
		return listRegravar;
	}
	
	
	@SuppressWarnings("unchecked")
	public Map<Integer, Integer> verificaDocumento(final DocumentoDTO doc) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		String sql = "SELECT P.CD_DOCUMENTO_PLAT, CD_DOCUMENTO_DIG from v_histo_apolice HIST " +
		             "JOIN documento_produto P ON P.CD_PRODUTO = HIST.cd_produto WHERE HIST.cd_ramo_produto_tmsr = :ramo" +
				     " AND HIST.cd_apolice_tmsr = :apolice" +
                     " AND NVL(HIST.cd_endosso_tmsr, 0) = :endosso";
		List<Object[]> lista = base.getSession().createSQLQuery(sql).setParameter("ramo", doc.getRamo())
																	.setParameter("apolice", doc.getNumApolice())
																	.setParameter("endosso", doc.getNumEndosso() == null ? 0 : doc.getNumEndosso())
																	.list();
		if (lista == null || lista.size() == 0) {
			return map;
		}
		
		for (Object[] objects : lista) {
			map.put(Integer.parseInt(objects[0].toString()), Integer.parseInt( objects[1].toString()));
		} 
		return map;
	}
	
	
}
