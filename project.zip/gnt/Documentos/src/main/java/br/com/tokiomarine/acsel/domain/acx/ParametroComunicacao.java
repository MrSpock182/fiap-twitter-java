package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PARAMETROS_COMUNICACAO")
public class ParametroComunicacao {

	@Id
	@Column(name="CD_PARAMETRO")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="paramComunicacaoGenerator")
	@SequenceGenerator(name = "paramComunicacaoGenerator", sequenceName = "SQ_PARAMETROS_COMUNICACAO", allocationSize=1)
	
	private Long codParametro;

	@Column(name="NM_PARAMETRO")
	private String nomeParametro;

	@Column(name="DS_PARAMETRO")
	private String descParametro;

	@Column(name="ID_CONSULTA")
	private String indConsulta;
	
	@Column(name="DT_INCLUSAO")
	private Date dtInclusao;
	
	@Column(name="NM_USUARIO_INCLUSAO")
	private String nomeUsuarioInclusao;
	
	@Column(name="DT_ATUALIZACAO")
	private Date dtAtualizacao;

	@Column(name="NM_USUARIO_ATUALIZACAO")
	private String nomeUsuarioAtualizacao;

	public Long getCodParametro() {
		return codParametro;
	}

	public void setCodParametro(Long codParametro) {
		this.codParametro = codParametro;
	}

	public String getNomeParametro() {
		return nomeParametro;
	}

	public void setNomeParametro(String nomeParametro) {
		this.nomeParametro = nomeParametro;
	}

	public String getDescParametro() {
		return descParametro;
	}

	public void setDescParametro(String descParametro) {
		this.descParametro = descParametro;
	}

	public String getIndConsulta() {
		return indConsulta;
	}

	public void setIndConsulta(String indConsulta) {
		this.indConsulta = indConsulta;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDtAtualizacao() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}

	public String getNomeUsuarioAtualizacao() {
		return nomeUsuarioAtualizacao;
	}

	public void setNomeUsuarioAtualizacao(String nomeUsuarioAtualizacao) {
		this.nomeUsuarioAtualizacao = nomeUsuarioAtualizacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((codParametro == null) ? 0 : codParametro.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParametroComunicacao other = (ParametroComunicacao) obj;
		if (codParametro == null) {
			if (other.codParametro != null)
				return false;
		} else if (!codParametro.equals(other.codParametro))
			return false;
		return true;
	}

}