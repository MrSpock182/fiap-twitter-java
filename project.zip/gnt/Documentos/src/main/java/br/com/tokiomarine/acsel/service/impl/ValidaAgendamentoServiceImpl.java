package br.com.tokiomarine.acsel.service.impl;

import java.util.Date;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.comunicador.ValidadorDestino;
import br.com.tokiomarine.acsel.comunicador.ValidadorDestinoFactory;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDocumento;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.dto.AgendamentoComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.ParametroComunicacaoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.AgendamentoComunicacaoRepository;
import br.com.tokiomarine.acsel.repository.ModeloComunicacaoRepository;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.ValidaAgendamentoService;
import br.com.tokiomarine.acsel.type.StatusAgendamento;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "ValidaAgendamentoService")
@Local(value = ValidaAgendamentoService.class)
public class ValidaAgendamentoServiceImpl implements ValidaAgendamentoService {

	private static Logger logger = LogManager.getLogger(ValidaAgendamentoServiceImpl.class);
	
	@Inject
	ModeloComunicacaoRepository modeloDao;
	@Inject
	AgendamentoComunicacaoRepository agendamentoDao; 
	@Inject
	ParametrosRepository parametrosRep;
	@Inject
	private ValidadorDestinoFactory validadorDestinoFactory;

	/***
	 * Método responsavel por validar o AgendamentoComunicacaoDTO primeiro documento enviado para o agendamento.
	 * Valida apenas os parametros enviados.
	 */
	@Override
	public void validaAgendamentoComunicacaoDTO(AgendamentoComunicacaoDTO agendamento) throws ServiceException {
		if(agendamento.getCodigo() != null && !agendamento.getCodigo().isEmpty()) {
			StringBuilder sb = new StringBuilder();
			ModeloComunicacao modelo = modeloDao.obtemModelo(agendamento.getCodigo());
			
			for (ParametroModelo param : modelo.getParametros()) {
				if (param.getIndExibeLista().equals("N") || param.getParametro().getIndConsulta().equals("S")) {
					String valor = agendamento.getValorParametro(param.getParametro().getNomeParametro());
					if (StringUtil.isNull(valor)) {
						sb.append("O parâmetro " + param.getParametro().getNomeParametro() + " não foi informado");
					}
				}
			}
			
			if(sb.length() > 0) {
				logger.info("Código: " + agendamento.getCodigo());
				for (ParametroComunicacaoDTO parametros : agendamento.getParametros()) {
					logger.info("Parametros: " + parametros.getNomeParametro());
				}
				
				throw new ServiceException(sb.toString());
			}	
		}
	}
	
	/***
	 * Método responsavel pela validação do documento de Agendamento enviado.
	 */
	@Override
	public boolean validaAgendamento(AgendamentoEnvio envio) throws ServiceException {
		validaDestinatarios(envio);
		validaDocumentos(envio);
		validaParametros(envio);
		return (!envio.getStatusEnvio().equals(StatusAgendamento.erro.getValue()));
	}

	private void validaDestinatarios(AgendamentoEnvio envio) throws ServiceException{
		if (envio.getAgendamentoDestinatarios() == null || envio.getAgendamentoDestinatarios().isEmpty()){
			incluiErro(envio, "Os destinatários não foram informados");
		}
		
		ValidadorDestino validadorDestino = this.validadorDestinoFactory.getValidador(envio.getAgendamentoModeloCanalComunicacao());
		validadorDestino.executa(envio);

		if (envio.getAgendamentoDestinatariosValidos().isEmpty()){
			incluiErro(envio, "Nunhum destinatário válido foi informado");
		}
	}

	private void validaDocumentos(AgendamentoEnvio envio) throws ServiceException{

		if (envio.getAgendamento().getDocumentos() == null || envio.getAgendamento().getDocumentos().isEmpty()) return;

		for (AgendamentoDocumento doc : envio.getAgendamento().getDocumentos()){
			if (doc.getIndEnviaEmail().equals("S") && StringUtil.isNull(doc.getUrlArquivo())){
				incluiErro(envio, "A URL do documento " + doc.getDocumento().getDescDocumento() + " não foi informada");
			}
		}
	}

	private void validaParametros(AgendamentoEnvio envio) throws ServiceException{
		ModeloComunicacao modelo = modeloDao.obtemModelo(envio.getAgendamento().getModelo().getCodModelo());
		for (ParametroModelo param : modelo.getParametros()){
			if (param.getIndExibeLista().equals("N") || param.getParametro().getIndConsulta().equals("S")){
				String valor = envio.getAgendamento().getValorParametro(param.getParametro().getNomeParametro());
				if (StringUtil.isNull(valor)){
					incluiErro(envio, "O parâmetro " + param.getParametro().getNomeParametro() + " não foi informado");
				}
			}
		}
	}
	
	@Override
	public void incluiErro(AgendamentoEnvio envio, String msgErro){
		envio.setStatusEnvio(StatusAgendamento.erro.getValue());
		AgendamentoErro erro = new AgendamentoErro();
		erro.setDtErro(new Date());
		erro.setDescErro(msgErro);
		erro.setAgendamento(envio); 
		agendamentoDao.incluiAgendamentoErro(erro);
	}
	
}
