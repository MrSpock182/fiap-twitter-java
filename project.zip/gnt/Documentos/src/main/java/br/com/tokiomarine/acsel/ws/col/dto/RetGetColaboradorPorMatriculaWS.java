
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retGetColaboradorPorMatriculaWS complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retGetColaboradorPorMatriculaWS">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="colaborador" type="{http://ws.col.tokiomarine.com.br/}retColaboradorPorMatricula" minOccurs="0"/>
 *         &lt;element name="retorno" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retGetColaboradorPorMatriculaWS", propOrder = {
    "colaborador",
    "retorno"
})
public class RetGetColaboradorPorMatriculaWS {

    protected RetColaboradorPorMatricula colaborador;
    protected String retorno;

    /**
     * Obt�m o valor da propriedade colaborador.
     *
     * @return
     *     possible object is
     *     {@link RetColaboradorPorMatricula }
     *
     */
    public RetColaboradorPorMatricula getColaborador() {
        return colaborador;
    }

    /**
     * Define o valor da propriedade colaborador.
     *
     * @param value
     *     allowed object is
     *     {@link RetColaboradorPorMatricula }
     *
     */
    public void setColaborador(RetColaboradorPorMatricula value) {
        this.colaborador = value;
    }

    /**
     * Obt�m o valor da propriedade retorno.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getRetorno() {
        return retorno;
    }

    /**
     * Define o valor da propriedade retorno.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setRetorno(String value) {
        this.retorno = value;
    }

}
