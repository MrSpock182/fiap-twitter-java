package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@IdClass(MunicipioPK.class)
@Table(name = "MUNICIPIO")
public class Municipio {

	@Id
	@Column(name="CODPAIS")
	private String codPais;

	@Id
	@Column(name="CODESTADO")
	private String codEstado;

	@Id
	@Column(name="CODCIUDAD")
	private String codCiudad;

	@ManyToOne
	@JoinColumns({
        @JoinColumn(updatable=false,insertable=false, name = "CODPAIS", referencedColumnName = "CODPAIS" ),
        @JoinColumn(updatable=false,insertable=false, name = "CODESTADO", referencedColumnName = "CODESTADO"),
        @JoinColumn(updatable=false,insertable=false, name = "CODCIUDAD", referencedColumnName = "CODCIUDAD")})
	private Ciudad ciudad;

	@Id
	@Column(name="CODMUNICIPIO")
	private String codMunicipio;

	@Column(name="DESCMUNICIPIO")
	private String descMunicipio;

	public String getCodPais() {
		return codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public Ciudad getCiudad() {
		return ciudad;
	}

	public void setCiudad(Ciudad ciudad) {
		this.ciudad = ciudad;
	}

	public String getCodMunicipio() {
		return codMunicipio;
	}

	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}

	public String getDescMunicipio() {
		return descMunicipio;
	}

	public void setDescMunicipio(String descMunicipio) {
		this.descMunicipio = descMunicipio;
	}
}