package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class AgendamentoDestinatarioPK implements Serializable {

	private static final long serialVersionUID = 1361670530027017627L;

	private AgendamentoComunicacao agendamento;
	private Integer seqDestinatario;

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}
	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}

	public Integer getSeqDestinatario() {
		return seqDestinatario;
	}
	public void setSeqDestinatario(Integer seqDestinatario) {
		this.seqDestinatario = seqDestinatario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((agendamento == null) ? 0 : agendamento.hashCode());
		result = prime * result
				+ ((seqDestinatario == null) ? 0 : seqDestinatario.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgendamentoDestinatarioPK other = (AgendamentoDestinatarioPK) obj;
		if (agendamento == null) {
			if (other.agendamento != null)
				return false;
		} else if (seqDestinatario == null) {
			if (other.seqDestinatario != null)
				return false;
		} else if (!agendamento.equals(other.agendamento)){
			return false;
		} else if (!seqDestinatario.equals(other.seqDestinatario)){
			return false;
		}

		return true;
	}

}