package br.com.tokiomarine.acsel.consumer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.EnvioComunicacaoService;
import br.com.tokiomarine.seguradora.arquitetura.framework.queue.QueueListenner;
import br.com.tokiomarine.seguradora.arquitetura.framework.queue.QueueManager;

public class EnvioEmailConsumerSingleton implements Runnable {
	
	private static Logger logger = LogManager.getLogger(EnvioEmailConsumerSingleton.class);
	
	private EnvioComunicacaoService envioService;
	private ParametrosRepository parametrosDao;
	
	public EnvioEmailConsumerSingleton(EnvioComunicacaoService envioService,	ParametrosRepository parametrosDao) {
		this.parametrosDao =parametrosDao;
		this.envioService = envioService;
	}
	
	@Override
	public void run() {
		try {
//			PropertyConfigurator.configure(this.getClass().getClassLoader().getResource("META-INF/log4j.properties"));
//			QueueManager.getInstance();
			
			String nomeFila = parametrosDao.obtemVlrParametro("JMS_FILAS", "JMS.FILA.EMAIL");
			QueueManager.getInstance().addQueueListener(nomeFila, new QueueListenner() {
				@Override
				public boolean onReceive(String mensagem) {
					try {
						envioService.enviaAgendamento(Long.parseLong(mensagem));
					} catch (Throwable e) {
						logger.error("Erro ao consumir a mensagem: " + mensagem + " motivo: " + e.getMessage(), e);
					}
					return true;
				}
			});
			
		} catch (Exception e) {
			logger.error("Erro na inicialização da fila");
		}
	}
}
