package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DOCUMENTO_DIGITAL")
public class DocumentoDigital implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_DOCUMENTO") private Long idDocumento;

	@ManyToOne
	@JoinColumns({
        @JoinColumn(name = "SEQARQ", referencedColumnName = "SEQARQ" )})
	private ISeqArq seqArq;

	@Column(name="CODITEM") private String codItem;
	@Column(name="COD_DOCUMENTO") private String codDocumento;
	@Column(name="TIPO_ENVIO") private String tipoEnvio;
	@Column(name="IND_ENVIO_EMAIL") private String indEnvioEmail;
	@Column(name="EMAIL_TO") private String emailTo;
	@Column(name="DATA_ENVIO_EMAIL") private Date dataEnvioEmail;

	@Column(name="IDEPOL") private Long idePol;
	@Column(name="NUMCERT") private Long numCert;
	@Column(name="NUMOPER") private Long numOper;

	public Long getIdDocumento() {
		return idDocumento;
	}
	public void setIdDocumento(Long idDocumento) {
		this.idDocumento = idDocumento;
	}
	public ISeqArq getSeqArq() {
		return seqArq;
	}
	public void setSeqArq(ISeqArq seqArq) {
		this.seqArq = seqArq;
	}
	public String getCodItem() {
		return codItem;
	}
	public void setCodItem(String codItem) {
		this.codItem = codItem;
	}
	public String getCodDocumento() {
		return codDocumento;
	}
	public void setCodDocumento(String codDocumento) {
		this.codDocumento = codDocumento;
	}
	public String getTipoEnvio() {
		return tipoEnvio;
	}
	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}
	public String getIndEnvioEmail() {
		return indEnvioEmail;
	}
	public void setIndEnvioEmail(String indEnvioEmail) {
		this.indEnvioEmail = indEnvioEmail;
	}
	public String getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	public Date getDataEnvioEmail() {
		return dataEnvioEmail;
	}
	public void setDataEnvioEmail(Date dataEnvioEmail) {
		this.dataEnvioEmail = dataEnvioEmail;
	}
	public Long getIdePol() {
		return idePol;
	}
	public void setIdePol(Long idePol) {
		this.idePol = idePol;
	}
	public Long getNumCert() {
		return numCert;
	}
	public void setNumCert(Long numCert) {
		this.numCert = numCert;
	}
	public Long getNumOper() {
		return numOper;
	}
	public void setNumOper(Long numOper) {
		this.numOper = numOper;
	}
}