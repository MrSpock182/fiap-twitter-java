package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class OperPolPK implements Serializable {

	private static final long serialVersionUID = 1L;

	private Poliza poliza;
	private Long numCert;
	private Long numOper;


	public Poliza getPoliza() {
		return poliza;
	}
	public void setPoliza(Poliza poliza) {
		this.poliza = poliza;
	}
	public Long getNumCert() {
		return numCert;
	}
	public void setNumCert(Long numCert) {
		this.numCert = numCert;
	}
	public Long getNumOper() {
		return numOper;
	}
	public void setNumOper(Long numOper) {
		this.numOper = numOper;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numCert == null) ? 0 : numCert.hashCode());
		result = prime * result + ((numOper == null) ? 0 : numOper.hashCode());
		result = prime * result + ((poliza == null) ? 0 : poliza.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OperPolPK other = (OperPolPK) obj;
		if (numCert == null) {
			if (other.numCert != null)
				return false;
		} else if (!numCert.equals(other.numCert))
			return false;
		if (numOper == null) {
			if (other.numOper != null)
				return false;
		} else if (!numOper.equals(other.numOper))
			return false;
		if (poliza == null) {
			if (other.poliza != null)
				return false;
		} else if (!poliza.equals(other.poliza))
			return false;
		return true;
	}
}
