package br.com.tokiomarine.acsel.dto;

import lombok.Getter;

@Getter
public class ComCopiaDTO {
	private String destino;
	private String cpfCnpj;
	private String copiaOculta;
}
