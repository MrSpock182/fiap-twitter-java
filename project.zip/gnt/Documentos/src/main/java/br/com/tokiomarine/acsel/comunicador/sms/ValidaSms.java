package br.com.tokiomarine.acsel.comunicador.sms;

import java.util.Date;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang.StringUtils;

import br.com.tokiomarine.acsel.comunicador.ValidadorDestino;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.repository.AgendamentoErroRepository;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "ValidaSms")
@Local(value = ValidaSms.class)
@Named("validaSms")
public class ValidaSms implements ValidadorDestino {

	@Inject
	private AgendamentoErroRepository agendamentoErroRepository; 	
	
	@Override
	public void executa(AgendamentoEnvio agendamentoEnvio) {
		this.validaSMSs(agendamentoEnvio);
	}
	
	private void validaSMSs(AgendamentoEnvio envio) {
		for (AgendamentoDestinatario cel : envio.getAgendamento().getDestinatarios()){

			if (StringUtil.isNull(cel.getDestinatario())){
				incluiAviso(envio, "O número de telefone celular não foi informado");
			} else if(!StringUtils.isNumeric(cel.getDestinatario())){
				incluiAviso(envio, "O número de telefone celular contém caracteres não numéricos");
			} else if (cel.getDestinatario().length() < 10){
				incluiAviso(envio, "O número de telefone celular " + cel.getDestinatario() + " é inválido");
			//} else if (!CelularUtil.valida(Integer.parseInt(cel.getDestinatario().substring(0, 2)), Integer.parseInt(cel.getDestinatario().substring(2)))){
			//	incluiAviso(envio, "O número de telefone celular " + cel.getDestinatario() + " é inválido");
			} else{
				cel.setIndValido("S");
			}
		}
	}	
	
	public void incluiAviso(AgendamentoEnvio envio, String msgErro){
		AgendamentoErro erro = new AgendamentoErro();
		erro.setDtErro(new Date());
		erro.setDescErro(msgErro);
		erro.setAgendamento(envio);
		this.agendamentoErroRepository.save(erro);
	}	

}
