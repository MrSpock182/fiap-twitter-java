package br.com.tokiomarine.acsel.type;

public enum TipoDestino {


	segurado("S", "SEGURADO", 1L, "1"),
	corretor("C", "CORRETOR", 2L, "2"),
	local("L", "LOCAL", 3L, ""),
	interno("I", "LOCAL", 7L, ""),
	seguradoCorretor("A", "SEGURADO + CORRETOR", null, "3");

	private String value;
	private String descricao;
	private Long ssvValue;
	private String platValue;

	TipoDestino(String value, String desc, Long ssvValue, String platValue) {
		this.value = value;
		this.descricao = desc;
		this.ssvValue = ssvValue;
		this.platValue = platValue;
	}

	public String getValue() {
		return value;
	}

	public String getDescricao() {
		return descricao;
	}

	public Long getSsvValue(){
		return this.ssvValue;
	}

	public String getPlataforma(){
		return this.platValue;
	}

	public static TipoDestino get(String tipoDestino){
		for (TipoDestino tipo : TipoDestino.values()){
			if (tipo.value.equals(tipoDestino)){
				return tipo;
			}
		}
		return null;
	}

	public static TipoDestino getPlataforma(String tipoDestino){
		for (TipoDestino tipo : TipoDestino.values()){
			if (tipo.platValue.equals(tipoDestino)){
				return tipo;
			}
		}
		return null;
	}
}
