package br.com.tokiomarine.acsel.type;

import javax.inject.Inject;
import javax.inject.Named;

import br.com.tokiomarine.acsel.comunicador.Comunicador;
import br.com.tokiomarine.acsel.comunicador.ValidadorDestino;
import br.com.tokiomarine.acsel.comunicador.mail.GNTMail;
import br.com.tokiomarine.acsel.comunicador.mail.ValidaEmail;
import br.com.tokiomarine.acsel.comunicador.sms.GNTSms;
import br.com.tokiomarine.acsel.comunicador.sms.ValidaSms;
import br.com.tokiomarine.acsel.comunicador.push.GNTPush;
import br.com.tokiomarine.acsel.comunicador.push.ValidaPush;

public enum TipoModelo {
	
	@Inject
	email("EMAIL", "E-MAIL") {
		
		@Inject @Named("gntMail")
		private GNTMail gntMail;
		
		@Inject @Named("validaMail")
		private ValidaEmail validaMail;		
		
		public Comunicador getComunicador() {
			return gntMail;
		}
		public ValidadorDestino getValidador() {
			return validaMail;
		}
	},
	@Inject
	sms("SMS", "SMS"){
		
		@Inject
		GNTSms gntSms;

		@Inject @Named("validaSms")
		private ValidaSms validaSms;		
		
		public Comunicador getComunicador() {
			return gntSms;
		}
		
		public ValidadorDestino getValidador() {
			return validaSms;
		}		
		
	},
	@Inject
	push("PUSH", "PUSH NOTIFICATION"){
		
		@Inject
		GNTPush gntPush;
		
		@Inject @Named("validaPush")
		private ValidaPush validaPush;		
		
		public Comunicador getComunicador() {
			return gntPush;
		}

		public ValidadorDestino getValidador() {
			return validaPush;
		}		
	};

	private String value;
	private String descricao;
	
	// TODO: verificar, esta retornando null (Diego)
	public abstract Comunicador getComunicador();
	
	// TODO: verificar, esta retornando null (Diego)
	public abstract ValidadorDestino getValidador();
	
	TipoModelo(String value, String desc) {
		this.value = value;
		this.descricao = desc;
	}
	
	public String getValue() {
		return value;
	}

	public String getDescricao() {
		return descricao;
	}

	public static TipoModelo get(String status){
		for (TipoModelo tipo : TipoModelo.values()){
			if (tipo.value.equals(status)){
				return tipo;
			}
		}
		return null;
	}
	
	
}

