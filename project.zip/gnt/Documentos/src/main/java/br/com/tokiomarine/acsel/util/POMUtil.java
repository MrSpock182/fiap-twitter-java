package br.com.tokiomarine.acsel.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Busca informacoes do arquivo projeto.properties gerado durante o build
 *
 * @author Fernando Boaglio
 */
public class POMUtil {

	private static String name = " ";
	private static String groupId = " ";
	private static String artifactId = " ";
	private static String version = " ";
	private static String data = " ";
	private static String dataNumerica = " ";

	private static final String ARQUIVO_DO_PROJETO = "/projeto.properties";

	private static Logger logger = LogManager.getLogger(POMUtil.class);

	static {
		InputStream inputStream = null;
		try {
			inputStream = POMUtil.class.getResourceAsStream(ARQUIVO_DO_PROJETO);
			if (inputStream != null) {
				Properties p = new Properties();
				p.load(inputStream);
				name = p.getProperty("name");
				groupId = p.getProperty("groupId");
				artifactId = p.getProperty("artifactId");
				version = p.getProperty("version");
				data = p.getProperty("dev.build.timestamp");
				dataNumerica = DateUtil.getDataNumerica(data);
			}
		} catch (Exception e) {
			logger.error("Erro ao ler as propriedades do POM.xml no arquivo: " + ARQUIVO_DO_PROJETO);
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (IOException e) {
				logger.error("Erro ao tentar fechar o stream de leitura do arquivo " + ARQUIVO_DO_PROJETO);
			}
		}

	}

	public static String getName() {
		return name;
	}

	public static String getGroupId() {
		return groupId;
	}

	public static String getArtifactId() {
		return artifactId;
	}

	public static String getVersion() {
		return version;
	}

	public static String getData() {
		return data;
	}

	public static String getDataNumerica() {
		return dataNumerica;
	}

}
