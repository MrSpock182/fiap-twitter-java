package br.com.tokiomarine.acsel.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ModeloComunicacaoDTO {

	private Long codigoModelo;

	@JsonInclude(Include.NON_EMPTY)
	private List<DocumentoComunicacaoDTO> documentos;

	@JsonInclude(Include.NON_EMPTY)
	private List<ParametroComunicacaoDTO> parametros;

	public Long getCodigoModelo() {
		return codigoModelo;
	}

	public void setCodigoModelo(Long codModelo) {
		this.codigoModelo = codModelo;
	}

	public List<DocumentoComunicacaoDTO> getDocumentos() {
		return documentos;
	}

	public void setDocumentos(List<DocumentoComunicacaoDTO> documentos) {
		this.documentos = documentos;
	}

	public List<ParametroComunicacaoDTO> getParametros() {
		return parametros;
	}

	public void setParametros(List<ParametroComunicacaoDTO> parametros) {
		this.parametros = parametros;
	}
}
