package br.com.tokiomarine.acsel.service;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;

public interface AgendamentoErroService {

	AgendamentoErro save(AgendamentoErro erro);

}
