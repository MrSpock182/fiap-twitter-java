package br.com.tokiomarine.acsel.service.impl;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.repository.AgendamentoErroRepository;
import br.com.tokiomarine.acsel.service.AgendamentoErroService;


@Stateless(name = "AgendamentoErroService")
@Local(value = AgendamentoErroService.class)
public class AgendamentoErroServiceImpl implements AgendamentoErroService {

	@Inject
	private AgendamentoErroRepository agendamentoErroRepository;

	@Override
	public AgendamentoErro save(AgendamentoErro agendamentoErro) {
		return this.agendamentoErroRepository.save(agendamentoErro);
	}

}
