package br.com.tokiomarine.acsel.builders;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;

public class AgendamentoDestinatarioBuilder {

	private AgendamentoComunicacao agendamento;
	private int seqDestinatario;
	private String destino;
	private String cpfCnpj;
	private String indValido;

	public static AgendamentoDestinatarioBuilder builder() {
		return new AgendamentoDestinatarioBuilder();
	}

	public AgendamentoDestinatario build() {
		AgendamentoDestinatario destinatario = new AgendamentoDestinatario();
		destinatario.setAgendamento(agendamento);
		destinatario.setSeqDestinatario(seqDestinatario);
		destinatario.setDestinatario(destino);
		destinatario.setCpfCnpj(cpfCnpj);
		destinatario.setIndValido(indValido);
		return destinatario;
	}

	public AgendamentoDestinatarioBuilder agendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
		return this;
	}

	public AgendamentoDestinatarioBuilder seqDestinatario(int seqDestinatario) {
		this.seqDestinatario = seqDestinatario;
		return this;
	}

	public AgendamentoDestinatarioBuilder destino(String destino) {
		this.destino = destino;
		return this;
	}

	public AgendamentoDestinatarioBuilder cpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
		return this;
	}

	public AgendamentoDestinatarioBuilder indValido(String indValido) {
		this.indValido = indValido;
		return this;
	}

}
