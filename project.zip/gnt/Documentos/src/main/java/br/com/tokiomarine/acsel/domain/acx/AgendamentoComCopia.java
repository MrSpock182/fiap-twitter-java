package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@IdClass(AgendamentoComCopiaPK.class)
@Table(name = "AGENDAMENTO_COMUNICACAO_COPIA")
public class AgendamentoComCopia {
	
	@Id
	@ManyToOne
	@JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
	private AgendamentoComunicacao agendamento;

	@Id
	@Column(name="CD_SEQUENCIA_COPIA")
	private Integer seqCopia;

	@Column(name="DS_DESTINATARIO")
	private String destinatario;

	@Column(name="ID_COPIA_VALIDO")
	private String indValido;
	
	@Column(name="DS_COPIA_CPFCNPJ")
	private String cpfCnpj;
	
	@Column(name="ID_COPIA_OCULTA")	
	private String copiaOculta;
	
	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}

	public Integer getSeqCopia() {
		return seqCopia;
	}

	public void setSeqCopia(Integer seqCopia) {
		this.seqCopia = seqCopia;
	}

	public String getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}

	public String getIndValido() {
		return indValido;
	}

	public void setIndValido(String indValido) {
		this.indValido = indValido;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getCopiaOculta() {
		return copiaOculta;
	}

	public void setCopiaOculta(String copiaOculta) {
		this.copiaOculta = copiaOculta;
	}
	
}
