package br.com.tokiomarine.acsel.service.impl;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDocumento;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.ImagemComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.dto.InfoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ModeloComunicacaoRepository;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.EmailParserService;
import br.com.tokiomarine.acsel.util.StringUtil;

/**
 * OBSOLETO Movido para br.com.tokiomarine.acsel.comunicador.mail.BodyMail
 * @author t803520
 *
 */
@Deprecated
@Stateless(name = "EmailParserService")
@Local(value = EmailParserService.class)
public class EmailParserServiceImpl implements EmailParserService {

	private static Logger logger = LogManager.getLogger(EmailParserServiceImpl.class);

	@Inject
	ModeloComunicacaoRepository modeloDao;

	@Inject
	ParametrosRepository padametrosDao;
	
	SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
	
	private ModeloComunicacao modelo;
	private DocumentBuilder builder;
	private Document emailHtml;
	private List<ImagemComunicacao> imagens;
	private HashMap<String, String> parametros;
	private HashMap<String, String> documentos;
	private String codCorretor;

	public EmailParserServiceImpl() throws ServiceException {

		try {
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();

			builder = builderFactory.newDocumentBuilder();

			parametros = new HashMap<String,String>();

			documentos = new HashMap<String, String>();

		} catch (ParserConfigurationException e) {
			logger.error("Erro na configuração do modelo", e);
			throw new ServiceException("Erro na configuração do modelo");
		}
	}

	@Override
	public String geraEmail(ModeloComunicacao mod, List<TextoModeloComunicacao> txtHistorico) throws ServiceException {

		try {
			this.modelo = mod;
			this.emailHtml = builder.parse(new InputSource(new StringReader(this.modelo.getPadrao().getFormatacaoPadrao())));

			this.parametros.clear();

			for (ParametroModelo param : modelo.getParametros()){
				this.parametros.put(param.getParametro().getNomeParametro(), param.getParametro().getNomeParametro());
			}

			this.documentos.clear();

			this.documentos.put("[DOCUMENTO]", "");

			this.imagens = modeloDao.obtemImagens();

			return geraHtml(txtHistorico);

		} catch (SAXException e) {
			logger.error("Erro na configuração do modelo", e);
			throw new ServiceException("Erro na configuração do modelo");
		} catch (IOException e) {
			logger.error("Erro na configuração do modelo", e);
			throw new ServiceException("Erro na configuração do modelo");
		}
	}

	@Override
	public void geraEmail(AgendamentoEnvio envio) throws ServiceException {

		try {

			AgendamentoComunicacao agend = envio.getAgendamento();

			this.modelo = agend.getModelo();

			this.parametros.clear();

			for (ParametroModelo param : modelo.getParametros()){
				this.parametros.put(param.getParametro().getNomeParametro(), agend.getValorParametro(param.getParametro().getNomeParametro()));
			}

			this.emailHtml = builder.parse(new InputSource(new StringReader(this.modelo.getPadrao().getFormatacaoPadrao())));
			this.documentos.clear();

			for(AgendamentoDocumento doc : agend.getDocumentos()){
				if (doc.getIndEnviaEmail().equals("S")){
					this.documentos.put(doc.getDocumento().getDescDocumento(), doc.getUrlArquivo());
				}
			}
			this.imagens = modeloDao.obtemImagens();
			envio.getAgendamento().setMensagemEnviada(geraHtml(null));

		} catch (SAXException e) {
			logger.error("Erro na configuração do modelo", e);
			throw new ServiceException("Erro na configuração do modelo");
		} catch (IOException e) {
			logger.error("Erro na configuração do modelo", e);
			throw new ServiceException("Erro na configuração do modelo");
		}
	}

	private void processaModelo(List<TextoModeloComunicacao> txtHistorico) throws ServiceException{
		NodeList tags = emailHtml.getElementsByTagName("*");

		for (int i = 0; i < tags.getLength(); i++) {
			Element tag = (Element) tags.item(i);

			if (tag.getNodeName().equals("img")){
				if (tag.getAttribute("class").contains("imgFooter") && this.modelo.getCodImagem() != null){
					processaImagem(tag, this.modelo.getCodImagem());
				} else if (tag.getAttribute("class").contains("imgHeader")){
					processaImagem(tag, Long.parseLong(tag.getAttribute("id")));
				}
			}
			if (tag.getAttribute("id").contains("body")){
				incluiTextos(tag, txtHistorico);
			}
		}
	}

	private void incluiTextos(Element tag, List<TextoModeloComunicacao> txtHistorico) throws ServiceException{
		List<TextoModeloComunicacao> textos = null;
		
		if (txtHistorico != null && txtHistorico.size() > 0) {
			textos = txtHistorico;
		} else {
			textos = modelo.getTextos();
		}
		
		try{
			for (TextoModeloComunicacao texto : textos){

				Element el = (Element) createNode(texto.getTextoComunicacao().getFormatacao());

				tag.appendChild(el);

				if (texto.getTextoComunicacao().getTipoTexto().equals("T")){
					processaTexto(el, texto.getTexto());
				} else if (texto.getTextoComunicacao().getTipoTexto().equals("V")){
					processaVariaveis(el);
				} else if (texto.getTextoComunicacao().getTipoTexto().equals("D")){
					processaDocumentos(el);
				} else if (texto.getTextoComunicacao().getTipoTexto().equals("I")){
					processaImagem(el, texto.getCodImagem());
				}
			}
		} catch(Exception e){
			logger.error("Erro ao criar textos", e);
			throw new ServiceException("Erro ao criar textos");
		}
	}

	private void processaTexto(Element tag, String texto) throws ServiceException{

		NodeList tagsVar = ((Element) tag).getElementsByTagName("*");

		if (tagsVar.getLength() == 0){
			incluiTexto(tag, texto);
		} else{
			for (int j = 0; j < tagsVar.getLength(); j++) {

				Element tagVar = (Element) tagsVar.item(j);

				if (tagVar.getAttribute("class").contains("texto")){
					incluiTexto(tagVar, texto);
				}
			}
		}
	}

	private void incluiTexto(Node tag, String texto) throws ServiceException{
		if (texto == null) {
			return;
		}
		
		texto = texto.replaceAll("&nbsp;", " ").replaceAll("<br>", "<br/>");
		try{
			String [] tokens = texto.split("\n");

			for (int i = 0; i < tokens.length; i++) {

				String token = tokens[i];

				String fragment = "<span>" + token + "</span>";

				String[] vars = StringUtils.substringsBetween(token, "[", "]");

				if (vars != null){
					for(String var : vars){
						
						ParametroModelo param;
						String valor = null;
						
						if(var.equals("CENTRAL_ATENDIMENTO")) {
							
							List<InfoDTO> centraisEspeciais = getContatosEspeciais(this.codCorretor, 1, new Date());
							if(centraisEspeciais != null) {
								valor = formatContatosEspeciais(centraisEspeciais);
							} else {
								valor = "0300 33 TOKIO(86546)";
							}
							
							fragment = fragment.replace("["+var+"]", valor);

						} else {
							
							param = obtemParametro(var);
							
							if (this.parametros.containsKey(var)){
								
								if(var.equals("TEL_CORRETOR")) {
									
									List<InfoDTO> telefonesEspeciais = getContatosEspeciais(this.codCorretor, 2, new Date());
									if(telefonesEspeciais != null) {
										valor = formatContatosEspeciais(telefonesEspeciais);
									} else {
										valor = this.parametros.get(var);
									}
									
								} else {
									
									valor = this.parametros.get(var);
								}

								if (valor == null){
									throw new ServiceException("Parâmetro " + var + " não informado");
								}

								if (param.getFormatacao() != null && !param.getFormatacao().isEmpty()){
									fragment = fragment.replace("["+var+"]", param.getFormatacao().replace("[PARAM]", valor));
								} else{
									fragment = fragment.replace("["+var+"]", valor);
								}
							}
						}
					}
				}

				Node fragmentNode = createNode(StringUtil.escapeXml(fragment));
				tag.appendChild(fragmentNode);

				if ((i+1) < tokens.length)
					tag.appendChild(emailHtml.createElement("br"));
			}

		} catch (ServiceException s){
			throw s;
		} catch(Exception e){
			logger.error("Erro ao parsear texto", e);
			throw new ServiceException("Erro ao parsear texto");
		}
	}
	
	private List<InfoDTO> getContatosEspeciais(String codCorretor, int codContato, Date date) {
		
		try {
			String urlBase = padametrosDao.obtemVlrParametro("APOL_DIGITAL", "URL_CORR_ESP_REST");
			
			String corretoresEspeciaisRestUrl = new StringBuilder().append(urlBase)
					.append("/corretores/")
					.append(codCorretor)
					.append("/contatos/")
					.append(codContato)
					.append("/data/")
					.append(sdf.format(date))
					.toString();
		
			RestTemplate restTemplate = new RestTemplate();
			
			return Arrays.asList(restTemplate.getForObject(corretoresEspeciaisRestUrl, InfoDTO[].class));
			
		} catch (Exception e1) {
			logger.error("Erro ao acessar o serviço de corretores especiais para codCorretor: " + codCorretor + ", codContato = 1 e data = " + sdf.format(new Date()));
			return null;
		}
		
	}
	
	private String formatContatosEspeciais(List<InfoDTO> contatosEspeciais) {
		StringBuilder sb = new StringBuilder();
		int aux = 0;
		for(InfoDTO centralDeAtendimento : contatosEspeciais) {
			if(++aux > 1) {
				sb.append(" / ");
			}
			sb.append(centralDeAtendimento.getConteudoInfo());
		}
		return sb.toString();
	}

	private void processaVariaveis(Element tag){
		Node tagClone = tag.cloneNode(true);
		removeChilds(tag);

		for (ParametroModelo param : modelo.getParametros()){

			if (param.getIndExibeLista().equals("S")){

				String valor = this.parametros.get(param.getParametro().getNomeParametro());

				if (valor == null) continue;

				Node var = tagClone.cloneNode(true);

				NodeList tagsVar = ((Element) var).getElementsByTagName("*");

				for (int j = 0; j < tagsVar.getLength(); j++) {

					Element tagVar = (Element) tagsVar.item(j);

					if (tagVar.getAttribute("class").contains("nome")){
						tagVar.setTextContent(param.getNomeExibicao());
					} else if (tagVar.getAttribute("class").contains("valor")){
						tagVar.setTextContent(valor);
					}
				}

				for (int j = 0; j < tagsVar.getLength(); j++) {
					if (tagsVar.item(j).getParentNode().equals(var)){
						tag.appendChild(tagsVar.item(j).cloneNode(true));
					}
				}
			}
		}
	}

	private void processaDocumentos(Element tag){
		Node tagClone = tag.cloneNode(true);
		removeChilds(tag);

		for (String documento : this.documentos.keySet()){

			Node doc = tagClone.cloneNode(true);

			NodeList tagsDoc = ((Element) doc).getElementsByTagName("*");

			for (int j = 0; j < tagsDoc.getLength(); j++) {

				Element tagDoc = (Element) tagsDoc.item(j);

				if (tagDoc.getTagName().equals("a")){
					tagDoc.setAttribute("href", this.documentos.get(documento));
					tagDoc.setTextContent(documento);
				}
			}

			for (int j = 0; j < tagsDoc.getLength(); j++) {
				if (tagsDoc.item(j).getParentNode().equals(doc)){
					tag.appendChild(tagsDoc.item(j).cloneNode(true));
				}
			}
		}
	}

	private void processaImagem(Element tag, Long id) throws ServiceException{
		tag.setAttribute("style", "padding:0px;margin-bottom:15px;margin-top:15px");
		
		NodeList tagsVar = ((Element) tag).getElementsByTagName("*");
	

		if (tagsVar.getLength() == 0){
			setImagem(tag, id);
		} else{
			for (int j = 0; j < tagsVar.getLength(); j++) {

				Element tagVar = (Element) tagsVar.item(j);

				if (tagVar.getNodeName().equals("img")){
					setImagem(tagVar, id);
				}
			}
		}
	}

	private void setImagem(Element tag, Long id){

		ImagemComunicacao img = buscaImagem(id);

		tag.setAttribute("src", img.getUrl());
		tag.setAttribute("alt", img.getDescImagem());
		tag.setAttribute("width", img.getLargura().toString());
		tag.setAttribute("height", img.getAltura().toString());

	}

	private ImagemComunicacao buscaImagem(Long id){
		for (ImagemComunicacao imagem : this.imagens) {
			if (imagem.getCodImagem().equals(id)){
				return imagem;
			}
		}
		return null;
	}

	private ParametroModelo obtemParametro(String nomeParam){
		for (ParametroModelo param : this.modelo.getParametros()) {
			if (param.getParametro().getNomeParametro().equals(nomeParam)){
				return param;
			}
		}
		return null;
	}

	private String geraHtml(List<TextoModeloComunicacao> txtHistorico) throws ServiceException{
		try{

			processaModelo(txtHistorico);

			Transformer trans = defineTransformer();
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);
			DOMSource source = new DOMSource(emailHtml);
			trans.transform(source, result);

			return new String(sw.toString().getBytes("UTF-8"), "UTF-8");

		} catch (Exception e){
			logger.error("Erro ao formatar e-mail", e);
			throw new ServiceException("Erro ao formatar e-mail");
		}
	}

	private Transformer defineTransformer() throws TransformerFactoryConfigurationError, TransformerConfigurationException {
		Transformer trans;
		TransformerFactory transfac = TransformerFactory.newInstance();
		trans = transfac.newTransformer();
		DOMImplementation domImpl = emailHtml.getImplementation();
		DocumentType doctype = domImpl.createDocumentType("html",
			    "-//W3C//DTD XHTML 1.0 Transitional//EN",
			    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
		trans.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, doctype.getPublicId());
		trans.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype.getSystemId());
		trans.setOutputProperty(OutputKeys.INDENT, "yes");
		trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		return trans;
	}

	private Node createNode(String fragment) throws ServiceException{
		fragment = ajustarTexto(fragment);
		Node fragmentNode;
		try {
			fragmentNode = builder.parse(new InputSource(new StringReader(fragment))).getDocumentElement();
			return emailHtml.importNode(fragmentNode, true);
		} catch (Exception e) {
			logger.error("Erro ao processar HTML", e);
			throw new ServiceException("Erro ao processar HTML");
		}
	}
	
	private String ajustarTexto(String texto) {
		StringBuilder strBuilder = new StringBuilder(texto.replaceAll("<br>", "<br/>"));
		int posTagImg = 0;
		
		do {
			posTagImg = strBuilder.indexOf("<img ", posTagImg);
			if (posTagImg > 0) {
				for (; posTagImg < strBuilder.length(); posTagImg++) {
					if (strBuilder.substring(posTagImg, posTagImg + 2).equals("/>")) {
						break;
					}
					
					if (strBuilder.substring(posTagImg, posTagImg + 1).equals(">")) {
						strBuilder.insert(posTagImg, "/");
						break;
					}
				}
			}
		} 	
		while (posTagImg > 0);
		
        return strBuilder.toString();		
	}

	private void removeChilds(Element element){
		NodeList recList = element.getChildNodes();
		int len = recList.getLength();
		for (int i = 0; i < len; i++) {
			element.removeChild(recList.item(0));
		}
	}
}
