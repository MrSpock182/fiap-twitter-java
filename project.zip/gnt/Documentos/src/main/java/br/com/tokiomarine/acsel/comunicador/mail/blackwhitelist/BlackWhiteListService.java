package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist;

public interface BlackWhiteListService {

	BlackListResource getBlackList(String destino);

}
