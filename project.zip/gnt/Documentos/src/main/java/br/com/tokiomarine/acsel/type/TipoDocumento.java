package br.com.tokiomarine.acsel.type;

public enum TipoDocumento {


	apolice("A", "APÓLICE"),
	endosso("E", "ENDOSSO"),
	pec("C", "PEC"),
	cav("V", "CAV"),
	dual("D", "CARTAS");

	private String value;
	private String descricao;

	TipoDocumento(String value, String desc) {
		this.value = value;
		this.descricao = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDescricao() {
		return descricao;
	}

	public static TipoDocumento get(String tipoDocumento){
		for (TipoDocumento tipo : TipoDocumento.values()){
			if (tipo.value.equals(tipoDocumento)){
				return tipo;
			}
		}
		return null;
	}
}
