package br.com.tokiomarine.acsel.dto;

public class ResumoAgendamentoDTO {

	private String nomeModelo;
	private String tipoModelo;
	private String nomeSistema;
	private Integer qtdEnviados;
	private Integer qtdNaoEnviados;
	private Integer qtdErro;

	public String getNomeModelo() {
		return nomeModelo;
	}
	public void setNomeModelo(String nomeModelo) {
		this.nomeModelo = nomeModelo;
	}
	public String getTipoModelo() {
		return tipoModelo;
	}
	public void setTipoModelo(String tipoModelo) {
		this.tipoModelo = tipoModelo;
	}
	public String getNomeSistema() {
		return nomeSistema;
	}
	public void setNomeSistema(String nomeSistema) {
		this.nomeSistema = nomeSistema;
	}
	public Integer getQtdEnviados() {
		return qtdEnviados;
	}
	public void setQtdEnviados(Integer qtdEnviados) {
		this.qtdEnviados = qtdEnviados;
	}
	public Integer getQtdNaoEnviados() {
		return qtdNaoEnviados;
	}
	public void setQtdNaoEnviados(Integer qtdNaoEnviados) {
		this.qtdNaoEnviados = qtdNaoEnviados;
	}
	public Integer getQtdErro() {
		return qtdErro;
	}
	public void setQtdErro(Integer qtdErro) {
		this.qtdErro = qtdErro;
	}

}
