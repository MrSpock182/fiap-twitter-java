package br.com.tokiomarine.acsel.type;

public enum OpcaoSolic {

	kitCompleto(1, "1", "Kit Completo", "Kit Completo", true),
	apolCartao(2, "3", "Somente Cartão", "Cartão", true),
	endosso(3, "1", "Kit Completo", "Endosso", true),
	endossoCartao(4, "R", "Endosso com Cartão", "Endosso com Cartão", true),
	padrao(5, "1", "Padrão", "Documento", false),

	apoliceComplet(6, "", "Kit Completo", "Kit Completo", false),
	apoliceResumida(7, "", "Kit Completo - Apólice Resumida", "Kit Completo", false),
	cartaoPlat(8, "113", "Somente Cartão", "Cartão", true),
	carne(9, "6", "Somente Carnê", "Carnê", false),
	contaMensal(10, "30", "Conta Mensal", "Conta Mensal", false),
	cartaoProtecaoGlobal(11, "114", "Somente Cartão", "Cartão Proteção Global", false),
	
	kitCompletoAUTF(1, "1", "Kit Completo", "Kit Completo", false),
	endossoAUTF(3, "1", "Kit Completo", "Endosso", false);

	private Integer codOpcao;
	private String codEmpacotador;
	private String descOpcao;
	private String descDocumento;
	private Boolean permiteMultiItem;

	OpcaoSolic(Integer cod, String codEmpacotador, String opcao, String documento, Boolean permiteMultiItem) {
		this.codOpcao = cod;
		this.codEmpacotador = codEmpacotador;
		this.descDocumento = documento;
		this.descOpcao = opcao;
		this.permiteMultiItem = permiteMultiItem;
	}

	public Integer getCodOpcao() {
		return codOpcao;
	}

	public String getCodEmpacotador() {
		return codEmpacotador;
	}

	public String getDescOpcao() {
		return descOpcao;
	}

	public String getDescDocumento(){
		return descDocumento;
	}

	public Boolean getPermiteMultiItem() {
		return permiteMultiItem;
	}

	public static OpcaoSolic getOpcao(Integer opcao){
		for (OpcaoSolic tipo : OpcaoSolic.values()){
			if (tipo.codOpcao.equals(opcao)){
				return tipo;
			}
		}
		return null;
	}
}