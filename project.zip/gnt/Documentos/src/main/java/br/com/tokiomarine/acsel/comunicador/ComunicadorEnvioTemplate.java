/* 
 * Copyright (C) 2017 Tokio Marine - T803520 | @diegolirio
 * Template de Envio para Comunicacao
 */
package br.com.tokiomarine.acsel.comunicador;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.exception.ServiceException;

public abstract class ComunicadorEnvioTemplate implements Comunicador {

	@Override 
	public void enviar(AgendamentoEnvio agendamentoEnvio) throws ServiceException {
		Boolean reenvio = (agendamentoEnvio.getAgendamento().getQuantidadeEnvios() > 0);
		if (!reenvio) {
			String mensagem = this.geraMensagem(agendamentoEnvio);
			agendamentoEnvio.setAgendamentoComunicacaoMensagemEnviada(mensagem);
		}
		this.enviarMensagem(agendamentoEnvio);
	}
 
	protected abstract void enviarMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException;

	protected abstract String geraMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException; 
	
}
