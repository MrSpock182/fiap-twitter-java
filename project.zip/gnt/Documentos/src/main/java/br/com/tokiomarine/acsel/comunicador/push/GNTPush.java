package br.com.tokiomarine.acsel.comunicador.push;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jboss.resteasy.client.ClientRequest;
import org.jboss.resteasy.client.ClientResponse;
import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;

import br.com.tokiomarine.acsel.comunicador.ComunicadorEnvioTemplate;
import br.com.tokiomarine.acsel.comunicador.mail.GNTMail;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.dto.MensagemPushDTO;
import br.com.tokiomarine.acsel.dto.PushNotificationDTO;
import br.com.tokiomarine.acsel.dto.RetornoPushNotificationDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.ValidaAgendamentoService;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "GNTPush")
@Local(value = GNTMail.class)
@Named("gntPush")
public final class GNTPush extends ComunicadorEnvioTemplate {

	private static Logger logger = LogManager.getLogger(GNTPush.class);
	
	@Inject
	ParametrosRepository parametrosDao;
	
	@Inject
	ValidaAgendamentoService validaAgendamento;	
	
	@Override
	protected void enviarMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException {
		try {

			for (AgendamentoDestinatario dest : agendamentoEnvio.getAgendamento().getDestinatariosValidos()){

				PushNotificationDTO push = new PushNotificationDTO();

				push.setFinalidade("cobranca_cliente");
				push.setDestinatario(dest.getCpfCnpj());
				push.setTitulo(agendamentoEnvio.getTitulo());
				Map<String, String> mensagens = agendamentoEnvio.getAgendamento().getMensagens();
				push.setChamada(mensagens.get("chamada"));
				push.setDataDeValidade((int) new Date().getTime());
				
				MensagemPushDTO key = new MensagemPushDTO();

				for (ParametroModelo param : agendamentoEnvio.getAgendamento().getModelo().getParametros()){
					if (param.getIndExibeLista().equals("S")){
						key.getKey().put(param.getNomeExibicao(), agendamentoEnvio.getAgendamento().getValorParametro(param.getParametro().getNomeParametro()));
					}
				}

				if (key.getKey().isEmpty()){
					push.setMensagem(mensagens.get("mensagem"));
					push.setMensagemKey(null);
				} else{
					push.setMensagem(null);
					key.setValue(mensagens.get("mensagem"));
					push.setMensagemKey(key);
				}

				ClientRequest request = new ClientRequest(parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "URL_SERVICE_SEND"));

				MultivaluedMap<String, String> headers = request.getHeaders();
				headers.putSingle("user-token", parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "USER_TOKEN"));

				ClientResponse<RetornoPushNotificationDTO> response =
						request.body(MediaType.APPLICATION_JSON_TYPE, push).post(RetornoPushNotificationDTO.class);

				RetornoPushNotificationDTO dadosRetorno = response.getEntity();

				if (dadosRetorno.getData() != null){ 
					if (dadosRetorno.getData().getErros() != null && !dadosRetorno.getData().getErros().isEmpty()){
						for (String msgErro : dadosRetorno.getData().getErros()){
							validaAgendamento.incluiErro(agendamentoEnvio, msgErro);
						}
					}
				} else if (!StringUtil.isNull(dadosRetorno.getBusinessException())){
					validaAgendamento.incluiErro(agendamentoEnvio, dadosRetorno.getBusinessException());
				} else{
					throw new ServiceException("Retorno inválido ao enviar notificação");
				}
			}

		} catch(ServiceException s){
			throw s;
		} catch (Exception e){
			logger.error("Erro ao enviar push notification", e);
			throw new ServiceException("Erro ao enviar push notification");
		}
	}

	@Override
	protected String geraMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException {
		String mesangem = "";
		
		AgendamentoComunicacao agend = agendamentoEnvio.getAgendamento();
		ModeloComunicacao modelo = agend.getModelo();

		Map<String, String> parametros = new HashMap<String,String>();
		for (ParametroModelo param : modelo.getParametros()){
			parametros.put(param.getParametro().getNomeParametro(), agend.getValorParametro(param.getParametro().getNomeParametro()));
		}

		Map<String, String> params = new HashMap<String,String>();
		for (TextoModeloComunicacao texto : modelo.getTextos()){
			if (texto.getTextoComunicacao().getTipoTexto().equals("P")){
				params.put("chamada", formataTexto(parametros, texto.getTexto()));
			} else{
				params.put("mensagem", formataTexto(parametros, texto.getTexto()));
			}
		}

		try {
			//agendamentoEnvio.getAgendamento().setMensagemEnviada(StringUtil.serialize(parametros));
			mesangem = StringUtil.serialize(params);
		} catch (JsonProcessingException e) {
			logger.error("Erro ao formatar mensagem", e);
			throw new ServiceException("Erro ao formatar mensagem");
		}		
		return mesangem;
	}

	private String formataTexto(Map<String, String> parametros, String texto) throws ServiceException{

		String txtRetorno = texto;

		String[] vars = StringUtils.substringsBetween(texto, "[", "]");

		if (vars != null){
			for(String var : vars){
					if (parametros.containsKey(var)){
						String valor = parametros.get(var);
						if (valor == null){
						throw new ServiceException("Parâmetro " + var + " não informado");
					}
						txtRetorno = txtRetorno.replace("["+var+"]", valor);
				}
			}
		}
		return txtRetorno;
	}	
	
}
