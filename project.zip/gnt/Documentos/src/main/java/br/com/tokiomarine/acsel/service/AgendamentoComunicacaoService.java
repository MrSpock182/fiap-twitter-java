package br.com.tokiomarine.acsel.service;

import java.util.Date;
import java.util.List;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.dto.AgendamentoComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.BuscaAgendamentoDTO;
import br.com.tokiomarine.acsel.dto.EmailDataEnvioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface AgendamentoComunicacaoService {

	List<AgendamentoComunicacao> buscaAgendamentos(BuscaAgendamentoDTO busca) throws ServiceException;

	AgendamentoComunicacao obtemAgendamento(Long id);

	AgendamentoComunicacao obtemAgendamentoCompleto(Long id);

	List<AgendamentoErro> obtemErros(Long id);

	AgendamentoComunicacao incluiAgendamento(AgendamentoComunicacaoDTO agendamentoDTO) throws ServiceException;

	void atualizaAgendamento(AgendamentoComunicacaoDTO agendamentoDTO) throws ServiceException;
	
	void atualizaAgendamento(AgendamentoComunicacao agendamentoComunicacao);	
	
	EmailDataEnvioDTO obtemDataEnvioEmail(Long idereg);
	
	boolean existAgendamento (Long codModelo);

	List<AgendamentoComunicacao> buscaAgendamentosPiloto() throws ServiceException;
	
	List<AgendamentoComunicacao> buscaAgendamentosPiloto(String codigo, Date dataAgendamento); 	

}