package br.com.tokiomarine.acsel.service;

import java.util.List;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface EmailParserService {

	String geraEmail(ModeloComunicacao mod, List<TextoModeloComunicacao> txtHist) throws ServiceException;

	void geraEmail(AgendamentoEnvio envio) throws ServiceException;

}