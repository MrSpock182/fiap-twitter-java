package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(CiudadPK.class)
@Table(name = "CIUDAD")
public class Ciudad {

	@Id
	@Column(name="CODPAIS")	private String codPais;
	@Id
	@Column(name="CODESTADO")	private String codEstado;
	@Id
	@Column(name="CODCIUDAD")	private String codCiudad;

	@Column(name="DESCCIUDAD")	private String descCiudad;
	@Column(name="CODCIUDADFISCAL")	private Long codCiudadFiscal;
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public String getCodCiudad() {
		return codCiudad;
	}
	public void setCodCiudad(String codCiudad) {
		this.codCiudad = codCiudad;
	}
	public String getDesc() {
		return descCiudad;
	}
	public void setDesc(String descCiudad) {
		this.descCiudad = descCiudad;
	}
	public Long getCodCiudadFiscal() {
		return codCiudadFiscal;
	}
	public void setCodCiudadFiscal(Long codCiudadFiscal) {
		this.codCiudadFiscal = codCiudadFiscal;
	}
}