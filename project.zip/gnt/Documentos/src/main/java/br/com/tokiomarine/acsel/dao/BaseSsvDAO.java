package br.com.tokiomarine.acsel.dao;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;

public class BaseSsvDAO {

	@PersistenceContext(unitName="entityManagerSSV")
	private EntityManager entityManager;

	public Session getSession(){
		return entityManager.unwrap(Session.class);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void persist(Object entity){
		entityManager.persist(entity);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Object merge(Object entity){
		return entityManager.merge(entity);
	}
}
