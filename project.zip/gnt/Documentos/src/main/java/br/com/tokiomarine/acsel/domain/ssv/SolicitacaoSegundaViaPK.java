package br.com.tokiomarine.acsel.domain.ssv;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * Classe que representa a chave primária (primary key) da tabela EMP0062_SOLCT_SEGDA_VIA_DOCTO.
 */
@SuppressWarnings("serial")
public class SolicitacaoSegundaViaPK implements Serializable {
	/** Atributo que mapeia o campo DT_HORA_SOLCT. */
	@Id
	@Column(name="DT_HORA_SOLCT",nullable=false)
	public Date dtHoraSolct;
	/** Atributo que mapeia o campo ID_DOCTO_FISCO. */
	@Id
	@Column(name="ID_DOCTO_FISCO",nullable=false)
	public Long idDoctoFisco;

	/**
	 * Construtor da classe.
	 */
	public SolicitacaoSegundaViaPK() {
	}

	/**
	 * Construtor da classe.
	 * @param dtHoraSolct valor do atributo dtHoraSolct
	 * @param idDoctoFisco valor do atributo idDoctoFisco
	 */
	public SolicitacaoSegundaViaPK(Date dtHoraSolct,Long idDoctoFisco) {
		this.dtHoraSolct = dtHoraSolct;
		this.idDoctoFisco = idDoctoFisco;
	}

	public boolean equals(Object other) {
		if(other instanceof SolicitacaoSegundaViaPK) {
			final SolicitacaoSegundaViaPK pk = (SolicitacaoSegundaViaPK) other;
			boolean ret = (pk.dtHoraSolct.equals(dtHoraSolct) && pk.idDoctoFisco.equals(idDoctoFisco));
			return ret;
		}
		return false;
	}

	public int hashCode() {
		return dtHoraSolct.hashCode() ^ idDoctoFisco.hashCode();
	}

}