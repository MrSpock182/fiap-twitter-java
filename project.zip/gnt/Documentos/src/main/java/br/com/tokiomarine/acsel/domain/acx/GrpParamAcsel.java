package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_GRP_PARAM_ACSEL")
public class GrpParamAcsel {

	@Id
	@Column(name="ID_GRP_PARAMETRO")	private Integer idGrpParametro;

	@Column(name="COD_GRP_PARAMETRO")	private String codGrpParametro;

	@Column(name="DESC_GRP_PARAMETRO")	private String descGrpParametro;

	public Integer getIdGrpParametro() {
		return idGrpParametro;
	}

	public void setIdGrpParametro(Integer idGrpParametro) {
		this.idGrpParametro = idGrpParametro;
	}

	public String getCodGrpParametro() {
		return codGrpParametro;
	}

	public void setCodGrpParametro(String codGrpParametro) {
		this.codGrpParametro = codGrpParametro;
	}

	public String getDescGrpParametro() {
		return descGrpParametro;
	}

	public void setDescGrpParametro(String descGrpParametro) {
		this.descGrpParametro = descGrpParametro;
	}
}