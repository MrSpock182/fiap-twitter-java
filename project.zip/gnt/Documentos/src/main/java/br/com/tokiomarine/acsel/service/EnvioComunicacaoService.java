package br.com.tokiomarine.acsel.service;

import br.com.tokiomarine.acsel.dto.AgendamentoComunicacaoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface EnvioComunicacaoService {

	boolean solicitaEnvio(Long seqAgendamento) throws ServiceException;

	void reprocessaEnvio(Long seqAgendamento) throws ServiceException;

	void enviaAgendamento(Long envioId) throws ServiceException;

	void solicitaReenvio(Long seqAgendamento, String usuario) throws ServiceException;

	void validaAgendamentoDTO(AgendamentoComunicacaoDTO agendamento) throws ServiceException;
	
}