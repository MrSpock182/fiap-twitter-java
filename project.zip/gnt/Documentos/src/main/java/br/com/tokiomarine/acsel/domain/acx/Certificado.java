package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@IdClass(CertificadoPK.class)
@Table(name = "CERTIFICADO")
public class Certificado {

	@Id
	@ManyToOne
	@JoinColumn(name="IDEPOL", referencedColumnName="IDEPOL")
	private Poliza poliza;

	@Id
	@Column(name="NUMCERT")	private Long numCert;

	@Column(name="STSCERT")	private String stsCert;
	@Column(name="DESCCERT")	private String descCert;

	@Column(name="FECING")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecIng;

	@Column(name="FECFIN")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecFin;

	@ManyToOne
	@JoinColumn(name="CODCLI", referencedColumnName="CODCLI")
	private Cliente cliente;


	@Column(name="CodOfiSUSC")	private String codOfiSusc;
	@Column(name="CodOfiEMI")	private String codOfiEmi;
	@Column(name="FECEXC")	@Temporal(TemporalType.TIMESTAMP)	private Date fecExc;
	@Column(name="CODMOTVEXC")	private String codMotvExc;
	@Column(name="TEXTMOTVEXC")	private String textMotvExc;
	@Column(name="CODGRUPO")	private String codGrupo;
	@Column(name="CODCANAL")	private String codCanal;
	@Column(name="CODSUBCANAL")	private String codSubCanal;
	@Column(name="FILIAL")	private String filial;
	@Column(name="OFFICER")	private String officer;
	@Column(name="BRANCH")	private String branch;
	@Column(name="INSPOR")	private String insPor;
	@Column(name="INDEXCLUIR")	private String indExcluir;


	public Poliza getPoliza() {
		return poliza;
	}
	public void setPoliza(Poliza poliza) {
		this.poliza = poliza;
	}
	public Long getNumCert() {
		return numCert;
	}
	public void setNumCert(Long numCert) {
		this.numCert = numCert;
	}
	public String getStsCert() {
		return stsCert;
	}
	public void setStsCert(String stsCert) {
		this.stsCert = stsCert;
	}
	public String getDescCert() {
		return descCert;
	}
	public void setDescCert(String descCert) {
		this.descCert = descCert;
	}
	public Date getFecIng() {
		return fecIng;
	}
	public void setFecIng(Date fecIng) {
		this.fecIng = fecIng;
	}
	public Date getFecFin() {
		return fecFin;
	}
	public void setFecFin(Date fecFin) {
		this.fecFin = fecFin;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public String getCodOfiSusc() {
		return codOfiSusc;
	}
	public void setCodOfiSusc(String codOfiSusc) {
		this.codOfiSusc = codOfiSusc;
	}
	public String getCodOfiEmi() {
		return codOfiEmi;
	}
	public void setCodOfiEmi(String codOfiEmi) {
		this.codOfiEmi = codOfiEmi;
	}
	public Date getFecExc() {
		return fecExc;
	}
	public void setFecExc(Date fecExc) {
		this.fecExc = fecExc;
	}
	public String getCodMotvExc() {
		return codMotvExc;
	}
	public void setCodMotvExc(String codMotvExc) {
		this.codMotvExc = codMotvExc;
	}
	public String getTextMotvExc() {
		return textMotvExc;
	}
	public void setTextMotvExc(String textMotvExc) {
		this.textMotvExc = textMotvExc;
	}
	public String getCodGrupo() {
		return codGrupo;
	}
	public void setCodGrupo(String codGrupo) {
		this.codGrupo = codGrupo;
	}
	public String getCodCanal() {
		return codCanal;
	}
	public void setCodCanal(String codCanal) {
		this.codCanal = codCanal;
	}
	public String getCodSubCanal() {
		return codSubCanal;
	}
	public void setCodSubCanal(String codSubCanal) {
		this.codSubCanal = codSubCanal;
	}
	public String getFilial() {
		return filial;
	}
	public void setFilial(String filial) {
		this.filial = filial;
	}
	public String getOfficer() {
		return officer;
	}
	public void setOfficer(String officer) {
		this.officer = officer;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getInsPor() {
		return insPor;
	}
	public void setInsPor(String insPor) {
		this.insPor = insPor;
	}
	public String getIndExcluir() {
		return indExcluir;
	}
	public void setIndExcluir(String indExcluir) {
		this.indExcluir = indExcluir;
	}
	@Override
	public String toString() {
		return "Certificado [poliza=" + poliza + ", numCert=" + numCert
				+ ", stsCert=" + stsCert + ", descCert=" + descCert
				+ ", fecIng=" + fecIng + ", fecFin=" + fecFin + ", cliente="
				+ cliente + ", codOfiSusc=" + codOfiSusc + ", codOfiEmi="
				+ codOfiEmi + ", fecExc=" + fecExc + ", codMotvExc="
				+ codMotvExc + ", textMotvExc=" + textMotvExc + ", codGrupo="
				+ codGrupo + ", codCanal=" + codCanal + ", codSubCanal="
				+ codSubCanal + ", filial=" + filial + ", officer=" + officer
				+ ", branch=" + branch + ", insPor=" + insPor + ", indExcluir="
				+ indExcluir + "]";
	}



}