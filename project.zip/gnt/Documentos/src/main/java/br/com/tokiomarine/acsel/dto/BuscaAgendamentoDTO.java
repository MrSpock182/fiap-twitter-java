package br.com.tokiomarine.acsel.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author T803520
 *
 */
public class BuscaAgendamentoDTO {

	private Long codModelo;
	private Long seqAgendamento;
	private String destinatario;
	private String cpfCnpj;
	private String tipoEnvio;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "GMT-3")
	private Date dataIni;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "GMT-3")
	private Date dataFim;
	private List<ParametroComunicacaoDTO> parametros;
	private Boolean novaBusca = false;

	public Long getCodModelo() {
		return codModelo;
	}
	public void setCodModelo(Long codModelo) {
		this.codModelo = codModelo;
	}
	public Long getSeqAgendamento() {
		return seqAgendamento;
	}
	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}
	public String getDestinatario() {
		return destinatario;
	}
	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}
	public String getCpfCnpj() {
		return cpfCnpj;
	}
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	
	public String getTipoEnvio() {
		return tipoEnvio;
	}
	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}
	public Date getDataIni() {
		return dataIni;
	}
	public void setDataIni(Date dataIni) {
		this.dataIni = dataIni;
	}
	public Date getDataFim() {
		return dataFim;
	}
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}
	public List<ParametroComunicacaoDTO> getParametros() {
		return parametros;
	}
	public void setParametros(List<ParametroComunicacaoDTO> parametros) {
		this.parametros = parametros;
	}
	public Boolean getNovaBusca() {
		return novaBusca;
	}
	public void setNovaBusca(Boolean novaBusca) {
		this.novaBusca = novaBusca;
	}
	public String obtemValorParametro(Long codParametro){
		if (this.parametros == null) return null;

		for (ParametroComunicacaoDTO param : this.parametros){
			if (param.getCodParametro().equals(codParametro))
				return param.getValorParametro();
		}
		return null;
	}
}
