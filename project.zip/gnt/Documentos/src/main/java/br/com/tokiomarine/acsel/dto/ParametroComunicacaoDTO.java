package br.com.tokiomarine.acsel.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ParametroComunicacaoDTO {

	@JsonInclude(Include.NON_NULL)
	private Long seqAgendamento;
	@JsonInclude(Include.NON_NULL)
	private Long codParametro;
	@JsonInclude(Include.NON_NULL)
	private String descParametro;
	@JsonInclude(Include.NON_NULL)
	private String nomeParametro;
	@JsonInclude(Include.NON_NULL)
	private String valorParametro;

	public Long getSeqAgendamento() {
		return seqAgendamento;
	}
	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}
	public Long getCodParametro() {
		return codParametro;
	}
	public void setCodParametro(Long codParametro) {
		this.codParametro = codParametro;
	}
	public String getDescParametro() {
		return descParametro;
	}
	public void setDescParametro(String descParametro) {
		this.descParametro = descParametro;
	}
	public String getNomeParametro() {
		return nomeParametro;
	}
	public void setNomeParametro(String nomeParametro) {
		this.nomeParametro = nomeParametro;
	}
	public String getValorParametro() {
		return valorParametro;
	}
	public void setValorParametro(String valorParametro) {
		this.valorParametro = valorParametro;
	}
}
