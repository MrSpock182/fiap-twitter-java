package br.com.tokiomarine.acsel.domain.plt;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SEGURADO")
public class Segurado {

	@Id
	@Column(name="CD_SEGURADO",nullable=false)
	private Long cdSegurado;

	@Column(name="ID_TIPO_SEGURADO",nullable=false)
	private String tipoSegurado;

	@Column(name="NR_CGC_CPF_SEGURADO",nullable=false)
	private Long nrCgcCpf;

	@Column(name="NR_ESTABELECIMENTO_SEGURADO",nullable=false)
	private Long nrEstabelecimento;

	@Column(name="NR_DIGITO_VERIFICADOR",nullable=false)
	private Long nrDigitoVerificador;

	@Column(name="NM_SEGURADO",nullable=false)
	private String nomeSegurado;

	public Long getCdSegurado() {
		return cdSegurado;
	}

	public void setCdSegurado(Long cdSegurado) {
		this.cdSegurado = cdSegurado;
	}

	public String getTipoSegurado() {
		return tipoSegurado;
	}

	public void setTipoSegurado(String tipoSegurado) {
		this.tipoSegurado = tipoSegurado;
	}

	public Long getNrCgcCpf() {
		return nrCgcCpf;
	}

	public void setNrCgcCpf(Long nrCgcCpf) {
		this.nrCgcCpf = nrCgcCpf;
	}

	public Long getNrEstabelecimento() {
		return nrEstabelecimento;
	}

	public void setNrEstabelecimento(Long nrEstabelecimento) {
		this.nrEstabelecimento = nrEstabelecimento;
	}

	public Long getNrDigitoVerificador() {
		return nrDigitoVerificador;
	}

	public void setNrDigitoVerificador(Long nrDigitoVerificador) {
		this.nrDigitoVerificador = nrDigitoVerificador;
	}

	public String getNomeSegurado() {
		return nomeSegurado;
	}

	public void setNomeSegurado(String nomeSegurado) {
		this.nomeSegurado = nomeSegurado;
	}

}
