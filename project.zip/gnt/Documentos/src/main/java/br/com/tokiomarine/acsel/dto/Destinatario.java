package br.com.tokiomarine.acsel.dto;

import lombok.Getter;

@Getter
public class Destinatario {

	private String destino, cpfCnpj;
	
} 
 