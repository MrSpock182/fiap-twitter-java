package br.com.tokiomarine.acsel.service;

import java.util.Collection;

import br.com.tokiomarine.acsel.dto.ModeloComunicacaoSistemaOrigem;

public interface ModeloComunicacaoSistemaOrigemService {

	Collection<ModeloComunicacaoSistemaOrigem> findAll();
	
}
