package br.com.tokiomarine.acsel.dto;

public class DocumentoImpressaoDTO {
	
	private Integer cdDocumento;
	private String dsDocumento;

	public Integer getCdDocumento() {
		return cdDocumento;
	}
	public void setCdDocumento(Integer cdDocumento) {
		this.cdDocumento = cdDocumento;
	}
	public String getDsDocumento() {
		return dsDocumento;
	}
	public void setDsDocumento(String dsDocumento) {
		this.dsDocumento = dsDocumento;
	}
	
}
