package br.com.tokiomarine.acsel.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.hibernate.SQLQuery;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.hibernate.jdbc.ReturningWork;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.IEspelhoEmp;
import br.com.tokiomarine.acsel.dto.BuscaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.EnderecoDTO;
import br.com.tokiomarine.acsel.dto.ItemApoliceDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.oracle.OracleUserType;
import br.com.tokiomarine.acsel.type.OpcaoSolic;
import br.com.tokiomarine.acsel.type.StatusDocumento;
import br.com.tokiomarine.acsel.util.Constants;
import br.com.tokiomarine.acsel.util.StringUtil;
import oracle.jdbc.OracleTypes;

public class EmpacotadorRepository{

	private static Logger logger = LoggerFactory.getLogger(EmpacotadorRepository.class);

	@Inject
	BaseAcxDAO base;

	@SuppressWarnings("unchecked")
	public List<DocumentoDTO> buscaDocumentos(BuscaDocumentosDTO busca){

		String sql =
				"SELECT DISTINCT EMP.IDEREG \"id\", " +
					"DOC.CODDOC \"codDocumento\", " +
					"DOC.NOMDOC \"descDocumento\", " +
					"CLI.CODCLIENTE \"codCliente\", " +
					"TER.NOMTER \"nomeCliente\", " +
					"DOC.DATA \"dataGeracao\", " +
					"ARQ.DTENVIO \"dataEnvio\", " +
					"PCL.CODRAMOCLI \"ramo\", " +
					"APO.NUMPOL \"numApolice\", " +
	                "DECODE(OPE.NUMENDOSO, 0, DECODE(CAT.CODIGO, NULL, NULL, 0), OPE.NUMENDOSO) \"numEndosso\", " +    // 13/06/2018 - WILSON           					
//					"DECODE(OPE.NUMENDOSO,0,NULL,OPE.NUMENDOSO) \"numEndosso\", " +                                    // 13/06/2018 - WILSON
					"PCL.CODNEG \"numNegocio\", " +
					"DOC.CODPAC \"codPacote\", " +
					"DOC.NOMPAC \"descPacote\", " +
					"APO.CODCIA \"codCompanhia\", " +
					"CIA.NOMCIA \"nomeCompanhia\", " +
					"INT.CODINTERCLI \"codCorretor\", " +
					"DOC.DESTINO \"tipoDestino\", " +
					"NVL(OPC.ID_TIPO_ENVIO,'01') \"formaEnvio\", " +
					"DECODE(EMP.INDPROCESADO, " +
						"'S', 'E', " +
						"'P') \"status\", " +
					"OPE.IDEPOL \"idePol\", " +
					"OPE.NUMCERT \"numCert\", " +
					"OPE.NUMOPER \"numOper\", " +
					"SUBSTR(OPE.TIPOOP,1,3) \"tipoOper\", " +
					"'N' \"indMultiItem\", " +
					"PRO.CODPROD \"codProduto\", " +
					"PRO.DESCPROD \"descProduto\", " +
					"OPC.CODMODPROD \"codModProd\", " +
					"CAT.CODIGO \"tipoEndosso\", " +
					"CAT.DESC_EMPACOTADOR \"descEndosso\", " +
					"ARQ.CODITEM \"codItem\" " +
				"FROM   POLIZA APO, " +
					"PRODUCTO PRO, " +
					"POLIZA_CLI PCL, " +
					"PART_INTER_POL PIP, " +
					"INTERMEDIARIO INT, " +
					"OPER_POL OPE, " +
					"OPER_POL_CLI OPC, " +
					"CATEG_ENDOSSO CAT, " +
					"MAESTRO_CIA CIA, " +
					"CLIENTE CLI, " +
					"TERCERO TER, " +
					"I_SEQ_ARQ ARQ, " +
					"I_ESPELHO_EMP EMP, " +
					"(SELECT DISTINCT I.IDEREG, " +
						"D.CODDOC, " +
						"D.NOMDOC, " +
						"P.CODPAC, " +
						"P.NOMPAC, " +
						"I.LINHA, " +
						"DECODE(E.CODITEM,'54',TO_DATE(SUBSTR(I.LINHA, 5, 8), 'YYYYMMDD'),TRUNC(S.DTENVIO)) DATA, " +
						"DECODE(E.CODITEM,'54',SUBSTR(I.LINHA, 13, 1),'S') DESTINO, " +
						"DECODE(E.CODITEM,'54',SUBSTR(I.LINHA, 181, 1),'1') FORMAENVIO " +
					"FROM I_ESPELHO_EMPACOTADOR I, " +
						"I_ESPELHO_EMP         E, " +
						"I_SEQ_ARQ             S, " +
						"EMPACOTADOR_DOCUMENTO D, " +
						"EMPACOTADOR_PACOTE    P " +
					"WHERE I.CODDOC = D.CODDOC " +
						"AND I.CODPAC = P.CODPAC " +
						"AND I.IDEREG = E.IDEREG " +
						"AND E.CODITEM= S.CODITEM " +
						"AND E.SEQARQ = LPAD(S.SEQARQ,7,'0') " +
						"AND I.CODDOC NOT IN ('DOC00480', " +
						"'DOC00490', " +
						"'DOC005', " +
						"'DOC00461', " +
						"'DOC00410', " +
						"'DOC00470', " +
						"'DOC02060', " +
						"'DOC02061', " +
						"'DOC02062', " +
						"'DOC02063', " +
						"'DOC02065')) DOC " +
				"WHERE  APO.IDEPOL   = PCL.IDEPOL " +
					"AND    APO.CODPROD  = PRO.CODPROD " +
					"AND    APO.IDEPOL   = OPE.IDEPOL " +
					"AND    APO.CODCLI   = CLI.CODCLI " +
					"AND    APO.IDEPOL   = PIP.IDEPOL " +
					"AND    OPE.IDEPOL   = OPC.IDEPOL " +
					"AND    OPE.NUMCERT  = OPC.NUMCERT " +
					"AND    OPE.NUMOPER  = OPC.NUMOPER " +
					"AND    OPC.TPALT    = CAT.CODIGO (+) " +
					"AND    APO.CODCIA   = CIA.CODCIA " +
					"AND    PIP.INDLIDER = 'S' " +
					"AND    PIP.CODINTER = INT.CODINTER " +
					"AND    CLI.TIPOID   = TER.TIPOID " +
					"AND    CLI.NUMID    = TER.NUMID " +
					"AND    CLI.DVID     = TER.DVID " +
					"AND    lpad(OPE.IDEPOL,14,'0')  = SUBSTR(EMP.CHAVEGENERICA,1,14) " +
					"AND    lpad(OPE.NUMCERT,10,'0') = SUBSTR(EMP.CHAVEGENERICA,15,10) " +
//					"AND    lpad(OPE.NUMOPER,14,'0') = SUBSTR(EMP.CHAVEGENERICA,25,14) " +   //27/06/2018 - DESATIVADO WILSON (P/ SELECIONAR ENDOSSO ESM PROCH-69)
                    "AND    OPE.TIPOOP NOT IN ('CNP', 'CNF') " +                             //27/06/2018 - WILSON (P/ SELECIONAR ENDOSSO ESM PROCH-69)
					"AND    ARQ.SEQARQ  = TO_NUMBER(EMP.SEQARQ) " +
					"AND    DOC.IDEREG  = EMP.IDEREG " +
//					"AND    ARQ.CODITEM IN ('54') " +
					"AND    ARQ.CODITEM IN ('54', '80') " +
					"AND    EMP.CHAVEGENERICA NOT IN (select EMP.CHAVEGENERICA from i_espelho_emp EMP , " +
	                       									"OPER_POL_CLI OPE " +
	                       							 "WHERE  OPE.IDEPOL  = TO_NUMBER(SUBSTR(EMP.CHAVEGENERICA, 1, 14)) " +
	                       							 "AND OPE.NUMCERT = TO_NUMBER(SUBSTR(EMP.CHAVEGENERICA, 15, 10)) " +
//	                       							 "AND OPE.NUMOPER = TO_NUMBER(SUBSTR(EMP.CHAVEGENERICA, 25, 14)) " +  //27/06/2018 - DESATIVADO WILSON (P/ SELECIONAR ENDOSSO ESM PROCH-69)
	                       							 "and OPE.IDEPOL = apo.idepol " +
	                       							 "AND    substr(EMP.livre,1,3) = 'ESM' " +
	                       							 "AND    OPE.TPALT IN ('B','D','F')) " +
				(busca.isSomenteApolice()?" AND SUBSTR(EMP.LIVRE,1,3) IN ('EMI','EMC') ":
					"AND SUBSTR(EMP.LIVRE,1,3) IN ('EMI','EMC','ESM','ECO','ECA','ERE','PEC','CAV') ") +
				(StringUtil.isNull(busca.getCodCorretor()) ?"":" AND INT.CODINTERCLI = :codCorretor ") +
				(busca.getApolice() == null ?" AND NVL2(TRIM(SUBSTR(EMP.CHAVEGENERICA,80,20)),'S', 'N') = 'N' ":" AND APO.NUMPOL = :numApolice ") +
				(StringUtil.isNull(busca.getRamo()) ?"":" AND PCL.CODRAMOCLI = LPAD(:codRamo,3,'0') ") +
				(busca.getNumEndosso() == null ?"":" AND OPE.NUMENDOSO = :numEndosso ") +
				(busca.getNegocio() == null ?"":" AND PCL.CODNEG = :numNegocio ") +
				(busca.getListaClientes() == null || busca.getListaClientes().isEmpty() ? "":" AND CLI.CODCLIENTE IN (:codCliente) ") +
				" AND OPE.FECMOV BETWEEN :dataIni AND :dataFim ";

		if (busca.getApolice() == null && busca.getNumEndosso() == null){
			// busca multi item
			sql = sql + "UNION ALL	" +
					"SELECT DISTINCT " +
					"ARQ.SEQARQ \"id\", " +
					"DOC.CODDOC \"codDocumento\", " +
					"DOC.NOMDOC \"descDocumento\", " +
					"CLI.CODCLIENTE \"codCliente\", " +
					"TER.NOMTER \"nomeCliente\", " +
					"DOC.DATA \"dataGeracao\", " +
					"ARQ.DTENVIO \"dataEnvio\", " +
					"NULL \"ramo\", " +
					"NULL \"numApolice\", " +
					"NULL \"numEndosso\", " +
					"PCL.CODNEG \"numNegocio\", " +
					"DOC.CODPAC \"codPacote\", " +
					"DOC.NOMPAC \"descPacote\", " +
					"APO.CODCIA \"codCompanhia\", " +
					"CIA.NOMCIA \"nomeCompanhia\", " +
					"INT.CODINTERCLI \"codCorretor\", " +
					"DOC.DESTINO \"tipoDestino\", " +
					"NVL(OPC.ID_TIPO_ENVIO,'01') \"formaEnvio\", " +
					"DECODE(EMP.INDPROCESADO, " +
					"'S', 'E', " +
					"'P') \"status\", " +
					"NULL \"idePol\", " +
					"NULL \"numCert\", " +
					"NULL \"numOper\", " +
					"SUBSTR(OPE.TIPOOP,1,3) \"tipoOper\", " +
					"'S' \"indMultiItem\", " +
					"PRO.DESCPROD \"descProduto\", " +
					"PRO.CODPROD \"codProduto\", " +
					"NULL \"codModProd\", " +
					"CAT.CODIGO \"tipoEndosso\", " +
					"CAT.DESC_EMPACOTADOR \"descEndosso\", " +
					"ARQ.CODITEM \"codItem\" " +
					"FROM   POLIZA APO,	" +
					"PRODUCTO PRO, " +
					"POLIZA_CLI PCL, " +
					"PART_INTER_POL PIP, " +
					"INTERMEDIARIO INT, " +
					"OPER_POL OPE, " +
					"OPER_POL_CLI OPC, " +
					"CATEG_ENDOSSO CAT, " +
					"MAESTRO_CIA CIA, " +
					"CLIENTE CLI, " +
					"TERCERO TER, " +
					"I_SEQ_ARQ ARQ,	" +
					"I_ESPELHO_EMP EMP, " +
					"(SELECT DISTINCT I.IDEREG, " +
						"D.CODDOC, " +
						"D.NOMDOC, " +
						"P.CODPAC, " +
						"P.NOMPAC, " +
						"I.LINHA, " +
						"DECODE(E.CODITEM,'54',TO_DATE(SUBSTR(I.LINHA, 5, 8), 'YYYYMMDD'),TRUNC(S.DTENVIO)) DATA, " +
						"DECODE(E.CODITEM,'54',SUBSTR(I.LINHA, 13, 1),'S') DESTINO, " +
						"DECODE(E.CODITEM,'54',SUBSTR(I.LINHA, 181, 1),'1') FORMAENVIO " +
					"FROM I_ESPELHO_EMPACOTADOR I, " +
						"I_ESPELHO_EMP         E, " +
						"I_SEQ_ARQ             S, " +
						"EMPACOTADOR_DOCUMENTO D, " +
						"EMPACOTADOR_PACOTE    P " +
					"WHERE I.CODDOC = D.CODDOC " +
						"AND I.CODPAC = P.CODPAC " +
						"AND I.IDEREG = E.IDEREG " +
						"AND E.CODITEM= S.CODITEM " +
						"AND E.SEQARQ = LPAD(S.SEQARQ,7,'0') " +
						"AND I.CODDOC NOT IN ('DOC00480', " +
						"'DOC00490', " +
						"'DOC00415', " +
						"'DOC00461', " +
						"'DOC00410', " +
						"'DOC00470', " +
						"'DOC02060', " +
						"'DOC02061', " +
						"'DOC02062', " +
						"'DOC02063', " +
						"'DOC02065')) DOC " +
					"WHERE  APO.IDEPOL   = PCL.IDEPOL " +
					"AND    APO.CODPROD  = PRO.CODPROD " +
					"AND    APO.IDEPOL   = OPE.IDEPOL " +
					"AND    APO.CODCLI   = CLI.CODCLI " +
					"AND    APO.IDEPOL   = PIP.IDEPOL " +
					"AND    OPE.IDEPOL   = OPC.IDEPOL " +
					"AND    OPE.NUMCERT  = OPC.NUMCERT " +
					"AND    OPE.NUMOPER  = OPC.NUMOPER " +
					"AND    OPC.TPALT    = CAT.CODIGO (+) " +
					"AND    APO.CODCIA   = CIA.CODCIA " +
					"AND    PIP.INDLIDER = 'S' " +
					"AND    PIP.CODINTER = INT.CODINTER " +
					"AND    CLI.TIPOID   = TER.TIPOID " +
					"AND    CLI.NUMID    = TER.NUMID " +
					"AND    CLI.DVID     = TER.DVID " +
					"AND    lpad(OPE.IDEPOL,14,'0')  = SUBSTR(EMP.CHAVEGENERICA,1,14) " +
					"AND    lpad(OPE.NUMCERT,10,'0') = SUBSTR(EMP.CHAVEGENERICA,15,10) " +
					"AND    lpad(OPE.NUMOPER,14,'0') = SUBSTR(EMP.CHAVEGENERICA,25,14) " +   
                    "AND    OPE.TIPOOP NOT IN ('CNP', 'CNF') " +                             //27/06/2018 - WILSON (P/ SELECIONAR ENDOSSO ESM PROCH-69)					
					"AND    ARQ.SEQARQ  = TO_NUMBER(EMP.SEQARQ) " +
					"AND    NVL2(TRIM(SUBSTR(EMP.CHAVEGENERICA,80,20)),'S', 'N') = 'S' " +
					"AND    DOC.IDEREG  = EMP.IDEREG " +
//					"AND    ARQ.CODITEM IN ('54') " +
					"AND    ARQ.CODITEM IN ('54', '80') " +
					"AND SUBSTR(EMP.LIVRE,1,3) IN ('EMI','EMC') " +
					(StringUtil.isNull(busca.getCodCorretor()) ?"":" AND INT.CODINTERCLI = :codCorretor ") +
					(StringUtil.isNull(busca.getRamo()) ?"":" AND PCL.CODRAMOCLI = LPAD(:codRamo,3,'0') ") +
					(busca.getNegocio() == null ?"":" AND PCL.CODNEG = :numNegocio ") +
					(busca.getListaClientes() == null || busca.getListaClientes().isEmpty() ? "":" AND CLI.CODCLIENTE IN (:codCliente) ") +
					
					"AND OPE.FECMOV BETWEEN :dataIni AND :dataFim ";
		}
		
		sql = sql + " UNION ALL " +
		
		"SELECT DISTINCT EMP.idereg \"id\", "+
		"DOC.coddoc \"codDocumento\", "+
		"DOC.nomdoc \"descDocumento\", "+
		"CLI.codcliente \"codCliente\", "+
		"TER.nomter \"nomeCliente\", "+
		"DOC.data \"dataGeracao\", "+
		"ARQ.dtenvio \"dataEnvio\", "+
		"PCL.codramocli \"ramo\", "+
		"APO.numpol \"numApolice\", "+
        "DECODE(OPE.NUMENDOSO, 0, DECODE(CAT.CODIGO, NULL, NULL, 0), OPE.NUMENDOSO) \"numEndosso\", " +    // 13/06/2018 - WILSON		
//		"Decode(OPE.numendoso, 0, NULL, OPE.numendoso) \"numEndosso\", "+                                  // 13/06/2018 - WILSON
		"PCL.codneg \"numNegocio\", "+
		"DOC.codpac \"codPacote\", "+
		"DOC.nompac \"descPacote\", "+
		"APO.codcia \"codCompanhia\", "+
		"CIA.nomcia \"nomeCompanhia\", "+
		"INT.codintercli \"codCorretor\", "+
		"DOC.destino \"tipoDestino\", "+
		"Nvl(OPC.id_tipo_envio, '01') \"formaEnvio\", "+
		"Decode(EMP.indprocesado, 'S', 'E', 'P') \"status\", "+
		"OPE.idepol \"idePol\", "+
		"OPE.numcert \"numCert\", "+
		"OPE.numoper \"numOper\", "+
		"Substr(OPE.TIPOOP, 1, 3) \"tipoOper\", "+
		"'N' \"indMultiItem\", "+
		"PRO.codprod \"codProduto\", " +
		"PRO.descprod \"descProduto\", "+
		"OPC.codmodprod \"codModProd\", "+
		"CAT.codigo \"tipoEndosso\", "+
		"CAT.desc_empacotador \"descEndosso\", "+
		"ARQ.coditem \"codItem\" "+
		"FROM   poliza APO, "+
		"producto PRO, "+
		"poliza_cli PCL, "+
		"part_inter_pol PIP, "+
		"intermediario INT, "+
		"oper_pol OPE, "+
		"oper_pol_cli OPC, "+
		"categ_endosso CAT, "+
		"maestro_cia CIA, "+
		"cliente CLI, "+
		"tercero TER, "+
		"i_seq_arq ARQ, "+
		"i_espelho_emp EMP, "+
		"( select DISTINCT "+
		"ed.IDEREG, "+
		"to_char(ed.cd_documento) as CODDOC, "+
		"dc.ds_documento as NOMDOC,	"+
		"NULL as CODPAC, "+
		"NULL as NOMPAC, "+
		"ed.dt_atualizacao as DATA, "+
		"substr(ie.destino,1,1) as DESTINO, "+
		"NULL as FORMAENVIO "+
		"from "+
		"i_espelho_documentos ed, "+
		"DOCUMENTOS_VERSIONAMENTO dv, "+
		"documentos_comunicacao dc , "+
		"i_espelho_emp ie "+
		"WHERE ed.CD_DOCUMENTO = dv.CD_DOCUMENTO "+
		"and ed.CD_VERSAO_DOCTO = dv.ID_VERSAO_DOCTO "+
		"and dv.cd_documento = dc.cd_documento "+
		"and ed.idereg = ie.idereg "+
		"AND IE.INDPROCESADO = 'S' "+
		"AND dc.cd_documento IN (29,32,30,31,33,67,68,75,80,71,72,77,82)) DOC "+
		"WHERE  APO.idepol = PCL.idepol "+                               	 	 	 	 	 	
		"AND APO.codprod = PRO.codprod "+
		"AND APO.idepol = OPE.idepol "+
		"AND APO.codcli = CLI.codcli "+
		"AND APO.idepol = PIP.idepol "+
		"AND OPE.idepol = OPC.idepol "+
		"AND OPE.numcert = OPC.numcert "+
		"AND OPE.numoper = OPC.numoper "+
		"AND OPC.tpalt = CAT.codigo (+) "+
		"AND APO.codcia = CIA.codcia "+
		"AND PIP.indlider = 'S' "+
		"AND PIP.codinter = INT.codinter "+
		"AND CLI.tipoid = TER.tipoid "+
		"AND CLI.numid = TER.numid "+
		"AND CLI.dvid = TER.dvid "+
		"AND Lpad(OPE.idepol, 14, '0') = Substr(EMP.chavegenerica, 1, 14) "+
		"AND Lpad(OPE.numcert, 10, '0') = Substr(EMP.chavegenerica, 15, 10) "+
		"AND Lpad(OPE.numoper, 14, '0') = Substr(EMP.chavegenerica, 25, 14) "+    
        "AND OPE.TIPOOP NOT IN ('CNP', 'CNF') " +                                 //27/06/2018 - WILSON (P/ SELECIONAR ENDOSSO ESM PROCH-69)
		"AND ARQ.seqarq = To_number(EMP.seqarq) "+                           	 	 	 	 	 	
		"AND DOC.idereg = EMP.idereg "+
		"AND ARQ.coditem = '40' "+
		"AND Substr(EMP.livre, 1, 3) IN ( 'EMI', 'EMC', 'ESM', 'ECO', "+
		"'ECA', 'ERE', 'PEC', 'CAV' ) "+

		(busca.isSomenteApolice()?" AND SUBSTR(EMP.LIVRE,1,3) IN ('EMI','EMC') ":
				"AND SUBSTR(EMP.LIVRE,1,3) IN ('EMI','EMC','ESM','ECO','ECA','ERE','PEC','CAV') ") +
		(StringUtil.isNull(busca.getCodCorretor()) ?"":" AND INT.CODINTERCLI = :codCorretor ") +
		(busca.getApolice() == null ?" AND NVL2(TRIM(SUBSTR(EMP.CHAVEGENERICA,80,20)),'S', 'N') = 'N' ":" AND APO.NUMPOL = :numApolice ") +
		(StringUtil.isNull(busca.getRamo()) ?"":" AND PCL.CODRAMOCLI = LPAD(:codRamo,3,'0') ") +
		(busca.getNumEndosso() == null ?"":" AND OPE.NUMENDOSO = :numEndosso ") +
		(busca.getNegocio() == null ?"":" AND PCL.CODNEG = :numNegocio ") +
		(busca.getListaClientes() == null || busca.getListaClientes().isEmpty() ? "":" AND CLI.CODCLIENTE IN (:codCliente) ") +
		
		" AND OPE.FECMOV BETWEEN :dataIni AND :dataFim ";
		
		sql = sql + "UNION ALL " +
				
		"select distinct ies.idereg id, " +                                                                           
			"doc.coddoc codDocumento, " +                                                                  
			"doc.nomdoc descDocumento, " +                                                                  
			"cli.codcliente codCliente, " +                                                                   
			"ter.nomter nomeCliente, " +                                                                   
			"doc.data dataGeracao, " +                                                                    
			"arq.dtenvio dataEnvio, " +                                                                       
			"pcli.codramocli ramo, " +                                                                           
			"pol.numpol numApolice, " +                                                                   
			"Decode(apo.numendoso, 0, NULL, apo.numendoso) numEndosso, " +                                                                   
			"pcli.codneg numNegocio, " +                                                                   
			"doc.codpac codPacote, " +                                                                       
			"doc.nompac descPacote, " +                                                                   
			"pol.codcia codCompanhia, " +                                                                    
			"mae.nomcia nomeCompanhia, " +                                                                    
			"int.codintercli codCorretor, " +                                                                   
			"doc.destino tipoDestino, " +                                                                   
			"Nvl(opcli.id_tipo_envio, 01) formaEnvio, " +                                                                  
			"Decode(ies.indprocesado, 'S', 'E', 'P') status, " +                      																								
			"pol.idepol idePol, " + 	 	 	 	 	 	 	 																								
			"ope.numCert, " +	 //21/09/2018	 	 	 	 	 	 																								
			"ope.numOper, " +	 //21/09/2018	 	 	 	 	 	 																								
			"Substr(OPE.TIPOOP, 1, 3) tipoOper, " +	 	 	 	 	 	 	 																								
			"'S' indMultiItem, " + 	 	 	 	
			"pro.codprod codProduto, " +
			"pro.descprod descProduto, " + 	 	 	 	 	 	 																								
			"null codModProd, " + 	 	 	 	 	 	 																								
			"apo.codcategendosso tipoEndosso, " + 	 	 	 	 	 	 																								
			"lval.descrip descEndosso, " +
			"arq.coditem coditem " +  
		"from poliza pol, " +
			"producto pro, " +
			"maestro_cia mae, " +
			"i_espelho_emp ies, " +
			"apolice_endosso apo, " +
			"cliente cli, " +
			"tercero ter, " + 
			"i_seq_arq arq, " +
			"poliza_cli pcli, " +
			"part_inter_pol par, " +
			"intermediario int, " +
			"lval, " +
			"oper_pol ope, " + 
			"oper_pol_cli opcli, " +
			"(  select distinct " +                                                                                            
				"ed.idereg, " +                                                                                                 
				"to_char(ed.cd_documento) as coddoc, " +                                                                              
				"dc.ds_documento as nomdoc, " +                                                                                       
				"null as codpac, " +                                                                                    
				"null as nompac, " +                                                                                         
				"ed.dt_atualizacao as data, " +                                                                                      
				"substr(ie.destino,1,1) as destino, " +                                                                                 
				"null as formaenvio " +                                                                                           
				"from " +                                                                                                        
				"i_espelho_documentos ed, " +                                                                                       
				"documentos_versionamento dv, " +                                                                                    
				"documentos_comunicacao dc , " +                                                                                    
				"i_espelho_emp ie " +                                                                                            
				"WHERE ed.cd_documento = dv.cd_documento " +                                                                               
				"and ed.cd_versao_docto = dv.id_versao_docto " +                                                                         
				"and dv.cd_documento = dc.cd_documento " +                                                                              
				"and ed.idereg = ie.idereg " +                                                                                        
				"and ie.indprocesado = 'S' " +                                                                                      
				"and dc.cd_documento in (39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54)) doc " +  	 	
		"where pol.codprod = pro.codprod " +
			"and pol.idepol = pcli.idepol " +
			"and pol.idepol = par.idepol " +
			"and pol.idepol = ope.idepol " +
			"AND ope.idepol   = opcli.IDEPOL " +
			"AND ope.numcert  = opcli.numcert " +
			"AND ope.numoper  = opcli.numoper " +
			"and mae.codcia = pol.codcia " +
			"and apo.idepol = pol.idepol " +
			"and apo.tipoop = ope.tipoop " +         //  07/06/2018-Wilson
            "and apo.numendoso = ope.numendoso " +   //  07/06/2018-Wilson
			"and doc.idereg = ies.idereg " +
			"and pol.codcli = cli.codcli " +
			"and cli.tipoid = ter.tipoid " +                                                                                       
			"and cli.numid = ter.numid " +                                                                                        
			"and cli.dvid = ter.dvid " +
			"and par.codinter = int.codinter " +
			"and par.indlider = 'S' " +             
			"and lval.tipolval =  'TIPOOPER' " +
			"and lval.codlval = apo.tipoop " +                                                                             
			"and arq.seqarq = To_number(ies.seqarq) " +
			"and arq.coditem = ies.coditem " +      //  07/06/2018-Wilson			
			"and Lpad(pol.idepol, 14, '0') = Substr(ies.chavegenerica, 1, 14) " +
			"and Lpad(apo.numendoso, 14, '0') = Substr(ies.chavegenerica, 39, 14) " +

		(busca.isSomenteApolice()?" AND SUBSTR(ies.LIVRE,1,3) IN ('EMI','EMC') ":
				"AND SUBSTR(ies.LIVRE,1,3) IN ('EMI','EMC','ESM','ECO','ECA','ERE','PEC','CAV') ") +
		(StringUtil.isNull(busca.getCodCorretor()) ?"":" AND int.CODINTERCLI = :codCorretor ") +
		(busca.getApolice() == null ?" AND NVL2(TRIM(SUBSTR(ies.CHAVEGENERICA,80,20)),'S', 'N') = 'N' ":" AND pol.NUMPOL = :numApolice ") +
		(StringUtil.isNull(busca.getRamo()) ?"":" AND pcli.CODRAMOCLI = LPAD(:codRamo,3,'0') ") +
		(busca.getNumEndosso() == null ?"":" AND ope.NUMENDOSO = :numEndosso ") +
		(busca.getNegocio() == null ?"":" AND pcli.CODNEG = :numNegocio ") +
		(busca.getListaClientes() == null || busca.getListaClientes().isEmpty() ? "":" AND CLI.CODCLIENTE IN (:codCliente) ") +
		
		" AND OPE.FECMOV BETWEEN :dataIni AND :dataFim ";
		
	   //02/04/2018 - Paulo Alencar
		sql = sql + "UNION ALL " +
		"select distinct ies.idereg id, " +                                                                           
			"doc.coddoc codDocumento, " +                                                                  
			"doc.nomdoc descDocumento, " +                                                                  
			"cli.codcliente codCliente, " +                                                                   
			"ter.nomter nomeCliente, " +                                                                   
			"doc.data dataGeracao, " +                                                                    
			"arq.dtenvio dataEnvio, " +                                                                       
			"pcli.codramocli ramo, " +                                                                           
			"pol.numpol numApolice, " +                                                                   
			"Decode(apo.numendoso, 0, NULL, apo.numendoso) numEndosso, " +                                                                   
			"pcli.codneg numNegocio, " +                                                                   
			"doc.codpac codPacote, " +                                                                       
			"doc.nompac descPacote, " +                                                                   
			"pol.codcia codCompanhia, " +                                                                    
			"mae.nomcia nomeCompanhia, " +                                                                    
			"int.codintercli codCorretor, " +                                                                   
			"doc.destino tipoDestino, " +                                                                   
			"Nvl(opcli.id_tipo_envio, 01) formaEnvio, " +                                                                  
			"Decode(ies.indprocesado, 'S', 'E', 'P') status, " +                      																								
			"pol.idepol idePol, " + 	 	 	 	 	 	 	 																								
			"ope.numCert, " +	//21/09/2018 	 	 	 	 	 																								
			"ope.numOper, " +	//21/09/2018 	 	 	 	 	 	 																								
			"Substr(OPE.TIPOOP, 1, 3) tipoOper, " +	 	 	 	 	 	 	 																								
			"'S' indMultiItem, " + 	 	 	 	
			"pro.codprod codProduto, " +
			"pro.descprod descProduto, " + 	 	 	 	 	 	 																								
			"null codModProd, " + 	 	 	 	 	 	 																								
			"apo.codcategendosso tipoEndosso, " + 	 	 	 	 	 	 																								
			"lval.descrip descEndosso, " +
			"arq.coditem coditem " +  
		"from poliza pol, " +
			"producto pro, " +
			"maestro_cia mae, " +
			"i_espelho_emp ies, " +
			"apolice_endosso apo, " +
			"cliente cli, " +
			"tercero ter, " + 
			"i_seq_arq arq, " +
			"poliza_cli pcli, " +
			"part_inter_pol par, " +
			"intermediario int, " +
			"lval, " +
			"oper_pol ope, " + 
			"oper_pol_cli opcli, " +
			"(  select distinct " +                                                                                            
				"ed.idereg, " +                                                                                                 
				"to_char(ed.cd_documento) as coddoc, " +                                                                              
				"dc.ds_documento as nomdoc, " +                                                                                       
				"null as codpac, " +                                                                                    
				"null as nompac, " +                                                                                         
				"ed.dt_atualizacao as data, " +                                                                                      
				"substr(ie.destino,1,1) as destino, " +                                                                                 
				"null as formaenvio " +                                                                                           
				"from " +                                                                                                        
				"i_espelho_documentos ed, " +                                                                                       
				"documentos_versionamento dv, " +                                                                                    
				"documentos_comunicacao dc , " +                                                                                    
				"i_espelho_emp ie " +                                                                                            
				"WHERE ed.cd_documento = dv.cd_documento " +                                                                               
				"and ed.cd_versao_docto = dv.id_versao_docto " +                                                                         
				"and dv.cd_documento = dc.cd_documento " +                                                                              
				"and ed.idereg = ie.idereg " +                                                                                        
				"and ie.indprocesado = 'S' " +                                                                                      
//				"and dc.cd_documento in (56, 57, 58, 59, 61)) doc " +    //07/06/2018-Wilson
                "and dc.cd_documento in (56, 57, 58, 59, 61, 67, 68, 75, 80, 71, 72, 77, 82, 83, 84, 85, 90, 91, 92, 94)) doc " +    //27/08/2018-FIANCA,CONDOMINIO,RESIDENCIAL				
		"where pol.codprod = pro.codprod " +
			"and pol.idepol = pcli.idepol " +
			"and pol.idepol = par.idepol " +
			"and pol.idepol = ope.idepol " +
			"AND ope.idepol   = opcli.IDEPOL " +
			"AND ope.numcert  = opcli.numcert " +
			"AND ope.numoper  = opcli.numoper " +
			"and mae.codcia = pol.codcia " +
			"and apo.idepol = pol.idepol " +
			"and apo.tipoop = ope.tipoop " +          //  07/06/2018-Wilson
            "and apo.numendoso = ope.numendoso " +    //  07/06/2018-Wilson
			"and doc.idereg = ies.idereg " +
			"and pol.codcli = cli.codcli " +
			"and cli.tipoid = ter.tipoid " +                                                                                       
			"and cli.numid = ter.numid " +                                                                                        
			"and cli.dvid = ter.dvid " +
			"and par.codinter = int.codinter " +
			"and par.indlider = 'S' " +             
			"and lval.tipolval =  'TIPOOPER' " +
			"and lval.codlval = apo.tipoop " +                                                                             
			"and arq.seqarq = To_number(ies.seqarq) " +
			"and arq.coditem = ies.coditem " +       //  07/06/2018-Wilson
			"and Lpad(pol.idepol, 14, '0') = Substr(ies.chavegenerica, 1, 14) " +
			"and Lpad(ope.numoper, 14, '0') = Substr(ies.chavegenerica, 25, 14) " +
		(busca.isSomenteApolice()?" AND SUBSTR(ies.LIVRE,1,3) IN ('EMI','EMC') ":
				"AND SUBSTR(ies.LIVRE,1,3) IN ('EMI','EMC','ESM','ECO','ECA','ERE','PEC','CAV') ") +
		(StringUtil.isNull(busca.getCodCorretor()) ?"":" AND int.CODINTERCLI = :codCorretor ") +
		(busca.getApolice() == null ?" AND NVL2(TRIM(SUBSTR(ies.CHAVEGENERICA,80,20)),'S', 'N') = 'N' ":" AND pol.NUMPOL = :numApolice ") +
		(StringUtil.isNull(busca.getRamo()) ?"":" AND pcli.CODRAMOCLI = LPAD(:codRamo,3,'0') ") +
		(busca.getNumEndosso() == null ?"":" AND ope.NUMENDOSO = :numEndosso ") +
		(busca.getNegocio() == null ?"":" AND pcli.CODNEG = :numNegocio ") +
		(busca.getListaClientes() == null || busca.getListaClientes().isEmpty() ? "":" AND CLI.CODCLIENTE IN (:codCliente) ") +
		" AND OPE.FECMOV BETWEEN :dataIni AND :dataFim ";		
		
//		System.out.println(sql);
//		logger.info(sql);

		SQLQuery q = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("codDocumento")
				.addScalar("descDocumento")
				.addScalar("codCliente")
				.addScalar("nomeCliente")
				.addScalar("dataGeracao")
				.addScalar("dataEnvio")
				.addScalar("ramo")
				.addScalar("numApolice", StandardBasicTypes.LONG)
				.addScalar("numNegocio", StandardBasicTypes.INTEGER)
				.addScalar("numEndosso", StandardBasicTypes.INTEGER)
				.addScalar("codPacote")
				.addScalar("descPacote")
				.addScalar("codCompanhia", StandardBasicTypes.STRING)
				.addScalar("nomeCompanhia")
				.addScalar("codCorretor")
				.addScalar("tipoDestino")
				.addScalar("formaEnvio")
				.addScalar("status")
				.addScalar("idePol", StandardBasicTypes.LONG)
				.addScalar("numCert", StandardBasicTypes.LONG)
				.addScalar("numOper", StandardBasicTypes.LONG)
				.addScalar("tipoOper")
				.addScalar("indMultiItem", StandardBasicTypes.STRING)
				.addScalar("codProduto")
				.addScalar("descProduto")
				.addScalar("codModProd")
				.addScalar("tipoEndosso")
				.addScalar("descEndosso")
				.addScalar("codItem");

		q.setParameter("dataIni", busca.getDataIni());
		q.setParameter("dataFim", busca.getDataFim());

		if (busca.getListaClientes() != null && !busca.getListaClientes().isEmpty())
			q.setParameterList("codCliente", busca.getListaClientes());
		if (!StringUtil.isNull(busca.getRamo()))
			q.setParameter("codRamo", busca.getRamo());
		if (busca.getApolice() != null)
			q.setParameter("numApolice", busca.getApolice());
		if (busca.getNumEndosso() != null)
			q.setParameter("numEndosso", busca.getNumEndosso());
		if (busca.getNegocio() != null)
			q.setParameter("numNegocio", busca.getNegocio());
		if (!StringUtil.isNull(busca.getCodCorretor())){
			q.setParameter("codCorretor", busca.getCodCorretor());
		}

		q.setResultTransformer(Transformers.aliasToBean(DocumentoDTO.class));

		return q.list();
	} //02/04/2018 - T803758

	
	@SuppressWarnings("unchecked")
	public List<SegundaViaDTO> buscaSegundaVia(Long idePol, Long numCert, Long numOper, String tipoOper){

		List<SegundaViaDTO> lista = new ArrayList<SegundaViaDTO>();

		String sql =
				" SELECT EMP.IDEREG \"id\"," +
				"        ARQ.DTPROC \"dataSolic\"," +
				"        TRIM(SUBSTR(EMP.LIVRE,15,15)) \"usuarioSolic\"," +
				"        DECODE(EMP.INDPROCESADO," +
				"               'S', 'E'," +
				"               'N', 'P'," +
			    "               'C', 'C') \"status\"," +
				"        TO_NUMBER(TRIM(SUBSTR(EMP.LIVRE,30,3))) \"numEndereco\"," +
				"        DECODE(SUBSTR(EMP.LIVRE,33,1)," +
				"               '1', 'Kit Completo'," +
				"               '3', 'Somente Cartão'," +
			    "               'R', 'Endosso com Cartão') \"opcaoSolic\"," +
				"        SUBSTR(EMP.LIVRE,7,1) \"tipoDestino\"," +
				"        TRIM(SUBSTR(EMP.LIVRE,34,30)) \"usuarioLocal\"," +
				"        TRIM(SUBSTR(EMP.LIVRE,64,30)) \"destinoLocal\"," +
				"        :numCert \"codItem\"" +
				" FROM   I_SEQ_ARQ     ARQ," +
				"        I_ESPELHO_EMP EMP" +
				" WHERE  SUBSTR(EMP.CHAVEGENERICA,1,14) = LPAD(:idPol,14,'0')" +
				" AND    SUBSTR(EMP.CHAVEGENERICA,15,10) = LPAD(:numCert,10,'0')" +
				" AND    SUBSTR(EMP.CHAVEGENERICA,25,14) = LPAD(:numOper,14,'0')" +
				" AND    EMP.CODSUBITEM = '058'" +				
				" AND    SUBSTR(EMP.LIVRE,4,3) = :tipoOper" +				
				" AND    ARQ.SEQARQ = TO_NUMBER(EMP.SEQARQ)" +
				" AND    (SUBSTR(EMP.CHAVEGENERICA,61,8) NOT IN ('DOC00480', 'DOC00490', 'DOC00415', 'DOC00461', 'DOC00410', 'DOC00470') OR ARQ.CODITEM = '40' )" +
				" AND    ARQ.CODITEM in ('54','40','51','30','31','32','33')" +
				" AND    ARQ.CODITEM = EMP.CODITEM" +				
				" ORDER  BY ARQ.DTEXTRAC DESC, EMP.IDEREG DESC";

		lista = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("dataSolic")
				.addScalar("usuarioSolic")
				.addScalar("status")
				.addScalar("tipoDestino", StandardBasicTypes.STRING)
				.addScalar("numEndereco", StandardBasicTypes.INTEGER)
				.addScalar("usuarioLocal")
				.addScalar("destinoLocal")
				.addScalar("opcaoSolic")
				.addScalar("codItem", StandardBasicTypes.STRING)
				.setResultTransformer(Transformers.aliasToBean(SegundaViaDTO.class))
				.setParameter("idPol", idePol)
				.setParameter("numCert", numCert)
				.setParameter("numOper", numOper)
				.setParameter("tipoOper", tipoOper)
				.list();

		return lista;
	}

	public EnderecoDTO obtemEnderecoEnvio(DocumentoDTO doc){

		Long ideReg;
		
		if (doc.getIndMultiItem()){
			if (doc.getListaItens() != null && doc.getListaItens().size() > 0) {
				ideReg = doc.getListaItens().get(0).getIdeReg();
			} else {
				ideReg = doc.getId();
			}
		} else{
			ideReg = doc.getId();
		}
		
		if(doc.getCodItem().equals("40") || Constants.AUTO_FROTA_COD_PRUDUTO.equals(doc.getCodProduto()) ) {
			String sql = " SELECT EMP.ENDERECO    AS  \"enderecoFormatado\"" +
					" FROM I_ESPELHO_EMP EMP WHERE  EMP.IDEREG = :ideReg";
			
			return (EnderecoDTO) base.getSession().createSQLQuery(sql)
					.setResultTransformer(Transformers.aliasToBean(EnderecoDTO.class))
					.setParameter("ideReg", ideReg)
					.setMaxResults(1)
					.uniqueResult();
			
		} else if(doc.getCodItem().equals("54") || doc.getCodItem().equals("80")) { //WILSON 30/08/2018
			String sql =
					" SELECT TRIM(SUBSTR(S.LINHA,241,40))      \"logradouro\"," +
					"        LTRIM(SUBSTR(S.LINHA,281,5),'0')  \"numero\"," +
					"        TRIM(SUBSTR(S.LINHA,286,15))      \"complemento\"," +
					"        TRIM(SUBSTR(S.LINHA,301,15))      \"bairro\"," +
					"        TRIM(SUBSTR(S.LINHA,316,9))       \"cep\"," +
					"        TRIM(SUBSTR(S.LINHA,325,15))      \"cidade\"," +
					"        TRIM(SUBSTR(S.LINHA,340,2))       \"estado\"" +
					" FROM   I_ESPELHO_EMPACOTADOR S" +
					" WHERE  S.IDEREG = :idReg" +
					" AND    S.CODDOC = :codDoc" +					
					" AND    SUBSTR(S.LINHA,102,8) = DECODE(:tipoDestino,'S','SUB00100', 'C','SUB00200')";
			
				return (EnderecoDTO) base.getSession().createSQLQuery(sql)
						.setResultTransformer(Transformers.aliasToBean(EnderecoDTO.class))
						.setParameter("idReg", ideReg)
						.setParameter("codDoc", doc.getCodDocumento())
						.setParameter("tipoDestino", doc.getTipoDestino().getValue())
						.setMaxResults(1)
						.uniqueResult();
		} else {  //WILSON 30/08/2018 => CODIGOS NOVOS DO PROJETO IN HOME
			String sql = "SELECT EMP.ENDERECO    AS  \"enderecoFormatado\"" +
					" FROM I_ESPELHO_EMP EMP WHERE  EMP.IDEREG = :ideReg";
			return (EnderecoDTO) base.getSession().createSQLQuery(sql)
					.setResultTransformer(Transformers.aliasToBean(EnderecoDTO.class))
					.setParameter("ideReg", ideReg)
					.setMaxResults(1)
					.uniqueResult();
		}
	}

	@SuppressWarnings("unchecked")
	public List<IEspelhoEmp> obtemEspelhoEmpCartao(IEspelhoEmp doc){
		return  base.getSession().createCriteria(IEspelhoEmp.class)
				.add(Restrictions.eq("seqArq.seqArq", doc.getSeqArq().getSeqArq()))
				.add(Restrictions.eq("seqArq.codItem", doc.getCodItem()))
				.add(Restrictions.eq("codSubItem", doc.getCodSubItem()))
				.add(Restrictions.like("chaveGenerica", doc.getChaveGenerica().substring(0, 52), MatchMode.START))
				.add(Restrictions.sqlRestriction("substr(livre,1,6) = '" + doc.getLivre().substring(0, 6) + "'"))
				.add(Restrictions.ne("indProcessado", StatusDocumento.cancelado.getValue()))
				.add(Restrictions.ne("idReg", doc.getIdReg()))
				.list();
	}

	public IEspelhoEmp obtemEspelhoEmp(Long idReg){
		return base.findById(IEspelhoEmp.class, idReg);
	}

	public IEspelhoEmp atualizaEspelhoEmp(IEspelhoEmp espelhoEmp){
		return (IEspelhoEmp) base.merge(espelhoEmp); 
	}

	public String solicitarSegundaVia(SolicSegundaViaDTO solic){
		if(solic.getDocumento().getCodProduto() != null && solic.getDocumento().getCodProduto().equals(Constants.AUTO_FROTA_COD_PRUDUTO) ) {
			return solicitarSegundaViaAutoFrota(solic, null);
		} else {
			return solicitarSegundaVia(solic,null);
		}
	}

	public String solicitarSegundaViaAutoFrota(final SolicSegundaViaDTO solic, final List<ItemApoliceDTO> items) {
		
		return base.getSession().doReturningWork(new ReturningWork<String>() {
			@Override
			public String execute(Connection con) throws SQLException {
				CallableStatement callable = con.prepareCall("BEGIN PR_EMPACOTADOR.Solicita_Segunda_Via(?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
				callable.setLong(1, solic.getDocumento().getIdePol()); //idePol
				callable.setLong(2, 0); //numCert
				callable.setLong(3, 0); //numOper
				callable.setString(4, solic.getTipoDestino().getValue()); //destino
				callable.setString(5, solic.getNumEndereco() == null ? null : solic.getNumEndereco().toString()); //numEnd
				callable.setString(6, solic.getUsuarioSolic().getCodUsuario()); //usuario
				callable.setString(7, OpcaoSolic.getOpcao(solic.getOpcao()).getCodEmpacotador()); //tipoEnvio
				callable.setString(8, StringUtil.isNull(solic.getColaborador())?" ":solic.getColaborador()); //nomeUsuario
				callable.setString(9, StringUtil.isNull(solic.getLocal())?" ":solic.getLocal() + ' ' + solic.getAndarLocalTrabalho()); //localUsuario
				callable.setString(10, solic.getMotivo()); //motivo
				callable.setString(11, solic.getIndEnvioAR() ? "S":"N"); //indAR
				callable.registerOutParameter(12, OracleTypes.VARCHAR); //mensagem
				
				if(items != null && !items.isEmpty()) {
					
					OracleUserType userType = new OracleUserType("REC_RELACAO_ITENS", "TAB_RELACAO_ITENS", con);

					for(ItemApoliceDTO i : items) {
						userType.addAttribute(i.getNumCert());
						userType.addAttribute(i.getNumOper());
						userType.addRow();
					}
					
					callable.setArray(13, userType.getArray()); //items	        
				} else {
					callable.setNull(13, OracleTypes.STRUCT, "TAB_RELACAO_ITENS"); //items
				}
				
				if(solic.getDocumento().getNumEndosso() != null) {
					callable.setLong(14, solic.getDocumento().getNumEndosso()); //numEndosso
				} else {
					callable.setLong(14, 0); //numEndosso
				}
				
				callable.execute();

				return callable.getString(12);
			}
		});
	}

	public String solicitarSegundaVia(final SolicSegundaViaDTO solic, final ItemApoliceDTO item){

		return base.getSession().doReturningWork(new ReturningWork<String>() {
			@Override
			public String execute(Connection con) throws SQLException {
				CallableStatement callable = con.prepareCall("BEGIN PR_EMPACOTADOR.Solicita_Segunda_Via(:idePol,:numCert,:numOper,"
						+ ":destino,:numEnd,:usuario,:tipoEnvio,:nomeUsuario,:localUsuario,:motivo,:indAR,:mensagem); END;");
				if (item != null){
					callable.setLong("idePol", item.getIdePol());
					callable.setLong("numCert", item.getNumCert());                                                 
					callable.setLong("numOper", item.getNumOper());
				} else{
					callable.setLong("idePol", solic.getDocumento().getIdePol());
					callable.setLong("numCert", solic.getDocumento().getNumCert());
					callable.setLong("numOper", solic.getDocumento().getNumOper());
				}
				callable.setString("destino", solic.getTipoDestino().getValue());
				callable.setString("numEnd", solic.getNumEndereco() == null ? null : solic.getNumEndereco().toString());
				callable.setString("usuario", solic.getUsuarioSolic().getCodUsuario());
				callable.setString("tipoEnvio", OpcaoSolic.getOpcao(solic.getOpcao()).getCodEmpacotador());
				callable.setString("nomeUsuario", StringUtil.isNull(solic.getColaborador())?" ":solic.getColaborador());
				callable.setString("localUsuario", StringUtil.isNull(solic.getLocal())?" ":solic.getLocal() + ' ' + solic.getAndarLocalTrabalho());
				callable.setString("motivo", solic.getMotivo());
				callable.setString("indAR", solic.getIndEnvioAR() ? "S":"N");
				callable.registerOutParameter("mensagem", OracleTypes.VARCHAR);

				callable.execute();

				return callable.getString("mensagem");
			}
		});
	}
	
	@SuppressWarnings("unchecked")
	public List<SegundaViaDTO> buscaSegundaViaAutoFrota(Long codItem, Long idePol, Integer numEndosso) {
		String sql = "SELECT EMP.IDEREG id, " +
							"ARQ.DTPROC dataSolic, " +
							"TRIM(SUBSTR(EMP.LIVRE,15,15)) usuarioSolic, " +
							"DECODE(EMP.INDPROCESADO, 'S', 'E', 'N', 'P', 'C', 'C') status, " +
							"TO_NUMBER(TRIM(SUBSTR(EMP.LIVRE,30,3))) numEndereco, " +
							"DECODE(SUBSTR(EMP.LIVRE,33,1), '1', 'Kit Completo', '3', 'Somente Cartão', 'R', 'Endosso com Cartão') opcaoSolic,  " +
							"SUBSTR(EMP.LIVRE,7,1) tipoDestino, " +
							"TRIM(SUBSTR(EMP.LIVRE,34,30)) usuarioLocal, " +
							"TRIM(SUBSTR(EMP.LIVRE,64,30)) destinoLocal, " +
							":codItem codItem " +
					 "FROM   I_SEQ_ARQ     ARQ, " +
					 		"I_ESPELHO_EMP EMP " +
					 "WHERE  ARQ.SEQARQ = TO_NUMBER(EMP.SEQARQ) " +
					 "AND    SUBSTR(EMP.CHAVEGENERICA,1,14) = LPAD(:idePol,14,'0') " +
					 "AND    SUBSTR(EMP.CHAVEGENERICA,39,14) = LPAD(:numendosso,14,'0') " +
					 "AND    (SUBSTR(EMP.CHAVEGENERICA,61,8) NOT IN ('DOC00480', 'DOC00490', 'DOC00415', 'DOC00461', 'DOC00410', 'DOC00470') OR ARQ.CODITEM = '40' ) " +
					 "AND    ARQ.CODITEM IN ('50','80') " + "AND    EMP.CODSUBITEM = '058' " +
					 "ORDER  BY ARQ.DTEXTRAC DESC, EMP.IDEREG DESC ";
		
		SQLQuery query = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("dataSolic")
				.addScalar("usuarioSolic")
				.addScalar("status")
				.addScalar("tipoDestino", StandardBasicTypes.STRING)
				.addScalar("numEndereco", StandardBasicTypes.INTEGER)
				.addScalar("usuarioLocal")
				.addScalar("destinoLocal")
				.addScalar("opcaoSolic")
				.addScalar("codItem", StandardBasicTypes.STRING);
		query.setResultTransformer(Transformers.aliasToBean(SegundaViaDTO.class));
		query.setParameter("codItem", codItem);
		query.setParameter("idePol", idePol);
		if(numEndosso != null) {
			query.setParameter("numendosso", numEndosso);
		} else {
			query.setParameter("numendosso", 0);
		}
		return query.list();
	}
	
/*
	//04/04/2018 - T803758
	@SuppressWarnings("unchecked")
	public List<SegundaViaDTO> buscaSegundaViaAuto(Long idePol, Long numCert, Long numOper, String tipoOper){

		List<SegundaViaDTO> lista = new ArrayList<SegundaViaDTO>();

		String sql =
				" SELECT EMP.IDEREG \"id\"," +
				"        ARQ.DTPROC \"dataSolic\"," +
				"        TRIM(SUBSTR(EMP.LIVRE,15,15)) \"usuarioSolic\"," +
				"        DECODE(EMP.INDPROCESADO," +
				"               'S', 'E'," +
				"               'N', 'P'," +
			    "               'C', 'C') \"status\"," +
				"        TO_NUMBER(TRIM(SUBSTR(EMP.LIVRE,30,3))) \"numEndereco\"," +
				"        DECODE(SUBSTR(EMP.LIVRE,33,1)," +
				"               '1', 'Kit Completo'," +
				"               '3', 'Somente Cartão'," +
			    "               'R', 'Endosso com Cartão') \"opcaoSolic\"," +
				"        SUBSTR(EMP.LIVRE,7,1) \"tipoDestino\"," +
				"        TRIM(SUBSTR(EMP.LIVRE,34,30)) \"usuarioLocal\"," +
				"        TRIM(SUBSTR(EMP.LIVRE,64,30)) \"destinoLocal\"," +
				"        :numCert \"codItem\"" +
				" FROM   I_SEQ_ARQ     ARQ," +
				"        I_ESPELHO_EMP EMP" +
				" WHERE  ARQ.SEQARQ = TO_NUMBER(EMP.SEQARQ)" +
				" AND    SUBSTR(EMP.CHAVEGENERICA,1,14) =  LPAD(:idPol,14,'0')" +
				" AND    SUBSTR(EMP.CHAVEGENERICA,15,10) = LPAD(:numCert,10,'0')" +
				" AND    SUBSTR(EMP.CHAVEGENERICA,25,14) = LPAD(:numOper,14,'0')" +
				" AND    SUBSTR(EMP.LIVRE,4,3) = :tipoOper" +
				" AND    ARQ.CODITEM = '51' " +
				" AND    EMP.CODSUBITEM = '060' " + 
				" ORDER  BY ARQ.DTEXTRAC DESC, EMP.IDEREG DESC";

		lista = base.getSession().createSQLQuery(sql)
				.addScalar("id", StandardBasicTypes.LONG)
				.addScalar("dataSolic")
				.addScalar("usuarioSolic")
				.addScalar("status")
				.addScalar("tipoDestino", StandardBasicTypes.STRING)
				.addScalar("numEndereco", StandardBasicTypes.INTEGER)
				.addScalar("usuarioLocal")
				.addScalar("destinoLocal")
				.addScalar("opcaoSolic")
				.addScalar("codItem", StandardBasicTypes.STRING)
				.setResultTransformer(Transformers.aliasToBean(SegundaViaDTO.class))
				.setParameter("idPol", idePol)
				.setParameter("numCert", numCert)
				.setParameter("numOper", numOper)
				.setParameter("tipoOper", tipoOper)
				.list();

		return lista;
    }	
*/    
	
	@SuppressWarnings("unchecked")
	public List<ItemApoliceDTO> buscaItensPorCodigo(List<String> listaItens, Long idePol, Integer numEndosso) {
		String sql = "select distinct cer.numseqitem codItem, " +
	                	 "mdpar.idepol idePol, " + 
	                	 "mdpar.numcert numCert, " + 
	                	 "ope.numoper numOper, " + 
	                	 "ies.idereg ideReg " + 
                	 "from   mod_datos_particulares mdpar, " + 
                	 	 "certificado cer, " + 
                	 	 "oper_pol ope, " + 
                	 	 "i_espelho_emp ies  " +
                	 "where cer.idepol = :idepol " +
                	 	 "and	mdpar.idepol = cer.idepol " +  
                	 	 "and    ope.idepol = cer.idepol " + 
                	 	 "and    mdpar.numcert = cer.numcert  " +
                	 	 "and    mdpar.numcert = ope.numcert " + 
                	 	 "and    lpad(:idepol,14,'0')  = SUBSTR(ies.chavegenerica,1,14) " +  
                	 	 "and    lpad(:numendosso,14,'0') = SUBSTR(ies.chavegenerica,39,14)  " +
                	 	 "and    cer.numseqitem IN (:items) ";
		
		SQLQuery query = base.getSession().createSQLQuery(sql);
		query.addScalar("codItem", StandardBasicTypes.STRING);
		query.addScalar("idePol", StandardBasicTypes.LONG);
		query.addScalar("numCert", StandardBasicTypes.LONG);
		query.addScalar("numOper", StandardBasicTypes.LONG);
		query.addScalar("ideReg", StandardBasicTypes.LONG);
		query.setParameter("idepol", idePol);
		if(numEndosso != null) {
			query.setParameter("numendosso", numEndosso);
		} else {
			query.setParameter("numendosso", 0);
		}
		query.setParameterList("items", listaItens);
		query.setResultTransformer(Transformers.aliasToBean(ItemApoliceDTO.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<ItemApoliceDTO> listItemsSegundaViaAUTF(Long idereg) {
		String sql = "select ies.idereg ideReg, " +
			       	 		"ies.numcert numCert, " +
			       	 		"ies.numoper numOper " +
			         "from   i_espelho_documentos_item ies " +
					 "where  idereg = :idereg";
		return base.getSession().createSQLQuery(sql)
				.addScalar("numCert", StandardBasicTypes.LONG)
				.addScalar("numOper", StandardBasicTypes.LONG)
				.addScalar("ideReg", StandardBasicTypes.LONG)
				.setParameter("idereg", idereg)
				.setResultTransformer(Transformers.aliasToBean(ItemApoliceDTO.class))
				.list();
	}
	
}

