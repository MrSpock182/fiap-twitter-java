package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "AGENDAMENTO_ERRO_ENVIO")
public class AgendamentoErro {

	@Id
	@Column(name="CD_SEQUENCIA_ERRO_ENVIO")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="seqErroGenerator")
	@SequenceGenerator(name = "seqErroGenerator", sequenceName = "SQ_AGENDAMENTO_ERRO_ENVIO",allocationSize=1)
	private Long seqErroEnvio;

	@ManyToOne
	@JoinColumn(name="CD_SEQUENCIA_ENVIO", referencedColumnName="CD_SEQUENCIA_ENVIO")
	private AgendamentoEnvio agendamento;

	@Column(name="DS_ERRO")
	private String descErro;

	@Column(name="DT_INCLUSAO")
	private Date dtErro;

	public Long getSeqErroEnvio() {
		return seqErroEnvio;
	}

	public void setSeqErroEnvio(Long seqErroEnvio) {
		this.seqErroEnvio = seqErroEnvio;
	}

	public AgendamentoEnvio getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoEnvio agendamento) {
		this.agendamento = agendamento;
	}

	public String getDescErro() {
		return descErro;
	}

	public void setDescErro(String descErro) {
		this.descErro = descErro;
	}

	public Date getDtErro() {
		return dtErro;
	}

	public void setDtErro(Date dtErro) {
		this.dtErro = dtErro;
	}

}