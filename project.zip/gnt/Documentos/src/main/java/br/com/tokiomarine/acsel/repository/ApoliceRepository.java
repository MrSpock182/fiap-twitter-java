package br.com.tokiomarine.acsel.repository;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.OperPol;
import br.com.tokiomarine.acsel.dto.DescricaoItemAutoFrotaDTO;
import br.com.tokiomarine.acsel.dto.ItemApoliceDTO;

public class ApoliceRepository{

	@Inject
	BaseAcxDAO base;

	public OperPol obtemOperPol(Long numPol, Integer numEndosso, String codCliente, Integer codNegocio){

		Criteria crit = base.getSession().createCriteria(OperPol.class)
				.createAlias("poliza", "po")
				.createAlias("po.cliente", "cl")
				.createAlias("po.polizaCli", "pc")
				.add(Restrictions.eq("po.numPol", numPol.longValue()))
				.add(Restrictions.eq("cl.codCliente", codCliente))
				.add(Restrictions.eq("pc.codNeg", codNegocio.longValue()))
				.add(Restrictions.eq("numEndoso", numEndosso.longValue()));

		OperPol ret = (OperPol) crit.uniqueResult();

		return ret;
	}

	@SuppressWarnings("unchecked")
	public List<ItemApoliceDTO> buscaItens(Long idereg, Integer codNegocio){

		List<ItemApoliceDTO> lista = new ArrayList<ItemApoliceDTO>();
		//10/04/2018 - T803758 
		String sql = "SELECT to_number(substr(iee.chavegenerica,15,10)) \"codItem\"," +
					"        'Apólice: ' || cli.codramocli || '/' || pol.numpol ||" +
					"        ' - Local Risco: ' ||" +
					"        (SELECT TRIM(B.VALTRASF) || ', ' ||" +
					"                NVL2(TRIM(H.VALTRASF), TRIM(C.VALTRASF) || ' - ', TRIM(C.VALTRASF)) ||" +
					"                TRIM(H.VALTRASF)" +
					"         FROM   DATOS_PARTICULARES B," +
					"                DATOS_PARTICULARES C," +
					"                DATOS_PARTICULARES H" +
					"         WHERE  B.IDEPOL = POL.IDEPOL" +
					"         AND    B.CODCRIT IN ('00112','00093','00072')" +
					"         AND    B.IDEPOL = C.IDEPOL" +
					"         AND    C.CODCRIT IN ('00301','00298','00304')" +
					"         AND    B.IDEPOL = H.IDEPOL" +
					"         AND    H.CODCRIT IN ('00299','00302','00305')) \"descItem\"," +
					"        substr(iee.chavegenerica,1,14) \"idePol\"," +
					"        substr(iee.chavegenerica,15,10) \"numCert\"," +
					"        substr(iee.chavegenerica,25,14) \"numOper\"," +
					"        iee.idereg \"ideReg\"" +
					" FROM   poliza_cli    cli," +
					"        i_espelho_emp iee," +
					"        poliza        pol" +
//					" WHERE  iee.coditem  IN ('54','51')" +
					" WHERE  iee.coditem  IN ('54','51','30','31','32','33')" +  //30=Residencial, 31=Condominio 32=Empresarial 33=Fianca 24/08/2018					
					" AND    cli.idepol   = pol.idepol" +
					" AND    cli.idepol   = to_number(substr(iee.chavegenerica,1,14))" +
					" AND    iee.idereg   = :idereg" +
					" AND    pol.codprod IN ('RESI','EMPR','COND','AUTO')" +
					" AND    cli.codneg = :codNeg";

		lista = base.getSession().createSQLQuery(sql)
				.addScalar("codItem", StandardBasicTypes.STRING)
				.addScalar("descItem")
				.addScalar("idePol", StandardBasicTypes.LONG)
				.addScalar("numCert", StandardBasicTypes.LONG)
				.addScalar("numOper", StandardBasicTypes.LONG)
				.addScalar("ideReg", StandardBasicTypes.LONG)
				.setResultTransformer(Transformers.aliasToBean(ItemApoliceDTO.class))
				.setParameter("codNeg", codNegocio)
				.setParameter("idereg", idereg)
//				.setParameter("seqArq", StringUtil.lpad(idereg.toString(), "0", 7))
				.list();

		return lista;
	}
	

	@SuppressWarnings("unchecked")
	public List<ItemApoliceDTO> buscaItensAutoFrota(Long idePol, Integer numEndosso) {
		
		List<ItemApoliceDTO> lista = new ArrayList<ItemApoliceDTO>();

		String sql = "select distinct cer.numseqitem codItem, " + 
				"                mdpar.idepol idePol, " + 
				"                mdpar.numcert numCert, " + 
				"                ope.numoper numOper, " + 
				"                ies.idereg ideReg " + 
				"           from   mod_datos_particulares mdpar, " + 
				"                  certificado cer, " + 
				"                  oper_pol ope, " + 
				"                  i_espelho_emp ies " + 
				"           where  mdpar.idepol = :idepol " + 
				"           and    cer.idepol = :idepol " + 
				"           and    ope.idepol = :idepol " + 
				"           and    ope.numendoso = :numendosso" + 
				"           and    mdpar.numcert = cer.numcert " + 
				"           and    mdpar.numcert = ope.numcert " + 
				"           and    lpad(:idepol,14,'0')  = SUBSTR(ies.chavegenerica,1,14) " + 
				"           and    lpad(ope.numendoso,14,'0') = SUBSTR(ies.chavegenerica,39,14)";

		SQLQuery query = base.getSession().createSQLQuery(sql)
			.addScalar("codItem", StandardBasicTypes.STRING)
			.addScalar("idePol", StandardBasicTypes.LONG)
			.addScalar("numCert", StandardBasicTypes.LONG)
			.addScalar("numOper", StandardBasicTypes.LONG)
			.addScalar("ideReg", StandardBasicTypes.LONG);
		
		query.setParameter("idepol", idePol);
		query.setParameter("numendosso", numEndosso);
		
		query.setResultTransformer(Transformers.aliasToBean(ItemApoliceDTO.class));
		lista = query.list();
		
		if(lista != null && !lista.isEmpty()) {
			for(ItemApoliceDTO i : lista ) {
				i.setDescItem(getDescItem(i));
			}
		}

		return lista;
	}
	
	private String getDescItem(ItemApoliceDTO i) {
		String sqlDesc = "select " + 
							"(select valtrasf from mod_datos_particulares " + 
							"where idepol = :idepol " + 
								"and numcert = :numcert " +
								"and numoper = :numoper " +
								"and codcrit = '00026') placa, " +
							"(select valtrasf from mod_datos_particulares " + 
							"where idepol = :idepol " + 
								"and numcert = :numcert " +
								"and numoper = :numoper " +
								"and codcrit = '00027') cor, " +
							"(select valtrasf from mod_datos_particulares " + 
							"where idepol = :idepol " + 
								"and numcert = :numcert " +
								"and numoper = :numoper " +
								"and codcrit = '00024') ano, " +
							"(select valtrasf from mod_datos_particulares " + 
							"where idepol = :idepol " + 
								"and numcert = :numcert " +
								"and numoper = :numoper " +
								"and codcrit = '00025') chassi " +
						 "from dual ";
		
		DescricaoItemAutoFrotaDTO desc = (DescricaoItemAutoFrotaDTO) base.getSession().createSQLQuery(sqlDesc)
				.addScalar("placa", StandardBasicTypes.STRING)
				.addScalar("cor", StandardBasicTypes.STRING)
				.addScalar("ano", StandardBasicTypes.STRING)
				.addScalar("chassi", StandardBasicTypes.STRING)
				.setParameter("idepol", i.getIdePol())
				.setParameter("numcert", i.getNumCert())
				.setParameter("numoper", i.getNumOper())
				.setResultTransformer(Transformers.aliasToBean(DescricaoItemAutoFrotaDTO.class))
				.uniqueResult();
		if(desc != null) {
			return mountDescription(desc);
		} else {
			return null;
		}
	}

	private String mountDescription(DescricaoItemAutoFrotaDTO desc) {
		StringBuilder description = new StringBuilder();
		description.append(desc.getPlaca());
		description.append(" - ");
		if(desc.getCor() != null) {
			description.append(desc.getCor());
			description.append(" - ");
		}
		description.append(desc.getAno());
		description.append(" - ");
		description.append(desc.getChassi());
		return description.toString();
	}

}
