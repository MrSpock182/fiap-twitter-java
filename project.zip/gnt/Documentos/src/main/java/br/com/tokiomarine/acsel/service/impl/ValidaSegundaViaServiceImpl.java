package br.com.tokiomarine.acsel.service.impl;

import java.text.MessageFormat;
import java.util.Calendar;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.dto.UsuarioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.SegundaViaService;
import br.com.tokiomarine.acsel.service.ValidaSegundaViaService;
import br.com.tokiomarine.acsel.type.FormaEnvio;
import br.com.tokiomarine.acsel.type.OpcaoSolic;
import br.com.tokiomarine.acsel.type.StatusDocumento;
import br.com.tokiomarine.acsel.type.TipoDestino;
import br.com.tokiomarine.acsel.util.Constants;
import br.com.tokiomarine.acsel.util.DateUtil;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "ValidaSegundaViaService")
@Local(value = ValidaSegundaViaService.class)
public class ValidaSegundaViaServiceImpl implements ValidaSegundaViaService {

	private static final String MSG_DATA_ORIGINAL = "O documento original foi emitido há menos de {0} dias. Caso não receba o documento até {1}, fazer a solicitação novamente.";
	private static final String MSG_DATA_2VIA = "Já foi solicitada uma 2ª via há menos de {0} dias. Consulte os dados abaixo.";
	private static final String MSG_2VIA_CORRETOR = "Já foi solicitada e encaminhada uma 2ª via desta apólice. Caso não receba o documento até {0}, entre no atendimento online em seu Portal ou ligue para o Contact Center Tel. 0300-33-86546. Consulte abaixo os dados da 2ª via encaminhada.";
	private static final String MSG_DIGITAL = "A apólice e o cartão do segurado {2} encaminhados em {1} para o e-mail {0}. Caso deseje que os documentos sejam encaminhados via correio, entre no atendimento online em seu Portal ou ligue para o Contact Center Tel. 0300-33-86546";
	private static final String MSG_MISTO = "A apólice {3} encaminhada em {1} para o e-mail {0} e o cartão encaminhado para o correio no endereço {2}. Caso deseje que a apólice seja encaminhada via correio, entre no atendimento online em seu Portal ou ligue para o Contact Center Tel. 0300-33-86546";
	private static final String MSG_MISTO_PREV = "A apólice {4} encaminhada em {1} para o e-mail {0} e o cartão encaminhado para o correio no endereço {2}, com previsão de chegada em {3}. Caso deseje que a apólice seja encaminhada via correio, entre no atendimento online em seu Portal ou ligue para o Contact Center Tel. 0300-33-86546";
	private static final String MSG_SEM_EMAIL = "O e-mail para envio dos documentos não está cadastrado ou está incorreto. Entre no atendimento online em seu Portal ou ligue para o Contact Center Tel. 0300-33-86546";

	@Inject
	ParametrosRepository parametrosRep;
	@Inject
	SegundaViaService segundaViaService;

	@Override
	public void validaSegundaVia(SolicSegundaViaDTO solic) throws ServiceException{
		validaFormaEnvio(solic.getDocumento(), solic.getUsuarioSolic());
		validaDataSegundaVia(solic.getDocumento(), solic.getUsuarioSolic(), solic.getListaItens());
		validaCamposObrigatorios(solic);
		validaOpcaoEnvio(solic);
		validaMotivo(solic);
	}

	@Override
	public void permiteNovaSolicitacao(DocumentoDTO doc, UsuarioDTO usuario) throws ServiceException{
		validaFormaEnvio(doc, usuario);
		validaDataSegundaVia(doc, usuario, null);
	}

	private int getQtdDiasLimite(DocumentoDTO doc, UsuarioDTO usuario){
		String param = "";
		if (usuario.isCorretor()){
			param = "QTD_DIAS_SOLIC_CORRETOR";
		} else if (doc.getSistemaOrigem().isPlataforma()){
			param = "QTD_DIAS_SOLIC_CORPORATE";
		} else{
			param = "QTD_DIAS_SOLIC";
		}
		return Integer.parseInt(parametrosRep.obtemVlrParametro("SEGUNDA_VIA", param));
	}

	private void validaFormaEnvio(DocumentoDTO doc, UsuarioDTO usuario) throws ServiceException{

		if (!usuario.isCorretor()){
			return;
		}

		if (doc.getFormaEnvio().documentoDigital()){

			if (StringUtil.isNull(doc.getEmailEnvio())){
				throw new ServiceException(MSG_SEM_EMAIL);
			}

			if (doc.getFormaEnvio().equals(FormaEnvio.cartao)){
				Calendar dataAtual = Calendar.getInstance();

				Calendar dataPrevista = Calendar.getInstance();
				dataPrevista.setTime(doc.getDataGeracao());
				dataPrevista.add(Calendar.DAY_OF_YEAR, getQtdDiasLimite(doc, usuario));

				if (dataAtual.getTime().after(dataPrevista.getTime())){
					throw new ServiceException(MessageFormat.format(MSG_MISTO,
							doc.getEmailEnvio(),
							doc.getDataEnvioEmail() == null?"breve":DateUtil.formataSemHora(doc.getDataEnvioEmail()),
							doc.getEnderecoEnvio().getEnderecoFormatado(),
							doc.getDataEnvioEmail() == null?"será":"foi"));
				} else{
					throw new ServiceException(MessageFormat.format(MSG_MISTO_PREV,
							doc.getEmailEnvio(),
							doc.getDataEnvioEmail() == null?"breve":DateUtil.formataSemHora(doc.getDataEnvioEmail()),
						    doc.getEnderecoEnvio().getEnderecoFormatado(),
						    DateUtil.formataSemHora(dataPrevista),
						    doc.getDataEnvioEmail() == null?"será":"foi"));
				}
			} else{
				throw new ServiceException(MessageFormat.format(MSG_DIGITAL,
						 doc.getEmailEnvio(),
					     doc.getDataEnvioEmail() == null?"breve":DateUtil.formataSemHora(doc.getDataEnvioEmail()),
					     doc.getDataEnvioEmail() == null?"serão":"foram"));
			}
		}
	}

	private void validaDataSegundaVia(DocumentoDTO doc, UsuarioDTO usuario, List<String> itens) throws ServiceException{
		Integer diasLimite = getQtdDiasLimite(doc, usuario);

		Calendar dataLimite = Calendar.getInstance();
		dataLimite.add(Calendar.DAY_OF_YEAR, diasLimite*-1);

		Calendar dataPrevista = Calendar.getInstance();
		dataPrevista.setTime(doc.getDataGeracao());
		dataPrevista.add(Calendar.DAY_OF_YEAR, diasLimite);

		if (doc.getFormaEnvio()!=null && !doc.getFormaEnvio().documentoDigital() && doc.getDataGeracao().after(dataLimite.getTime())){
			throw new ServiceException(MessageFormat.format(MSG_DATA_ORIGINAL, diasLimite.toString(), DateUtil.formataSemHora(dataPrevista)));
		}

		for (SegundaViaDTO dto : doc.getHistSegundaVia()){

			if (!StatusDocumento.cancelado.equals(dto.getStatus())){

				if (!StringUtil.isNull(dto.getCodItem()) && !Constants.AUTO_FROTA_COD_PRUDUTO.equals(doc.getCodProduto())){
					if (itens == null || (itens != null && !itens.contains(dto.getCodItem())))
						continue;
				}

				dataPrevista.setTime(dto.getDataSolic());
				dataPrevista.add(Calendar.DAY_OF_YEAR, diasLimite);

				if (usuario.isCorretor()){
					doc.setUltimaSolicitacao(dto);
					throw new ServiceException(MessageFormat.format(MSG_2VIA_CORRETOR, DateUtil.formataSemHora(dataPrevista)));
				}

				if (dto.getDataSolic().after(dataLimite.getTime())){
					doc.setUltimaSolicitacao(dto);
					throw new ServiceException(MessageFormat.format(MSG_DATA_2VIA, diasLimite));
				}
			}
		}
	}

	private void validaCamposObrigatorios(SolicSegundaViaDTO solic) throws ServiceException{
		if (solic.getDocumento().getListaItens() != null && !solic.getDocumento().getListaItens().isEmpty() &&
				OpcaoSolic.getOpcao(solic.getOpcao()).getPermiteMultiItem()
				&& !Constants.AUTO_FROTA_COD_PRUDUTO.equals(solic.getDocumento().getCodProduto())){
			if (solic.getListaItens() == null || solic.getListaItens().isEmpty()){
				throw new ServiceException("É necessário selecionar os itens desejados");
			}
		}
		if (solic.getTipoDestino() == null ||
				(solic.getTipoDestino().equals(TipoDestino.local) && solic.getUsuarioSolic().isCorretor())){
			throw new ServiceException("Tipo de destino inválido");
		}
		if (solic.getTipoDestino().equals(TipoDestino.segurado) &&
				(solic.getNumEndereco() == null || solic.getNumEndereco() < 0)){
			throw new ServiceException("Endereço inválido");
		}
		if (solic.getTipoDestino().equals(TipoDestino.local)){
			if (StringUtil.isNull(solic.getLocal()) ||
					StringUtil.isNull(solic.getColaborador()) ||
					StringUtil.isNull(solic.getAndarLocalTrabalho())){
				throw new ServiceException("Favor preencher todos os campos obrigatórios");
			}
		}
	}

	private void validaOpcaoEnvio(SolicSegundaViaDTO solic) throws ServiceException{
/*		
		boolean existe = false;
		for (OpcaoSolic opc : segundaViaService.obtemOpcoesSolic(solic.getDocumento(), solic.getUsuarioSolic())){
			if (opc.getCodOpcao().equals(solic.getOpcao()))
				existe = true;
		}
		if (!existe){
			throw new ServiceException("Tipo de envio Inválido");
		}
*/		

		if (solic.getDocumento().getSistemaOrigem().isSSV()){
			if (solic.getOpcao().equals(OpcaoSolic.endossoCartao.getCodOpcao())){
				throw new ServiceException("Não é possível solicitar o endosso com cartão para esse documento. Favor realizar a solicitação manualmente com a área responsável.");
			}
		}
	}

	private void validaMotivo(SolicSegundaViaDTO solic) throws ServiceException{
		Lval lval = parametrosRep.obtemLval("MOTSEVIA", solic.getMotivo());
		if (lval != null){
			solic.setMotivo(lval.getDescrip());
			return;
		}
		throw new ServiceException("Motivo Inválido");
	}
}

