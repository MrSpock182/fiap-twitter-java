package br.com.tokiomarine.acsel.repository;

import java.util.List;

import javax.inject.Inject;

import org.hibernate.Hibernate;
import org.hibernate.criterion.Restrictions;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.Cliente;

public class ClienteRepository{

	@Inject
	BaseAcxDAO base;

	public List<Cliente> obtemClientesNumID(Long numId, String dvId){
		@SuppressWarnings("unchecked")
		List<Cliente> clientes = base.getSession().createCriteria(Cliente.class)
				.add(Restrictions.eq("tercero.numId", numId))
				.add(Restrictions.eq("tercero.dvId", dvId))
				.add(Restrictions.isNotNull("codCliente"))  //PROCH-45 - 20/07/2018- Retorna muitas Linhas
				.list();

		return clientes;
	}

	public Cliente obtemClienteCodCliente(String codCliente){
		Cliente cliente = (Cliente) base.getSession().createCriteria(Cliente.class)
				.add(Restrictions.eq("codCliente", codCliente))
				.uniqueResult();
		Hibernate.initialize(cliente.getTercero().getTerceroEnderecos());

		return cliente;
	}
}
