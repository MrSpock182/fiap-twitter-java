package br.com.tokiomarine.acsel.dto;

import java.util.List;

public class DadosRetornoPushNotificationDTO {

	private List<String> erros;
	private List<String> logs;

	public List<String> getErros() {
		return erros;
	}
	public void setErros(List<String> erros) {
		this.erros = erros;
	}
	public List<String> getLogs() {
		return logs;
	}
	public void setLogs(List<String> logs) {
		this.logs = logs;
	}
}
