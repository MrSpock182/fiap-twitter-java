package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMPACOTADOR_DOCUMENTO")
public class EmpacotadorDocumento implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CODDOC") private String codDocumento;

	@Column(name="NOMDOC") private String nomeDocumento;

	@Column(name="INDDOC") private String statusDocumento;

	public String getCodDocumento() {
		return codDocumento;
	}

	public void setCodDocumento(String codDocumento) {
		this.codDocumento = codDocumento;
	}

	public String getNomeDocumento() {
		return nomeDocumento;
	}

	public void setNomeDocumento(String nomeDocumento) {
		this.nomeDocumento = nomeDocumento;
	}

	public String getStatusDocumento() {
		return statusDocumento;
	}

	public void setStatusDocumento(String statusDocumento) {
		this.statusDocumento = statusDocumento;
	}

}