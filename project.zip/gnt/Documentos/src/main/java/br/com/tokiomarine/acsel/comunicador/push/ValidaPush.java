package br.com.tokiomarine.acsel.comunicador.push;

import java.util.Date;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

import br.com.tokiomarine.acsel.comunicador.ValidadorDestino;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.repository.AgendamentoErroRepository;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "ValidaPush")
@Local(value = ValidaPush.class)
@Named("validaPush")
public class ValidaPush implements ValidadorDestino {

	@Inject
	private AgendamentoErroRepository agendamentoErroRepository; 		
	
	@Override
	public void executa(AgendamentoEnvio agendamentoEnvio) {
		this.validaPush(agendamentoEnvio);
	}
	
	private void validaPush(AgendamentoEnvio envio) {
		for (AgendamentoDestinatario chave : envio.getAgendamento().getDestinatarios()){
			if (StringUtil.isNull(chave.getDestinatario())){
				incluiAviso(envio, "A chave do destinatário não foi informada");
			} else{
				chave.setIndValido("S");
			}
		}
	}	
	
	public void incluiAviso(AgendamentoEnvio envio, String msgErro){
		AgendamentoErro erro = new AgendamentoErro();
		erro.setDtErro(new Date());
		erro.setDescErro(msgErro);
		erro.setAgendamento(envio);
		this.agendamentoErroRepository.save(erro);
	}		

}
