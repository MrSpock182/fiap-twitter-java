package br.com.tokiomarine.acsel.dto;

public class SegundaViaConsultaDTO {
	private Long idepol;
	private Long numcert;
	private Long numoper;
	private Long numendosso;

	public SegundaViaConsultaDTO() {}

	public SegundaViaConsultaDTO(Long idepol, Long numcert, Long numoper, Long numendosso) {
		this.idepol = idepol;
		this.numcert = numcert;
		this.numoper = numoper;
		this.numendosso = numendosso;
	}

	public Long getIdepol() {
		return idepol;
	}

	public void setIdepol(Long idepol) {
		this.idepol = idepol;
	}

	public Long getNumcert() {
		return numcert;
	}

	public void setNumcert(Long numcert) {
		this.numcert = numcert;
	}

	public Long getNumoper() {
		return numoper;
	}

	public void setNumoper(Long numoper) {
		this.numoper = numoper;
	}

	public Long getNumendosso() {
		return numendosso;
	}

	public void setNumendosso(Long numendosso) {
		this.numendosso = numendosso;
	}
	
}
