package br.com.tokiomarine.acsel.dto;

import java.util.Date;

import br.com.tokiomarine.acsel.type.StatusDocumento;
import br.com.tokiomarine.acsel.type.TipoDestino;

public class SegundaViaDTO {

	private Long id;
	private DocumentoDTO documento;
	private Date dataSolic;
	private String usuarioSolic;
	private String nomeUsuarioSolic;
	private String status;
	private String tipoDestino;
	private Integer numEndereco;
	private String usuarioLocal;
	private String destinoLocal;
	private EnderecoDTO enderecoEnvio;
	private String opcaoSolic;
	private boolean permiteCancelamento;
	private String codItem;
	private ItemApoliceDTO item;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public DocumentoDTO getDocumento() {
		return documento;
	}
	public void setDocumento(DocumentoDTO documento) {
		this.documento = documento;
	}
	public Date getDataSolic() {
		return dataSolic;
	}
	public void setDataSolic(Date dataSolic) {
		this.dataSolic = dataSolic;
	}
	public String getUsuarioSolic() {
		return usuarioSolic;
	}
	public void setUsuarioSolic(String usuarioSolic) {
		this.usuarioSolic = usuarioSolic;
	}
	public String getNomeUsuarioSolic() {
		return nomeUsuarioSolic;
	}
	public void setNomeUsuarioSolic(String nomeUsuarioSolic) {
		this.nomeUsuarioSolic = nomeUsuarioSolic;
	}
	public StatusDocumento getStatus() {
		return StatusDocumento.get(status);
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public TipoDestino getTipoDestino() {
		return TipoDestino.get(tipoDestino);
	}
	public void setTipoDestino(String tipoDestino) {
		this.tipoDestino = tipoDestino;
	}
	public Integer getNumEndereco() {
		return numEndereco;
	}
	public void setNumEndereco(Integer numEndereco) {
		this.numEndereco = numEndereco;
	}
	public String getUsuarioLocal() {
		return usuarioLocal;
	}
	public void setUsuarioLocal(String usuarioLocal) {
		this.usuarioLocal = usuarioLocal;
	}
	public String getDestinoLocal() {
		return destinoLocal;
	}
	public void setDestinoLocal(String destinoLocal) {
		this.destinoLocal = destinoLocal;
	}
	public boolean isPermiteCancelamento() {
		return permiteCancelamento;
	}
	public void setPermiteCancelamento(boolean permiteCancelamento) {
		this.permiteCancelamento = permiteCancelamento;
	}
	public EnderecoDTO getEnderecoEnvio() {
		return enderecoEnvio;
	}
	public void setEnderecoEnvio(EnderecoDTO enderecoEnvio) {
		this.enderecoEnvio = enderecoEnvio;
	}
	public String getOpcaoSolic() {
		return opcaoSolic;
	}
	public void setOpcaoSolic(String opcaoSolic) {
		this.opcaoSolic = opcaoSolic;
	}
	public String getCodItem() {
		return codItem;
	}
	public void setCodItem(String codItem) {
		this.codItem = codItem;
	}
	public ItemApoliceDTO getItem() {
		return item;
	}
	public void setItem(ItemApoliceDTO item) {
		this.item = item;
	}
}
