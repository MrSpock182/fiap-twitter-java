package br.com.tokiomarine.acsel.repository;

import javax.inject.Inject;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;

public class AgendamentoErroRepository {

	@Inject
	BaseAcxDAO base;

	public AgendamentoErro save(AgendamentoErro agendamentoErro){
		base.persist(agendamentoErro);
		return agendamentoErro;
	}

}
