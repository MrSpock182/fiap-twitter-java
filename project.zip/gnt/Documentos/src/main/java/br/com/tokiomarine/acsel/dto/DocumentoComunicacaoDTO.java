package br.com.tokiomarine.acsel.dto;

public class DocumentoComunicacaoDTO {

	private Long seqAgendamento;
	private Long codDocumento;
	private String urlDocumento;
	private String indEnviaEmail;

	public Long getSeqAgendamento() {
		return seqAgendamento;
	}
	public void setSeqAgendamento(Long seqAgendamento) {
		this.seqAgendamento = seqAgendamento;
	}
	public Long getCodDocumento() {
		return codDocumento;
	}
	public void setCodDocumento(Long codDocumento) {
		this.codDocumento = codDocumento;
	}
	public String getUrlDocumento() {
		return urlDocumento;
	}
	public void setUrlDocumento(String urlDocumento) {
		this.urlDocumento = urlDocumento;
	}
	public String getIndEnviaEmail() {
		return indEnviaEmail;
	}
	public void setIndEnviaEmail(String indEnviaEmail) {
		this.indEnviaEmail = indEnviaEmail;
	}
}
