package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PADRAO_COMUNICACAO")
public class PadraoComunicacao {

	@Id
	@Column(name="CD_PADRAO_COMUNICACAO")
	private Long codPadrao;

	@Column(name="DS_PADRAO")
	private String descPadrao;

	@Column(name="DS_FORMATACAO_PADRAO")
	private String formatacaoPadrao;

	@Column(name="DT_ATUALIZACAO")
	private Date dtAtualizacao;

	@Column(name="NM_USUARIO_ATUALIZACAO")
	private String nomeUsuarioAtualizacao;

	public Long getCodPadrao() {
		return codPadrao;
	}

	public void setCodPadrao(Long codPadrao) {
		this.codPadrao = codPadrao;
	}

	public String getDescPadrao() {
		return descPadrao;
	}

	public void setDescPadrao(String descPadrao) {
		this.descPadrao = descPadrao;
	}

	public String getFormatacaoPadrao() {
		return formatacaoPadrao;
	}

	public void setFormatacaoPadrao(String formatacaoPadrao) {
		this.formatacaoPadrao = formatacaoPadrao;
	}

	public Date getDtAtualizacao() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}

	public String getNomeUsuarioAtualizacao() {
		return nomeUsuarioAtualizacao;
	}

	public void setNomeUsuarioAtualizacao(String nomeUsuarioAtualizacao) {
		this.nomeUsuarioAtualizacao = nomeUsuarioAtualizacao;
	}
}