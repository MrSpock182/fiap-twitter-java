package br.com.tokiomarine.acsel.service;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface MensagemParserService {

	void geraMensagem(AgendamentoEnvio envio) throws ServiceException;

	void geraTitulo(AgendamentoEnvio envio) throws ServiceException;

}