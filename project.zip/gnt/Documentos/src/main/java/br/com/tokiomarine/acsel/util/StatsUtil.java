package br.com.tokiomarine.acsel.util;

public class StatsUtil {

	private static long buscas = 0;

	public static void somaUmaBusca() {
		buscas++;
	}

	public static long getBuscas() {
		return buscas;
	}

}
