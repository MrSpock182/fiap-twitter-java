package br.com.tokiomarine.acsel.service;

import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.dto.UsuarioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;

public interface ValidaSegundaViaService {

	void validaSegundaVia(SolicSegundaViaDTO solic) throws ServiceException;

	void permiteNovaSolicitacao(DocumentoDTO doc, UsuarioDTO usuario) throws ServiceException;

}