package br.com.tokiomarine.acsel.dto;

public class DocumentoRegravar {
	private String ramo;
	private Long numApolice;
	private Long codDocumentoCsf;
	private String urlDocumentoCsf;
	private Long codDocumentoDigital;
	private String urlDocumentoDigital;

	public String getRamo() {
		return ramo;
	}

	public void setRamo(String ramo) {
		this.ramo = ramo;
	}

	public Long getNumApolice() {
		return numApolice;
	}

	public void setNumApolice(Long numApolice) {
		this.numApolice = numApolice;
	}

	public Long getCodDocumentoCsf() {
		return codDocumentoCsf;
	}

	public void setCodDocumentoCsf(Long codDocumentoCsf) {
		this.codDocumentoCsf = codDocumentoCsf;
	}

	public String getUrlDocumentoCsf() {
		return urlDocumentoCsf;
	}

	public void setUrlDocumentoCsf(String urlDocumentoCsf) {
		this.urlDocumentoCsf = urlDocumentoCsf;
	}

	public Long getCodDocumentoDigital() {
		return codDocumentoDigital;
	}

	public void setCodDocumentoDigital(Long codDocumentoDigital) {
		this.codDocumentoDigital = codDocumentoDigital;
	}

	public String getUrlDocumentoDigital() {
		return urlDocumentoDigital;
	}

	public void setUrlDocumentoDigital(String urlDocumentoDigital) {
		this.urlDocumentoDigital = urlDocumentoDigital;
	}


}
