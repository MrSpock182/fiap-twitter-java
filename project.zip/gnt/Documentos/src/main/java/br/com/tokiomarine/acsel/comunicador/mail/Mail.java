package br.com.tokiomarine.acsel.comunicador.mail;

import br.com.tokiomarine.acsel.dto.AnexoEmail;


public interface Mail {

	//void send(String subject, String message, String from, List<String> recipientsTO, List<String> recipientsCC);

	boolean sendMailHtml(String subject, String messageHtml, String from, String[] to, String[] cc, String[] ccOculto, Long seqAgendamento);
	
	boolean sendMailHtmlAttach(String subject, String messageHtml, String from, String[] to, String[] cc, String[] ccOculto, AnexoEmail[] anexos, Long seqAgendamento);
	
}
