package br.com.tokiomarine.acsel.domain.acx;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Table(name="AGENDAMENTO_COMUNICACAO_ANEXO")
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(AgendamentoAnexoPK.class) 
public class AgendamentoAnexo {
	
	@Id
	@Column(name="CD_ANEXO_ID")
	private Long id;

	@Id
	@ManyToOne
	@JoinColumn(name="CD_SEQUENCIA_AGENDAMENTO", referencedColumnName="CD_SEQUENCIA_AGENDAMENTO")
	private AgendamentoComunicacao agendamento;
	
	@Column(name="NM_ANEXO_NOME")
	private String nome;
	
	@Column(name="DS_ANEXO_ARQBASE64")
	private String arquivoBase64;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getArquivoBase64() {
		return arquivoBase64;
	}

	public void setArquivoBase64(String arquivoBase64) {
		this.arquivoBase64 = arquivoBase64;
	}

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}
	
} 
