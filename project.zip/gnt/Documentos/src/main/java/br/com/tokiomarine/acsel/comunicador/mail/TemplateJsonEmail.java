package br.com.tokiomarine.acsel.comunicador.mail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.tokiomarine.acsel.comunicador.TemplateJson;
import br.com.tokiomarine.acsel.dto.DocumentoTemplateDTO;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;

public class TemplateJsonEmail extends TemplateJson {

	private String rastreiaEnvio;
	private String anexos;
	private List<DocumentoTemplateDTO> documentos;
	private List<Map<String, String>> comCopias;
	
	public String getRastreiaEnvio() {
		return rastreiaEnvio;
	}

	public void setRastreiaEnvio(String rastreiaEnvio) {
		this.rastreiaEnvio = rastreiaEnvio;
	}

	public String getAnexos() {
		return anexos;
	}

	public void setAnexos(String anexos) {
		this.anexos = anexos;
	}

	public List<Map<String, String>> getComCopias() {
		return comCopias;
	}

	public void setComCopias(List<Map<String, String>> comCopias) {
		this.comCopias = comCopias;
	}

	public TemplateJsonEmail(String modeloCodigo, ModeloComunicacaoDTO dto, String cc) {
		super(modeloCodigo, dto);
		
		if(cc.equals("S")) {
			this.setComCopias(emailCopia());
		}
		
		this.documentos = new ArrayList<>();
		this.setRastreiaEnvio("N");
		this.setAnexos(null);
		this.documentos.add(new DocumentoTemplateDTO());
		this.documentos.add(new DocumentoTemplateDTO());
	}
	
	private List<Map<String, String>> emailCopia() {
		List<Map<String, String>> listCopia = new ArrayList<>();
		Map<String, String> copias = new HashMap<>();
		copias.put("destino", "gnt@tokiomarine.com.br");
		copias.put("copiaOculta", "N");
		copias.put("cpfCnpj", "99999999");
		listCopia.add(copias);
		return listCopia;
	}
	
}


