package br.com.tokiomarine.acsel.service.impl;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.domain.acx.CadServicos;
import br.com.tokiomarine.acsel.domain.acx.GrpParamAcsel;
import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.domain.acx.ParamAcsel;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.service.ParametrosService;

@Stateless(name = "ParametrosService")
@Local(value = ParametrosService.class)
public class ParametrosServiceImpl implements ParametrosService {

	@Inject
	ParametrosRepository parametrosDao;

	@Override
	public List<Lval> obtemListaValores(String tipoLval) {
		return parametrosDao.obtemListaValores(tipoLval);
	}

	@Override
	public Lval obtemLval(String tipoLval, String codLval) {
		return parametrosDao.obtemLval(tipoLval, codLval);
	}

	@Override
	public List<GrpParamAcsel> obtemGrupos() {
		return parametrosDao.obtemGrupos();
	}

	@Override
	public List<ParamAcsel> obtemParametrosGrupo(Integer grupoId) {
		return parametrosDao.obtemParametrosGrupo(grupoId);
	}

	@Override
	public ParamAcsel atualizaParam(ParamAcsel param) {
		return parametrosDao.atualizaParam(param);
	}

	@Override
	public void insereParam(ParamAcsel param) {
		parametrosDao.insereParam(param);
	}

	@Override
	public void removeParam(ParamAcsel param) {
		parametrosDao.removeParam(param);
	}

	@Override
	public String obtemVlrParametro(String grupo, String param) {
		return parametrosDao.obtemVlrParametro(grupo, param);
	}

	@Override
	public CadServicos obtemServico(String codServico){
		return parametrosDao.obtemServico(codServico);
	}

}
