package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.tokiomarine.acsel.util.StringUtil;


@Entity
@Table(name = "CLIENTE")
public class Cliente implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CODCLI")
	private String codCli;

	@Column(name="CODCLICORP")	private String codCliCorp;

	/*
	@Column(name="TIPOID")		private String tipoId;
	@Column(name="NUMID")		private Long numId;
	@Column(name="DVID")		private String dvId;
	*/

	@ManyToOne
	@JoinColumns({
        @JoinColumn(name = "TIPOID", referencedColumnName = "TIPOID" ),
        @JoinColumn(name = "NUMID", referencedColumnName = "NUMID"),
        @JoinColumn(name = "DVID", referencedColumnName = "DVID" )})
	private Tercero tercero;

	@Column(name="CLASECLI")	private String claseCli;
	@Column(name="TIPOCLI")		private String tipoCli;
	@Column(name="SEXO")		private String sexo;

	@Column(name="FECNAC")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecNac;

	@Column(name="EDOCIVIL")	private String edoCivil;
	@Column(name="CODACT")	private String codAct;

	@Column(name="FECVINC")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecVinc;

	@Column(name="FECLISTANEGRA")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecListaNegra;

	@Column(name="CODLISTANEGRA")	private String codListaNegra;
	@Column(name="MTOINGANUAL")	private BigDecimal mtoIngAnual;

	@Column(name="FECINGANUAL")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecIngAnual;

	@Column(name="NUMCTAAUX")	private String numCtaAux;
	@Column(name="TIPOCONYUGE")	private String tipoConyuge;
	@Column(name="NUMIDCONYUGE")	private Long numIdConyuge;
	@Column(name="DVIDCONYUGE")	private String dvIdConyuge;
	@Column(name="NOMCONYUGE")	private String nomConyuge;
	@Column(name="APECONYUGE")	private String apeConyuge;
	@Column(name="TIPOFACT")	private String tipoFact;
	@Column(name="MTOSUELDO")	private BigDecimal mtoSueldo;
	@Column(name="CODCLIENTE")	private String codCliente;

	@Column(name="FECCOBRJUD")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecCobrJud;

	@Column(name="INDCLIPREF")	private String indCliPref;

	@Column(name="DTINCLUSAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtInclusao;

	@Column(name="DTALTERACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtAlteracao;

	@Column(name="STSBLOQUEIO")	private String stsBloqueio;
	@Column(name="INDCLIGLOB")	private String indCliGlob;


	public String getCodCli() {
		return codCli;
	}
	public void setCodCli(String codCli) {
		this.codCli = codCli;
	}
	public String getCodCliCorp() {
		return codCliCorp;
	}
	public void setCodCliCorp(String codCliCorp) {
		this.codCliCorp = codCliCorp;
	}
	/*
	public String getTipoId() {
		return tipoId;
	}
	public void setTipoId(String tipoId) {
		this.tipoId = tipoId;
	}
	public Long getNumId() {
		return numId;
	}
	public void setNumId(Long numId) {
		this.numId = numId;
	}
	public String getDvId() {
		return dvId;
	}
	public void setDvId(String dvId) {
		this.dvId = dvId;
	}
	*/
	public String getClaseCli() {
		return claseCli;
	}
	public void setClaseCli(String claseCli) {
		this.claseCli = claseCli;
	}
	public String getTipoCli() {
		return tipoCli;
	}
	public void setTipoCli(String tipoCli) {
		this.tipoCli = tipoCli;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public Date getFecNac() {
		return fecNac;
	}
	public void setFecNac(Date fecNac) {
		this.fecNac = fecNac;
	}
	public String getEdoCivil() {
		return edoCivil;
	}
	public void setEdoCivil(String edoCivil) {
		this.edoCivil = edoCivil;
	}
	public String getCodAct() {
		return codAct;
	}
	public void setCodAct(String codAct) {
		this.codAct = codAct;
	}
	public Date getFecVinc() {
		return fecVinc;
	}
	public void setFecVinc(Date fecVinc) {
		this.fecVinc = fecVinc;
	}
	public Date getFecListaNegra() {
		return fecListaNegra;
	}
	public void setFecListaNegra(Date fecListaNegra) {
		this.fecListaNegra = fecListaNegra;
	}
	public String getCodListaNegra() {
		return codListaNegra;
	}
	public void setCodListaNegra(String codListaNegra) {
		this.codListaNegra = codListaNegra;
	}
	public BigDecimal getMtoIngAnual() {
		if (mtoIngAnual==null) mtoIngAnual = new BigDecimal(0);

		return mtoIngAnual;
	}
	public void setMtoIngAnual(BigDecimal mtoIngAnual) {
		this.mtoIngAnual = mtoIngAnual;
	}
	public Date getFecIngAnual() {
		return fecIngAnual;
	}
	public void setFecIngAnual(Date fecIngAnual) {
		this.fecIngAnual = fecIngAnual;
	}
	public String getNumCtaAux() {
		return numCtaAux;
	}
	public void setNumCtaAux(String numCtaAux) {
		this.numCtaAux = numCtaAux;
	}
	public String getTipoConyuge() {
		return tipoConyuge;
	}
	public void setTipoConyuge(String tipoConyuge) {
		this.tipoConyuge = tipoConyuge;
	}
	public Long getNumIdConyuge() {
		return numIdConyuge;
	}
	public void setNumIdConyuge(Long numIdConyuge) {
		this.numIdConyuge = numIdConyuge;
	}
	public String getDvIdConyuge() {
		return dvIdConyuge;
	}
	public void setDvIdConyuge(String dvIdConyuge) {
		this.dvIdConyuge = dvIdConyuge;
	}
	public String getNomConyuge() {
		return nomConyuge;
	}
	public void setNomConyuge(String nomConyuge) {
		this.nomConyuge = nomConyuge;
	}
	public String getApeConyuge() {
		return apeConyuge;
	}
	public void setApeConyuge(String apeConyuge) {
		this.apeConyuge = apeConyuge;
	}
	public String getTipoFact() {
		return tipoFact;
	}
	public void setTipoFact(String tipoFact) {
		this.tipoFact = tipoFact;
	}
	public BigDecimal getMtoSueldo() {
		if (mtoSueldo==null) mtoSueldo = new BigDecimal(0);

		return mtoSueldo;
	}
	public void setMtoSueldo(BigDecimal mtoSueldo) {
		this.mtoSueldo = mtoSueldo;
	}
	public String getCodCliente() {
		return StringUtil.lpad(codCliente, "0", 8);
	}
	public void setCodCliente(String codCliente) {
		this.codCliente = StringUtil.lpad(codCliente, "0", 8);;
	}
	public Date getFecCobrJud() {
		return fecCobrJud;
	}
	public void setFecCobrJud(Date fecCobrJud) {
		this.fecCobrJud = fecCobrJud;
	}
	public String getIndCliPref() {
		return indCliPref;
	}
	public void setIndCliPref(String indCliPref) {
		this.indCliPref = indCliPref;
	}
	public Date getDtInclusao() {
		return dtInclusao;
	}
	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}
	public Date getDtAlteracao() {
		return dtAlteracao;
	}
	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}
	public String getStsBloqueio() {
		return stsBloqueio;
	}
	public void setStsBloqueio(String stsBloqueio) {
		this.stsBloqueio = stsBloqueio;
	}
	public String getIndCliGlob() {
		return indCliGlob;
	}
	public void setIndCliGlob(String indCliGlob) {
		this.indCliGlob = indCliGlob;
	}

	public Tercero getTercero() {
		return tercero;
	}
	public void setTercero(Tercero tercero) {
		this.tercero = tercero;
	}
	@Override
	public String toString() {
		return "Cliente [codCli=" + codCli + ", codCliCorp=" + codCliCorp
				//+ ", tipoId=" + tipoId + ", numId=" + numId + ", dvId=" + dvId
				+ ", claseCli=" + claseCli + ", tipoCli=" + tipoCli + ", sexo="
				+ sexo + ", fecNac=" + fecNac + ", edoCivil=" + edoCivil
				+ ", codAct=" + codAct + ", fecVinc=" + fecVinc
				+ ", fecListaNegra=" + fecListaNegra + ", codListaNegra="
				+ codListaNegra + ", mtoIngAnual=" + mtoIngAnual
				+ ", fecIngAnual=" + fecIngAnual + ", numCtaAux=" + numCtaAux
				+ ", tipoConyuge=" + tipoConyuge + ", numIdConyuge="
				+ numIdConyuge + ", dvIdConyuge=" + dvIdConyuge
				+ ", nomConyuge=" + nomConyuge + ", apeConyuge=" + apeConyuge
				+ ", tipoFact=" + tipoFact + ", mtoSueldo=" + mtoSueldo
				+ ", codCliente=" + codCliente + ", fecCobrJud=" + fecCobrJud
				+ ", indCliPref=" + indCliPref + ", dtInclusao=" + dtInclusao
				+ ", dtAlteracao=" + dtAlteracao + ", stsBloqueio="
				+ stsBloqueio + ", indCliGlob=" + indCliGlob + "]";
	}

}
