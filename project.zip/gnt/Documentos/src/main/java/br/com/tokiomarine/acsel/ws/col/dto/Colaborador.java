
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de colaborador complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="colaborador">
 *   &lt;complexContent>
 *     &lt;extension base="{http://ws.col.tokiomarine.com.br/}colaboradorBasico">
 *       &lt;sequence>
 *         &lt;element name="ativo" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="codigoCargo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoCargoLegado" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoSituacao" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoTipoColaborador" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="cpf" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="dataAdmissao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataDemissao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="descricaoSituacao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="descricaoTipoColaborador" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idDepartamento" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="matriculaSuperior" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="nomeCargo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeDepartamento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeDiretoria" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeLocalComercial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomePredioComercial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeSuperior" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "colaborador", propOrder = {
    "ativo",
    "codigoCargo",
    "codigoCargoLegado",
    "codigoSituacao",
    "codigoTipoColaborador",
    "cpf",
    "dataAdmissao",
    "dataDemissao",
    "descricaoSituacao",
    "descricaoTipoColaborador",
    "email",
    "idDepartamento",
    "matriculaSuperior",
    "nomeCargo",
    "nomeDepartamento",
    "nomeDiretoria",
    "nomeLocalComercial",
    "nomePredioComercial",
    "nomeSuperior"
})
public class Colaborador
    extends ColaboradorBasico
{

    protected boolean ativo;
    protected int codigoCargo;
    protected int codigoCargoLegado;
    protected int codigoSituacao;
    protected int codigoTipoColaborador;
    protected long cpf;
    protected String dataAdmissao;
    protected String dataDemissao;
    protected String descricaoSituacao;
    protected String descricaoTipoColaborador;
    protected String email;
    protected Integer idDepartamento;
    protected Integer matriculaSuperior;
    protected String nomeCargo;
    protected String nomeDepartamento;
    protected String nomeDiretoria;
    protected String nomeLocalComercial;
    protected String nomePredioComercial;
    protected String nomeSuperior;

    /**
     * Obt�m o valor da propriedade ativo.
     *
     */
    public boolean isAtivo() {
        return ativo;
    }

    /**
     * Define o valor da propriedade ativo.
     *
     */
    public void setAtivo(boolean value) {
        this.ativo = value;
    }

    /**
     * Obt�m o valor da propriedade codigoCargo.
     *
     */
    public int getCodigoCargo() {
        return codigoCargo;
    }

    /**
     * Define o valor da propriedade codigoCargo.
     *
     */
    public void setCodigoCargo(int value) {
        this.codigoCargo = value;
    }

    /**
     * Obt�m o valor da propriedade codigoCargoLegado.
     *
     */
    public int getCodigoCargoLegado() {
        return codigoCargoLegado;
    }

    /**
     * Define o valor da propriedade codigoCargoLegado.
     *
     */
    public void setCodigoCargoLegado(int value) {
        this.codigoCargoLegado = value;
    }

    /**
     * Obt�m o valor da propriedade codigoSituacao.
     *
     */
    public int getCodigoSituacao() {
        return codigoSituacao;
    }

    /**
     * Define o valor da propriedade codigoSituacao.
     *
     */
    public void setCodigoSituacao(int value) {
        this.codigoSituacao = value;
    }

    /**
     * Obt�m o valor da propriedade codigoTipoColaborador.
     *
     */
    public int getCodigoTipoColaborador() {
        return codigoTipoColaborador;
    }

    /**
     * Define o valor da propriedade codigoTipoColaborador.
     *
     */
    public void setCodigoTipoColaborador(int value) {
        this.codigoTipoColaborador = value;
    }

    /**
     * Obt�m o valor da propriedade cpf.
     *
     */
    public long getCpf() {
        return cpf;
    }

    /**
     * Define o valor da propriedade cpf.
     *
     */
    public void setCpf(long value) {
        this.cpf = value;
    }

    /**
     * Obt�m o valor da propriedade dataAdmissao.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDataAdmissao() {
        return dataAdmissao;
    }

    /**
     * Define o valor da propriedade dataAdmissao.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDataAdmissao(String value) {
        this.dataAdmissao = value;
    }

    /**
     * Obt�m o valor da propriedade dataDemissao.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDataDemissao() {
        return dataDemissao;
    }

    /**
     * Define o valor da propriedade dataDemissao.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDataDemissao(String value) {
        this.dataDemissao = value;
    }

    /**
     * Obt�m o valor da propriedade descricaoSituacao.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDescricaoSituacao() {
        return descricaoSituacao;
    }

    /**
     * Define o valor da propriedade descricaoSituacao.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDescricaoSituacao(String value) {
        this.descricaoSituacao = value;
    }

    /**
     * Obt�m o valor da propriedade descricaoTipoColaborador.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDescricaoTipoColaborador() {
        return descricaoTipoColaborador;
    }

    /**
     * Define o valor da propriedade descricaoTipoColaborador.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDescricaoTipoColaborador(String value) {
        this.descricaoTipoColaborador = value;
    }

    /**
     * Obt�m o valor da propriedade email.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getEmail() {
        return email;
    }

    /**
     * Define o valor da propriedade email.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Obt�m o valor da propriedade idDepartamento.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getIdDepartamento() {
        return idDepartamento;
    }

    /**
     * Define o valor da propriedade idDepartamento.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setIdDepartamento(Integer value) {
        this.idDepartamento = value;
    }

    /**
     * Obt�m o valor da propriedade matriculaSuperior.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getMatriculaSuperior() {
        return matriculaSuperior;
    }

    /**
     * Define o valor da propriedade matriculaSuperior.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setMatriculaSuperior(Integer value) {
        this.matriculaSuperior = value;
    }

    /**
     * Obt�m o valor da propriedade nomeCargo.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeCargo() {
        return nomeCargo;
    }

    /**
     * Define o valor da propriedade nomeCargo.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeCargo(String value) {
        this.nomeCargo = value;
    }

    /**
     * Obt�m o valor da propriedade nomeDepartamento.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeDepartamento() {
        return nomeDepartamento;
    }

    /**
     * Define o valor da propriedade nomeDepartamento.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeDepartamento(String value) {
        this.nomeDepartamento = value;
    }

    /**
     * Obt�m o valor da propriedade nomeDiretoria.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeDiretoria() {
        return nomeDiretoria;
    }

    /**
     * Define o valor da propriedade nomeDiretoria.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeDiretoria(String value) {
        this.nomeDiretoria = value;
    }

    /**
     * Obt�m o valor da propriedade nomeLocalComercial.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeLocalComercial() {
        return nomeLocalComercial;
    }

    /**
     * Define o valor da propriedade nomeLocalComercial.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeLocalComercial(String value) {
        this.nomeLocalComercial = value;
    }

    /**
     * Obt�m o valor da propriedade nomePredioComercial.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomePredioComercial() {
        return nomePredioComercial;
    }

    /**
     * Define o valor da propriedade nomePredioComercial.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomePredioComercial(String value) {
        this.nomePredioComercial = value;
    }

    /**
     * Obt�m o valor da propriedade nomeSuperior.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeSuperior() {
        return nomeSuperior;
    }

    /**
     * Define o valor da propriedade nomeSuperior.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeSuperior(String value) {
        this.nomeSuperior = value;
    }

}
