
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retColaboradorPorLocal complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retColaboradorPorLocal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ativo" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="codigoSituacao" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="cpf" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="matricula" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeLocalComercial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomePredioComercial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retColaboradorPorLocal", propOrder = {
    "ativo",
    "codigoSituacao",
    "cpf",
    "matricula",
    "nome",
    "nomeLocalComercial",
    "nomePredioComercial"
})
public class RetColaboradorPorLocal {

    protected boolean ativo;
    protected int codigoSituacao;
    protected long cpf;
    protected Integer matricula;
    protected String nome;
    protected String nomeLocalComercial;
    protected String nomePredioComercial;

    /**
     * Obt�m o valor da propriedade ativo.
     *
     */
    public boolean isAtivo() {
        return ativo;
    }

    /**
     * Define o valor da propriedade ativo.
     *
     */
    public void setAtivo(boolean value) {
        this.ativo = value;
    }

    /**
     * Obt�m o valor da propriedade codigoSituacao.
     *
     */
    public int getCodigoSituacao() {
        return codigoSituacao;
    }

    /**
     * Define o valor da propriedade codigoSituacao.
     *
     */
    public void setCodigoSituacao(int value) {
        this.codigoSituacao = value;
    }

    /**
     * Obt�m o valor da propriedade cpf.
     *
     */
    public long getCpf() {
        return cpf;
    }

    /**
     * Define o valor da propriedade cpf.
     *
     */
    public void setCpf(long value) {
        this.cpf = value;
    }

    /**
     * Obt�m o valor da propriedade matricula.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getMatricula() {
        return matricula;
    }

    /**
     * Define o valor da propriedade matricula.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setMatricula(Integer value) {
        this.matricula = value;
    }

    /**
     * Obt�m o valor da propriedade nome.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Obt�m o valor da propriedade nomeLocalComercial.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeLocalComercial() {
        return nomeLocalComercial;
    }

    /**
     * Define o valor da propriedade nomeLocalComercial.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeLocalComercial(String value) {
        this.nomeLocalComercial = value;
    }

    /**
     * Obt�m o valor da propriedade nomePredioComercial.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomePredioComercial() {
        return nomePredioComercial;
    }

    /**
     * Define o valor da propriedade nomePredioComercial.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomePredioComercial(String value) {
        this.nomePredioComercial = value;
    }

}
