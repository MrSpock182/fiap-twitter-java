package br.com.tokiomarine.acsel.comunicador;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;

public interface RastreioEnvio {

	AgendamentoComunicacao addRastreio(AgendamentoComunicacao agendamentoComunicacao);

}
