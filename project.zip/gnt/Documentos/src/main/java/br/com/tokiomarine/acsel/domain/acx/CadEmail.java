package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@IdClass(CadEmailPK.class)
@Table(name = "TAB_CAD_EMAIL")
public class CadEmail {

	@Id @Column(name="IDSERVICO") private Integer idServico;
	@Id @Column(name="IDEMAIL")	private Integer idEmail;
	@Column(name="TIPOEMAIL") private String tipoEmail;
	@Column(name="EMAIL") private String email;

	@ManyToOne
	@JoinColumn(insertable=false, updatable=false, name = "IDSERVICO", referencedColumnName = "IDSERVICO")
	private CadServicos servico;

	public Integer getIdServico() {
		return idServico;
	}

	public void setIdServico(Integer idServico) {
		this.idServico = idServico;
	}

	public Integer getIdEmail() {
		return idEmail;
	}

	public void setIdEmail(Integer idEmail) {
		this.idEmail = idEmail;
	}

	public String getTipoEmail() {
		return tipoEmail;
	}

	public void setTipoEmail(String tipoEmail) {
		this.tipoEmail = tipoEmail;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public CadServicos getServico() {
		return servico;
	}

	public void setServico(CadServicos servico) {
		this.servico = servico;
	}
}