package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "INTERMEDIARIO")
public class Intermediario implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CODINTER")	private String codInter;

	@Column(name="STSLEGALINTER")	private String stsLegalInter;
	@Column(name="AGENTERETENCION")	private String agenteRetencion;
	@Column(name="NUMCTAAUX")	private String numCtaAux;
	/*
	@Column(name="TIPOID")	private String tipoId;
	@Column(name="NUMID")	private Long numId;
	@Column(name="DVID")	private String dvId;
	*/
	@ManyToOne
	@JoinColumns({
        @JoinColumn(name = "TIPOID", referencedColumnName = "TIPOID" ),
        @JoinColumn(name = "NUMID", referencedColumnName = "NUMID"),
        @JoinColumn(name = "DVID", referencedColumnName = "DVID" )})
	private Tercero tercero;

	@Column(name="STSINTER")	private String stsInter;
	@Column(name="FECNAC")	@Temporal(TemporalType.TIMESTAMP)	private Date fecNac;
	@Column(name="FECING")	@Temporal(TemporalType.TIMESTAMP)	private Date fecIng;
	@Column(name="CODSUPERINT")	private String codSuperint;
	@Column(name="FECRET")	@Temporal(TemporalType.TIMESTAMP)	private Date fecRet;
	@Column(name="FECVENCECARNET")	@Temporal(TemporalType.TIMESTAMP)	private Date fecVenceCarnet;
	@Column(name="TIPOINTER")	private String tipoInter;
	@Column(name="CODEJECUTIVOCUENTA")	private String codEjecutivoCuenta;
	@Column(name="CodOfi")	private String codOfi;
	@Column(name="CORTECUENTA")	private String corteCuenta;
	@Column(name="CODCOBRADOR")	private String codCobrador;
	@Column(name="EMITECHEQUE")	private String emiteCheque;
	@Column(name="NUMDEPENDIR")	private Long numDependIr;
	@Column(name="CODINTERCLI")	private String codInterCli;
	@Column(name="INDLISTANEG")	private String indListaNeg;
	@Column(name="VALMINDIAPGTOCOM")	private Long valMinDiaPgtoCom;
	@Column(name="INDMICROEMP")	private String indMicroEmp;
	@Column(name="DESTDOC")	private String destDoc;
	@Column(name="TIPOALTSUSEP")	private String tipoAltSusep;
	@Column(name="FECPROCSUSEP")	@Temporal(TemporalType.TIMESTAMP)	private Date fecProcSusep;
	@Column(name="CODCLASCOR")	private String codClasCor;
	@Column(name="PERIODPGTO")	private String periodPgto;
	@Column(name="DESTEXTRATO")	private String destExtrato;
	@Column(name="DESTCORCLASSIC")	private String destCorClassic;
	@Column(name="SUCCENTRAL")	private String sucCentral;
	@Column(name="FECULTATUALIZACAO")	@Temporal(TemporalType.TIMESTAMP)	private Date fecUltAtualizacao;
	@Column(name="TIPOCOR")	private Long tipoCor;
	@Column(name="CRREALPLUG")	private String crRealPlug;
	@Column(name="CODNAC")	private String codNac;
	@Column(name="CODMOTIVSUS")	private String codMotivSus;
	@Column(name="FECINIRECOLH")	@Temporal(TemporalType.TIMESTAMP)	private Date fecIniRecolh;
	@Column(name="FECALTRECOLH")	@Temporal(TemporalType.TIMESTAMP)	private Date fecAltRecolh;
	@Column(name="NOMERESPALTRECOLH")	private String nomeRespAltRecolh;
	@Column(name="TPCOMUNICRET")	private String tpComunicRet;
	@Column(name="NOMRESP")	private String nomResp;
	@Column(name="NUMIDNEW")	private Long numIdNew;
	@Column(name="DTINCLUSAO")	@Temporal(TemporalType.TIMESTAMP)	private Date dtInclusao;
	@Column(name="DTALTERACAO")	@Temporal(TemporalType.TIMESTAMP)	private Date dtAlteracao;
	@Column(name="INDRECOLH")	private String indRecolh;
	@Column(name="ICONEIMP")	private String iconeImp;
	@Column(name="SITECOR")	private String siteCor;
	@Column(name="INDRECADSUSEP")	private String indRecadSusep;
	@Column(name="DESTDOCPE")	private String destDocPE;
	@Column(name="STSNEGOC")	private String stsNegoc;
	@Column(name="DTINIVIG")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIniVig;
	@Column(name="DTFIMVIG")	@Temporal(TemporalType.TIMESTAMP)	private Date dtFimVig;
	@Column(name="INDCORFICT")	private String indCorFict;
	@Column(name="INDBLOQPLAT")	private String indBloqPlat;
	@Column(name="CODCIABLOQ")	private String codCiaBloq;
	@Column(name="INDATIVOSUSEP")	private String indAtivoSusep;
	@Column(name="CODCATEGORIA")	private String codCategoria;
	@Column(name="USRSUSPENSO")	private String usrSuspenso;
	@Column(name="DTSUSPENSO")	@Temporal(TemporalType.TIMESTAMP)	private Date dtSuspenso;
	@Column(name="DTINIPNC")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIniPnc;
	@Column(name="DTFIMPNC")	@Temporal(TemporalType.TIMESTAMP)	private Date dtFimPnc;
	@Column(name="VALDESPOPER")	private Long valDespOper;
	@Column(name="DTINIPLUG")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIniPlug;
	@Column(name="DTFIMPLUG")	@Temporal(TemporalType.TIMESTAMP)	private Date dtFimPlug;
	@Column(name="DTPRITRANSPLUG")	@Temporal(TemporalType.TIMESTAMP)	private Date dtPriTransPlug;
	@Column(name="DTULTTRANSPLUG")	@Temporal(TemporalType.TIMESTAMP)	private Date dtUltTransPlug;
	@Column(name="COD_LOCAL")	private Long codLoCal;
	@Column(name="COD_SUBLOCAL")	private Long codSubLocal;
	@Column(name="COD_CORRETOR_PLATAFORMA")	private Long codCorretorPlataforma;
	@Column(name="REMUNERACAO_ADIC")	private String remuneracaoAdic;
	@Column(name="PAGTO_SOBRE_PREMIO")	private String pagtoSobrePremio;
	@Column(name="COD_PERIODICIDADE")	private String codPeriodicidade;
	@Column(name="DESCRMOTIVSUS")	private String descrMotivSus;
	@Column(name="DTARQSUSEP")	@Temporal(TemporalType.TIMESTAMP)	private Date dtArqSusep;
	@Column(name="INDCOMADIC")	private String indComAdic;
	@Column(name="INDPLR")	private String indPlr;
	@Column(name="INDCONTDIF")	private String indContDif;
	@Column(name="DTINICOMADIC")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIniComAdic;
	@Column(name="DTFIMCOMADIC")	@Temporal(TemporalType.TIMESTAMP)	private Date dtFimComAdic;
	@Column(name="DTINCCOMADIC")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIncComAdic;
	@Column(name="DTINIPLR")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIniPlr;
	@Column(name="DTFIMPLR")	@Temporal(TemporalType.TIMESTAMP)	private Date dtFimPlr;
	@Column(name="DTINCPLR")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIncPlr;
	@Column(name="DTINICONTDIF")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIniContDif;
	@Column(name="DTFIMCONTDIF")	@Temporal(TemporalType.TIMESTAMP)	private Date dtFimContDif;
	@Column(name="DTINCCONTDIF")	@Temporal(TemporalType.TIMESTAMP)	private Date dtIncContDif;
	@Column(name="ASSESSORIAFRANQUEADORA")	private String assessoriaFranqueadora;
	@Column(name="CODINTERCATIVO")	private String codInterCativo;
	@Column(name="INDREPSEGURO")	private String indRepSeguro;
	//@Column(name="INDCOBDIF")	private String indCobDif;
	public String getCodInter() {
		return codInter;
	}
	public void setCodInter(String codInter) {
		this.codInter = codInter;
	}
	public String getStsLegalInter() {
		return stsLegalInter;
	}
	public void setStsLegalInter(String stsLegalInter) {
		this.stsLegalInter = stsLegalInter;
	}
	public String getAgenteRetencion() {
		return agenteRetencion;
	}
	public void setAgenteRetencion(String agenteRetencion) {
		this.agenteRetencion = agenteRetencion;
	}
	public String getNumCtaAux() {
		return numCtaAux;
	}
	public void setNumCtaAux(String numCtaAux) {
		this.numCtaAux = numCtaAux;
	}
	/*
	public String getTipoId() {
		return tipoId;
	}
	public void setTipoId(String tipoId) {
		this.tipoId = tipoId;
	}
	public Long getNumId() {
		return numId;
	}
	public void setNumId(Long numId) {
		this.numId = numId;
	}
	public String getDvId() {
		return dvId;
	}
	public void setDvId(String dvId) {
		this.dvId = dvId;
	}
	*/
	public String getStsInter() {
		return stsInter;
	}
	public void setStsInter(String stsInter) {
		this.stsInter = stsInter;
	}
	public Date getFecNac() {
		return fecNac;
	}
	public void setFecNac(Date fecNac) {
		this.fecNac = fecNac;
	}
	public Date getFecIng() {
		return fecIng;
	}
	public void setFecIng(Date fecIng) {
		this.fecIng = fecIng;
	}
	public String getCodSuperint() {
		return codSuperint;
	}
	public void setCodSuperint(String codSuperint) {
		this.codSuperint = codSuperint;
	}
	public Date getFecRet() {
		return fecRet;
	}
	public void setFecRet(Date fecRet) {
		this.fecRet = fecRet;
	}
	public Date getFecVenceCarnet() {
		return fecVenceCarnet;
	}
	public void setFecVenceCarnet(Date fecVenceCarnet) {
		this.fecVenceCarnet = fecVenceCarnet;
	}
	public String getTipoInter() {
		return tipoInter;
	}
	public void setTipoInter(String tipoInter) {
		this.tipoInter = tipoInter;
	}
	public String getCodEjecutivoCuenta() {
		return codEjecutivoCuenta;
	}
	public void setCodEjecutivoCuenta(String codEjecutivoCuenta) {
		this.codEjecutivoCuenta = codEjecutivoCuenta;
	}
	public String getCodOfi() {
		return codOfi;
	}
	public void setCodOfi(String codOfi) {
		this.codOfi = codOfi;
	}
	public String getCorteCuenta() {
		return corteCuenta;
	}
	public void setCorteCuenta(String corteCuenta) {
		this.corteCuenta = corteCuenta;
	}
	public String getCodCobrador() {
		return codCobrador;
	}
	public void setCodCobrador(String codCobrador) {
		this.codCobrador = codCobrador;
	}
	public String getEmiteCheque() {
		return emiteCheque;
	}
	public void setEmiteCheque(String emiteCheque) {
		this.emiteCheque = emiteCheque;
	}
	public Long getNumDependIr() {
		return numDependIr;
	}
	public void setNumDependIr(Long numDependIr) {
		this.numDependIr = numDependIr;
	}
	public String getCodInterCli() {
		return codInterCli;
	}
	public void setCodInterCli(String codInterCli) {
		this.codInterCli = codInterCli;
	}
	public String getIndListaNeg() {
		return indListaNeg;
	}
	public void setIndListaNeg(String indListaNeg) {
		this.indListaNeg = indListaNeg;
	}
	public Long getValMinDiaPgtoCom() {
		return valMinDiaPgtoCom;
	}
	public void setValMinDiaPgtoCom(Long valMinDiaPgtoCom) {
		this.valMinDiaPgtoCom = valMinDiaPgtoCom;
	}
	public String getIndMicroEmp() {
		return indMicroEmp;
	}
	public void setIndMicroEmp(String indMicroEmp) {
		this.indMicroEmp = indMicroEmp;
	}
	public String getDestDoc() {
		return destDoc;
	}
	public void setDestDoc(String destDoc) {
		this.destDoc = destDoc;
	}
	public String getTipoAltSusep() {
		return tipoAltSusep;
	}
	public void setTipoAltSusep(String tipoAltSusep) {
		this.tipoAltSusep = tipoAltSusep;
	}
	public Date getFecProcSusep() {
		return fecProcSusep;
	}
	public void setFecProcSusep(Date fecProcSusep) {
		this.fecProcSusep = fecProcSusep;
	}
	public String getCodClasCor() {
		return codClasCor;
	}
	public void setCodClasCor(String codClasCor) {
		this.codClasCor = codClasCor;
	}
	public String getPeriodPgto() {
		return periodPgto;
	}
	public void setPeriodPgto(String periodPgto) {
		this.periodPgto = periodPgto;
	}
	public String getDestExtrato() {
		return destExtrato;
	}
	public void setDestExtrato(String destExtrato) {
		this.destExtrato = destExtrato;
	}
	public String getDestCorClassic() {
		return destCorClassic;
	}
	public void setDestCorClassic(String destCorClassic) {
		this.destCorClassic = destCorClassic;
	}
	public String getSucCentral() {
		return sucCentral;
	}
	public void setSucCentral(String sucCentral) {
		this.sucCentral = sucCentral;
	}
	public Date getFecUltAtualizacao() {
		return fecUltAtualizacao;
	}
	public void setFecUltAtualizacao(Date fecUltAtualizacao) {
		this.fecUltAtualizacao = fecUltAtualizacao;
	}
	public Long getTipoCor() {
		return tipoCor;
	}
	public void setTipoCor(Long tipoCor) {
		this.tipoCor = tipoCor;
	}
	public String getCrRealPlug() {
		return crRealPlug;
	}
	public void setCrRealPlug(String crRealPlug) {
		this.crRealPlug = crRealPlug;
	}
	public String getCodNac() {
		return codNac;
	}
	public void setCodNac(String codNac) {
		this.codNac = codNac;
	}
	public String getCodMotivSus() {
		return codMotivSus;
	}
	public void setCodMotivSus(String codMotivSus) {
		this.codMotivSus = codMotivSus;
	}
	public Date getFecIniRecolh() {
		return fecIniRecolh;
	}
	public void setFecIniRecolh(Date fecIniRecolh) {
		this.fecIniRecolh = fecIniRecolh;
	}
	public Date getFecAltRecolh() {
		return fecAltRecolh;
	}
	public void setFecAltRecolh(Date fecAltRecolh) {
		this.fecAltRecolh = fecAltRecolh;
	}
	public String getNomeRespAltRecolh() {
		return nomeRespAltRecolh;
	}
	public void setNomeRespAltRecolh(String nomeRespAltRecolh) {
		this.nomeRespAltRecolh = nomeRespAltRecolh;
	}
	public String getTpComunicRet() {
		return tpComunicRet;
	}
	public void setTpComunicRet(String tpComunicRet) {
		this.tpComunicRet = tpComunicRet;
	}
	public String getNomResp() {
		return nomResp;
	}
	public void setNomResp(String nomResp) {
		this.nomResp = nomResp;
	}
	public Long getNumIdNew() {
		return numIdNew;
	}
	public void setNumIdNew(Long numIdNew) {
		this.numIdNew = numIdNew;
	}
	public Date getDtInclusao() {
		return dtInclusao;
	}
	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}
	public Date getDtAlteracao() {
		return dtAlteracao;
	}
	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}
	public String getIndRecolh() {
		return indRecolh;
	}
	public void setIndRecolh(String indRecolh) {
		this.indRecolh = indRecolh;
	}
	public String getIconeImp() {
		return iconeImp;
	}
	public void setIconeImp(String iconeImp) {
		this.iconeImp = iconeImp;
	}
	public String getSiteCor() {
		return siteCor;
	}
	public void setSiteCor(String siteCor) {
		this.siteCor = siteCor;
	}
	public String getIndRecadSusep() {
		return indRecadSusep;
	}
	public void setIndRecadSusep(String indRecadSusep) {
		this.indRecadSusep = indRecadSusep;
	}
	public String getDestDocPE() {
		return destDocPE;
	}
	public void setDestDocPE(String destDocPE) {
		this.destDocPE = destDocPE;
	}
	public String getStsNegoc() {
		return stsNegoc;
	}
	public void setStsNegoc(String stsNegoc) {
		this.stsNegoc = stsNegoc;
	}
	public Date getDtIniVig() {
		return dtIniVig;
	}
	public void setDtIniVig(Date dtIniVig) {
		this.dtIniVig = dtIniVig;
	}
	public Date getDtFimVig() {
		return dtFimVig;
	}
	public void setDtFimVig(Date dtFimVig) {
		this.dtFimVig = dtFimVig;
	}
	public String getIndCorFict() {
		return indCorFict;
	}
	public void setIndCorFict(String indCorFict) {
		this.indCorFict = indCorFict;
	}
	public String getIndBloqPlat() {
		return indBloqPlat;
	}
	public void setIndBloqPlat(String indBloqPlat) {
		this.indBloqPlat = indBloqPlat;
	}
	public String getCodCiaBloq() {
		return codCiaBloq;
	}
	public void setCodCiaBloq(String codCiaBloq) {
		this.codCiaBloq = codCiaBloq;
	}
	public String getIndAtivoSusep() {
		return indAtivoSusep;
	}
	public void setIndAtivoSusep(String indAtivoSusep) {
		this.indAtivoSusep = indAtivoSusep;
	}
	public String getCodCategoria() {
		return codCategoria;
	}
	public void setCodCategoria(String codCategoria) {
		this.codCategoria = codCategoria;
	}
	public String getUsrSuspenso() {
		return usrSuspenso;
	}
	public void setUsrSuspenso(String usrSuspenso) {
		this.usrSuspenso = usrSuspenso;
	}
	public Date getDtSuspenso() {
		return dtSuspenso;
	}
	public void setDtSuspenso(Date dtSuspenso) {
		this.dtSuspenso = dtSuspenso;
	}
	public Date getDtIniPnc() {
		return dtIniPnc;
	}
	public void setDtIniPnc(Date dtIniPnc) {
		this.dtIniPnc = dtIniPnc;
	}
	public Date getDtFimPnc() {
		return dtFimPnc;
	}
	public void setDtFimPnc(Date dtFimPnc) {
		this.dtFimPnc = dtFimPnc;
	}
	public Long getValDespOper() {
		return valDespOper;
	}
	public void setValDespOper(Long valDespOper) {
		this.valDespOper = valDespOper;
	}
	public Date getDtIniPlug() {
		return dtIniPlug;
	}
	public void setDtIniPlug(Date dtIniPlug) {
		this.dtIniPlug = dtIniPlug;
	}
	public Date getDtFimPlug() {
		return dtFimPlug;
	}
	public void setDtFimPlug(Date dtFimPlug) {
		this.dtFimPlug = dtFimPlug;
	}
	public Date getDtPriTransPlug() {
		return dtPriTransPlug;
	}
	public void setDtPriTransPlug(Date dtPriTransPlug) {
		this.dtPriTransPlug = dtPriTransPlug;
	}
	public Date getDtUltTransPlug() {
		return dtUltTransPlug;
	}
	public void setDtUltTransPlug(Date dtUltTransPlug) {
		this.dtUltTransPlug = dtUltTransPlug;
	}
	public Long getCodLoCal() {
		return codLoCal;
	}
	public void setCodLoCal(Long codLoCal) {
		this.codLoCal = codLoCal;
	}
	public Long getCodSubLocal() {
		return codSubLocal;
	}
	public void setCodSubLocal(Long codSubLocal) {
		this.codSubLocal = codSubLocal;
	}
	public Long getCodCorretorPlataforma() {
		return codCorretorPlataforma;
	}
	public void setCodCorretorPlataforma(Long codCorretorPlataforma) {
		this.codCorretorPlataforma = codCorretorPlataforma;
	}
	public String getRemuneracaoAdic() {
		return remuneracaoAdic;
	}
	public void setRemuneracaoAdic(String remuneracaoAdic) {
		this.remuneracaoAdic = remuneracaoAdic;
	}
	public String getPagtoSobrePremio() {
		return pagtoSobrePremio;
	}
	public void setPagtoSobrePremio(String pagtoSobrePremio) {
		this.pagtoSobrePremio = pagtoSobrePremio;
	}
	public String getCodPeriodicidade() {
		return codPeriodicidade;
	}
	public void setCodPeriodicidade(String codPeriodicidade) {
		this.codPeriodicidade = codPeriodicidade;
	}
	public String getDescrMotivSus() {
		return descrMotivSus;
	}
	public void setDescrMotivSus(String descrMotivSus) {
		this.descrMotivSus = descrMotivSus;
	}
	public Date getDtArqSusep() {
		return dtArqSusep;
	}
	public void setDtArqSusep(Date dtArqSusep) {
		this.dtArqSusep = dtArqSusep;
	}
	public String getIndComAdic() {
		return indComAdic;
	}
	public void setIndComAdic(String indComAdic) {
		this.indComAdic = indComAdic;
	}
	public String getIndPlr() {
		return indPlr;
	}
	public void setIndPlr(String indPlr) {
		this.indPlr = indPlr;
	}
	public String getIndContDif() {
		return indContDif;
	}
	public void setIndContDif(String indContDif) {
		this.indContDif = indContDif;
	}
	public Date getDtIniComAdic() {
		return dtIniComAdic;
	}
	public void setDtIniComAdic(Date dtIniComAdic) {
		this.dtIniComAdic = dtIniComAdic;
	}
	public Date getDtFimComAdic() {
		return dtFimComAdic;
	}
	public void setDtFimComAdic(Date dtFimComAdic) {
		this.dtFimComAdic = dtFimComAdic;
	}
	public Date getDtIncComAdic() {
		return dtIncComAdic;
	}
	public void setDtIncComAdic(Date dtIncComAdic) {
		this.dtIncComAdic = dtIncComAdic;
	}
	public Date getDtIniPlr() {
		return dtIniPlr;
	}
	public void setDtIniPlr(Date dtIniPlr) {
		this.dtIniPlr = dtIniPlr;
	}
	public Date getDtFimPlr() {
		return dtFimPlr;
	}
	public void setDtFimPlr(Date dtFimPlr) {
		this.dtFimPlr = dtFimPlr;
	}
	public Date getDtIncPlr() {
		return dtIncPlr;
	}
	public void setDtIncPlr(Date dtIncPlr) {
		this.dtIncPlr = dtIncPlr;
	}
	public Date getDtIniContDif() {
		return dtIniContDif;
	}
	public void setDtIniContDif(Date dtIniContDif) {
		this.dtIniContDif = dtIniContDif;
	}
	public Date getDtFimContDif() {
		return dtFimContDif;
	}
	public void setDtFimContDif(Date dtFimContDif) {
		this.dtFimContDif = dtFimContDif;
	}
	public Date getDtIncContDif() {
		return dtIncContDif;
	}
	public void setDtIncContDif(Date dtIncContDif) {
		this.dtIncContDif = dtIncContDif;
	}
	public String getAssessoriaFranqueadora() {
		return assessoriaFranqueadora;
	}
	public void setAssessoriaFranqueadora(String assessoriaFranqueadora) {
		this.assessoriaFranqueadora = assessoriaFranqueadora;
	}
	public String getCodInterCativo() {
		return codInterCativo;
	}
	public void setCodInterCativo(String codInterCativo) {
		this.codInterCativo = codInterCativo;
	}
	public String getIndRepSeguro() {
		return indRepSeguro;
	}
	public void setIndRepSeguro(String indRepSeguro) {
		this.indRepSeguro = indRepSeguro;
	}
	/*public String getIndCobDif() {
		return indCobDif;
	}
	public void setIndCobDif(String indCobDif) {
		this.indCobDif = indCobDif;
	}*/



	@Override
	public String toString() {
		return "Intermediario [codInter=" + codInter + ", stsLegalInter="
				+ stsLegalInter + ", agenteRetencion=" + agenteRetencion
				+ ", numCtaAux=" + numCtaAux
				//+ ", tipoId=" + tipoId + ", numId=" + numId + ", dvId=" + dvId
				+ ", stsInter="
				+ stsInter + ", fecNac=" + fecNac + ", fecIng=" + fecIng
				+ ", codSuperint=" + codSuperint + ", fecRet=" + fecRet
				+ ", fecVenceCarnet=" + fecVenceCarnet + ", tipoInter="
				+ tipoInter + ", codEjecutivoCuenta=" + codEjecutivoCuenta
				+ ", codOfi=" + codOfi + ", corteCuenta=" + corteCuenta
				+ ", codCobrador=" + codCobrador + ", emiteCheque="
				+ emiteCheque + ", numDependIr=" + numDependIr
				+ ", codInterCli=" + codInterCli + ", indListaNeg="
				+ indListaNeg + ", valMinDiaPgtoCom=" + valMinDiaPgtoCom
				+ ", indMicroEmp=" + indMicroEmp + ", destDoc=" + destDoc
				+ ", tipoAltSusep=" + tipoAltSusep + ", fecProcSusep="
				+ fecProcSusep + ", codClasCor=" + codClasCor + ", periodPgto="
				+ periodPgto + ", destExtrato=" + destExtrato
				+ ", destCorClassic=" + destCorClassic + ", sucCentral="
				+ sucCentral + ", fecUltAtualizacao=" + fecUltAtualizacao
				+ ", tipoCor=" + tipoCor + ", crRealPlug=" + crRealPlug
				+ ", codNac=" + codNac + ", codMotivSus=" + codMotivSus
				+ ", fecIniRecolh=" + fecIniRecolh + ", fecAltRecolh="
				+ fecAltRecolh + ", nomeRespAltRecolh=" + nomeRespAltRecolh
				+ ", tpComunicRet=" + tpComunicRet + ", nomResp=" + nomResp
				+ ", numIdNew=" + numIdNew + ", dtInclusao=" + dtInclusao
				+ ", dtAlteracao=" + dtAlteracao + ", indRecolh=" + indRecolh
				+ ", iconeImp=" + iconeImp + ", siteCor=" + siteCor
				+ ", indRecadSusep=" + indRecadSusep + ", destDocPE="
				+ destDocPE + ", stsNegoc=" + stsNegoc + ", dtIniVig="
				+ dtIniVig + ", dtFimVig=" + dtFimVig + ", indCorFict="
				+ indCorFict + ", indBloqPlat=" + indBloqPlat + ", codCiaBloq="
				+ codCiaBloq + ", indAtivoSusep=" + indAtivoSusep
				+ ", codCategoria=" + codCategoria + ", usrSuspenso="
				+ usrSuspenso + ", dtSuspenso=" + dtSuspenso + ", dtIniPnc="
				+ dtIniPnc + ", dtFimPnc=" + dtFimPnc + ", valDespOper="
				+ valDespOper + ", dtIniPlug=" + dtIniPlug + ", dtFimPlug="
				+ dtFimPlug + ", dtPriTransPlug=" + dtPriTransPlug
				+ ", dtUltTransPlug=" + dtUltTransPlug + ", codLoCal="
				+ codLoCal + ", codSubLocal=" + codSubLocal
				+ ", codCorretorPlataforma=" + codCorretorPlataforma
				+ ", remuneracaoAdic=" + remuneracaoAdic
				+ ", pagtoSobrePremio=" + pagtoSobrePremio
				+ ", codPeriodicidade=" + codPeriodicidade + ", descrMotivSus="
				+ descrMotivSus + ", dtArqSusep=" + dtArqSusep
				+ ", indComAdic=" + indComAdic + ", indPlr=" + indPlr
				+ ", indContDif=" + indContDif + ", dtIniComAdic="
				+ dtIniComAdic + ", dtFimComAdic=" + dtFimComAdic
				+ ", dtIncComAdic=" + dtIncComAdic + ", dtIniPlr=" + dtIniPlr
				+ ", dtFimPlr=" + dtFimPlr + ", dtIncPlr=" + dtIncPlr
				+ ", dtIniContDif=" + dtIniContDif + ", dtFimContDif="
				+ dtFimContDif + ", dtIncContDif=" + dtIncContDif
				+ ", assessoriaFranqueadora=" + assessoriaFranqueadora
				+ ", codInterCativo=" + codInterCativo + ", indRepSeguro="
				+ indRepSeguro
				//+ ", indCobDif=" + indCobDif
				+ "]";
	}
	public Tercero getTercero() {
		return tercero;
	}
	public void setTercero(Tercero tercero) {
		this.tercero = tercero;
	}



}