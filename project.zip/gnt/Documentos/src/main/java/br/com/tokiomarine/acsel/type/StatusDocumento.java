package br.com.tokiomarine.acsel.type;

public enum StatusDocumento {


	pendente("P", "PENDENTE"),
	enviado("E", "ENVIADA"),
	cancelado("C", "CANCELADA");

	private String value;
	private String descricao;

	StatusDocumento(String value, String desc) {
		this.value = value;
		this.descricao = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDescricao() {
		return descricao;
	}

	public static StatusDocumento get(String status){
		for (StatusDocumento tipo : StatusDocumento.values()){
			if (tipo.value.equals(status)){
				return tipo;
			}
		}
		return null;
	}
}
