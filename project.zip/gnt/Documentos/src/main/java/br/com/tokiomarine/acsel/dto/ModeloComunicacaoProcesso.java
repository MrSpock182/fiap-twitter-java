package br.com.tokiomarine.acsel.dto;

import lombok.Builder;
import lombok.Getter;

@Builder
public class ModeloComunicacaoProcesso {

	@Getter
	private String codigo, descricao;
	
	
}
