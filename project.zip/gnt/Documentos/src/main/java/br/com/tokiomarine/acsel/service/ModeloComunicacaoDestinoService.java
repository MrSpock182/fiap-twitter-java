package br.com.tokiomarine.acsel.service;

import java.util.Collection;

import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDestino;

public interface ModeloComunicacaoDestinoService {

	Collection<ModeloComunicacaoDestino> findAll();

}
