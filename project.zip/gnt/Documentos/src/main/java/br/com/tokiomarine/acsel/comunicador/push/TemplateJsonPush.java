package br.com.tokiomarine.acsel.comunicador.push;

import br.com.tokiomarine.acsel.comunicador.TemplateJson;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;

public class TemplateJsonPush extends TemplateJson {

	private String corretorCpfCnpj;

	public String getCorretorCpfCnpj() {
		return corretorCpfCnpj;
	}

	public void setCorretorCpfCnpj(String corretorCpfCnpj) {
		this.corretorCpfCnpj = corretorCpfCnpj;
	}
	
	public TemplateJsonPush(String modeloCodigo, ModeloComunicacaoDTO dto) {
		super(modeloCodigo, dto);
		this.setCorretorCpfCnpj("99999999");
	}

}
