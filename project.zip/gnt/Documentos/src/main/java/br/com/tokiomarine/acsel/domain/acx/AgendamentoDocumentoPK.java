package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class AgendamentoDocumentoPK implements Serializable{

	private static final long serialVersionUID = 1249882555827771803L;

	private AgendamentoComunicacao agendamento;
	private DocumentoComunicacao documento;

	public AgendamentoComunicacao getAgendamento() {
		return agendamento;
	}
	public void setAgendamento(AgendamentoComunicacao agendamento) {
		this.agendamento = agendamento;
	}
	public DocumentoComunicacao getDocumento() {
		return documento;
	}
	public void setDocumento(DocumentoComunicacao documento) {
		this.documento = documento;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((agendamento == null) ? 0 : agendamento.hashCode());
		result = prime * result
				+ ((documento == null) ? 0 : documento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgendamentoDocumentoPK other = (AgendamentoDocumentoPK) obj;
		if (agendamento == null) {
			if (other.agendamento != null)
				return false;
		} else if (documento == null) {
			if (other.documento != null)
				return false;
		} else if (!agendamento.equals(other.agendamento)){
			return false;
		} else if (!documento.equals(other.documento)){
			return false;
		}

		return true;
	}

}