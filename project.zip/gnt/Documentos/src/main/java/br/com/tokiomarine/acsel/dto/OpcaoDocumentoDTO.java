package br.com.tokiomarine.acsel.dto;

public class OpcaoDocumentoDTO {

	private String codDocumento;
	private String descDocumento;
	private Boolean obrigatorio;

	public OpcaoDocumentoDTO(String codDocumento, String descDocumento, Boolean obrigatorio) {
		this.codDocumento = codDocumento;
		this.descDocumento = descDocumento;
		this.obrigatorio = obrigatorio;
	}

	public String getCodDocumento() {
		return codDocumento;
	}
	public void setCodDocumento(String codDocumento) {
		this.codDocumento = codDocumento;
	}
	public String getDescDocumento() {
		return descDocumento;
	}
	public void setDescDocumento(String descDocumento) {
		this.descDocumento = descDocumento;
	}
	public Boolean getObrigatorio() {
		return obrigatorio;
	}
	public void setObrigatorio(Boolean obrigatorio) {
		this.obrigatorio = obrigatorio;
	}
}
