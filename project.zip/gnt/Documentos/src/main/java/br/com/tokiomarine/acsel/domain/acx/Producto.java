package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="PRODUCTO")
public class Producto implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CODPROD")	private String codProd;

	@Column(name="DESCPROD")	private String descProd;
	@Column(name="STSPROD")	private String stsprod;
	@Column(name="INDMULTIRAMO")	private String indMultiRamo;
	@Column(name="INDMULTIPLAN")	private String indMultiPlan;
	@Column(name="TIPOSUSCPROD")	private String tipoSuscProd;
	@Column(name="NOMREPORTECERT")	private String nomReporteCert;
	@Column(name="INDPLANPOL")	private String indPlanPol;
	@Column(name="INDRECADCTO")	private String indRecaDcto;
	@Column(name="CODPLANFRACC")	private String codPlanFracc;
	@Column(name="MODPLANFRACC")	private String modPlanFracc;
	@Column(name="INDEXCREN")	private String indExcren;
	@Column(name="INDIMPFACTTARCRE")	private String indImpfacttarcre;
	@Column(name="INDCOBTARJCRE")	private String indCobtarjcre;
	@Column(name="INDRESPPAGO")	private String indRespPago;
	@Column(name="NUM_APOLICE")	private String numApolice;
	@Column(name="NUM_SINISTRO")	private String numSinistro;
	@Column(name="INDNUMCERT")	private String indNumcert;
	@Column(name="NOMFORMACONSPROD")	private String nomFormaConsProd;
	@Column(name="NOMFORMAPROP")	private String nomFormaProp;
	@Column(name="PROPCOMISION")	private String propComision;
	@Column(name="INDCLUBE")	private String indClube;
	@Column(name="TIPRISCO")	private String tipRisco;
	@Column(name="CODCIA")	private String codCia;
	@Column(name="CODPRODGL")	private String codProdgl;
	@Column(name="INDPRESTAMI")	private String indPrestami;
	@Column(name="QTDDIASPROP")	private Long qtdDiasProp;
	@Column(name="QTDDIASRETROAT")	private Long qtdDiasRetroat;
	@Column(name="QTDDIASRETROATPOL")	private Long qtdDiasRetroatPol;
	@Column(name="QTDMAXDIAVIG")	private Long qtdMaxDiavig;
	@Column(name="TIPOVIG")	private String tipoVig;
	@Column(name="CODCNV")	private String codCnv;
	@Column(name="INDRENAUTO")	private String indRenAuto;
	@Column(name="NUMDIASREN")	private Long numDiasRen;
	@Column(name="INDVIDAGRUPO")	private String indVidaGrupo;
	@Column(name="INDESM")	private String indEsm;
	@Column(name="INDPROLABORE")	private String indProlabore;
	@Column(name="NOMREPORTE_PROPOSTA")	private String nomReporteProposta;
	@Column(name="QTDMAXSEG")	private Long qtdMaxSeg;
	@Column(name="INDEDUCACIONAL")	private String indEducacional;
	@Column(name="TIPPERINDENIZA")	private String tipperIndeniza;
	@Column(name="QTDMENSINDENIZA")	private Long qtdmensIndeniza;
	@Column(name="LIMMAXINDENIZA")	private BigDecimal limMaxIndeniza;
	@Column(name="CODPRODPLA")	private Long codProdpla;
	@Column(name="QTDMINSOCIOS")	private Long qtdMinSocios;
	@Column(name="QTDMAXSOCIOS")	private Long qtdMaxSocios;
	@Column(name="QTDMINFUNCS")	private Long qtdMinFuncs;
	@Column(name="QTDMAXFUNCS")	private Long qtdMaxFuncs;
	@Column(name="QTDMINSEG")	private Long qtdMinSeg;
	@Column(name="NUMMINPARC")	private Long numMinParc;
	@Column(name="NUMMAXPARC")	private Long numMaxParc;
	@Column(name="PORCMINAGEN")	private BigDecimal porcMinAgen;
	@Column(name="PORCMAXAGEN")	private BigDecimal porcMaxAgen;
	@Column(name="PRIMAMIN")	private BigDecimal primaMin;
	@Column(name="PRIMAMAX")	private BigDecimal primaMax;
	@Column(name="IDADEMIN")	private Long idadeMin;
	@Column(name="IDADEMAX")	private Long idadeMax;
	@Column(name="PORCMINCOM")	private BigDecimal porcMinCom;
	@Column(name="PORCMAXCOM")	private BigDecimal porcMaxCom;
	@Column(name="PRIMATOTMINPARC")	private BigDecimal primaTotMinParc;
	@Column(name="PRIMATOTMAXPARC")	private BigDecimal primaTotMaxParc;
	@Column(name="DIVISORAGEN")	private BigDecimal divisorAgen;
	@Column(name="QTDDIASPRERENOV")	private Long qtddiasprerenov;
	public String getCodProd() {
		return codProd;
	}
	public void setCodProd(String codProd) {
		this.codProd = codProd;
	}
	public String getDescProd() {
		return descProd;
	}
	public void setDescProd(String descProd) {
		this.descProd = descProd;
	}
	public String getStsprod() {
		return stsprod;
	}
	public void setStsprod(String stsprod) {
		this.stsprod = stsprod;
	}
	public String getIndMultiRamo() {
		return indMultiRamo;
	}
	public void setIndMultiRamo(String indMultiRamo) {
		this.indMultiRamo = indMultiRamo;
	}
	public String getIndMultiPlan() {
		return indMultiPlan;
	}
	public void setIndMultiPlan(String indMultiPlan) {
		this.indMultiPlan = indMultiPlan;
	}
	public String getTipoSuscProd() {
		return tipoSuscProd;
	}
	public void setTipoSuscProd(String tipoSuscProd) {
		this.tipoSuscProd = tipoSuscProd;
	}
	public String getNomReporteCert() {
		return nomReporteCert;
	}
	public void setNomReporteCert(String nomReporteCert) {
		this.nomReporteCert = nomReporteCert;
	}
	public String getIndPlanPol() {
		return indPlanPol;
	}
	public void setIndPlanPol(String indPlanPol) {
		this.indPlanPol = indPlanPol;
	}
	public String getIndRecaDcto() {
		return indRecaDcto;
	}
	public void setIndRecaDcto(String indRecaDcto) {
		this.indRecaDcto = indRecaDcto;
	}
	public String getCodPlanFracc() {
		return codPlanFracc;
	}
	public void setCodPlanFracc(String codPlanFracc) {
		this.codPlanFracc = codPlanFracc;
	}
	public String getModPlanFracc() {
		return modPlanFracc;
	}
	public void setModPlanFracc(String modPlanFracc) {
		this.modPlanFracc = modPlanFracc;
	}
	public String getIndExcren() {
		return indExcren;
	}
	public void setIndExcren(String indExcren) {
		this.indExcren = indExcren;
	}
	public String getIndImpfacttarcre() {
		return indImpfacttarcre;
	}
	public void setIndImpfacttarcre(String indImpfacttarcre) {
		this.indImpfacttarcre = indImpfacttarcre;
	}
	public String getIndCobtarjcre() {
		return indCobtarjcre;
	}
	public void setIndCobtarjcre(String indCobtarjcre) {
		this.indCobtarjcre = indCobtarjcre;
	}
	public String getIndRespPago() {
		return indRespPago;
	}
	public void setIndRespPago(String indRespPago) {
		this.indRespPago = indRespPago;
	}
	public String getNumApolice() {
		return numApolice;
	}
	public void setNumApolice(String numApolice) {
		this.numApolice = numApolice;
	}
	public String getNumSinistro() {
		return numSinistro;
	}
	public void setNumSinistro(String numSinistro) {
		this.numSinistro = numSinistro;
	}
	public String getIndNumcert() {
		return indNumcert;
	}
	public void setIndNumcert(String indNumcert) {
		this.indNumcert = indNumcert;
	}
	public String getNomFormaConsProd() {
		return nomFormaConsProd;
	}
	public void setNomFormaConsProd(String nomFormaConsProd) {
		this.nomFormaConsProd = nomFormaConsProd;
	}
	public String getNomFormaProp() {
		return nomFormaProp;
	}
	public void setNomFormaProp(String nomFormaProp) {
		this.nomFormaProp = nomFormaProp;
	}
	public String getPropComision() {
		return propComision;
	}
	public void setPropComision(String propComision) {
		this.propComision = propComision;
	}
	public String getIndClube() {
		return indClube;
	}
	public void setIndClube(String indClube) {
		this.indClube = indClube;
	}
	public String getTipRisco() {
		return tipRisco;
	}
	public void setTipRisco(String tipRisco) {
		this.tipRisco = tipRisco;
	}
	public String getCodCia() {
		return codCia;
	}
	public void setCodCia(String codCia) {
		this.codCia = codCia;
	}
	public String getCodProdgl() {
		return codProdgl;
	}
	public void setCodProdgl(String codProdgl) {
		this.codProdgl = codProdgl;
	}
	public String getIndPrestami() {
		return indPrestami;
	}
	public void setIndPrestami(String indPrestami) {
		this.indPrestami = indPrestami;
	}
	public Long getQtdDiasProp() {
		return qtdDiasProp;
	}
	public void setQtdDiasProp(Long qtdDiasProp) {
		this.qtdDiasProp = qtdDiasProp;
	}
	public Long getQtdDiasRetroat() {
		return qtdDiasRetroat;
	}
	public void setQtdDiasRetroat(Long qtdDiasRetroat) {
		this.qtdDiasRetroat = qtdDiasRetroat;
	}
	public Long getQtdDiasRetroatPol() {
		return qtdDiasRetroatPol;
	}
	public void setQtdDiasRetroatPol(Long qtdDiasRetroatPol) {
		this.qtdDiasRetroatPol = qtdDiasRetroatPol;
	}
	public Long getQtdMaxDiavig() {
		return qtdMaxDiavig;
	}
	public void setQtdMaxDiavig(Long qtdMaxDiavig) {
		this.qtdMaxDiavig = qtdMaxDiavig;
	}
	public String getTipoVig() {
		return tipoVig;
	}
	public void setTipoVig(String tipoVig) {
		this.tipoVig = tipoVig;
	}
	public String getCodCnv() {
		return codCnv;
	}
	public void setCodCnv(String codCnv) {
		this.codCnv = codCnv;
	}
	public String getIndRenAuto() {
		return indRenAuto;
	}
	public void setIndRenAuto(String indRenAuto) {
		this.indRenAuto = indRenAuto;
	}
	public Long getNumDiasRen() {
		return numDiasRen;
	}
	public void setNumDiasRen(Long numDiasRen) {
		this.numDiasRen = numDiasRen;
	}
	public String getIndVidaGrupo() {
		return indVidaGrupo;
	}
	public void setIndVidaGrupo(String indVidaGrupo) {
		this.indVidaGrupo = indVidaGrupo;
	}
	public String getIndEsm() {
		return indEsm;
	}
	public void setIndEsm(String indEsm) {
		this.indEsm = indEsm;
	}
	public String getIndProlabore() {
		return indProlabore;
	}
	public void setIndProlabore(String indProlabore) {
		this.indProlabore = indProlabore;
	}
	public String getNomReporteProposta() {
		return nomReporteProposta;
	}
	public void setNomReporteProposta(String nomReporteProposta) {
		this.nomReporteProposta = nomReporteProposta;
	}
	public Long getQtdMaxSeg() {
		return qtdMaxSeg;
	}
	public void setQtdMaxSeg(Long qtdMaxSeg) {
		this.qtdMaxSeg = qtdMaxSeg;
	}
	public String getIndEducacional() {
		return indEducacional;
	}
	public void setIndEducacional(String indEducacional) {
		this.indEducacional = indEducacional;
	}
	public String getTipperIndeniza() {
		return tipperIndeniza;
	}
	public void setTipperIndeniza(String tipperIndeniza) {
		this.tipperIndeniza = tipperIndeniza;
	}
	public Long getQtdmensIndeniza() {
		return qtdmensIndeniza;
	}
	public void setQtdmensIndeniza(Long qtdmensIndeniza) {
		this.qtdmensIndeniza = qtdmensIndeniza;
	}
	public BigDecimal getLimMaxIndeniza() {
		if (limMaxIndeniza==null) limMaxIndeniza = new BigDecimal(0);

		return limMaxIndeniza;
	}
	public void setLimMaxIndeniza(BigDecimal limMaxIndeniza) {
		this.limMaxIndeniza = limMaxIndeniza;
	}
	public Long getCodProdpla() {
		return codProdpla;
	}
	public void setCodProdpla(Long codProdpla) {
		this.codProdpla = codProdpla;
	}
	public Long getQtdMinSocios() {
		return qtdMinSocios;
	}
	public void setQtdMinSocios(Long qtdMinSocios) {
		this.qtdMinSocios = qtdMinSocios;
	}
	public Long getQtdMaxSocios() {
		return qtdMaxSocios;
	}
	public void setQtdMaxSocios(Long qtdMaxSocios) {
		this.qtdMaxSocios = qtdMaxSocios;
	}
	public Long getQtdMinFuncs() {
		return qtdMinFuncs;
	}
	public void setQtdMinFuncs(Long qtdMinFuncs) {
		this.qtdMinFuncs = qtdMinFuncs;
	}
	public Long getQtdMaxFuncs() {
		return qtdMaxFuncs;
	}
	public void setQtdMaxFuncs(Long qtdMaxFuncs) {
		this.qtdMaxFuncs = qtdMaxFuncs;
	}
	public Long getQtdMinSeg() {
		return qtdMinSeg;
	}
	public void setQtdMinSeg(Long qtdMinSeg) {
		this.qtdMinSeg = qtdMinSeg;
	}
	public Long getNumMinParc() {
		return numMinParc;
	}
	public void setNumMinParc(Long numMinParc) {
		this.numMinParc = numMinParc;
	}
	public Long getNumMaxParc() {
		return numMaxParc;
	}
	public void setNumMaxParc(Long numMaxParc) {
		this.numMaxParc = numMaxParc;
	}
	public BigDecimal getPorcMinAgen() {
		if (porcMinAgen==null) porcMinAgen = new BigDecimal(0);

		return porcMinAgen;
	}
	public void setPorcMinAgen(BigDecimal porcMinAgen) {
		this.porcMinAgen = porcMinAgen;
	}
	public BigDecimal getPorcMaxAgen() {
		if (porcMaxAgen==null) porcMaxAgen = new BigDecimal(0);

		return porcMaxAgen;
	}
	public void setPorcMaxAgen(BigDecimal porcMaxAgen) {
		this.porcMaxAgen = porcMaxAgen;
	}
	public BigDecimal getPrimaMin() {
		if (primaMin==null) primaMin = new BigDecimal(0);

		return primaMin;
	}
	public void setPrimaMin(BigDecimal primaMin) {
		this.primaMin = primaMin;
	}
	public BigDecimal getPrimaMax() {
		if (primaMax==null) primaMax = new BigDecimal(0);

		return primaMax;
	}
	public void setPrimaMax(BigDecimal primaMax) {
		this.primaMax = primaMax;
	}
	public Long getIdadeMin() {
		return idadeMin;
	}
	public void setIdadeMin(Long idadeMin) {
		this.idadeMin = idadeMin;
	}
	public Long getIdadeMax() {
		return idadeMax;
	}
	public void setIdadeMax(Long idadeMax) {
		this.idadeMax = idadeMax;
	}
	public BigDecimal getPorcMinCom() {
		if (porcMinCom==null) porcMinCom = new BigDecimal(0);

		return porcMinCom;
	}
	public void setPorcMinCom(BigDecimal porcMinCom) {
		this.porcMinCom = porcMinCom;
	}
	public BigDecimal getPorcMaxCom() {
		if (porcMaxCom==null) porcMaxCom = new BigDecimal(0);

		return porcMaxCom;
	}
	public void setPorcMaxCom(BigDecimal porcMaxCom) {
		this.porcMaxCom = porcMaxCom;
	}
	public BigDecimal getPrimaTotMinParc() {
		if (primaTotMinParc==null) primaTotMinParc = new BigDecimal(0);

		return primaTotMinParc;
	}
	public void setPrimaTotMinParc(BigDecimal primaTotMinParc) {
		this.primaTotMinParc = primaTotMinParc;
	}
	public BigDecimal getPrimaTotMaxParc() {
		if (primaTotMaxParc==null) primaTotMaxParc = new BigDecimal(0);

		return primaTotMaxParc;
	}
	public void setPrimaTotMaxParc(BigDecimal primaTotMaxParc) {
		this.primaTotMaxParc = primaTotMaxParc;
	}
	public BigDecimal getDivisorAgen() {
		if (divisorAgen==null) divisorAgen = new BigDecimal(0);

		return divisorAgen;
	}
	public void setDivisorAgen(BigDecimal divisorAgen) {
		this.divisorAgen = divisorAgen;
	}
	public Long getQtddiasprerenov() {
		return qtddiasprerenov;
	}
	public void setQtddiasprerenov(Long qtddiasprerenov) {
		this.qtddiasprerenov = qtddiasprerenov;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codProd == null) ? 0 : codProd.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		if (codProd == null) {
			if (other.codProd != null)
				return false;
		} else if (!codProd.equals(other.codProd))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Producto [codProd=" + codProd + ", descProd=" + descProd
				+ ", stsprod=" + stsprod + ", indMultiRamo=" + indMultiRamo
				+ ", indMultiPlan=" + indMultiPlan + ", tipoSuscProd="
				+ tipoSuscProd + ", nomReporteCert=" + nomReporteCert
				+ ", indPlanPol=" + indPlanPol + ", indRecaDcto=" + indRecaDcto
				+ ", codPlanFracc=" + codPlanFracc + ", modPlanFracc="
				+ modPlanFracc + ", indExcren=" + indExcren
				+ ", indImpfacttarcre=" + indImpfacttarcre + ", indCobtarjcre="
				+ indCobtarjcre + ", indRespPago=" + indRespPago
				+ ", numApolice=" + numApolice + ", numSinistro=" + numSinistro
				+ ", indNumcert=" + indNumcert + ", nomFormaConsProd="
				+ nomFormaConsProd + ", nomFormaProp=" + nomFormaProp
				+ ", propComision=" + propComision + ", indClube=" + indClube
				+ ", tipRisco=" + tipRisco + ", codCia=" + codCia
				+ ", codProdgl=" + codProdgl + ", indPrestami=" + indPrestami
				+ ", qtdDiasProp=" + qtdDiasProp + ", qtdDiasRetroat="
				+ qtdDiasRetroat + ", qtdDiasRetroatPol=" + qtdDiasRetroatPol
				+ ", qtdMaxDiavig=" + qtdMaxDiavig + ", tipoVig=" + tipoVig
				+ ", codCnv=" + codCnv + ", indRenAuto=" + indRenAuto
				+ ", numDiasRen=" + numDiasRen + ", indVidaGrupo="
				+ indVidaGrupo + ", indEsm=" + indEsm + ", indProlabore="
				+ indProlabore + ", nomReporteProposta=" + nomReporteProposta
				+ ", qtdMaxSeg=" + qtdMaxSeg + ", indEducacional="
				+ indEducacional + ", tipperIndeniza=" + tipperIndeniza
				+ ", qtdmensIndeniza=" + qtdmensIndeniza + ", limMaxIndeniza="
				+ limMaxIndeniza + ", codProdpla=" + codProdpla
				+ ", qtdMinSocios=" + qtdMinSocios + ", qtdMaxSocios="
				+ qtdMaxSocios + ", qtdMinFuncs=" + qtdMinFuncs
				+ ", qtdMaxFuncs=" + qtdMaxFuncs + ", qtdMinSeg=" + qtdMinSeg
				+ ", numMinParc=" + numMinParc + ", numMaxParc=" + numMaxParc
				+ ", porcMinAgen=" + porcMinAgen + ", porcMaxAgen="
				+ porcMaxAgen + ", primaMin=" + primaMin + ", primaMax="
				+ primaMax + ", idadeMin=" + idadeMin + ", idadeMax="
				+ idadeMax + ", porcMinCom=" + porcMinCom + ", porcMaxCom="
				+ porcMaxCom + ", primaTotMinParc=" + primaTotMinParc
				+ ", primaTotMaxParc=" + primaTotMaxParc + ", divisorAgen="
				+ divisorAgen + ", qtddiasprerenov=" + qtddiasprerenov + "]";
	}



}