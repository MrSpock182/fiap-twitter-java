package br.com.tokiomarine.acsel.comunicador;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

import br.com.tokiomarine.acsel.type.TipoModelo;

@Stateless(name = "ComunicadorFactory")
public final class ComunicadorFactory {

	@Inject @Named("gntMail")
	private Comunicador gntMail;
	
	@Inject @Named("gntSms")
	private Comunicador gntSms;
	 
	@Inject @Named("gntPush")
	private Comunicador gntPush;

	/*
	 * TODO: a classe sempre crescera se entrar um novo Canal de Comunicacao (Aplicar OCP)
	 */
	public Comunicador getComunicador(TipoModelo tipoModelo) {
		
		/*
		 * TODO: Comentado porque getComunicador() pega um Comunicador que nao esta no contexto do servidor, 
		 * 	atributos dentro da Impl tambem estarao nulos por serem injetados .... 
		 */
		//Comunicador comunicador = tipoModelo.getComunicador();
		//if(comunicador != null) return comunicador;
		
		if(TipoModelo.email == tipoModelo) {
			return this.gntMail;  
		}
		if(TipoModelo.sms == tipoModelo) {
			return this.gntSms;
		}
		if(TipoModelo.push == tipoModelo) {
			return this.gntPush;
		}
		throw new RuntimeException("Comunicador inválido!");
	}
	
}
