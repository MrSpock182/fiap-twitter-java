package br.com.tokiomarine.acsel.util;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.tokiomarine.acsel.type.Aplicacao;

public class VariaveisAmbienteUtil {

	private static Logger logger = LogManager.getLogger(VariaveisAmbienteUtil.class);

	private static String ambienteDetectado;
	private static String cdnPublico;
	private static String cdnRestrito;

	static {
		try {
			if (ServerDetector.isJBoss7() || ServerDetector.isJBoss()) {

				logger.info(" Detectado: JBoss Server");

				ambienteDetectado = System.getProperty(Aplicacao.variavelAmbiente.value());
				cdnPublico = System.getProperty(Aplicacao.cdnPublico.value());
				cdnRestrito = System.getProperty(Aplicacao.cdnRestrito.value());

			} else if (ServerDetector.isTomcat()) {

				logger.info(" Detectado: Tomcat");

				Context initCtx = new InitialContext();
				Context envCtx = (Context) initCtx.lookup("java:comp/env");

				ambienteDetectado = (String) envCtx.lookup(Aplicacao.variavelAmbiente.value());
				cdnPublico = (String) envCtx.lookup(Aplicacao.cdnPublico.value());
				cdnRestrito = (String) envCtx.lookup(Aplicacao.cdnRestrito.value());

			}
			logger.info(" Ambiente detectado: " + ambienteDetectado);
			logger.info(" CDN publico: " + cdnPublico);
			logger.info(" CDN restrito: " + cdnRestrito);

		} catch (Exception e) {
			logger.error("Erro ao detectar servidor",e);
		}
	}

	public static String getAmbienteDetectado() {
		return ambienteDetectado;
	}

	public static String getCdnPublico() {
		return cdnPublico;
	}

	public static String getCdnRestrito() {
		return cdnRestrito;
	}

}
