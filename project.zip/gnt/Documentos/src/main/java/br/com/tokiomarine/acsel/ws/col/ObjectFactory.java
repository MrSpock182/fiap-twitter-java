
package br.com.tokiomarine.acsel.ws.col;

import javax.xml.bind.annotation.XmlRegistry;

import br.com.tokiomarine.acsel.ws.col.dto.Colaborador;
import br.com.tokiomarine.acsel.ws.col.dto.ColaboradorBasico;
import br.com.tokiomarine.acsel.ws.col.dto.LocalTrabalho;
import br.com.tokiomarine.acsel.ws.col.dto.RetCentrosDeCustoWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetColaboradorPorLocal;
import br.com.tokiomarine.acsel.ws.col.dto.RetColaboradorPorMatricula;
import br.com.tokiomarine.acsel.ws.col.dto.RetColaboradorPorNome;
import br.com.tokiomarine.acsel.ws.col.dto.RetColaboradoresPorDepartamento;
import br.com.tokiomarine.acsel.ws.col.dto.RetConsultaDadoFuncionarioWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetDadoFuncionario;
import br.com.tokiomarine.acsel.ws.col.dto.RetDepartamentoPorNome;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetColaboradorPorMatriculaWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetColaboradoresPorDepartamentoWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetColaboradoresPorLocalWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetColaboradoresPorNomeWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetDepartamentos;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetDepartamentosPorNomeWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetGetDepartamentosWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetornoSuperiorWS;
import br.com.tokiomarine.acsel.ws.col.dto.RetornoWS;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the br.com.tokiomarine.col.ws package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.tokiomarine.col.ws
     *
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RetCentrosDeCustoWS }
     *
     */
    public RetCentrosDeCustoWS createRetCentrosDeCustoWS() {
        return new RetCentrosDeCustoWS();
    }

    /**
     * Create an instance of {@link RetornoSuperiorWS }
     *
     */
    public RetornoSuperiorWS createRetornoSuperiorWS() {
        return new RetornoSuperiorWS();
    }

    /**
     * Create an instance of {@link RetGetDepartamentosWS }
     *
     */
    public RetGetDepartamentosWS createRetGetDepartamentosWS() {
        return new RetGetDepartamentosWS();
    }

    /**
     * Create an instance of {@link RetConsultaDadoFuncionarioWS }
     *
     */
    public RetConsultaDadoFuncionarioWS createRetConsultaDadoFuncionarioWS() {
        return new RetConsultaDadoFuncionarioWS();
    }

    /**
     * Create an instance of {@link RetGetColaboradoresPorNomeWS }
     *
     */
    public RetGetColaboradoresPorNomeWS createRetGetColaboradoresPorNomeWS() {
        return new RetGetColaboradoresPorNomeWS();
    }

    /**
     * Create an instance of {@link RetGetDepartamentosPorNomeWS }
     *
     */
    public RetGetDepartamentosPorNomeWS createRetGetDepartamentosPorNomeWS() {
        return new RetGetDepartamentosPorNomeWS();
    }

    /**
     * Create an instance of {@link RetColaboradorPorMatricula }
     *
     */
    public RetColaboradorPorMatricula createRetColaboradorPorMatricula() {
        return new RetColaboradorPorMatricula();
    }

    /**
     * Create an instance of {@link RetornoWS }
     *
     */
    public RetornoWS createRetornoWS() {
        return new RetornoWS();
    }

    /**
     * Create an instance of {@link RetColaboradoresPorDepartamento }
     *
     */
    public RetColaboradoresPorDepartamento createRetColaboradoresPorDepartamento() {
        return new RetColaboradoresPorDepartamento();
    }

    /**
     * Create an instance of {@link RetGetColaboradoresPorDepartamentoWS }
     *
     */
    public RetGetColaboradoresPorDepartamentoWS createRetGetColaboradoresPorDepartamentoWS() {
        return new RetGetColaboradoresPorDepartamentoWS();
    }

    /**
     * Create an instance of {@link RetGetDepartamentos }
     *
     */
    public RetGetDepartamentos createRetGetDepartamentos() {
        return new RetGetDepartamentos();
    }

    /**
     * Create an instance of {@link RetGetColaboradoresPorLocalWS }
     *
     */
    public RetGetColaboradoresPorLocalWS createRetGetColaboradoresPorLocalWS() {
        return new RetGetColaboradoresPorLocalWS();
    }

    /**
     * Create an instance of {@link LocalTrabalho }
     *
     */
    public LocalTrabalho createLocalTrabalho() {
        return new LocalTrabalho();
    }

    /**
     * Create an instance of {@link Colaborador }
     *
     */
    public Colaborador createColaborador() {
        return new Colaborador();
    }

    /**
     * Create an instance of {@link RetColaboradorPorNome }
     *
     */
    public RetColaboradorPorNome createRetColaboradorPorNome() {
        return new RetColaboradorPorNome();
    }

    /**
     * Create an instance of {@link RetDepartamentoPorNome }
     *
     */
    public RetDepartamentoPorNome createRetDepartamentoPorNome() {
        return new RetDepartamentoPorNome();
    }

    /**
     * Create an instance of {@link RetDadoFuncionario }
     *
     */
    public RetDadoFuncionario createRetDadoFuncionario() {
        return new RetDadoFuncionario();
    }

    /**
     * Create an instance of {@link RetGetColaboradorPorMatriculaWS }
     *
     */
    public RetGetColaboradorPorMatriculaWS createRetGetColaboradorPorMatriculaWS() {
        return new RetGetColaboradorPorMatriculaWS();
    }

    /**
     * Create an instance of {@link RetColaboradorPorLocal }
     *
     */
    public RetColaboradorPorLocal createRetColaboradorPorLocal() {
        return new RetColaboradorPorLocal();
    }

    /**
     * Create an instance of {@link ColaboradorBasico }
     *
     */
    public ColaboradorBasico createColaboradorBasico() {
        return new ColaboradorBasico();
    }

}
