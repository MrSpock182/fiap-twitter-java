package br.com.tokiomarine.acsel.service;

import java.util.Date;

import br.com.tokiomarine.acsel.exception.ServiceException;

public interface RelatorioAgendamentoService {

	void geraRelatorioDia(Date dataReferencia) throws ServiceException;

}