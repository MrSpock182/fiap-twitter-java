package br.com.tokiomarine.acsel.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.domain.acx.Tercero;
import br.com.tokiomarine.acsel.domain.acx.TerceroEnderecos;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.EnderecoDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;
import br.com.tokiomarine.acsel.repository.ClienteRepository;
import br.com.tokiomarine.acsel.repository.DocumentoSSVRepository;
import br.com.tokiomarine.acsel.repository.EmpacotadorRepository;
import br.com.tokiomarine.acsel.service.EnderecosService;
import br.com.tokiomarine.acsel.type.TipoDestino;

@Stateless(name = "EnderecosService")
@Local(value = EnderecosService.class)
public class EnderecosServiceImpl implements EnderecosService {

	@Inject
	EmpacotadorRepository empacotadorRep;
	@Inject
	DocumentoSSVRepository documentoSSVRep;
	@Inject
	ClienteRepository clienteRep;

	@Override
	public List<EnderecoDTO> obtemEnderecos(Tercero tercero){

		List<EnderecoDTO> lista = new ArrayList<EnderecoDTO>();
		for (TerceroEnderecos end : tercero.getTerceroEnderecos()) {
			EnderecoDTO dto = new EnderecoDTO();
			dto.setId(end.getNumEnd());
			dto.setLogradourdo(end.getEndereco());
			dto.setNumero(end.getNumLograd());
			dto.setComplemento(end.getCompLograd());
			dto.setBairro(end.getMunicipio().getDescMunicipio());
			dto.setCidade(end.getCiudad().getDesc());
			dto.setEstado(end.getCodEstado());
			dto.setCep(end.getZip());
			lista.add(dto);
		}
		return lista;
	}

	@Override
	public EnderecoDTO obtemEndereco(Tercero tercero){

		EnderecoDTO dto = new EnderecoDTO();
		dto.setId(1L);
		dto.setLogradourdo(tercero.getEndereco());
		dto.setNumero(tercero.getNumLograd());
		dto.setComplemento(tercero.getCompLograd());
		dto.setBairro(tercero.getMunicipio().getDescMunicipio());
		dto.setCidade(tercero.getCiudad().getDesc());
		dto.setEstado(tercero.getCodEstado());
		dto.setCep(tercero.getZip());
		return dto;
	}

	@Override
	public EnderecoDTO obtemEnderecoEnvio(DocumentoDTO doc){
		if (doc.getSistemaOrigem().isAcsel()){
			return empacotadorRep.obtemEnderecoEnvio(doc);
		} else if (doc.getSistemaOrigem().isSSV()){
			return documentoSSVRep.obtemEnderecoEnvio(doc);
		}
		return null;
	}

	@Override
	public EnderecoDTO obtemEnderecoEnvio(SegundaViaDTO segundaVia){
		if (segundaVia.getTipoDestino() == null) {
           return null;
		}
		
		if (segundaVia.getTipoDestino().equals(TipoDestino.corretor)){
			return segundaVia.getDocumento().getEnderecoCorretor();
		} else if (segundaVia.getTipoDestino().equals(TipoDestino.segurado)){
			for (EnderecoDTO end : segundaVia.getDocumento().getEnderecosCliente()){
				if (segundaVia.getNumEndereco() != null && end.getId().intValue() == segundaVia.getNumEndereco()){
					return end;
				}
			}
		}
		return null;
	}

	
}
