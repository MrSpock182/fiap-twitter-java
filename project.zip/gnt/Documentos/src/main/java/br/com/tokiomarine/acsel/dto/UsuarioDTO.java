package br.com.tokiomarine.acsel.dto;

import br.com.tokiomarine.acsel.type.TipoUsuario;
import br.com.tokiomarine.acsel.util.StringUtil;

public class UsuarioDTO {

	private String idUsuario;
	private String nomeUsuario;
	private TipoUsuario tipoUsuario;
	private String codCorretor;

	public String getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}
	public String getNomeUsuario() {
		return nomeUsuario;
	}
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}
	public TipoUsuario getTipoUsuario() {
		return tipoUsuario;
	}
	public void setTipoUsuario(TipoUsuario tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
	public String getCodCorretor() {
		return codCorretor;
	}
	public void setCodCorretor(String codCorretor) {
		this.codCorretor = StringUtil.lpad(codCorretor,"0",6);
	}
	public boolean isCorretor(){
		return this.tipoUsuario.equals(TipoUsuario.corretor);
	}
	public String getCodUsuario(){
		if (isCorretor()){
			return this.codCorretor;
		} else{
			return this.idUsuario;
		}
	}
}
