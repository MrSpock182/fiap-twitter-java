package br.com.tokiomarine.acsel.dto;

import com.sun.mail.util.BASE64DecoderStream;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnexoEmail {

	@Getter @Setter
	private String nome, fileBase64;
	
	@Getter @Setter
	private byte [] binario;
	
	public static class AnexoEmailBuilder {
		public AnexoEmailBuilder binario(String arquivoBase64) {
			byte[] bytes = arquivoBase64.getBytes();
			byte[] decode = BASE64DecoderStream.decode(bytes);
			this.binario = decode;
			return this;			
		}
	}

}
