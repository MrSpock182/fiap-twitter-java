package br.com.tokiomarine.acsel.service;

import java.util.Date;
import java.util.List;

import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.dto.DocumentoDTO;
import br.com.tokiomarine.acsel.dto.DocumentoRecriar;
import br.com.tokiomarine.acsel.dto.DownloadDocumentoDTO;
import br.com.tokiomarine.acsel.dto.SegundaViaDTO;
import br.com.tokiomarine.acsel.dto.SolicSegundaViaDTO;
import br.com.tokiomarine.acsel.dto.UsuarioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.type.OpcaoSolic;

public interface SegundaViaService {

	void solicitaSegundaVia(SolicSegundaViaDTO solic) throws ServiceException;

	void cancelaSegundaVia(SegundaViaDTO segundaVia, UsuarioDTO usuarioSessao) throws ServiceException;

	List<SegundaViaDTO> obtemSolicitacoes(DocumentoDTO documento);

	List<Lval> obtemMotivosSolic();

	List<OpcaoSolic> obtemOpcoesSolic(DocumentoDTO doc, UsuarioDTO usuario) throws ServiceException;

	boolean permiteCorretor(String codCorretor);

	boolean permiteEnvioAR(DocumentoDTO doc, UsuarioDTO usuario);

	String obtemLinkDownload(DocumentoDTO doc, String codItem, Long codDocumento, String email, List<DownloadDocumentoDTO> lista) throws ServiceException;
	
//	String obtemArquivoPDF(DownloadDocumentoDTO downloadDocumentoDTO, List<DownloadDocumentoDTO> lista, String email );
	
	boolean fileExists(String urlSegundaVia);
	
	String reprocessDocument(final DocumentoDTO doc, final Long codDocumento) throws Exception;
	
	List<DocumentoRecriar> listaDocument(Date dataInicio);

}
