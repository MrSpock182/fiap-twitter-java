package br.com.tokiomarine.acsel.service.impl;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoErro;
import br.com.tokiomarine.acsel.domain.acx.CadServicos;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.dto.ResumoAgendamentoDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.AgendamentoComunicacaoRepository;
import br.com.tokiomarine.acsel.repository.ModeloComunicacaoRepository;
import br.com.tokiomarine.acsel.service.EmailService;
import br.com.tokiomarine.acsel.service.ParametrosService;
import br.com.tokiomarine.acsel.service.RelatorioAgendamentoService;
import br.com.tokiomarine.acsel.type.StatusAgendamento;
import br.com.tokiomarine.acsel.util.DateUtil;
import br.com.tokiomarine.infra.componente.email.dto.Anexo;

@Stateless(name = "RelatorioAgendamentoService")
@Local(value = RelatorioAgendamentoService.class)
public class RelatorioAgendamentoServiceImpl implements RelatorioAgendamentoService{

	private static Logger logger = LogManager.getLogger(RelatorioAgendamentoServiceImpl.class);

	@Inject
	AgendamentoComunicacaoRepository agendamentoDao;
	@Inject
	ModeloComunicacaoRepository modeloDao;
	@Inject
	ParametrosService paramService;
	@Inject
	EmailService emailService;

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void geraRelatorioDia(Date dataReferencia) throws ServiceException{

		CadServicos servicoEmail = paramService.obtemServico("AP_DIG_REL_AGEND");

		String html = geraHTML(servicoEmail, dataReferencia);
		Anexo anexo = geraPlanilha(dataReferencia);

		emailService.enviaEmail(servicoEmail, html, anexo, null);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	private Anexo geraPlanilha(Date dataReferencia) throws ServiceException{

		try{
			List<ModeloComunicacao> modelos = obterModelos();
			HSSFWorkbook planilha = new HSSFWorkbook();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();

			CellStyle cellStyle = planilha.createCellStyle();
			CreationHelper createHelper = planilha.getCreationHelper();
		    cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy hh:mm:ss"));

		    for (ModeloComunicacao modelo : modelos){

				int numLinha = 0;
				int numCell = 0;

				HSSFSheet abaPlanilha = planilha.createSheet(modelo.getNomeModelo());

				List<ParametroModelo> parametros = obterParametros(modelo);

				HSSFRow linhaHeader = abaPlanilha.createRow(numLinha++);

				linhaHeader.createCell(numCell++).setCellValue("Identificador");

				for (ParametroModelo param : parametros) {
					linhaHeader.createCell(numCell++).setCellValue(param.getParametro().getNomeParametro());
				}

				linhaHeader.createCell(numCell++).setCellValue("Data Agendamento");
				linhaHeader.createCell(numCell++).setCellValue("Data Envio");
				linhaHeader.createCell(numCell++).setCellValue("Enviado para");
				linhaHeader.createCell(numCell++).setCellValue("Situação");
				linhaHeader.createCell(numCell++).setCellValue("Mensagem Erro");

				for (AgendamentoComunicacao agend : obterAgendamentosDia(dataReferencia, modelo)){

					HSSFRow linha = abaPlanilha.createRow(numLinha++);
					numCell = 0;

					linha.createCell(numCell++).setCellValue(agend.getSeqAgendamento().toString());

					for (ParametroModelo param : parametros) {
						linha.createCell(numCell++).setCellValue(agend.getValorParametro(param.getParametro().getNomeParametro()));
					}

					HSSFCell cell = linha.createCell(numCell++);
					cell.setCellValue(agend.getDtAgendamento());
					cell.setCellStyle(cellStyle);

					if (agend.getDtEnvioOriginal() == null){
						linha.createCell(numCell++).setCellValue("");
					} else{
						cell = linha.createCell(numCell++);
						cell.setCellValue(agend.getDtEnvioOriginal());
						cell.setCellStyle(cellStyle);
					}

					linha.createCell(numCell++).setCellValue(agend.formataDestinatarios());
					linha.createCell(numCell++).setCellValue(agend.getStatus().getDescricao());

					String erros = "";
					AgendamentoEnvio envio = obterUltimoEnvio(agend);
					if (envio != null && envio.getStatus().equals(StatusAgendamento.erro)){
						for (AgendamentoErro erro : obterErros(envio)){
							erros = erros + erro.getDescErro() + ";";
						}
					}
					linha.createCell(numCell++).setCellValue(erros);
				}
			}
			planilha.write(bos);

			return new Anexo("RelatorioEnvios" + DateUtil.formataSemHora(dataReferencia) + ".xls",
					"Relatório diário de envios", "application/excel", bos.toByteArray());

		} catch (Exception e){
			logger.error("Erro ao gerar planilha de relatório", e);
		}

		return null;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	private List<AgendamentoErro> obterErros(AgendamentoEnvio envio) {
		return agendamentoDao.obtemErros(envio.getSeqEnvio());
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	private AgendamentoEnvio obterUltimoEnvio(AgendamentoComunicacao agend) {
		return agendamentoDao.obtemUltimoEnvio(agend.getSeqAgendamento());
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	private List<AgendamentoComunicacao> obterAgendamentosDia(Date dataReferencia, ModeloComunicacao modelo) {
		return agendamentoDao.buscaAgendamentosDia(modelo.getCodModelo(), dataReferencia);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	private List<ParametroModelo> obterParametros(ModeloComunicacao modelo) {
		return modeloDao.obtemParametrosConsulta(modelo.getCodModelo());
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	private List<ModeloComunicacao> obterModelos() {
		return modeloDao.obtemModelosWithSituacaoModeloEqS();
	}

	private String geraHTML(CadServicos servico, Date dataReferencia) throws ServiceException{

		String htmlEmail = "";

		try{

			List<ResumoAgendamentoDTO> listaResumo = agendamentoDao.obtemResumoDia(dataReferencia);

			htmlEmail = servico.getTextoEmail();
			htmlEmail = htmlEmail.replace("$DATAPROCESSAMENTO$", DateUtil.formataSemHora(dataReferencia));
			htmlEmail = htmlEmail.replace("$TABELARESUMO$", formataTabela(listaResumo));

		} catch (Exception e){
			logger.error("Erro ao gerar e-mail de relatório", e);
			throw new ServiceException("Erro ao gerar e-mail de relatório");
		}

		return htmlEmail;
	}

	private String formataTabela(List<ResumoAgendamentoDTO> tabela){
		StringBuilder tabelaResumo = new StringBuilder();

		for (ResumoAgendamentoDTO res :tabela){
			tabelaResumo.append("<tr>");

			tabelaResumo.append("<td>");
			tabelaResumo.append(res.getNomeModelo());
			tabelaResumo.append("</td>");

			tabelaResumo.append("<td style='text-align:center'>");
			tabelaResumo.append(res.getTipoModelo());
			tabelaResumo.append("</td>");

			tabelaResumo.append("<td style='text-align:center'>");
			tabelaResumo.append(res.getNomeSistema());
			tabelaResumo.append("</td>");

			tabelaResumo.append("<td style='text-align:right'>");
			tabelaResumo.append(res.getQtdEnviados());
			tabelaResumo.append("</td>");

			tabelaResumo.append("<td style='text-align:right'>");
			tabelaResumo.append(res.getQtdNaoEnviados());
			tabelaResumo.append("</td>");

			tabelaResumo.append("<td style='text-align:right'>");
			tabelaResumo.append(res.getQtdErro());
			tabelaResumo.append("</td>");

			tabelaResumo.append("</tr>");
		}
		return tabelaResumo.toString();
	}

}
