package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class LvalPK implements Serializable {

	private static final long serialVersionUID = 1L;

	private String tipoLval;
	private String codLval;
	public String getTipoLval() {
		return tipoLval;
	}
	public void setTipoLval(String tipoLval) {
		this.tipoLval = tipoLval;
	}
	public String getCodLval() {
		return codLval;
	}
	public void setCodLval(String codLval) {
		this.codLval = codLval;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codLval == null) ? 0 : codLval.hashCode());
		result = prime * result
				+ ((tipoLval == null) ? 0 : tipoLval.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LvalPK other = (LvalPK) obj;
		if (codLval == null) {
			if (other.codLval != null)
				return false;
		} else if (!codLval.equals(other.codLval))
			return false;
		if (tipoLval == null) {
			if (other.tipoLval != null)
				return false;
		} else if (!tipoLval.equals(other.tipoLval))
			return false;
		return true;
	}
}
