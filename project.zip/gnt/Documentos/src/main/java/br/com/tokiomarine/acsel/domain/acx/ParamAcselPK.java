package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class ParamAcselPK implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idGrpParamAcsel;
	private String codParametro;

	public Integer getIdGrpParamAcsel() {
		return idGrpParamAcsel;
	}
	public void setIdGrpParamAcsel(Integer idGrpParamAcsel) {
		this.idGrpParamAcsel = idGrpParamAcsel;
	}
	public String getCodParametro() {
		return codParametro;
	}
	public void setCodParametro(String codParametro) {
		this.codParametro = codParametro;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idGrpParamAcsel == null) ? 0 : idGrpParamAcsel.hashCode());
		result = prime * result
				+ ((codParametro == null) ? 0 : codParametro.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParamAcselPK other = (ParamAcselPK) obj;
		if (codParametro == null) {
			if (other.codParametro != null)
				return false;
		} else if (!codParametro.equals(other.codParametro))
			return false;
		if (idGrpParamAcsel == null) {
			if (other.idGrpParamAcsel != null)
				return false;
		} else if (!idGrpParamAcsel.equals(other.idGrpParamAcsel))
			return false;
		return true;
	}
}
