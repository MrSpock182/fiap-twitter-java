package br.com.tokiomarine.acsel.domain.acx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(LvalPK.class)
@Table(name = "LVAL")
public class Lval {

	@Id
	@Column(name="TIPOLVAL")	private String tipoLval;
	@Id
	@Column(name="CODLVAL")	private String codLval;

	@Column(name="DESCRIP")	private String descrip;
	public String getTipoLval() {
		return tipoLval;
	}
	public void setTipoLval(String tipoLval) {
		this.tipoLval = tipoLval;
	}
	public String getCodLval() {
		return codLval;
	}
	public void setCodLval(String codLval) {
		this.codLval = codLval;
	}
	public String getDescrip() {
		return descrip;
	}
	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}
}