package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "POLIZA")
public class Poliza implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SQ_IDEPOL", sequenceName="SQ_IDEPOL")
	@GeneratedValue(generator="SQ_IDEPOL", strategy=GenerationType.AUTO)
	@Column(name="IDEPOL")	private Long idePol; 							//Identificador único de la Póliza.

	@Column(name="CODPOL")	private String codPol;
	@Column(name="NUMPOL")	private Long numPol;

	@ManyToOne
	@JoinColumn(name="CODCLI", referencedColumnName="CODCLI")
	private Cliente cliente;

	@Column(name="TIPOCOTPOL")	private String tipoCotPol;

	@Column(name="FECOPER")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecOper;

	@Column(name="OBSERVA")	private String observa;
	@Column(name="NUMREN")	private Long numRen;
	@Column(name="INDNUMPOL")	private String indNumPol;

	@ManyToOne()
    @JoinColumn(name = "CODPROD", referencedColumnName = "CODPROD" )
	private Producto producto;

	@OneToOne
	@JoinColumn(name="IDEPOL", referencedColumnName="IDEPOL")
	private PolizaCli polizaCli;

	@Column(name="STSPOL")	private String stsPol;

	@Column(name="FECREN")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecRen;

	@Column(name="FECINIVIG")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecIniVig;

	@Column(name="FECFINVIG")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecFinVig;

	@Column(name="TIPOVIG")	private String tipoVig;
	@Column(name="TIPOPDCION")	private String tipoPdCion;
	@Column(name="TIPOFACT")	private String tipoFact;
	@Column(name="INDCOA")	private String indCoa;
	@Column(name="CODFORMFCION")	private String codFormfCion;
	@Column(name="CodOfiEMI")	private String codOfiEmi;
	@Column(name="CodOfiSUSC")	private String codOfiSusc;
	@Column(name="CODMONEDA")	private String codMoneda;
	@Column(name="INDMULTIINTER")	private String indMultiInter;
	@Column(name="INDPolADHESION")	private String indPolAdhesion;
	@Column(name="INDRENAUTO")	private String indRenAuto;

	@Column(name="FECANUL")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecAnul;

	@Column(name="CODMOTVANUL")	private String codMotvAnul;
	@Column(name="TEXTMOTVANUL")	private String textMotvAnul;
	@Column(name="TIPOSUSC")	private String tipoSusc;
	@Column(name="CODFORMPAGO")	private String codFormPago;
	@Column(name="TIPOANUL")	private String tipoAnul;

	@Column(name="FECULTFACT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecUltfact;

	@Column(name="CODPLANFRAC")	private String codPlanFrac;
	@Column(name="MODPLANFRAC")	private String modPlanFrac;
	@Column(name="INDCOBPROV")	private String indCobprov;
	@Column(name="INDTIPOPRO")	private String indTipoPro;
	@Column(name="CLASEPOL")	private String clasePol;			//Clase de la Póliza.
	@Column(name="PORCCTP")	private BigDecimal porcCtp; 			//Porcentaje de Corto Plazo para anulacion
	@Column(name="INDFACT")	private String indFact;
	@Column(name="INDMOVPolREN")	private String indMovPolren;
	@Column(name="INDRESPPAGO")	private String indRespPago;

	@Column(name="FECINIPOL")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecIniPol;

	@Column(name="IDECOT")	private Long ideCot;
	@Column(name="INDRECUPREA")	private String indRecuprea;
	@Column(name="TIPOCOBRO")	private String tipoCobro;
	@Column(name="CODESTIPULANTE")	private String codEstipulante;
	@Column(name="PORCPROLABOR")	private BigDecimal porcProlabor;
	@Column(name="INDPAGOVISTA")	private String indPagoVista;
	@Column(name="INDGENBOL")	private String indGenBol;
	@Column(name="INDDEVIOF")	private String indDeviof;
	@Column(name="TIPOCOB")	private String tipoCob;
	@Column(name="CODCIA")	private String codCia;
	@Column(name="CODRAMO")	private String codRamo;
	@Column(name="CODENTFINANCAP")	private String codEntfinancap;
	@Column(name="INDCOBRLIQIMP")	private String indCobrLiqImp;
	@Column(name="IDEPolREN")	private Long idePolRen;
	@Column(name="INDCOBRJUD")	private String indCobrJud;
	@Column(name="INDBLOQFATUR")	private String indBloqFatur;
	@Column(name="DEVDOC")	private String devDoc;
	@Column(name="CODMONCORRECSIN")	private String codMonCorrecSin;

	@Column(name="FECINCPOL")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecIncPol;


	@Column(name="IDEPROP")
	@SequenceGenerator(name="SQ_IDEPROP", sequenceName="SQ_IDEPROP")
	@GeneratedValue(generator="SQ_IDEPROP", strategy=GenerationType.AUTO)
	private Long ideProp;


	@Column(name="DESTDOC")	private String destDoc;
	@Column(name="PORCCOM")	private BigDecimal porcCom;
	@Column(name="DIFERAGENC")	private Long diferAgenc;
	@Column(name="IDEFACTVG")	private Long ideFactvg;
	@Column(name="INDESPECIAL")	private String indEspecial;
	@Column(name="INDPGTOCARNE")	private String indPgtoCarne;
	@Column(name="INDHONDA")	private String indHonda;
	@Column(name="PORCAGEN")	private BigDecimal porcAgen;
	@Column(name="CODCIAORIG")	private String codCiaOrig;
	@Column(name="ID_CRT_GERENCIAL")	private String idCrtGerencial;
	@Column(name="ID_MICRO_SEGURO")	private String idMicroSeguro;

	public Long getIdePol() {
		return idePol;
	}
	public void setIdePol(Long idePol) {
		this.idePol = idePol;
	}
	public String getCodPol() {
		return codPol;
	}
	public void setCodPol(String codPol) {
		this.codPol = codPol;
	}
	public Long getNumPol() {
		return numPol;
	}
	public void setNumPol(Long numPol) {
		this.numPol = numPol;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public String getTipoCotPol() {
		return tipoCotPol;
	}
	public void setTipoCotPol(String tipoCotPol) {
		this.tipoCotPol = tipoCotPol;
	}
	public Date getFecOper() {
		return fecOper;
	}
	public void setFecOper(Date fecOper) {
		this.fecOper = fecOper;
	}
	public String getObserva() {
		return observa;
	}
	public void setObserva(String observa) {
		this.observa = observa;
	}
	public Long getNumRen() {
		return numRen;
	}
	public void setNumRen(Long numRen) {
		this.numRen = numRen;
	}
	public String getIndNumPol() {
		return indNumPol;
	}
	public void setIndNumPol(String indNumPol) {
		this.indNumPol = indNumPol;
	}
	public Producto getProducto() {
		return producto;
	}
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
	public PolizaCli getPolizaCli() {
		return polizaCli;
	}
	public void setPolizaCli(PolizaCli polizaCli) {
		this.polizaCli = polizaCli;
	}
	public String getStsPol() {
		return stsPol;
	}
	public void setStsPol(String stsPol) {
		this.stsPol = stsPol;
	}
	public Date getFecRen() {
		return fecRen;
	}
	public void setFecRen(Date fecRen) {
		this.fecRen = fecRen;
	}
	public Date getFecIniVig() {
		return fecIniVig;
	}
	public void setFecIniVig(Date fecIniVig) {
		this.fecIniVig = fecIniVig;
	}
	public Date getFecFinVig() {
		return fecFinVig;
	}
	public void setFecFinVig(Date fecFinVig) {
		this.fecFinVig = fecFinVig;
	}
	public String getTipoVig() {
		return tipoVig;
	}
	public void setTipoVig(String tipoVig) {
		this.tipoVig = tipoVig;
	}
	public String getTipoPdCion() {
		return tipoPdCion;
	}
	public void setTipoPdCion(String tipoPdCion) {
		this.tipoPdCion = tipoPdCion;
	}
	public String getTipoFact() {
		return tipoFact;
	}
	public void setTipoFact(String tipoFact) {
		this.tipoFact = tipoFact;
	}
	public String getIndCoa() {
		return indCoa;
	}
	public void setIndCoa(String indCoa) {
		this.indCoa = indCoa;
	}
	public String getCodFormfCion() {
		return codFormfCion;
	}
	public void setCodFormfCion(String codFormfCion) {
		this.codFormfCion = codFormfCion;
	}
	public String getCodOfiEmi() {
		return codOfiEmi;
	}
	public void setCodOfiEmi(String codOfiEmi) {
		this.codOfiEmi = codOfiEmi;
	}
	public String getCodOfiSusc() {
		return codOfiSusc;
	}
	public void setCodOfiSusc(String codOfiSusc) {
		this.codOfiSusc = codOfiSusc;
	}
	public String getCodMoneda() {
		return codMoneda;
	}
	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}
	public String getIndMultiInter() {
		return indMultiInter;
	}
	public void setIndMultiInter(String indMultiInter) {
		this.indMultiInter = indMultiInter;
	}
	public String getIndPolAdhesion() {
		return indPolAdhesion;
	}
	public void setIndPolAdhesion(String indPolAdhesion) {
		this.indPolAdhesion = indPolAdhesion;
	}
	public String getIndRenAuto() {
		return indRenAuto;
	}
	public void setIndRenAuto(String indRenAuto) {
		this.indRenAuto = indRenAuto;
	}
	public Date getFecAnul() {
		return fecAnul;
	}
	public void setFecAnul(Date fecAnul) {
		this.fecAnul = fecAnul;
	}
	public String getCodMotvAnul() {
		return codMotvAnul;
	}
	public void setCodMotvAnul(String codMotvAnul) {
		this.codMotvAnul = codMotvAnul;
	}
	public String getTextMotvAnul() {
		return textMotvAnul;
	}
	public void setTextMotvAnul(String textMotvAnul) {
		this.textMotvAnul = textMotvAnul;
	}
	public String getTipoSusc() {
		return tipoSusc;
	}
	public void setTipoSusc(String tipoSusc) {
		this.tipoSusc = tipoSusc;
	}
	public String getCodFormPago() {
		return codFormPago;
	}
	public void setCodFormPago(String codFormPago) {
		this.codFormPago = codFormPago;
	}
	public String getTipoAnul() {
		return tipoAnul;
	}
	public void setTipoAnul(String tipoAnul) {
		this.tipoAnul = tipoAnul;
	}
	public Date getFecUltfact() {
		return fecUltfact;
	}
	public void setFecUltfact(Date fecUltfact) {
		this.fecUltfact = fecUltfact;
	}
	public String getCodPlanFrac() {
		return codPlanFrac;
	}
	public void setCodPlanFrac(String codPlanFrac) {
		this.codPlanFrac = codPlanFrac;
	}
	public String getModPlanFrac() {
		return modPlanFrac;
	}
	public void setModPlanFrac(String modPlanFrac) {
		this.modPlanFrac = modPlanFrac;
	}
	public String getIndCobprov() {
		return indCobprov;
	}
	public void setIndCobprov(String indCobprov) {
		this.indCobprov = indCobprov;
	}
	public String getIndTipoPro() {
		return indTipoPro;
	}
	public void setIndTipoPro(String indTipoPro) {
		this.indTipoPro = indTipoPro;
	}
	public String getClasePol() {
		return clasePol;
	}
	public void setClasePol(String clasePol) {
		this.clasePol = clasePol;
	}
	public BigDecimal getPorcCtp() {
		if (porcCtp==null) porcCtp = new BigDecimal(0);

		return porcCtp;
	}
	public void setPorcCtp(BigDecimal porcCtp) {
		this.porcCtp = porcCtp;
	}
	public String getIndFact() {
		return indFact;
	}
	public void setIndFact(String indFact) {
		this.indFact = indFact;
	}
	public String getIndMovPolren() {
		return indMovPolren;
	}
	public void setIndMovPolren(String indMovPolren) {
		this.indMovPolren = indMovPolren;
	}
	public String getIndRespPago() {
		return indRespPago;
	}
	public void setIndRespPago(String indRespPago) {
		this.indRespPago = indRespPago;
	}
	public Date getFecIniPol() {
		return fecIniPol;
	}
	public void setFecIniPol(Date fecIniPol) {
		this.fecIniPol = fecIniPol;
	}
	public Long getIdeCot() {
		return ideCot;
	}
	public void setIdeCot(Long ideCot) {
		this.ideCot = ideCot;
	}
	public String getIndRecuprea() {
		return indRecuprea;
	}
	public void setIndRecuprea(String indRecuprea) {
		this.indRecuprea = indRecuprea;
	}
	public String getTipoCobro() {
		return tipoCobro;
	}
	public void setTipoCobro(String tipoCobro) {
		this.tipoCobro = tipoCobro;
	}
	public String getCodEstipulante() {
		return codEstipulante;
	}
	public void setCodEstipulante(String codEstipulante) {
		this.codEstipulante = codEstipulante;
	}
	public BigDecimal getPorcProlabor() {
		if (porcProlabor==null) porcProlabor = new BigDecimal(0);

		return porcProlabor;
	}
	public void setPorcProlabor(BigDecimal porcProlabor) {
		this.porcProlabor = porcProlabor;
	}
	public String getIndPagoVista() {
		return indPagoVista;
	}
	public void setIndPagoVista(String indPagoVista) {
		this.indPagoVista = indPagoVista;
	}
	public String getIndGenBol() {
		return indGenBol;
	}
	public void setIndGenBol(String indGenBol) {
		this.indGenBol = indGenBol;
	}
	public String getIndDeviof() {
		return indDeviof;
	}
	public void setIndDeviof(String indDeviof) {
		this.indDeviof = indDeviof;
	}
	public String getTipoCob() {
		return tipoCob;
	}
	public void setTipoCob(String tipoCob) {
		this.tipoCob = tipoCob;
	}
	public String getCodCia() {
		return codCia;
	}
	public void setCodCia(String codCia) {
		this.codCia = codCia;
	}
	public String getCodRamo() {
		return codRamo;
	}
	public void setCodRamo(String codRamo) {
		this.codRamo = codRamo;
	}
	public String getCodEntfinancap() {
		return codEntfinancap;
	}
	public void setCodEntfinancap(String codEntfinancap) {
		this.codEntfinancap = codEntfinancap;
	}
	public String getIndCobrLiqImp() {
		return indCobrLiqImp;
	}
	public void setIndCobrLiqImp(String indCobrLiqImp) {
		this.indCobrLiqImp = indCobrLiqImp;
	}
	public Long getIdePolRen() {
		return idePolRen;
	}
	public void setIdePolRen(Long idePolRen) {
		this.idePolRen = idePolRen;
	}
	public String getIndCobrJud() {
		return indCobrJud;
	}
	public void setIndCobrJud(String indCobrJud) {
		this.indCobrJud = indCobrJud;
	}
	public String getIndBloqFatur() {
		return indBloqFatur;
	}
	public void setIndBloqFatur(String indBloqFatur) {
		this.indBloqFatur = indBloqFatur;
	}
	public String getDevDoc() {
		return devDoc;
	}
	public void setDevDoc(String devDoc) {
		this.devDoc = devDoc;
	}
	public String getCodMonCorrecSin() {
		return codMonCorrecSin;
	}
	public void setCodMonCorrecSin(String codMonCorrecSin) {
		this.codMonCorrecSin = codMonCorrecSin;
	}
	public Date getFecIncPol() {
		return fecIncPol;
	}
	public void setFecIncPol(Date fecIncPol) {
		this.fecIncPol = fecIncPol;
	}
	public Long getIdeProp() {
		return ideProp;
	}
	public void setIdeProp(Long ideProp) {
		this.ideProp = ideProp;
	}
	public String getDestDoc() {
		return destDoc;
	}
	public void setDestDoc(String destDoc) {
		this.destDoc = destDoc;
	}
	public BigDecimal getPorcCom() {
		if (porcCom==null) porcCom = new BigDecimal(0);

		return porcCom;
	}
	public void setPorcCom(BigDecimal porcCom) {
		this.porcCom = porcCom;
	}
	public Long getDiferAgenc() {
		return diferAgenc;
	}
	public void setDiferAgenc(Long diferAgenc) {
		this.diferAgenc = diferAgenc;
	}
	public Long getIdeFactvg() {
		return ideFactvg;
	}
	public void setIdeFactvg(Long ideFactvg) {
		this.ideFactvg = ideFactvg;
	}
	public String getIndEspecial() {
		return indEspecial;
	}
	public void setIndEspecial(String indEspecial) {
		this.indEspecial = indEspecial;
	}
	public String getIndPgtoCarne() {
		return indPgtoCarne;
	}
	public void setIndPgtoCarne(String indPgtoCarne) {
		this.indPgtoCarne = indPgtoCarne;
	}
	public String getIndHonda() {
		return indHonda;
	}
	public void setIndHonda(String indHonda) {
		this.indHonda = indHonda;
	}
	public BigDecimal getPorcAgen() {
		if (porcAgen==null) porcAgen = new BigDecimal(0);

		return porcAgen;
	}
	public void setPorcAgen(BigDecimal porcAgen) {
		this.porcAgen = porcAgen;
	}
	public String getCodCiaOrig() {
		return codCiaOrig;
	}
	public void setCodCiaOrig(String codCiaOrig) {
		this.codCiaOrig = codCiaOrig;
	}
	public String getIdCrtGerencial() {
		return idCrtGerencial;
	}
	public void setIdCrtGerencial(String idCrtGerencial) {
		this.idCrtGerencial = idCrtGerencial;
	}
	public String getIdMicroSeguro() {
		return idMicroSeguro;
	}
	public void setIdMicroSeguro(String idMicroSeguro) {
		this.idMicroSeguro = idMicroSeguro;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idePol == null) ? 0 : idePol.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Poliza other = (Poliza) obj;
		if (idePol == null) {
			if (other.idePol != null)
				return false;
		} else if (!idePol.equals(other.idePol))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Poliza [idePol=" + idePol + ", codPol=" + codPol + ", numPol="
				+ numPol + ", cliente=" + cliente + ", tipoCotPol="
				+ tipoCotPol + ", fecOper=" + fecOper + ", observa=" + observa
				+ ", numRen=" + numRen + ", indNumPol=" + indNumPol
				+ ", codProd=" + ", stsPol=" + stsPol + ", fecRen="
				+ fecRen + ", fecIniVig=" + fecIniVig + ", fecFinVig="
				+ fecFinVig + ", tipoVig=" + tipoVig + ", tipoPdCion="
				+ tipoPdCion + ", tipoFact=" + tipoFact + ", indCoa=" + indCoa
				+ ", codFormfCion=" + codFormfCion + ", codOfiEmi=" + codOfiEmi
				+ ", codOfiSusc=" + codOfiSusc + ", codMoneda=" + codMoneda
				+ ", indMultiInter=" + indMultiInter + ", indPolAdhesion="
				+ indPolAdhesion + ", indRenAuto=" + indRenAuto + ", fecAnul="
				+ fecAnul + ", codMotvAnul=" + codMotvAnul + ", textMotvAnul="
				+ textMotvAnul + ", tipoSusc=" + tipoSusc + ", codFormPago="
				+ codFormPago + ", tipoAnul=" + tipoAnul + ", fecUltfact="
				+ fecUltfact + ", codPlanFrac=" + codPlanFrac
				+ ", modPlanFrac=" + modPlanFrac + ", indCobprov=" + indCobprov
				+ ", indTipoPro=" + indTipoPro + ", clasePol=" + clasePol
				+ ", porcCtp=" + porcCtp + ", indFact=" + indFact
				+ ", indMovPolren=" + indMovPolren + ", indRespPago="
				+ indRespPago + ", fecIniPol=" + fecIniPol + ", ideCot="
				+ ideCot + ", indRecuprea=" + indRecuprea + ", tipoCobro="
				+ tipoCobro + ", codEstipulante=" + codEstipulante
				+ ", porcProlabor=" + porcProlabor + ", indPagoVista="
				+ indPagoVista + ", indGenBol=" + indGenBol + ", indDeviof="
				+ indDeviof + ", tipoCob=" + tipoCob + ", codCia=" + codCia
				+ ", codRamo=" + codRamo + ", codEntfinancap=" + codEntfinancap
				+ ", indCobrLiqImp=" + indCobrLiqImp + ", idePolRen="
				+ idePolRen + ", indCobrJud=" + indCobrJud + ", indBloqFatur="
				+ indBloqFatur + ", devDoc=" + devDoc + ", codMonCorrecSin="
				+ codMonCorrecSin + ", fecIncPol=" + fecIncPol + ", ideProp="
				+ ideProp + ", destDoc=" + destDoc + ", porcCom=" + porcCom
				+ ", diferAgenc=" + diferAgenc + ", ideFactvg=" + ideFactvg
				+ ", indEspecial=" + indEspecial + ", indPgtoCarne="
				+ indPgtoCarne + ", indHonda=" + indHonda + ", porcAgen="
				+ porcAgen + ", codCiaOrig=" + codCiaOrig + ", idCrtGerencial="
				+ idCrtGerencial + ", idMicroSeguro=" + idMicroSeguro + "]";
	}




}