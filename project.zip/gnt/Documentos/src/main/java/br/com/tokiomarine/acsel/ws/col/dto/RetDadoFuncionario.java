
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retDadoFuncionario complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retDadoFuncionario">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="centroCusto" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="codigoLocal" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="descricaoLocal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mensagemErro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="validado" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retDadoFuncionario", propOrder = {
    "centroCusto",
    "codigoLocal",
    "descricaoLocal",
    "mensagemErro",
    "validado"
})
public class RetDadoFuncionario {

    protected Integer centroCusto;
    protected Integer codigoLocal;
    protected String descricaoLocal;
    protected String mensagemErro;
    protected String validado;

    /**
     * Obt�m o valor da propriedade centroCusto.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getCentroCusto() {
        return centroCusto;
    }

    /**
     * Define o valor da propriedade centroCusto.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setCentroCusto(Integer value) {
        this.centroCusto = value;
    }

    /**
     * Obt�m o valor da propriedade codigoLocal.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getCodigoLocal() {
        return codigoLocal;
    }

    /**
     * Define o valor da propriedade codigoLocal.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setCodigoLocal(Integer value) {
        this.codigoLocal = value;
    }

    /**
     * Obt�m o valor da propriedade descricaoLocal.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDescricaoLocal() {
        return descricaoLocal;
    }

    /**
     * Define o valor da propriedade descricaoLocal.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDescricaoLocal(String value) {
        this.descricaoLocal = value;
    }

    /**
     * Obt�m o valor da propriedade mensagemErro.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMensagemErro() {
        return mensagemErro;
    }

    /**
     * Define o valor da propriedade mensagemErro.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMensagemErro(String value) {
        this.mensagemErro = value;
    }

    /**
     * Obt�m o valor da propriedade validado.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getValidado() {
        return validado;
    }

    /**
     * Define o valor da propriedade validado.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setValidado(String value) {
        this.validado = value;
    }

}
