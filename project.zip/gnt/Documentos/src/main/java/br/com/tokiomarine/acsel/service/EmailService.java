package br.com.tokiomarine.acsel.service;

import br.com.tokiomarine.acsel.domain.acx.CadServicos;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.infra.componente.email.dto.Anexo;

public interface EmailService {
	
	public void enviaEmail(CadServicos servico, String emailHTML, Anexo anexo, String destinatario) throws ServiceException;

}
