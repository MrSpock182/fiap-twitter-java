package br.com.tokiomarine.acsel.dto;

import java.util.List;

public class ConsultaDocumentosDTO {
	
	private Integer cdRamoProdutoTmsr;
	private Integer cdApoliceTmsr;
	private Integer cdEndossoTmsr;
	private Integer cdDocumento;
	private List<DocumentoDocstoreDTO> documentos;
	private Integer codigoRetorno;
	private String mensagemRetorno;
	
	public Integer getCdRamoProdutoTmsr() {
		return cdRamoProdutoTmsr;
	}
	public void setCdRamoProdutoTmsr(Integer cdRamoProdutoTmsr) {
		this.cdRamoProdutoTmsr = cdRamoProdutoTmsr;
	}
	public Integer getCdApoliceTmsr() {
		return cdApoliceTmsr;
	}
	public void setCdApoliceTmsr(Integer cdApoliceTmsr) {
		this.cdApoliceTmsr = cdApoliceTmsr;
	}
	public Integer getCdEndossoTmsr() {
		return cdEndossoTmsr;
	}
	public void setCdEndossoTmsr(Integer cdEndossoTmsr) {
		this.cdEndossoTmsr = cdEndossoTmsr;
	}
	public Integer getCdDocumento() {
		return cdDocumento;
	}
	public void setCdDocumento(Integer cdDocumento) {
		this.cdDocumento = cdDocumento;
	}
	public List<DocumentoDocstoreDTO> getDocumentos() {
		return documentos;
	}
	public void setDocumentos(List<DocumentoDocstoreDTO> documentos) {
		this.documentos = documentos;
	}
	public Integer getCodigoRetorno() {
		return codigoRetorno;
	}
	public void setCodigoRetorno(Integer codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}
	public String getMensagemRetorno() {
		return mensagemRetorno;
	}
	public void setMensagemRetorno(String mensagemRetorno) {
		this.mensagemRetorno = mensagemRetorno;
	}
	
	
}
