package br.com.tokiomarine.acsel.dao;

import java.sql.Connection;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.internal.SessionImpl;

public class BaseAcxDAO {

	@PersistenceContext(unitName="entityManagerACX")
	private EntityManager entityManager;
	
	public Session getSession(){
		return entityManager.unwrap(Session.class);
	}
	
	public Connection getConnection() {
		return ((SessionImpl) entityManager.getDelegate()).connection();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void persist(Object entity){
		entityManager.persist(entity);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Object merge(Object entity){
		return entityManager.merge(entity);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void remove(Object entity){
		entityManager.remove(entity);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public <T> T findById(Class<T> cl, Object id){
		return entityManager.find(cl, id);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void flush(){
		entityManager.flush();
	}
}
