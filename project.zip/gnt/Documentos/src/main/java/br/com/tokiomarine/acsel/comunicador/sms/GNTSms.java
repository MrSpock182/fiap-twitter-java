package br.com.tokiomarine.acsel.comunicador.sms;

import java.util.HashMap;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jboss.resteasy.client.ClientRequest;
import org.jboss.resteasy.client.ClientResponse;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataOutput;

import com.fasterxml.jackson.core.JsonProcessingException;

import br.com.tokiomarine.acsel.comunicador.ComunicadorEnvioTemplate;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoDestinatario;
import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.repository.ParametrosRepository;
import br.com.tokiomarine.acsel.util.StringUtil;

@Stateless(name = "GNTSms")
@Local(value = GNTSms.class)
@Named("gntSms")
public final class GNTSms extends ComunicadorEnvioTemplate {

	private static Logger logger = LogManager.getLogger(GNTSms.class);

	@Inject
	ParametrosRepository parametrosDao;

	@Override
	protected void enviarMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException {
		try {

			Map<String, String> mensagens = agendamentoEnvio.getAgendamento().getMensagens();
			String url = parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "URL_SMS_ENVIO");
			String chave = parametrosDao.obtemVlrParametro("PUSH_NOTIFICATION", "SMS_API_KEY");

			for (AgendamentoDestinatario cel : agendamentoEnvio.getAgendamento().getDestinatariosValidos()) {

				ClientRequest request = new ClientRequest(url);

				MultipartFormDataOutput formParameters = new MultipartFormDataOutput();

				formParameters.addFormData("apikey", chave, MediaType.TEXT_PLAIN_TYPE);
				formParameters.addFormData("ntc", "55" + cel.getDestinatario(), MediaType.TEXT_PLAIN_TYPE);
				formParameters.addFormData("mensagem", mensagens.get("mensagem"), MediaType.TEXT_PLAIN_TYPE);
				formParameters.addFormData("id",
						"SQ_AGENDAMENTO=" + agendamentoEnvio.getAgendamento().getSeqAgendamento().toString(),
						MediaType.TEXT_PLAIN_TYPE);
				// formParameters.addFormData("idsistema", "ID_SISTEMA=" +
				// agendamentoEnvio.getAgendamento().getModelo().getNomeSistemaOrigem(),
				// MediaType.TEXT_PLAIN_TYPE);
				request.body(MediaType.MULTIPART_FORM_DATA_TYPE, formParameters);

				ClientResponse<String> response = request.post(String.class);

				if (response.getResponseStatus().equals(Status.OK)) {
					agendamentoEnvio.setCodRetornoEnvio(response.getEntity());
				} else {
					logger.error("Erro ao acessar serviço de envio de SMS: " + response.getEntity());
					throw new ServiceException(
							"Erro ao acessar serviço de envio de SMS: " + response.getResponseStatus());
				}
			}

		} catch (Exception e) {
			logger.error("Erro ao enviar SMS", e);
			throw new ServiceException("Erro ao enviar SMS");
		}
	}

	@Override
	protected String geraMensagem(AgendamentoEnvio agendamentoEnvio) throws ServiceException {

		String mesangem = "";

		AgendamentoComunicacao agend = agendamentoEnvio.getAgendamento();
		ModeloComunicacao modelo = agend.getModelo();

		Map<String, String> parametros = new HashMap<String, String>();
		for (ParametroModelo param : modelo.getParametros()) {
			parametros.put(param.getParametro().getNomeParametro(),
					agend.getValorParametro(param.getParametro().getNomeParametro()));
		}

		Map<String, String> params = new HashMap<String, String>();
		for (TextoModeloComunicacao texto : modelo.getTextos()) {
			if (texto.getTextoComunicacao().getTipoTexto().equals("P")) {
				params.put("chamada", formataTexto(parametros, texto.getTexto()));
			} else {
				params.put("mensagem", formataTexto(parametros, texto.getTexto()));
			}
		}

		try {
			// agendamentoEnvio.getAgendamento().setMensagemEnviada(StringUtil.serialize(parametros));
			mesangem = StringUtil.serialize(params);
		} catch (JsonProcessingException e) {
			logger.error("Erro ao formatar mensagem", e);
			throw new ServiceException("Erro ao formatar mensagem");
		}
		return mesangem;
	}

	public void verificarMensagem(AgendamentoComunicacao agendamento) throws ServiceException {
		String mesangem = "";

		ModeloComunicacao modelo = agendamento.getModelo();

		Map<String, String> parametros = new HashMap<String, String>();
		for (ParametroModelo param : modelo.getParametros()) {
			parametros.put(param.getParametro().getNomeParametro(),
					agendamento.getValorParametro(param.getParametro().getNomeParametro()));
		}

		Map<String, String> params = new HashMap<String, String>();
		for (TextoModeloComunicacao texto : modelo.getTextos()) {
			if (texto.getTextoComunicacao().getTipoTexto().equals("P")) {
				params.put("chamada", formataTexto(parametros, texto.getTexto()));
			} else {
				params.put("mensagem", formataTexto(parametros, texto.getTexto()));
			}
		}

		try {
			mesangem = StringUtil.serialize(params);
		} catch (JsonProcessingException e) {
			throw new ServiceException("Erro ao formatar mensagem");
		}

		if(params.get("mensagem").length() > 150) {
			throw new ServiceException("Sua mensagem possui valor maior que 150 caracteres: " + params.get("mensagem").toString());
		}
	}

	private String formataTexto(Map<String, String> parametros, String texto) throws ServiceException {

		String txtRetorno = texto;

		String[] vars = StringUtils.substringsBetween(texto, "[", "]");

		if (vars != null) {
			for (String var : vars) {
				if (parametros.containsKey(var)) {
					String valor = parametros.get(var);
					if (valor == null) {
						throw new ServiceException("Parâmetro " + var + " não informado");
					}
					txtRetorno = txtRetorno.replace("[" + var + "]", valor);
				}
			}
		}
		return txtRetorno;
	}

}
