package br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist;

public interface BlackWhiteListRestServiceClient {

	BlackListResource getBlackList(String destino);

}
