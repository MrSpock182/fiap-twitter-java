package br.com.tokiomarine.acsel.repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;

import br.com.tokiomarine.acsel.dao.BaseAcxDAO;
import br.com.tokiomarine.acsel.domain.acx.DocumentoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ImagemComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.PadraoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.PerfilModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.TextoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.exception.ServiceException;

public class ModeloComunicacaoRepository{
	
	public final String PERFIL_APROVAR = "aprovar";
	public final String PERFIL_ADMIN   = "admin";
	
	public final String STATUS_APROVAR   = "A APROVAR";	
	public final String STATUS_APROVADO  = "APROVADO";	
	public final String STATUS_RECUSADO  = "RECUSADO";	
	public final String STATUS_ATIVADO   = "ATIVADO";

	@Inject
	BaseAcxDAO base;

	@SuppressWarnings("unchecked")
	public List<ModeloComunicacao> obtemModelos(){
		return base.getSession().createCriteria(ModeloComunicacao.class).addOrder(Order.asc("codigo")).list();
	}
	
	@SuppressWarnings("unchecked")
	public List<ModeloComunicacao> obtemModelosWithSituacaoModeloEqS(){
		Criteria criteria = base.getSession().createCriteria(ModeloComunicacao.class);
		criteria.add(Restrictions.eq("situacaoModelo", "S"));
		return criteria.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<ModeloComunicacao> obtemModelosInativos(String perfil){
		Criteria criteria = base.getSession().createCriteria(ModeloComunicacao.class);
		criteria.add(Restrictions.eq("situacaoModelo", "N"));
		if (perfil != null && !perfil.equals("")) {
			if (perfil.equals(PERFIL_APROVAR)) {
				criteria.add(Restrictions.eq("status", STATUS_APROVAR));	
			} else {
				criteria.add(Restrictions.ne("status", STATUS_APROVAR));				
			}
		}
		criteria.addOrder(Order.asc("codigo") );
		return criteria.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<DocumentoComunicacao> obtemDocumentos(){
		return base.getSession().createCriteria(DocumentoComunicacao.class).list();
	}

	@SuppressWarnings("unchecked")
	public List<PadraoComunicacao> obtemPadroes(){
		return base.getSession().createCriteria(PadraoComunicacao.class).list();
	}

	@SuppressWarnings("unchecked")
	public List<TextoComunicacao> obtemTextos(String tipoModelo){
		return base.getSession().createCriteria(TextoComunicacao.class)
				.add(Restrictions.eq("tipoModelo", tipoModelo))
				.addOrder(Order.asc("codTexto"))
				.list();
	}

	public ParametroComunicacao obtemParametroComunicacao(Long id){
		return base.findById(ParametroComunicacao.class, id);
	}
	
	public ParametroComunicacao obtemParametroNome(String nome){
		return (ParametroComunicacao) base.getSession().createCriteria(ParametroComunicacao.class)
				.add(Restrictions.eq("nomeParametro", nome))
				.uniqueResult();
	}
	
	public ParametroComunicacao atualizaParametroComunicacao(ParametroComunicacao param){
		return (ParametroComunicacao) base.merge(param);
	}
	
	public PadraoComunicacao obtemPadrao(Long id){
		return base.findById(PadraoComunicacao.class, id);
	}

	public ImagemComunicacao obtemImagem(Long id){
		return base.findById(ImagemComunicacao.class, id);
	}

	public DocumentoComunicacao obtemDocumento(Long id){
		return base.findById(DocumentoComunicacao.class, id);
	}

	public ModeloComunicacao obtemModelo(Long id){

		ModeloComunicacao mod = base.findById(ModeloComunicacao.class, id);

		if (mod != null){
			Hibernate.initialize(mod.getParametros());
			Hibernate.initialize(mod.getTextos());
		}

		return mod;
	}
	
	public ModeloComunicacao obtemModelo(String codigo){
		Criteria criteria = base.getSession().createCriteria(ModeloComunicacao.class);
		criteria.add(Restrictions.eq("codigo", codigo));
		ModeloComunicacao mod = (ModeloComunicacao) criteria.uniqueResult();
		if (mod != null){
			Hibernate.initialize(mod.getParametros());
			Hibernate.initialize(mod.getTextos());
		}		
		return mod;
	}		

	public TextoComunicacao obtemTextoComunicacao(Long id){

		return (TextoComunicacao) base.getSession().createCriteria(TextoComunicacao.class)
				.add(Restrictions.eq("codTexto", id))
				.uniqueResult();
	}

	public TextoModeloComunicacao obtemTexto(Long id){

		return (TextoModeloComunicacao) base.getSession().createCriteria(TextoModeloComunicacao.class)
				.add(Restrictions.eq("idTexto", id))
				.uniqueResult();
	}

	public ParametroModelo obtemParametro(Long id){

		return (ParametroModelo) base.getSession().createCriteria(ParametroModelo.class)
				.add(Restrictions.eq("idModeloParam", id))
				.uniqueResult();
	}
	
	public ParametroModelo obtemParametro(Long idModelo, Long codParametro){
		return (ParametroModelo) base.getSession().createCriteria(ParametroModelo.class)
				.createAlias("modelo", "m")
				.createAlias("parametro", "p")
				.add(Restrictions.eq("m.codModelo", idModelo))				
				.add(Restrictions.eq("p.codParametro", codParametro))
				.uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	public List<ImagemComunicacao> obtemImagens(){
		return base.getSession().createCriteria(ImagemComunicacao.class).list();
	}

	@SuppressWarnings("unchecked")
	public List<ParametroComunicacao> obtemParametrosDisponiveis(Long idModelo){
		DetachedCriteria dt = DetachedCriteria.forClass(ParametroModelo.class)
				.createAlias("modelo", "m")
				.createAlias("parametro", "p")
			    .add(Restrictions.eq("m.codModelo", idModelo))
			    .setProjection(Projections.property("p.codParametro"));

		return base.getSession().createCriteria(ParametroComunicacao.class)
				.add(Subqueries.propertyNotIn("codParametro", dt))
				.list();
	}

	@SuppressWarnings("unchecked")
	public List<ParametroModelo> obtemParametrosConsulta(Long idModelo){
		return base.getSession().createCriteria(ParametroModelo.class)
				.createAlias("modelo", "m")
				.createAlias("parametro", "p")
				.add(Restrictions.eq("m.codModelo", idModelo))
				.add(Restrictions.eq("p.indConsulta", "S"))
				.list();
	}

	@SuppressWarnings("unchecked")
	public List<ParametroComunicacao> obtemParametrosConsulta(){
		return base.getSession().createCriteria(ParametroComunicacao.class)
				.add(Restrictions.eq("indConsulta", "S"))
				.list();
	}

	public ModeloComunicacao atualizaModelo(ModeloComunicacao mod){
		return (ModeloComunicacao) base.merge(mod);
	}

	public TextoModeloComunicacao atualizaTexto(TextoModeloComunicacao texto){
		return (TextoModeloComunicacao) base.merge(texto);
	}

	public ParametroModelo atualizaParametro(ParametroModelo param){
		return (ParametroModelo) base.merge(param);
	}

	public void removeTexto(Long id){
		TextoModeloComunicacao texto = obtemTexto(id);
		base.remove(texto);
	}

	public void removeParametro(Long id){
		ParametroModelo param = obtemParametro(id);
		base.remove(param);
	}
	
	public void removeModelo (ModeloComunicacao modelo) {
		base.remove(modelo);
	}
	
	public String proximoCodigo(String prefixo) {
		return (String) base.getSession().createCriteria(ModeloComunicacao.class)
				.add(Restrictions.like("codigo", prefixo, MatchMode.START))
				.setProjection(Projections.max("codigo"))
				.uniqueResult();
	}
	
	public PerfilModeloComunicacao obtemPerfil(String codUsuario, String codPerfil) {
		return (PerfilModeloComunicacao) base.getSession().createCriteria(PerfilModeloComunicacao.class)
											 .add(Restrictions.eq("codLogin", codUsuario))
											 .add(Restrictions.eq("codPerfil", codPerfil))
											 .uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	public List<TextoModeloComunicacao> dataHistorico(Long idModelo) throws ServiceException {
		String hql = "SELECT F2.CD_MODELO_COM_TEXTO, F2.CD_MODELO_COMUNICACAO, F2.CD_TEXTO, F2.DS_TEXTO, F2.CD_SEQUENCIA, F2.CD_IMAGEM, TO_CHAR(F2.DT_ATUALIZACAO, 'DD/MM/YYYY HH24:MI:SS') DT_INCLUSAO, " +
					 "F2.NM_USUARIO_ATUALIZACAO NM_USUARIO_INCLUSAO, TO_CHAR(F2.DT_ATUALIZACAO, 'DD/MM/YYYY HH24:MI:SS') DT_ATUALIZACAO, F2.NM_USUARIO_ATUALIZACAO, " +
					 "CASE WHEN F2.FINAL_VIGENCIA IS NULL THEN 'I' ELSE F2.TP_MOVIM END TP_MOVIM, " +
				     "TO_CHAR(F2.INICIO_VIGENCIA, 'DD/MM/YYYY HH24:MI:SS') INICIO_VIGENCIA, TO_CHAR(F2.FINAL_VIGENCIA, 'DD/MM/YYYY HH24:MI:SS') FINAL_VIGENCIA FROM (" +
					 "SELECT MAX(FINAL_VIGENCIA) OVER (PARTITION BY F1.CD_MODELO_COMUNICACAO) AS MAXIMO, F1.* FROM (" +
					 "SELECT 'O' TIPO_REGISTRO, MOD.CD_MODELO_COMUNICACAO, MOD.CD_TEXTO, MOD.DS_TEXTO, MOD.CD_SEQUENCIA, MOD.CD_IMAGEM, " +
					 "TO_DATE(TO_CHAR(SYSDATE, 'DD/MM/YYYY') || '23:59:59', 'DD/MM/YYYY HH24:MI:SS') DT_ATUALIZACAO, " +
			         "CASE WHEN MOD.FINAL_VIGENCIA IS NOT NULL THEN MOD.FINAL_VIGENCIA ELSE SYSDATE END DATA_MOVIM, " +
					 "MOD.INICIO_VIGENCIA, MOD.FINAL_VIGENCIA, CASE WHEN MOD.NM_USUARIO_ATUALIZACAO IS NULL THEN MOD.NM_USUARIO_INCLUSAO ELSE MOD.NM_USUARIO_ATUALIZACAO END NM_USUARIO_ATUALIZACAO, " +
					 "MOD.TP_MOVIM, MOD.CD_MODELO_COM_TEXTO FROM MODELO_COMUNICACAO_TEXTO MOD " +
				     "JOIN TEXTO_COMUNICACAO TXT ON (TXT.CD_TEXTO = MOD.CD_TEXTO) " +
					 "WHERE MOD.CD_MODELO_COMUNICACAO = :idModelO" +
				     " AND (TXT.TIP_TEXTO IN ('V', 'D') OR MOD.CD_IMAGEM IS NOT NULL OR (MOD.DS_TEXTO IS NOT NULL AND MOD.NM_USUARIO_ATUALIZACAO IS NOT NULL)) " +				     
					 "UNION ALL " +
					 "SELECT 'H' TIPO_REGISTRO, HIST.CD_MODELO_COMUNICACAO, HIST.CD_TEXTO, HIST.DS_TEXTO, HIST.CD_SEQUENCIA, HIST.CD_IMAGEM, HIST.FINAL_VIGENCIA, " +
					 "CASE WHEN HIST.FINAL_VIGENCIA IS NOT NULL THEN HIST.FINAL_VIGENCIA ELSE SYSDATE END DATA_MOVIM, " +
					 "HIST.INICIO_VIGENCIA, HIST.FINAL_VIGENCIA, HIST.NM_USUARIO_INCLUSAO, " +
					 "HIST.TP_MOVIM, HIST.CD_MODELO_COM_TEXTO_HIST FROM MODELO_COMUNICACAO_TEXTO_HIST HIST " +
				     "JOIN TEXTO_COMUNICACAO TXT ON (TXT.CD_TEXTO = HIST.CD_TEXTO) " +       
					 "WHERE HIST.CD_MODELO_COMUNICACAO = :idModelH" +
				     " AND (TXT.TIP_TEXTO IN ('V', 'D') OR HIST.CD_IMAGEM IS NOT NULL OR (HIST.DS_TEXTO IS NOT NULL AND HIST.NM_USUARIO_INCLUSAO IS NOT NULL)) " +	
		             "AND (HIST.TP_MOVIM <> 'E' OR HIST.NM_USUARIO_INCLUSAO IS NOT NULL) " +
					 ") F1) F2 WHERE F2.FINAL_VIGENCIA IS NOT NULL OR F2.INICIO_VIGENCIA > F2.MAXIMO ORDER BY F2.DATA_MOVIM DESC";
		Query query = base.getSession().createSQLQuery(hql)
				.setParameter("idModelO", idModelo)
				.setParameter("idModelH", idModelo);
		List<Object[]> result = query.list();
		
		if (result == null || result.size() == 0) {
			return null;
		}
		
		return montarListaHistorico(result);
	}

	@SuppressWarnings("unchecked")
	public List<TextoModeloComunicacao> obtemHistorico(Long idModelo, String dataHist) throws ServiceException {	
		String hql = "SELECT F2.CD_MODELO_COM_TEXTO, F2.CD_MODELO_COMUNICACAO, F2.CD_TEXTO, F2.DS_TEXTO, F2.CD_SEQUENCIA, F2.CD_IMAGEM, TO_CHAR(F2.DT_ATUALIZACAO, 'DD/MM/YYYY HH24:MI:SS') DT_INCLUSAO, " +
		             "F2.NM_USUARIO_ATUALIZACAO NM_USUARIO_INCLUSAO, TO_CHAR(F2.DT_ATUALIZACAO, 'DD/MM/YYYY HH24:MI:SS') DT_ATUALIZACAO, F2.NM_USUARIO_ATUALIZACAO, F2.TP_MOVIM, " + 
			         "TO_CHAR(F2.INICIO_VIGENCIA, 'DD/MM/YYYY HH24:MI:SS') INICIO_VIGENCIA, TO_CHAR(F2.FINAL_VIGENCIA, 'DD/MM/YYYY HH24:MI:SS') FINAL_VIGENCIA FROM (" +
			         "SELECT ROW_NUMBER() OVER (PARTITION BY F1.CD_TEXTO, CD_SEQUENCIA ORDER BY F1.CD_TEXTO, F1.CD_SEQUENCIA, F1.TIPO_REGISTRO, F1.DT_ATUALIZACAO) AS LINHA, " +
			         "COUNT(*) OVER (PARTITION BY F1.CD_TEXTO, CD_SEQUENCIA ) AS QTD_LINHA, F1.* FROM (" +
			         "SELECT 'O' TIPO_REGISTRO, MOD.CD_MODELO_COMUNICACAO, MOD.CD_TEXTO, MOD.DS_TEXTO, MOD.CD_SEQUENCIA, MOD.CD_IMAGEM, MOD.DT_ATUALIZACAO, " +
			         "TO_DATE(TO_CHAR(MOD.DT_ATUALIZACAO, 'DD/MM/YYYY'), 'DD/MM/YYYY') DATA_MOVIM, MOD.INICIO_VIGENCIA, MOD.FINAL_VIGENCIA, " +
			         "CASE WHEN MOD.NM_USUARIO_ATUALIZACAO IS NULL THEN MOD.NM_USUARIO_INCLUSAO ELSE MOD.NM_USUARIO_ATUALIZACAO END NM_USUARIO_ATUALIZACAO, " +
			         "MOD.TP_MOVIM, MOD.CD_MODELO_COM_TEXTO FROM MODELO_COMUNICACAO_TEXTO MOD " +
			         "JOIN TEXTO_COMUNICACAO TXT ON (TXT.CD_TEXTO = MOD.CD_TEXTO) " +
			         "WHERE MOD.CD_MODELO_COMUNICACAO = :idModelO" +
				     " AND (TXT.TIP_TEXTO IN ('V', 'D') OR MOD.CD_IMAGEM IS NOT NULL OR (MOD.DS_TEXTO IS NOT NULL AND MOD.NM_USUARIO_ATUALIZACAO IS NOT NULL)) " +	
		             "AND TO_DATE(TO_CHAR(MOD.INICIO_VIGENCIA, 'YYYYMMDDHH24MISS'), 'YYYYMMDDHH24MISS') < TO_DATE(:dataHist1, 'YYYYMMDDHH24MISS')" +			         
			         "UNION ALL " +
			         "SELECT 'H' TIPO_REGISTRO, HIST.CD_MODELO_COMUNICACAO, HIST.CD_TEXTO, HIST.DS_TEXTO, HIST.CD_SEQUENCIA, HIST.CD_IMAGEM, HIST.DT_INCLUSAO, " +
			         "TO_DATE (TO_CHAR(HIST.DT_INCLUSAO, 'DD/MM/YYYY'), 'DD/MM/YYYY') DATA_MOVIM, HIST.INICIO_VIGENCIA, HIST.FINAL_VIGENCIA, HIST.NM_USUARIO_INCLUSAO, " +
			         "HIST.TP_MOVIM, HIST.CD_MODELO_COM_TEXTO_HIST FROM MODELO_COMUNICACAO_TEXTO_HIST HIST " +
			         "JOIN TEXTO_COMUNICACAO TXT ON (TXT.CD_TEXTO = HIST.CD_TEXTO) " +			         
			         "WHERE HIST.CD_MODELO_COMUNICACAO = :idModelH" +
				     " AND (TXT.TIP_TEXTO IN ('V', 'D') OR HIST.CD_IMAGEM IS NOT NULL OR (HIST.DS_TEXTO IS NOT NULL AND HIST.NM_USUARIO_INCLUSAO IS NOT NULL)) " +
				     "AND (HIST.TP_MOVIM <> 'E' OR HIST.NM_USUARIO_INCLUSAO IS NOT NULL) " +
		             "AND TO_DATE(TO_CHAR(HIST.INICIO_VIGENCIA, 'YYYYMMDDHH24MISS'), 'YYYYMMDDHH24MISS') <= TO_DATE(:dataHist2, 'YYYYMMDDHH24MISS') " +
		             "AND TO_DATE(TO_CHAR(HIST.FINAL_VIGENCIA, 'YYYYMMDDHH24MISS'), 'YYYYMMDDHH24MISS') >= TO_DATE(:dataHist2, 'YYYYMMDDHH24MISS') ) F1 " +
			         "ORDER BY F1.CD_TEXTO, F1.TIPO_REGISTRO, F1.DT_ATUALIZACAO) F2 " +
			         "WHERE F2.LINHA = F2.QTD_LINHA ORDER BY F2.CD_SEQUENCIA";
		Query query = base.getSession().createSQLQuery(hql)
				.setParameter("idModelO", idModelo)
				.setParameter("dataHist1", dataHist)
				.setParameter("idModelH", idModelo)
				.setParameter("dataHist2", dataHist);
		List<Object[]> result = query.list();
		
		if (result == null || result.size() == 0) {
			return null;
		}
		
		return montarListaHistorico(result);
	}
	
	private List<TextoModeloComunicacao> montarListaHistorico(List<Object[]> result) throws ServiceException {
		List<TextoModeloComunicacao> lista = new ArrayList<TextoModeloComunicacao>();
		SimpleDateFormat sdf =  new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		for (Object[] fieldTexto : result) {
			ModeloComunicacao mod = base.findById(ModeloComunicacao.class, Long.parseLong(fieldTexto[1].toString()));
			TextoComunicacao  txt = base.findById(TextoComunicacao.class,  Long.parseLong(fieldTexto[2].toString()));
			TextoModeloComunicacao texto = new TextoModeloComunicacao();
			texto.setIdTexto(Long.parseLong(fieldTexto[0].toString()) );
			texto.setModelo(mod);
			texto.setTextoComunicacao(txt);
			if (fieldTexto[3] != null) {
				texto.setTexto(fieldTexto[3].toString());				
			}

			if (fieldTexto[4] != null) {
				texto.setNumSequencia(Integer.parseInt(fieldTexto[4].toString()));				
			}
			
			if (fieldTexto[5] != null) {
				texto.setCodImagem(Long.parseLong(fieldTexto[5].toString()) );
				ImagemComunicacao imagem = base.findById(ImagemComunicacao.class, texto.getCodImagem());
				texto.setImagem(imagem);				
			}
			
			try {
				texto.setDtInclusao(sdf.parse(fieldTexto[6].toString()));
				texto.setDataAtualizacao(sdf.parse(fieldTexto[8].toString()));
				texto.setDtInicioVigencia(sdf.parse(fieldTexto[11].toString()));
				if (fieldTexto[12] != null) {
					texto.setDtFinalVigencia(sdf.parse(fieldTexto[12].toString()));				
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			texto.setNomeUsuarioInclusao(fieldTexto[7].toString());				
			texto.setNomeUsuarioAtualizacao(fieldTexto[9].toString());				
			texto.setTipoMovimento(fieldTexto[10].toString());
			lista.add(texto);
		}
		return lista;
	}
	
}
