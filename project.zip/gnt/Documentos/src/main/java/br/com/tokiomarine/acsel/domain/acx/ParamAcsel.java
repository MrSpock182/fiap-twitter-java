package br.com.tokiomarine.acsel.domain.acx;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@IdClass(ParamAcselPK.class)
@Table(name = "TAB_PARAM_ACSEL")
public class ParamAcsel {

	@Id
	@Column(name="ID_GRP_PARAMETRO")	private Integer idGrpParamAcsel;
	@Id
	@Column(name="COD_PARAMETRO")		private String codParametro;
	@Column(name="DESC_PARAMETRO")		private String descParametro;
	@Column(name="VLR_PARAMETRO")		private String vlrParametro;
	@Column(name="COD_USU_ULT_ALTER")	private String codUsuarioAlter;
	@Column(name="DT_ULTIMA_ALTER")	private Date dtUltimaAlter;

	@ManyToOne
	@JoinColumn(insertable=false, updatable=false, name = "ID_GRP_PARAMETRO", referencedColumnName = "ID_GRP_PARAMETRO")
	private GrpParamAcsel grpParametro;

	public Integer getIdGrpParamAcsel() {
		return idGrpParamAcsel;
	}
	public void setIdGrpParamAcsel(Integer idGrpParamAcsel) {
		this.idGrpParamAcsel = idGrpParamAcsel;
	}
	public String getCodParametro() {
		return codParametro;
	}
	public void setCodParametro(String codParametro) {
		this.codParametro = codParametro;
	}
	public String getDescParametro() {
		return descParametro;
	}
	public void setDescParametro(String descParametro) {
		this.descParametro = descParametro;
	}
	public String getVlrParametro() {
		return vlrParametro;
	}
	public void setVlrParametro(String vlrParametro) {
		this.vlrParametro = vlrParametro;
	}
	public GrpParamAcsel getGrpParametro() {
		return grpParametro;
	}
	public void setGrpParametro(GrpParamAcsel grpParametro) {
		this.grpParametro = grpParametro;
	}
	public String getCodUsuarioAlter() {
		return codUsuarioAlter;
	}
	public void setCodUsuarioAlter(String codUsuarioAlter) {
		this.codUsuarioAlter = codUsuarioAlter;
	}
	public Date getDtUltimaAlter() {
		return dtUltimaAlter;
	}
	public void setDtUltimaAlter(Date dtUltimaAlter) {
		this.dtUltimaAlter = dtUltimaAlter;
	}
}