
package br.com.tokiomarine.acsel.ws.col.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retGetDepartamentos complex type.
 *
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 *
 * <pre>
 * &lt;complexType name="retGetDepartamentos">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="centroDeCusto" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="diretoria" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailGestor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="matriculaGestor" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeGestor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retGetDepartamentos", propOrder = {
    "centroDeCusto",
    "diretoria",
    "emailGestor",
    "id",
    "matriculaGestor",
    "nome",
    "nomeGestor"
})
public class RetGetDepartamentos {

    protected Integer centroDeCusto;
    protected String diretoria;
    protected String emailGestor;
    protected Integer id;
    protected Integer matriculaGestor;
    protected String nome;
    protected String nomeGestor;

    /**
     * Obt�m o valor da propriedade centroDeCusto.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getCentroDeCusto() {
        return centroDeCusto;
    }

    /**
     * Define o valor da propriedade centroDeCusto.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setCentroDeCusto(Integer value) {
        this.centroDeCusto = value;
    }

    /**
     * Obt�m o valor da propriedade diretoria.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDiretoria() {
        return diretoria;
    }

    /**
     * Define o valor da propriedade diretoria.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDiretoria(String value) {
        this.diretoria = value;
    }

    /**
     * Obt�m o valor da propriedade emailGestor.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getEmailGestor() {
        return emailGestor;
    }

    /**
     * Define o valor da propriedade emailGestor.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setEmailGestor(String value) {
        this.emailGestor = value;
    }

    /**
     * Obt�m o valor da propriedade id.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getId() {
        return id;
    }

    /**
     * Define o valor da propriedade id.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Obt�m o valor da propriedade matriculaGestor.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getMatriculaGestor() {
        return matriculaGestor;
    }

    /**
     * Define o valor da propriedade matriculaGestor.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setMatriculaGestor(Integer value) {
        this.matriculaGestor = value;
    }

    /**
     * Obt�m o valor da propriedade nome.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Obt�m o valor da propriedade nomeGestor.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNomeGestor() {
        return nomeGestor;
    }

    /**
     * Define o valor da propriedade nomeGestor.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNomeGestor(String value) {
        this.nomeGestor = value;
    }

}
