package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

public class TerceroPK implements Serializable {

	private static final long serialVersionUID = 1L;

	private String tipoId;
	private Long numId;
	private String dvId;
	public String getTipoId() {
		return tipoId;
	}
	public void setTipoId(String tipoId) {
		this.tipoId = tipoId;
	}
	public Long getNumId() {
		return numId;
	}
	public void setNumId(Long numId) {
		this.numId = numId;
	}
	public String getDvId() {
		return dvId;
	}
	public void setDvId(String dvId) {
		this.dvId = dvId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dvId == null) ? 0 : dvId.hashCode());
		result = prime * result + ((numId == null) ? 0 : numId.hashCode());
		result = prime * result + ((tipoId == null) ? 0 : tipoId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TerceroPK other = (TerceroPK) obj;
		if (dvId == null) {
			if (other.dvId != null)
				return false;
		} else if (!dvId.equals(other.dvId))
			return false;
		if (numId == null) {
			if (other.numId != null)
				return false;
		} else if (!numId.equals(other.numId))
			return false;
		if (tipoId == null) {
			if (other.tipoId != null)
				return false;
		} else if (!tipoId.equals(other.tipoId))
			return false;
		return true;
	}
}
