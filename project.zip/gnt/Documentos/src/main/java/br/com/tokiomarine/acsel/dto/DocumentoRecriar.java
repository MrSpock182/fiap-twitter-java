package br.com.tokiomarine.acsel.dto;

public class DocumentoRecriar {

	private String ramo;
	private Long numApolice;
	private Integer numEndosso;
	private String codDocumento;	
	private String tipoApoliceEndosso;
	
	private String url;

	public String getRamo() {
		return ramo;
	}

	public void setRamo(String ramo) {
		this.ramo = ramo;
	}

	public Long getNumApolice() {
		return numApolice;
	}

	public void setNumApolice(Long numApolice) {
		this.numApolice = numApolice;
	}

	public Integer getNumEndosso() {
		return numEndosso;
	}

	public void setNumEndosso(Integer numEndosso) {
		this.numEndosso = numEndosso;
	}

	public String getCodDocumento() {
		return codDocumento;
	}

	public void setCodDocumento(String codDocumento) {
		this.codDocumento = codDocumento;
	}

	public String getTipoApoliceEndosso() {
		return tipoApoliceEndosso;
	}

	public void setTipoApoliceEndosso(String tipoApoliceEndosso) {
		this.tipoApoliceEndosso = tipoApoliceEndosso;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
