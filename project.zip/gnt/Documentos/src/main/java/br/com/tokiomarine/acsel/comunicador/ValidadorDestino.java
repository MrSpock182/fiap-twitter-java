/* 
 * Copyright (C) 2017 Tokio Marine - T803520 | @diegolirio
 */
package br.com.tokiomarine.acsel.comunicador;

import br.com.tokiomarine.acsel.domain.acx.AgendamentoEnvio;

/**
 * Contrato para Validar de Destino 
 * @author Diego Lirio
 */
public interface ValidadorDestino {

	void executa(AgendamentoEnvio agendamentoEnvio);

}
