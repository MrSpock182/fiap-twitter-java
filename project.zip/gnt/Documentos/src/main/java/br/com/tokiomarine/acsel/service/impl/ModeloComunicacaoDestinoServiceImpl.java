package br.com.tokiomarine.acsel.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.tokiomarine.acsel.domain.acx.Lval;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDestino;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoDestinoService;
import br.com.tokiomarine.acsel.service.ParametrosService;

@Stateless(name="ModeloComunicacaoDestinoService")
@Local(value=ModeloComunicacaoDestinoService.class)
public class ModeloComunicacaoDestinoServiceImpl implements ModeloComunicacaoDestinoService {

	@Inject
	ParametrosService paramsService;
	
	@Override
	public Collection<ModeloComunicacaoDestino> findAll() {
		Collection<ModeloComunicacaoDestino> list = new ArrayList<>();
		List<Lval> obtemListaValores = this.paramsService.obtemListaValores("GNT_DEST");
		for (Lval lval : obtemListaValores) {
			list.add(ModeloComunicacaoDestino.builder().codigo(lval.getCodLval()).descricao(lval.getDescrip()).build());
		}
		return list;
	}

}
