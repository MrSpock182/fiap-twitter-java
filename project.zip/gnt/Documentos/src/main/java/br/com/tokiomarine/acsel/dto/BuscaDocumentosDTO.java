package br.com.tokiomarine.acsel.dto;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.tokiomarine.acsel.util.StringUtil;

public class BuscaDocumentosDTO {

	private String tipoBusca;
	private String cpf;
	private String cnpj;
	private String ramo;
	private Long apolice;
	private Integer numEndosso;
	private Integer negocio;
	private Date dataIni;
	private Date dataFim;
	private String codCorretor;
	private boolean somenteApolice;
	private List<String> listaClientes;
	private List<Long> listaClientesPlataforma;
	private String tipoApoliceEndosso;

	public String getTipoBusca() {
		return tipoBusca;
	}
	public void setTipoBusca(String tipoBusca) {
		this.tipoBusca = tipoBusca;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getRamo() {
		return ramo;
	}
	public void setRamo(String ramo) {
		this.ramo = ramo;
	}
	public Long getApolice() {
		return apolice;
	}
	public void setApolice(Long apolice) {
		this.apolice = apolice;
	}
	public Integer getNegocio() {
		return negocio;
	}
	public void setNegocio(Integer negocio) {
		this.negocio = negocio;
	}
	public Integer getNumEndosso() {
		return numEndosso;
	}
	public void setNumEndosso(Integer numEndosso) {
		this.numEndosso = numEndosso;
	}
	public Date getDataIni() {
		return dataIni;
	}
	public void setDataIni(Date dataIni) {
		this.dataIni = dataIni;
	}
	public Date getDataFim() {
		return dataFim;
	}
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}
	public List<String> getListaClientes() {
		return listaClientes;
	}
	public void setListaClientes(List<String> listaClientes) {
		this.listaClientes = listaClientes;
	}
	public List<Long> getListaClientesPlataforma() {
		return listaClientesPlataforma;
	}
	public void setListaClientesPlataforma(List<Long> listaClientesPlataforma) {
		this.listaClientesPlataforma = listaClientesPlataforma;
	}
	public String getCodCorretor() {
		return codCorretor;
	}
	public void setCodCorretor(String codCorretor) {
		this.codCorretor = codCorretor;
	}
	public boolean isSomenteApolice() {
		return somenteApolice;
	}
	public void setSomenteApolice(boolean somenteApolice) {
		this.somenteApolice = somenteApolice;
	}
	public Long getNumDocumento(){

		String s = "";

		if (!StringUtil.isNull(getCpf())){
			s = StringUtils.split(getCpf(),"-")[0];
		}
		if (!StringUtil.isNull(getCnpj())){
			s = StringUtils.split(getCnpj(),"-")[0];
		}
		return Long.parseLong(StringUtil.removeSeparadores(s));
	}
	public Long getNumDocumentoSemFilial(){
		String s = "";

		if (!StringUtil.isNull(getCpf())){
			s = StringUtils.split(getCpf(),"-")[0];
		}
		if (!StringUtil.isNull(getCnpj())){
			s = StringUtils.split(getCnpj(),"/")[0];
		}
		return Long.parseLong(StringUtil.removeSeparadores(s));
	}
	public Long getNumFilial(){
		String s = "";
		if (!StringUtil.isNull(getCnpj())){
			s = StringUtils.split(getCnpj(),"-")[0];
			s = StringUtils.split(s,"/")[1];
			return Long.parseLong(s);
		} else{
			return 0L;
		}
	}

	public String getDvDocumento(){
		if (!StringUtil.isNull(getCpf())){
			return StringUtils.split(getCpf(),"-")[1];
		}
		if (!StringUtil.isNull(getCnpj())){
			return StringUtils.split(getCnpj(),"-")[1];
		}
		return "";
	}
	public String getTipoApoliceEndosso() {
		return tipoApoliceEndosso;
	}
	public void setTipoApoliceEndosso(String tipoApoliceEndosso) {
		this.tipoApoliceEndosso = tipoApoliceEndosso;
	}

}
