package br.com.tokiomarine.acsel.repository;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import br.com.tokiomarine.acsel.dao.BasePlatDAO;
import br.com.tokiomarine.acsel.dto.DocumentoDocstoreDTO;
import br.com.tokiomarine.acsel.dto.DocumentoImpressaoDTO;

public class ConsultaDocumentosPlatRepository {
	
	@Inject
	BasePlatDAO base;

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<DocumentoDocstoreDTO> listaDocumentos(Integer cdRamoProdutoTmsr, Integer cdApoliceTmsr, Integer cdEndossoTmsr, Integer cdDocumento) {
		
		StringBuilder sql = new StringBuilder("SELECT DISTINCT NVL(B.DS_URL_ARQUIVO, B.DS_URL_DOCSTORE) \"url\", "
												+ "B.CD_DOCUMENTO \"cdDocumento\", "
												+ "D.DS_DOCUMENTO \"dsDocumento\" " 
										   + " FROM APOLICE_DOCUMENTO_DIGITAL A, " 
												+ "APOLICE_DOCUMENTO_DIGITAL_ARQ B, " 
												+ "V_HISTO_APOLICE C, "
												+ "DOCUMENTO_IMPRESSAO D "
												+ "WHERE A.CD_SEQUENCIA = B.CD_SEQUENCIA "
										        + "AND   A.CD_LOCAL = C.CD_LOCAL "
										        + "AND   A.CD_RAMO = C.CD_RAMO "
										        + "AND   A.CD_APOLICE = C.CD_APOLICE " 
										        + "AND   NVL(A.CD_ENDOSSO, 0) = NVL(C.CD_ENDOSSO, 0) "
										        + "AND   C.CD_RAMO_PRODUTO_TMSR = :cdRamoProdutoTmsr "
										        + "AND   C.CD_APOLICE_TMSR = :cdApoliceTmsr "
										        + "AND 	 D.CD_DOCUMENTO = B.CD_DOCUMENTO "
										        + "AND   NVL(A.CD_ENDOSSO, 0) = NVL(C.CD_ENDOSSO, 0) "
										        + "AND   (B.DS_URL_ARQUIVO IS NOT NULL OR B.DS_URL_DOCSTORE IS NOT NULL) ");
		if(cdEndossoTmsr != null) {
			sql.append( "AND   NVL(C.CD_ENDOSSO_TMSR, 0) = NVL(:cdEndossoTmsr, 0) ");
		} 
		
		if(cdDocumento != null) {
			sql.append("AND   B.CD_DOCUMENTO = :cdDocumento ");
		}														        
		
		SQLQuery query = base.getSession().createSQLQuery(sql.toString());
		query.setParameter("cdRamoProdutoTmsr", cdRamoProdutoTmsr);
		query.setParameter("cdApoliceTmsr", cdApoliceTmsr);
		
		if(cdEndossoTmsr != null) {
			query.setParameter("cdEndossoTmsr", cdEndossoTmsr);
		} 
		
		if(cdDocumento != null) {
			query.setParameter("cdDocumento", cdDocumento);
		}
		
		query.addScalar("url", StandardBasicTypes.STRING);
		query.addScalar("cdDocumento", StandardBasicTypes.INTEGER);
		query.addScalar("dsDocumento", StandardBasicTypes.STRING);
		query.setResultTransformer(Transformers.aliasToBean(DocumentoDocstoreDTO.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<DocumentoImpressaoDTO> listaDocumentosDisponiveis() {
		return (List<DocumentoImpressaoDTO>) base.getSession().createSQLQuery("SELECT DISTINCT B.CD_DOCUMENTO cdDocumento, "
															  + "B.DS_DOCUMENTO dsDocumento "
													     + "FROM APOLICE_DOCUMENTO_DIGITAL_ARQ A, "
											  			 + "DOCUMENTO_IMPRESSAO B "
											  			 + "WHERE A.CD_DOCUMENTO = B.CD_DOCUMENTO ORDER BY B.CD_DOCUMENTO")
				.addScalar("cdDocumento", StandardBasicTypes.INTEGER)
				.addScalar("dsDocumento", StandardBasicTypes.STRING)
				.setResultTransformer(Transformers.aliasToBean(DocumentoImpressaoDTO.class))
				.list();
	}

}
