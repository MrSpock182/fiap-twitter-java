package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.tokiomarine.acsel.util.StringUtil;

@Entity
@Table(name = "POLIZA_CLI")
public class PolizaCli implements Serializable {
	private static final long serialVersionUID = 1L;


	@Id
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDEPOL", referencedColumnName="IDEPOL")
	private Poliza poliza;

	@Column(name="SISTORI")	private String sistOri;
	@Column(name="TPSOLEND")	private String tpSolEnd;
	@Column(name="TIPOCOBR")	private String tipoCobr;
	@Column(name="INDSEGVULT")	private String indSegVult;
	@Column(name="INDSEGSORT")	private String indSegSort;
	@Column(name="NUMATASORT")	private Long numAtaSort;
	@Column(name="DTSORT")	@Temporal(TemporalType.TIMESTAMP)	private Date dtSort;
	@Column(name="CODPRODRM")	private String codProdRm;
	@Column(name="CODMODPROD")	private String codModProd;
	@Column(name="CODMONEDA")	private String codMoneda;
	@Column(name="PERREAJ")	private String perReaj;
	@Column(name="TPCOMERC")	private String tpComerc;
	@Column(name="CODNEG")	private Long codNeg;
	@Column(name="CODINDXCAP")	private String codIndXcap;
	@Column(name="CODINDXPRE")	private String codIndXpre;
	@Column(name="TASAADICFRAC")	private BigDecimal tasaAdicFrac;
	@Column(name="TASAADICFRAC1")	private BigDecimal tasaAdicFrac1;
	@Column(name="VALADICFRAC")	private BigDecimal valAdicFrac;
	@Column(name="VALDESCCOS")	private BigDecimal valDescCos;
	@Column(name="CORRETCOS")	private String corretCos;
	@Column(name="VALCOMCOS")	private BigDecimal valComCos;
	@Column(name="CODMODALIDADE")	private String codModalidade;
	@Column(name="PORCJUROS")	private BigDecimal porcJuros;
	@Column(name="VALJUROS")	private BigDecimal valJuros;
	@Column(name="CODESTIP")	private Long codEstip;
	@Column(name="CODSUBESTIP")	private Long codSubestip;
	@Column(name="CODRAMOCLI")	private String codRamoCli;
	@Column(name="DTFIMVIGPROP")	@Temporal(TemporalType.TIMESTAMP)	private Date dtFimVigProp;
	@Column(name="CD_COSSEGURO_ACEITO")	private Long cdCosseguroAceito;
	@Column(name="CD_SEQUENCIA_COSSEGURO")	private Long cdSequenciaCosseguro;
	@Column(name="NUM_SERIE_CAP")	private Long numSerieCap;
	@Column(name="NUM_TITULO_CAP")	private Long numTituloCap;
	@Column(name="NUM_SORTEIO_CAP")	private Long numSorteioCap;
	@Column(name="INDREENQETARIO")	private String indReenqEtario;
	@Column(name="NUMORCCVGWEB")	private Long numOrcCvgWeb;
	@Column(name="INDATZCVGWEB")	private String indAtzCvgWeb;
	@Column(name="DTATZCVGWEB")	@Temporal(TemporalType.TIMESTAMP)	private Date dtAtzCvgWeb;
	@Column(name="INDKITAPP")	private String indKitApp;
	@Column(name="NUM_PROTOC_PROVISAO") private String numProtocProvisao;

	public Poliza getPoliza() {
		return poliza;
	}
	public void setPoliza(Poliza poliza) {
		this.poliza = poliza;
	}
	public String getSistOri() {
		return sistOri;
	}
	public void setSistOri(String sistOri) {
		this.sistOri = sistOri;
	}
	public String getTpSolEnd() {
		return tpSolEnd;
	}
	public void setTpSolEnd(String tpSolEnd) {
		this.tpSolEnd = tpSolEnd;
	}
	public String getTipoCobr() {
		return tipoCobr;
	}
	public void setTipoCobr(String tipoCobr) {
		this.tipoCobr = tipoCobr;
	}
	public String getIndSegVult() {
		return indSegVult;
	}
	public void setIndSegVult(String indSegVult) {
		this.indSegVult = indSegVult;
	}
	public String getIndSegSort() {
		return indSegSort;
	}
	public void setIndSegSort(String indSegSort) {
		this.indSegSort = indSegSort;
	}
	public Long getNumAtaSort() {
		return numAtaSort;
	}
	public void setNumAtaSort(Long numAtaSort) {
		this.numAtaSort = numAtaSort;
	}
	public Date getDtSort() {
		return dtSort;
	}
	public void setDtSort(Date dtSort) {
		this.dtSort = dtSort;
	}
	public String getCodProdRm() {
		return codProdRm;
	}
	public void setCodProdRm(String codProdRm) {
		this.codProdRm = codProdRm;
	}
	public String getCodModProd() {
		return codModProd;
	}
	public void setCodModProd(String codModProd) {
		this.codModProd = codModProd;
	}
	public String getCodMoneda() {
		return codMoneda;
	}
	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}
	public String getPerReaj() {
		return perReaj;
	}
	public void setPerReaj(String perReaj) {
		this.perReaj = perReaj;
	}
	public String getTpComerc() {
		return tpComerc;
	}
	public void setTpComerc(String tpComerc) {
		this.tpComerc = tpComerc;
	}
	public Long getCodNeg() {
		return codNeg;
	}
	public void setCodNeg(Long codNeg) {
		this.codNeg = codNeg;
	}
	public String getCodIndXcap() {
		return codIndXcap;
	}
	public void setCodIndXcap(String codIndXcap) {
		this.codIndXcap = codIndXcap;
	}
	public String getCodIndXpre() {
		return codIndXpre;
	}
	public void setCodIndXpre(String codIndXpre) {
		this.codIndXpre = codIndXpre;
	}
	public BigDecimal getTasaAdicFrac() {

		return StringUtil.formataTaxa(tasaAdicFrac);
	}
	public void setTasaAdicFrac(BigDecimal tasaAdicFrac) {

		this.tasaAdicFrac = StringUtil.formataTaxa(tasaAdicFrac);
	}
	public BigDecimal getTasaAdicFrac1() {

		return StringUtil.formataTaxa(tasaAdicFrac1);
	}
	public void setTasaAdicFrac1(BigDecimal tasaAdicFrac1) {

		this.tasaAdicFrac1 = StringUtil.formataTaxa(tasaAdicFrac1);;
	}
	public BigDecimal getValAdicFrac() {
		if (valAdicFrac==null) valAdicFrac = new BigDecimal(0);

		return valAdicFrac;
	}
	public void setValAdicFrac(BigDecimal valAdicFrac) {
		this.valAdicFrac = valAdicFrac;
	}
	public BigDecimal getValDescCos() {
		if (valDescCos==null) valDescCos = new BigDecimal(0);

		return valDescCos;
	}
	public void setValDescCos(BigDecimal valDescCos) {
		this.valDescCos = valDescCos;
	}
	public String getCorretCos() {
		return corretCos;
	}
	public void setCorretCos(String corretCos) {
		this.corretCos = corretCos;
	}
	public BigDecimal getValComCos() {
		if (valComCos==null) valComCos = new BigDecimal(0);

		return valComCos;
	}
	public void setValComCos(BigDecimal valComCos) {
		this.valComCos = valComCos;
	}
	public String getCodModalidade() {
		return codModalidade;
	}
	public void setCodModalidade(String codModalidade) {
		this.codModalidade = codModalidade;
	}
	public BigDecimal getPorcJuros() {
		if (porcJuros==null) porcJuros = new BigDecimal(0);

		return porcJuros;
	}
	public void setPorcJuros(BigDecimal porcJuros) {
		this.porcJuros = porcJuros;
	}
	public BigDecimal getValJuros() {
		if (valJuros==null) valJuros = new BigDecimal(0);

		return valJuros;
	}
	public void setValJuros(BigDecimal valJuros) {
		this.valJuros = valJuros;
	}
	public Long getCodEstip() {
		return codEstip;
	}
	public void setCodEstip(Long codEstip) {
		this.codEstip = codEstip;
	}
	public Long getCodSubestip() {
		return codSubestip;
	}
	public void setCodSubestip(Long codSubestip) {
		this.codSubestip = codSubestip;
	}
	public String getCodRamoCli() {
		return codRamoCli;
	}
	public void setCodRamoCli(String codRamoCli) {
		this.codRamoCli = codRamoCli;
	}
	public Date getDtFimVigProp() {
		return dtFimVigProp;
	}
	public void setDtFimVigProp(Date dtFimVigProp) {
		this.dtFimVigProp = dtFimVigProp;
	}
	public Long getCdCosseguroAceito() {
		return cdCosseguroAceito;
	}
	public void setCdCosseguroAceito(Long cdCosseguroAceito) {
		this.cdCosseguroAceito = cdCosseguroAceito;
	}
	public Long getCdSequenciaCosseguro() {
		return cdSequenciaCosseguro;
	}
	public void setCdSequenciaCosseguro(Long cdSequenciaCosseguro) {
		this.cdSequenciaCosseguro = cdSequenciaCosseguro;
	}
	public Long getNumSerieCap() {
		return numSerieCap;
	}
	public void setNumSerieCap(Long numSerieCap) {
		this.numSerieCap = numSerieCap;
	}
	public Long getNumTituloCap() {
		return numTituloCap;
	}
	public void setNumTituloCap(Long numTituloCap) {
		this.numTituloCap = numTituloCap;
	}
	public Long getNumSorteioCap() {
		return numSorteioCap;
	}
	public void setNumSorteioCap(Long numSorteioCap) {
		this.numSorteioCap = numSorteioCap;
	}
	public String getIndReenqEtario() {
		return indReenqEtario;
	}
	public void setIndReenqEtario(String indReenqEtario) {
		this.indReenqEtario = indReenqEtario;
	}
	public Long getNumOrcCvgWeb() {
		return numOrcCvgWeb;
	}
	public void setNumOrcCvgWeb(Long numOrcCvgWeb) {
		this.numOrcCvgWeb = numOrcCvgWeb;
	}
	public String getIndAtzCvgWeb() {
		return indAtzCvgWeb;
	}
	public void setIndAtzCvgWeb(String indAtzCvgWeb) {
		this.indAtzCvgWeb = indAtzCvgWeb;
	}
	public Date getDtAtzCvgWeb() {
		return dtAtzCvgWeb;
	}
	public void setDtAtzCvgWeb(Date dtAtzCvgWeb) {
		this.dtAtzCvgWeb = dtAtzCvgWeb;
	}
	public String getIndKitApp() {
		return indKitApp;
	}
	public void setIndKitApp(String indKitApp) {
		this.indKitApp = indKitApp;
	}
	public String getNumProtocProvisao() {
		return numProtocProvisao;
	}
	public void setNumProtocProvisao(String numProtocProvisao) {
		this.numProtocProvisao = numProtocProvisao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((poliza == null) ? 0 : poliza.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PolizaCli other = (PolizaCli) obj;
		if (poliza == null) {
			if (other.poliza != null)
				return false;
		} else if (!poliza.equals(other.poliza))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PolizaCli [poliza=" + poliza + ", sistOri=" + sistOri
				+ ", tpSolEnd=" + tpSolEnd + ", tipoCobr=" + tipoCobr
				+ ", indSegVult=" + indSegVult + ", indSegSort=" + indSegSort
				+ ", numAtaSort=" + numAtaSort + ", dtSort=" + dtSort
				+ ", codProdRm=" + codProdRm + ", codModProd=" + codModProd
				+ ", codMoneda=" + codMoneda + ", perReaj=" + perReaj
				+ ", tpComerc=" + tpComerc + ", codNeg=" + codNeg
				+ ", codIndXcap=" + codIndXcap + ", codIndXpre=" + codIndXpre
				+ ", tasaAdicFrac=" + tasaAdicFrac + ", tasaAdicFrac1="
				+ tasaAdicFrac1 + ", valAdicFrac=" + valAdicFrac
				+ ", valDescCos=" + valDescCos + ", corretCos=" + corretCos
				+ ", valComCos=" + valComCos + ", codModalidade="
				+ codModalidade + ", porcJuros=" + porcJuros + ", valJuros="
				+ valJuros + ", codEstip=" + codEstip + ", codSubestip="
				+ codSubestip + ", codRamoCli=" + codRamoCli
				+ ", dtFimVigProp=" + dtFimVigProp + ", cdCosseguroAceito="
				+ cdCosseguroAceito + ", cdSequenciaCosseguro="
				+ cdSequenciaCosseguro + ", numSerieCap=" + numSerieCap
				+ ", numTituloCap=" + numTituloCap + ", numSorteioCap="
				+ numSorteioCap + ", indReenqEtario=" + indReenqEtario
				+ ", numOrcCvgWeb=" + numOrcCvgWeb + ", indAtzCvgWeb="
				+ indAtzCvgWeb + ", dtAtzCvgWeb=" + dtAtzCvgWeb
				+ ", indKitApp=" + indKitApp + ", numProtocProvisao=" + numProtocProvisao + "]";
	}

}