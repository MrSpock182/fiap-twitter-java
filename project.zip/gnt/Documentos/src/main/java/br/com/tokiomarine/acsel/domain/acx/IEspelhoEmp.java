package br.com.tokiomarine.acsel.domain.acx;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.tokiomarine.acsel.util.StringUtil;

@Entity
@Table(name = "I_ESPELHO_EMP")
public class IEspelhoEmp implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="IDEREG") private Long idReg;

	@ManyToOne
	@JoinColumns(
		{
			@JoinColumn(name = "SEQARQ", referencedColumnName = "SEQARQ" ),
			@JoinColumn(name = "CODITEM", referencedColumnName = "CODITEM" )
        }
	)
	private ISeqArq seqArq;
	//@Column(name="CODITEM") private String codItem;
	@Column(name="CODSUBITEM") private String codSubItem;
	@Column(name="CHAVEGENERICA") private String chaveGenerica;
	@Column(name="LIVRE") private String livre;
	@Column(name="INDPROCESADO") private String indProcessado;
	@Column(name="CD_ARQV") private String codArquivo;

	public String getCodItem() {
		//return StringUtil.lpad(codItem, "0", 2);
		
		return this.seqArq!=null ? StringUtil.lpad(this.seqArq.getCodItem(), "0", 2):null;
	}
	public void setCodItem(String codItem) {
		//this.codItem = codItem;
		if(this.seqArq == null){
			this.seqArq = new ISeqArq();
		}
	
		this.seqArq.setCodItem(codItem);
		
	}
	
	public Long getIdReg() {
		return idReg;
	}
	public void setIdReg(Long idReg) {
		this.idReg = idReg;
	}
	public ISeqArq getSeqArq() {
		return seqArq;
	}
	public void setSeqArq(ISeqArq seqArq) {
		this.seqArq = seqArq;
	}

	public String getCodSubItem() {
		return codSubItem;
	}
	public void setCodSubItem(String codSubItem) {
		this.codSubItem = codSubItem;
	}
	public String getChaveGenerica() {
		return chaveGenerica;
	}
	public void setChaveGenerica(String chaveGenerica) {
		this.chaveGenerica = chaveGenerica;
	}
	public String getLivre() {
		return livre;
	}
	public void setLivre(String livre) {
		this.livre = livre;
	}
	public String getIndProcessado() {
		return indProcessado;
	}
	public void setIndProcessado(String indProcessado) {
		this.indProcessado = indProcessado;
	}
	public String getCodArquivo() {
		return codArquivo;
	}
	public void setCodArquivo(String codArquivo) {
		this.codArquivo = codArquivo;
	}
}