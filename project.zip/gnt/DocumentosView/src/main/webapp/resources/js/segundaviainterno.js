function loadLocais(){
	$.blockUI();
	$.ajax({
	    dataType : "json",
	    url : 'col/locaisTrabalho',
	    headers : {
	        'Accept' : 'application/json',
	        'Content-Type' : 'application/json; charset=UTF-8'
	    },
	    type: 'GET',
	    success : function(resp) {
	        $.each(resp,function(key, local) {
	            var opcao = "<option value='" + local.nome + "'>" + local.nome + "</>";
	            $('#listaLocais').append(opcao);
	        })
	    	$("#enderecoLocal").toggleClass("hide");
	        $.unblockUI();
	    },
	    error : function(){
	    	$.unblockUI();
	        alert("Erro ao buscar locais de trabalho");
	    }
	});

}

function loadColaboradores(local){
	$.blockUI();
	$.ajax({
	    dataType : "json",
	    url : 'col/colaboradores',
	    headers : {
	        'Accept' : 'application/json',
	        'Content-Type' : 'application/json; charset=UTF-8'
	    },
	    type: 'POST',
	    data: local,
	    success : function(resp) {
	    	$('#listaColaboradores').append("<option value=''>Selecione o Colaborador</>");
	        $.each(resp,function(key, col) {
	            var opcao = "<option value='" + col.nome + "'>" + col.nome + "</>";
	            $('#listaColaboradores').append(opcao);
	        })
	        $('#colaborador').removeClass("hide");
	        $.unblockUI();
	    },
	    error : function(){
	    	$.unblockUI();
	        alert("Erro ao buscar colaboradores");
	    }
	});
}

