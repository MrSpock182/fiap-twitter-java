
function initSegundaVia() {
    $('#tableResult').dataTable({
        "order": [
			    [4, "desc"]
			 ],
		"columnDefs": [{ orderable: false, targets: [6] }],
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

    if($("#tipoBusca").val() == "A"){
    	showBuscaApolice();
    } else{
    	showBuscaCliente();
    }

    jQuery("#formBusca").validationEngine();

    $('#negocioHelp').popover();

    $('.btn-hist').click(function(e) {
        e.stopPropagation();
    });
};

function showBuscaApolice() {
	$("#tipoBusca").val("A");
	$("#buscaCliente").addClass("hide");
	$("#buscaApolice").removeClass("hide");
	$("#tipoApolice").addClass("active");
	$("#tipoCliente").removeClass("active");
};

function showBuscaCliente() {
	$("#tipoBusca").val("C");
	$("#buscaCliente").removeClass("hide");
	$("#buscaApolice").addClass("hide");
	$("#tipoCliente").addClass("active");
	$("#tipoApolice").removeClass("active");
};

function initDetalhes() {
	onChangeDestino($("#tipoDestino").val());
	jQuery("#segundavia").validationEngine();

    $('#tableItens').dataTable({
        "paging" : true,
        "searching" : true,
        "ordering" : true,
        "bInfo": true,
        "bLengthChange": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

    tableItens = $('#tableItens').DataTable();

    $('#tableItens tbody').on( 'click', 'tr', function () {
    	$(this).toggleClass('active')
    });

    incluiItens();

    $('#modalItem').on('hide.bs.modal', function () {
    	incluiItens();
    });

    $('#tableItensPDF').dataTable({
        "paging" : true,
        "searching" : true,
        "ordering" : true,
        "bInfo": true,
        "bLengthChange": false,
        "drawCallback": function( settings ) {
            $("#tableResult").wrap( "<div class='table-responsive'></div>" );
        }
    });

    tableItensPDF = $('#tableItensPDF').DataTable();

    $('#tableItensPDF tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('active') ) {
            $(this).removeClass('active');
        }
        else {
        	tableItensPDF.$('tr.active').removeClass('active');
            $(this).addClass('active');
        }
    });
};

function onChangeDestino(val){
	$("#enderecosCliente").addClass("hide");
	$("#enderecoCorretor").addClass("hide");
	$("#enderecoLocal").addClass("hide");

	if (val == "S"){
		$("#enderecosCliente").toggleClass("hide");
	}
	if (val == "C"){
		$("#enderecoCorretor").toggleClass("hide");
	}
	if (val == "L"){
		loadLocais();
	}
}

function onChangeLocal(val){
	$('#listaColaboradores').empty();
	$('#colaborador').addClass("hide");
	if (val != "")
		loadColaboradores(val);
}

function onChangeOpcao(val){
	$('#divListaDocumentos').addClass("hide");
	if (val.options[val.selectedIndex].className === "true"){
		$('.multiItemOnly').removeClass("hide");
	} else{
		$('.multiItemOnly').addClass("hide");
	}
}

function loadHist(id){

	$('#divModalHist').html("<i class='fa fa-spinner fa-spin'></i> Por favor aguarde...");

	$.ajax( {
        dataType: 'text',
        type: "GET",
        url:  "segundavia/hist",
	    data : {
	    	id : id
	    },
        success:function(result){
        	$('#divModalHist').html(result);
		    initTableHist();
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		$('#divModalHist').html("Erro ao buscar histórico de solicitações");
    	}
	});
}

function initTableHist(){
    $('#tableHist').dataTable({
    	"paging":   true,
    	"ordering": false,
    	"info":     true,
    	"searching": true,
    	"bLengthChange": false,
        "drawCallback": function( settings ) {
            $("#tableHist").wrap( "<div class='table-responsive'></div>" );
        }
    });
    $('#statusHelp').popover();
}

function cancelaSegundaVia(id, idVia){
	$('#hist').html("<i class='fa fa-spinner fa-spin'></i> Por favor aguarde...");
	$.ajax( {
		dataType: 'text',
        type: "POST",
        url:  "segundavia/cancela",
	    data : {
	    	id : id,
	    	idVia : idVia
	    },
        success:function(result){
        	$('#hist').html(result);
		    initTableHist();
    	},
    	error: function(jqXHR, textStatus, errorThrown) {
    		$('#hist').html("Erro ao cancelar solicitação");
    	}
	});
}

function geraPDFDocumento(id, idDocto, idepol, numEndosso){
	if (!$("#formPDF").validationEngine('validate')) return;
	$("#messagePDFAlert").removeClass('hide');
	$("#messagePDF").html('<i class="fa fa-spinner fa-spin"></i> Por favor, aguarde a geração do documento...');

	var codItem = tableItensPDF.$('tr.active').find('td.idItem').html();
	
	$.ajax({
	    dataType : "text",
	    url : 'segundavia/geraDocumento',
	    data : {
	    	id : id,
	    	idDocto : idDocto,
	    	codItem : codItem,
	    	idepol: idepol, 
	    	numEndosso: numEndosso,
	    	email : $('#inputEmail').val(),
	    	
	    },
	    headers : {},
	    type: 'GET',
	    success : function(resp) {
	    	if (resp != ""){
	    		console.log(resp);	    		
	    		document.getElementById('downloadTarget').src = resp;
	    		$("#messagePDF").html('Documento gerado com sucesso! O download será iniciado em instantes...');
	    	} else{
	    		$("#messagePDF").html('Não foi possível gerar o documento. Por favor, tente novamente mais tarde.');
	    	}
	    },
	    error : function(jqXHR, textStatus, errorThrown){
	    	$("#messagePDF").html('Não foi possível gerar o documento. Por favor, tente novamente mais tarde.');
	    }
	});
}

function incluiItens(){
	$('#divItens').empty();
	tableItens.$('tr.active').each(function(index) {
		$('#divItens').append("<input type='hidden' name='listaItens[" + index + "]' value='" + $(this).children(":first").html() + "'/>");
	});
	if (tableItens.$('tr.active').length > 0){
		$('#inputListaItens').val(tableItens.$('tr.active').length + " item(s) selecionado(s)");
	} else{
		$('#inputListaItens').val("");
	}
}

function incluiTodos(){
	tableItens.$('tr').addClass('active');
}

function removeTodos(){
	tableItens.$('tr').removeClass('active');
}

