package br.com.tokiomarine.acsel.dto;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value= {"classpath:application.properties"})
public class ApplicationProperties {

	@Value("${application.version}")
	private String version;

	@Value(value="${application.artifactId}")
	private String artifactId;
 
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}

	@Override
	public String toString() {
		return "ApplicationProperties [version=" + version + ", artifactId=" + artifactId + "]";
	} 
	
	
}
