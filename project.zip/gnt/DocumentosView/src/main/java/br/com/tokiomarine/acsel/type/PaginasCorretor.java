package br.com.tokiomarine.acsel.type;

public enum PaginasCorretor {

	segundavia("segundavia"),
	segundaviadet("segundaviadet"),
	indisponivel("indisponivel");

	PaginasCorretor(String value) {
		this.value = value;
	}

	PaginasCorretor() {}

	private String value;

	public String value() {
		if (value != null) {
			return "corretor/" + value;
		} else {
			return "corretor/" + this.name();
		}
	}
}
