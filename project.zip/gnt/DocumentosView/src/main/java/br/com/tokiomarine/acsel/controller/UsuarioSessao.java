package br.com.tokiomarine.acsel.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.acsel.dto.UsuarioDTO;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.service.ColaboradoresService;
import br.com.tokiomarine.acsel.type.TipoUsuario;
import br.com.tokiomarine.acsel.util.StringUtil;
import br.com.tokiomarine.acsel.util.VariaveisAmbienteUtil;
import br.com.tokiomarine.sso.model.UsuarioLogado;
import br.com.tokiomarine.sso.model.UsuarioLogadoException;

@Component
@Scope("session")
public class UsuarioSessao {

	private static Logger logger = LoggerFactory.getLogger(UsuarioSessao.class);
	private static final String USUARIO_DESENVOLVIMENTO_VALIDO = "T803797";
	
	@Autowired
	ColaboradoresService adService;

	private String idUsuario;
	private String nomeUsuario;
	private TipoUsuario tipoUsuario;
	private String codCorretor;
	private String ambiente = VariaveisAmbienteUtil.getAmbienteDetectado();
	
	public String getIdUsuario() {
		return idUsuario;
	}
	private void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}
	public String getNomeUsuario() {
		return nomeUsuario;
	}
	private void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}
	public TipoUsuario getTipoUsuario() {
		return tipoUsuario;
	}
	private void setTipoUsuario(TipoUsuario tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
	public String getCodCorretor() {
		return codCorretor;
	}
	private void setCodCorretor(String codCorretor) {
		this.codCorretor = StringUtil.lpad(codCorretor,"0",6);
	}
	public boolean isCorretor(){
		return this.tipoUsuario.equals(TipoUsuario.corretor);
	}
	public String getCodUsuario(){
		return isCorretor() ? this.codCorretor : this.idUsuario;
	}
	
	public UsuarioDTO getUsuario(){
		UsuarioDTO dto = new UsuarioDTO();
		dto.setCodCorretor(getCodCorretor());
		dto.setIdUsuario(getIdUsuario());
		dto.setNomeUsuario(getNomeUsuario());
		dto.setTipoUsuario(getTipoUsuario());
		return dto;
	}

	public void loadUsuarioCorretor(HttpServletRequest request) throws ServiceException{
		try {
			UsuarioLogado user = new UsuarioLogado(request);
			this.setIdUsuario(this.getUserEnvironment(user.getLogin()));
			this.setCodCorretor(user.getCodigoInterno().toString());
			this.setNomeUsuario(user.getNome());
			if (StringUtil.isNull(this.getIdUsuario())){
				logger.info(user.getLogin());
				throw new ServiceException("ID do usuário não encontrado");
			}
			if (StringUtil.isNull(this.getCodCorretor())){
				throw new ServiceException("Código do corretor não encontrado");
			}
			this.setTipoUsuario(TipoUsuario.corretor);
		} catch (UsuarioLogadoException e) {
			throw new ServiceException("Não foi possível obter o corretor logado: " + e.getMessage());
		} catch (Exception e){
			throw new ServiceException("Erro ao obter o corretor logado: " + e.getMessage());
		}
	}

	public void loadUsuarioInterno(HttpServletRequest request) throws ServiceException{
		try {
			this.setIdUsuario(this.getUserEnvironment(request.getHeader("login")));
			this.setNomeUsuario(request.getHeader("nome"));
			if (StringUtil.isNull(this.getIdUsuario())){
				logger.warn(request.getHeader("login"));
				throw new ServiceException("ID do usuário não encontrado | " + ambiente);
			} else if (adService.obtemColaborador(this.getIdUsuario()).isEmpty()){
				throw new ServiceException("Colaborador não encontrado");
			}
			this.setTipoUsuario(TipoUsuario.interno);
		} catch (Exception e){
			throw new ServiceException("Erro ao obter o usuário logado: " + e.getMessage());
		}
	}
	 
	private String getUserEnvironment(String userLogin) {
		if("LOCAL".equals(ambiente) || "DESENVOLVIMENTO".equals(ambiente))
			return USUARIO_DESENVOLVIMENTO_VALIDO;
		return userLogin;
	}
}
