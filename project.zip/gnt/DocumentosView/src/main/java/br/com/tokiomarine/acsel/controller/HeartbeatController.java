package br.com.tokiomarine.acsel.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoService;
import br.com.tokiomarine.acsel.type.Aplicacao;
import br.com.tokiomarine.acsel.util.MimeType;
import br.com.tokiomarine.acsel.util.StringUtil;
import br.com.tokiomarine.acsel.util.TempoDeExecucaoUtil;

@Controller
public class HeartbeatController {

	private final String MENSAGEM_DE_SUCESSO = "OK";
	private final String MENSAGEM_DE_ERRO = "ERRO";

	private static Logger logger = LogManager.getLogger(HeartbeatController.class);

	@Autowired
	ModeloComunicacaoService modeloService;

	@RequestMapping(value = "/heartbeat",method = RequestMethod.GET)
	@ResponseBody
	protected String hearbeat(HttpServletResponse response) throws ServletException,IOException {

		response.setContentType(MimeType.html.getContentType());
		response.setCharacterEncoding(Aplicacao.encodingPadrao.value());

		StringBuilder resultado = new StringBuilder();
		String retornoSQL = "";
		String retornoTempoTotal = "";
		boolean deuErro = false;

		long threadId = Thread.currentThread().getId();
		TempoDeExecucaoUtil tempoDeExecucaoUtil = new TempoDeExecucaoUtil(threadId);

		resultado.append("<html><pre>");
		try {
			logger.info("teste da rotina com SQL");
			tempoDeExecucaoUtil.inicioProcesso();
			List<ModeloComunicacao> lista = modeloService.obtemModelos();
			tempoDeExecucaoUtil.fimProcesso();
			retornoSQL = "[SUCESSO] - [   SQL   ] - " + StringUtil.formataNumeroComDuasCasasDecimais(tempoDeExecucaoUtil.getDuracaoProcessoEmMilisegundos()) + " ms - retornou: " + lista.size() + " valores";
			logger.info(retornoSQL);
		} catch (Exception e) {
			logger.error("Erro no Heartbeat",e);
			retornoSQL = "[ERRO] - [   SQL   ] - erro ao acessar o MongoDB:" + e.getMessage();
			// deu erro!
			resultado.append(MENSAGEM_DE_ERRO);
			deuErro = true;
		}

		tempoDeExecucaoUtil.fim();
		retornoTempoTotal = "Tempo total: " + StringUtil.formataNumeroComDuasCasasDecimais(tempoDeExecucaoUtil.getDuracaoEmMilisegundos()) + " ms";
		logger.info(retornoTempoTotal);

		// tudo Ok ?
		if (!deuErro) {
			resultado.append(MENSAGEM_DE_SUCESSO + "\n");
		}

		resultado.append("---------------------------------------------------------------------------------------------------------------------------------------------- \n");
		resultado.append(retornoSQL + "\n");
		resultado.append("---------------------------------------------------------------------------------------------------------------------------------------------- \n");
		resultado.append(retornoTempoTotal + "\n");
		resultado.append("</pre></html>");
		return resultado.toString();

	}

}
