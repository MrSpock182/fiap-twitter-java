package br.com.tokiomarine.acsel.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.tokiomarine.acsel.type.Aplicacao;
import br.com.tokiomarine.acsel.util.MimeType;
import br.com.tokiomarine.acsel.util.StatsUtil;

public class StatsServlet extends HttpServlet {

	private static final long serialVersionUID = -9152999868136048339L;

	protected void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {

		response.setContentType(MimeType.json.getContentType());
		response.setCharacterEncoding(Aplicacao.encodingPadrao.value());

		PrintWriter out = response.getWriter();

		StringBuilder resultado = new StringBuilder();

		resultado.append("{");
		resultado.append("\"buscas\":" + StatsUtil.getBuscas());
		resultado.append("}");

		out.println(resultado.toString().trim());

	}

	@Override
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		processRequest(request,response);
	}

	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		processRequest(request,response);
	}

}
