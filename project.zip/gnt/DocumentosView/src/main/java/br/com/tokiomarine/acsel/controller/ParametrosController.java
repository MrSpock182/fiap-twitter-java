package br.com.tokiomarine.acsel.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import br.com.tokiomarine.acsel.domain.acx.GrpParamAcsel;
import br.com.tokiomarine.acsel.domain.acx.ParamAcsel;
import br.com.tokiomarine.acsel.service.ParametrosService;
import br.com.tokiomarine.acsel.type.Paginas;

@Controller
@Scope("request")
@SessionAttributes({"grupos","grupo", "parametros"})
@RequestMapping(value = "/parametros")
public class ParametrosController {

	// model attributes
	public static final String GRUPO = "grupo";
	public static final String GRUPOS = "grupos";
	public static final String PARAMETRO = "parametro";
	public static final String PARAMETROS = "parametros";

	@Autowired
	MessageSource messages;
	@Autowired
	ParametrosService parametrosService;
	@Autowired
	UsuarioSessao usuarioSessao;


	private static Logger logger = LogManager.getLogger(ParametrosController.class);

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String main(HttpServletRequest request, Model model) throws Exception {

		try{
			logger.error("teste");
			List<GrpParamAcsel> grupos = parametrosService.obtemGrupos();
			usuarioSessao.loadUsuarioInterno(request);

			model.addAttribute(GRUPO, new GrpParamAcsel());
			model.addAttribute(GRUPOS, grupos);
			model.addAttribute(PARAMETROS, new ArrayList<ParamAcsel>());
			model.addAttribute(PARAMETRO, new ParamAcsel());

			return Paginas.parametros.value();
		} catch (Exception e){
			return obtemPaginaErro(e, model);
		}
	}

	@RequestMapping(value = "",method = RequestMethod.POST)
	public String post(@ModelAttribute GrpParamAcsel busca, Model model){

		try{
			List<ParamAcsel> parametros = parametrosService.obtemParametrosGrupo(busca.getIdGrpParametro());

			model.addAttribute(GRUPO, busca);
			model.addAttribute(PARAMETROS, parametros);
			model.addAttribute(PARAMETRO, new ParamAcsel());

			return Paginas.parametros.value();
		} catch (Exception e){
			return obtemPaginaErro(e, model);
		}
	}

	@RequestMapping(value = "insere",method = RequestMethod.POST)
	public @ResponseBody String insereParam(@RequestBody ParamAcsel param){

		String msgRet = "";
		try{
			param.setCodUsuarioAlter(usuarioSessao.getIdUsuario());
			param.setDtUltimaAlter(new Date());
			parametrosService.insereParam(param);

		} catch (Exception e){
			msgRet = "Erro ao inserir parâmetro: " + e;
 		}

		return msgRet;
	}

	@RequestMapping(value = "atualiza",method = RequestMethod.POST)
	public @ResponseBody String atualizaParam(Integer id, String vlrParam, Model model){

		String msgRet = "";
		try{
			@SuppressWarnings("unchecked")
			List<ParamAcsel> parametros = (List<ParamAcsel>) model.asMap().get(PARAMETROS);

			ParamAcsel p = parametros.get(id);

			p.setVlrParametro(vlrParam);
			p.setCodUsuarioAlter(usuarioSessao.getIdUsuario());
			p.setDtUltimaAlter(new Date());

			parametrosService.atualizaParam(p);
		} catch (Exception e){
			msgRet = "Erro ao atualizar parâmetro: " + e;
 		}

		return msgRet;
	}

	@RequestMapping(value = "remove",method = RequestMethod.POST)
	public @ResponseBody String removeParam(Integer id, Model model){

		String msgRet = "";
		try{
			@SuppressWarnings("unchecked")
			List<ParamAcsel> parametros = (List<ParamAcsel>) model.asMap().get(PARAMETROS);

			ParamAcsel p = parametros.get(id);
			parametrosService.removeParam(p);

		} catch (Exception e){
			msgRet = "Erro ao remover parâmetro: " + e;
 		}

		return msgRet;
	}

	private String obtemPaginaErro(Exception e, Model model){
		model.addAttribute("mensagem",e.getMessage());
		model.addAttribute("stacktrace",ExceptionUtils.getFullStackTrace(e));
		logger.error("Erro",e);
		return Paginas.error.value();
	}
}