package br.com.tokiomarine.acsel.controller;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.tokiomarine.acsel.comunicador.TemplateJson;
import br.com.tokiomarine.acsel.comunicador.mail.TemplateJsonEmail;
import br.com.tokiomarine.acsel.comunicador.sms.TemplateJsonSms;
import br.com.tokiomarine.acsel.domain.acx.ModeloComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroComunicacao;
import br.com.tokiomarine.acsel.domain.acx.ParametroModelo;
import br.com.tokiomarine.acsel.domain.acx.TextoComunicacao;
import br.com.tokiomarine.acsel.domain.acx.TextoModeloComunicacao;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoDTO;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoProcesso;
import br.com.tokiomarine.acsel.dto.ModeloComunicacaoSistemaOrigem;
import br.com.tokiomarine.acsel.exception.ServiceException;
import br.com.tokiomarine.acsel.service.AgendamentoComunicacaoService;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoDestinoService;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoProcessoService;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoService;
import br.com.tokiomarine.acsel.service.ModeloComunicacaoSistemaOrigemService;
import br.com.tokiomarine.acsel.type.Paginas;
import br.com.tokiomarine.acsel.type.TipoModelo;

@Controller
@Scope("request")
@RequestMapping(value = "/comunicacao/modelos")
public class ModeloComunicacaoController {

	// model attributes
	public static final String MODELOS = "modelos";
	public static final String MODELO = "modelo";
	public static final String DOCUMENTOS = "documentos";
	public static final String PARAMETROS = "parametros";
	public static final String TEXTOS = "textos";
	public static final String PADROES = "padroes";
	public static final String IMAGENS = "imagens";
	public static final String MODELO_COMUNICACAO_DESTINOS = "destinos";
	private static final String MODELO_COMUNICACAO_PROCESSOS = "processos";
	private static final String MODELO_COMUNICACAO_SISTEMA_ORIGEM = "sistemasOrigemLista";
	private static final String HISTORICOS = "historicos";
	private static final String INATIVOS = "inativos";
	private static final String EXIST_AGENDAMENTO = "existAgendamento";
	private static final String PERFIL_USUARIO   = "perfilUsuario";
	private static final String ERRO_STATUS     = "erroStatus";
		
	@Autowired
	UsuarioSessao usuarioSessao;
	@Autowired
	ModeloComunicacaoService modeloService;
	
	@Autowired
	private ModeloComunicacaoDestinoService modeloComunicacaoDestinoService;
	@Autowired
	private ModeloComunicacaoProcessoService modeloComunicacaoProcessoService;
	@Autowired
	private ModeloComunicacaoSistemaOrigemService modeloComunicacaoSistemaOrigemService;
	@Autowired
	private ModeloComunicacaoService modeloComunicacaoService;
	@Autowired
	private AgendamentoComunicacaoService agendamentoComunicacaoService;

	private static Logger logger = LogManager.getLogger(ModeloComunicacaoController.class);

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String main(Integer id, HttpServletRequest request, Model model){

		try{
			usuarioSessao.loadUsuarioInterno(request);

			List<ModeloComunicacao> modelos = modeloService.obtemModelos();

			model.addAttribute(MODELOS, modelos);

			return Paginas.listamodelos.value();
		} catch (Exception e){
			return obtemPaginaErro(e, model);
		}
	}

	@RequestMapping(value = "/detalhes", method = RequestMethod.GET)
	public String modelo(Integer id, HttpServletRequest request, Model model) {

		try{
			ModeloComunicacao modelo;
			model.addAttribute(MODELO_COMUNICACAO_SISTEMA_ORIGEM, modeloComunicacaoSistemaOrigemService.findAll());

			if (id == null || id <= 0){
				modelo = new ModeloComunicacao();
				modelo.setPiloto("N");
				model.addAttribute(MODELO, modelo);
				model.addAttribute(PADROES, modeloService.obtemPadroes());
				model.addAttribute(IMAGENS, modeloService.obtemImagens());
				model.addAttribute(MODELO_COMUNICACAO_PROCESSOS, modeloComunicacaoProcessoService.findAll());				
				return Paginas.novomodelo.value();
			}

			modelo = modeloService.obtemModelo(id.longValue());
			model.addAttribute(MODELO, modelo);
			model.addAttribute(TEXTOS, modeloService.obtemTextos(modelo.getTipoModelo()));
			model.addAttribute(PARAMETROS, modeloService.obtemParametrosDisponiveis(modelo.getCodModelo()));
			model.addAttribute(PADROES, modeloService.obtemPadroes());
			model.addAttribute(IMAGENS, modeloService.obtemImagens());
			model.addAttribute(MODELO_COMUNICACAO_DESTINOS, modeloComunicacaoDestinoService.findAll());
			model.addAttribute(MODELO_COMUNICACAO_PROCESSOS, modeloComunicacaoProcessoService.findAll()); 
			model.addAttribute(HISTORICOS, modeloComunicacaoService.obtemDataHistorico(id) );
			model.addAttribute(EXIST_AGENDAMENTO, agendamentoComunicacaoService.existAgendamento(id.longValue()));

			if (TipoModelo.sms.equals(modelo.getCanalComunicacao())){
				return Paginas.modelosms.value();
			} else if (TipoModelo.push.equals(modelo.getCanalComunicacao())){
				return Paginas.modelopush.value();
			} else{
				return Paginas.modeloemail.value();
			}

		} catch (Exception e){
			return obtemPaginaErro(e, model);
		}
	}

	@RequestMapping(value = "/detalhes",method = RequestMethod.POST)
	public ResponseEntity<String> incluiModelo(@RequestBody ModeloComunicacao modelo){

		String msgRet = "";
		HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		try{

			modelo.setDtInclusao(new Date());
			modelo.setNomeUsuarioInclusao(usuarioSessao.getCodUsuario());
			modelo.setCodigo(gerarNovoCodigo (modelo));			
			modelo = modeloService.incluiModelo(modelo);
			msgRet = modelo.getCodModelo().toString();
//			msgRet = "Modelo gravado com sucesso";
			httpStatus = HttpStatus.CREATED;
		} catch (ServiceException e){
			msgRet = e.getMessage();
			httpStatus = HttpStatus.NOT_ACCEPTABLE;
 		} catch (Exception e){
			msgRet = "Erro ao incluir modelo: " + e;
			logger.error("Erro ao incluir modelo", e);
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
 		}

		return new ResponseEntity<String>(msgRet, httpStatus);
	}

	@RequestMapping(value = "atualiza",method = RequestMethod.POST)
	public ResponseEntity<String> atualizaModelo(Integer id, @RequestBody ModeloComunicacao modelo){

		String msgRet = "";
		HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		try{
			modelo.setCodModelo(id.longValue());
			modelo.setNomeUsuarioAtualizacao(usuarioSessao.getCodUsuario());
			modelo.setCodigo(gerarNovoCodigo (modelo));
			modeloService.atualizaModelo(modelo);
			httpStatus = HttpStatus.OK;
		} catch (ServiceException e){
			msgRet = e.getMessage();
			httpStatus = HttpStatus.NOT_ACCEPTABLE;
 		} catch (Exception e){
			msgRet = "Erro ao atualizar modelo: " + (e == null ? e : e.getMessage());
			logger.error("Erro ao atualizar modelo", e);
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
 		}
		return new ResponseEntity<String>(msgRet, httpStatus);
	}

	@RequestMapping(value = "texto",method = RequestMethod.POST)
	public @ResponseBody String incluiTexto(Integer idModelo, Integer idTexto){

		String msgRet = "";
		try{

			TextoComunicacao texto = modeloService.obtemTextoComunicacao(idTexto.longValue());

			modeloService.incluiTextoComunicacao(modeloService.obtemModelo(idModelo.longValue()), texto, usuarioSessao.getUsuario());


		} catch (ServiceException e){
			msgRet = e.getMessage();
 		}
		  catch (Exception e){
			msgRet = "Erro ao incluir texto no modelo: " + e;
			logger.error("Erro ao incluir texto no modelo", e);
 		}

		return msgRet;
	}

	@RequestMapping(value = "texto",method = RequestMethod.DELETE)
	public @ResponseBody String removeTexto(Integer id){

		String msgRet = "";
		try{

			modeloService.removeTexto(id.longValue(), usuarioSessao.getUsuario());

		} catch (ServiceException e){
			msgRet = e.getMessage();
 		}
		  catch (Exception e){
			msgRet = "Erro ao remover texto do modelo: " + e;
			logger.error("Erro ao remover texto do modelo", e);
 		}

		return msgRet;
	}
	
	@RequestMapping(value = "novoparametro",method = RequestMethod.POST)
	public @ResponseBody String incluiCadParametro(@RequestBody ParametroComunicacao cadParametro){

		String msgRet = "";
		try{
			modeloService.incluiNovoParametroComunicacao(cadParametro, usuarioSessao.getUsuario());
		} catch (ServiceException e){
			msgRet = e.getMessage();
 		}
		  catch (Exception e){
			msgRet = "Erro ao incluir parâmetro no cadastro: " + e;
			logger.error("Erro ao incluir parâmetro no cadastro: ", e);
 		}
		return msgRet;
	}
	
	@RequestMapping(value = "parametro",method = RequestMethod.POST)
	public @ResponseBody String incluiParametro(Integer idModelo, Integer idParam){

		String msgRet = "";
		try{
			ParametroComunicacao param = modeloService.obtemParametroComunicacao(idParam.longValue());
			modeloService.incluiParametroComunicacao(modeloService.obtemModelo(idModelo.longValue()), param, usuarioSessao.getUsuario());

		} catch (ServiceException e){
			msgRet = e.getMessage();
 		}
		  catch (Exception e){
			msgRet = "Erro ao incluir parâmetro no modelo: " + e;
			logger.error("Erro ao incluir parâmetro no modelo", e);
 		}

		return msgRet;
	}

	@RequestMapping(value = "parametro",method = RequestMethod.DELETE)
	public @ResponseBody String removeParametro(Integer id){

		String msgRet = "";
		try{

			modeloService.removeParametro(id.longValue());

		} catch (ServiceException e){
			msgRet = e.getMessage();
 		}
		  catch (Exception e){
			msgRet = "Erro ao remover parâmetro do modelo: " + e;
			logger.error("Erro ao remover parâmetro do modelo", e);
 		}

		return msgRet;
	}

	@RequestMapping(value = "textos",method = RequestMethod.POST)
	public @ResponseBody String atualizaTextos(@RequestBody List<TextoModeloComunicacao> textos){

		String msgRet = "";
		try{

			modeloService.atualizaTextos(textos, usuarioSessao.getUsuario());

		} catch (ServiceException e){
			msgRet = e.getMessage();
 		}
		  catch (Exception e){
			msgRet = "Erro ao atualizar textos do modelo: " + e;
			logger.error("Erro ao atualizar textos do modelo", e);
 		}

		return msgRet;
	}

	@RequestMapping(value = "parametros",method = RequestMethod.POST)
	public @ResponseBody String atualizaParametros(@RequestBody List<ParametroModelo> parametros){

		String msgRet = "";
		try{
			modeloService.atualizaParametros(parametros, usuarioSessao.getUsuario());
		} catch (ServiceException e){
			msgRet = e.getMessage();
 		}
		  catch (Exception e){
			msgRet = "Erro ao atualizar parâmetros do modelo: " + e;
			logger.error("Erro ao atualizar parâmetros do modelo", e);
 		}
		return msgRet;
	}

	@RequestMapping(value = "preview",method = RequestMethod.GET, produces={MediaType.TEXT_HTML_VALUE})
	public @ResponseBody String obtemPreview(Integer id){

		String msgRet = "";

		try{
			msgRet = modeloService.obtemEmailFormatado(id);

		} catch (Exception e){
			msgRet = "Erro ao obter preview";
			logger.error("Erro ao obter preview", e);
 		}

		return msgRet;
	}
	
	@RequestMapping(value = "previewHist",method = RequestMethod.GET, produces={MediaType.TEXT_HTML_VALUE})
	public @ResponseBody String obtemPreviewHist(Integer id, String datAlteracao) {

		String msgRet = "";

		try{
			msgRet = modeloService.obtemEmailFormatado(id, datAlteracao);

		} catch (Exception e){
			msgRet = "Erro ao obter preview";
			logger.error("Erro ao obter preview", e);
 		}

		return msgRet;
	}
	
	@RequestMapping(value = "/proximoCodigo", method = RequestMethod.GET)
	public ResponseEntity<String> proximoCodigo(String prefixo) {
		
		String msgRet = "";
		HttpStatus httpStatus = HttpStatus.OK;
		msgRet = modeloService.proximoCodigo(prefixo);
		return new ResponseEntity<String>(msgRet, httpStatus);
	}
	
	@RequestMapping(value = "/status", method = RequestMethod.GET)
	public String statusInativos(String perfil, HttpServletRequest request, Model model){

		try{
			usuarioSessao.loadUsuarioInterno(request);
			List<ModeloComunicacao> modelos = modeloService.obtemModelosInativos(perfil, usuarioSessao.getCodUsuario());
			model.addAttribute(INATIVOS, modelos);
			model.addAttribute(PERFIL_USUARIO, perfil);
			
			return Paginas.listamodelosinativos.value();
		} catch (ServiceException e){
			model.addAttribute(ERRO_STATUS, e.getMessage());
			return Paginas.listamodelosinativos.value();
		} catch (Exception e){
			return obtemPaginaErro(e, model);
		}
	}
	
	@RequestMapping(value = "aprovarmodelo",method = RequestMethod.POST)
	public ResponseEntity<String> aprovarModelo(@RequestBody ModeloComunicacao modelo){

		String msgRet = "";
		HttpStatus httpStatus = HttpStatus.OK;		
		try{
			modelo.setNomeUsuarioAtualizacao(usuarioSessao.getCodUsuario());
			modeloService.aprovarModelo(modelo);
		} catch (ServiceException e){
			msgRet = e.getMessage();
			httpStatus = HttpStatus.NOT_ACCEPTABLE;			
 		}
		  catch (Exception e){
			msgRet = "Erro ao aprovar modelo: " + e;
			logger.error("Erro ao aprovar modelo: ", e);
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
 		}
		return new ResponseEntity<String>(msgRet, httpStatus);
	}
	
	public String obtemPaginaErro(Exception e, Model model){
		model.addAttribute("mensagem",e.getMessage());
		model.addAttribute("stacktrace",ExceptionUtils.getFullStackTrace(e));
		logger.error("Erro",e);
		return Paginas.error.value();
	}
	
	private String gerarNovoCodigo (ModeloComunicacao modelo) throws ServiceException {
		ModeloComunicacao modOld = null;
		if (modelo.getCodModelo() == null) {
			modOld = modelo;
		} else {
			modOld = modeloService.obtemModelo(modelo.getCodModelo()); 
		}
				
		if (modelo.getCodModelo() == null || (modelo.getProcesso() != null && !modelo.getProcesso().equals(modOld.getProcesso())) ) {
			String prefixo = modelo.getTipoModelo().equals("EMAIL") ? "EM" : modelo.getTipoModelo().equals("SMS") ? "SM" : "PU";
			Collection<ModeloComunicacaoSistemaOrigem> listOrigem = modeloComunicacaoSistemaOrigemService.findAll();
			for (ModeloComunicacaoSistemaOrigem modeloComunicacaoSistemaOrigem : listOrigem) {
				if (modeloComunicacaoSistemaOrigem.getDescricao().equals(modOld.getNomeSistemaOrigem()) ) {
					prefixo += modeloComunicacaoSistemaOrigem.getCodigo();
				}
			}
			Collection<ModeloComunicacaoProcesso> listaProcesso = modeloComunicacaoProcessoService.findAll();
			for (ModeloComunicacaoProcesso modeloComunicacaoProcesso : listaProcesso) {
				if (modeloComunicacaoProcesso.getDescricao().equals(modelo.getProcesso()) ) {
					prefixo += modeloComunicacaoProcesso.getCodigo();
				}
			}
			return modeloService.proximoCodigo(prefixo);
		} else {
            return modOld.getCodigo();			
		}
	}
	
	@RequestMapping(value = "excluir",method = RequestMethod.DELETE)	
	public ResponseEntity<String> excluirModelo(Integer idModelo){
		String msgRet = "";
		HttpStatus httpStatus = HttpStatus.OK;
		
        if (agendamentoComunicacaoService.existAgendamento(idModelo.longValue())) {
			msgRet = "Exclusão não permitida.\nModelo com agendamento";
			return new ResponseEntity<>(msgRet, HttpStatus.NOT_ACCEPTABLE);
        }
		
		try {
			modeloService.removeModelo(idModelo.longValue(), usuarioSessao.getUsuario());
		} catch (ServiceException e) {
			msgRet = e.getMessage();
			httpStatus = HttpStatus.NOT_ACCEPTABLE;			
		} catch (Exception e){
			msgRet = "Erro ao excluir modelo: " + e;
			logger.error("Erro ao excluir modelo: ", e);
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<String>(msgRet, httpStatus);
	}
	
	@RequestMapping(value = "/gerar-json", method = RequestMethod.POST)
	public ResponseEntity<String> gerarJson(@RequestBody Map<String, String> json) {
		//@PathParam("codModeloDocumento") Long codModeloDocumento
		
		try {
			ModeloComunicacao modelo = modeloService.obtemModelo(Long.parseLong(json.get("codModeloDocumento")));

			if (modelo == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}

			ModeloComunicacaoDTO dto = modeloService.obtemModeloComunicacaoDTO(modelo);
			
			TemplateJson template;
			switch (modelo.getTipoModelo()) {
				case "SMS":
					template = new TemplateJsonSms(modelo.getCodigo(), dto);
					break;
				case "EMAIL":
					template = new TemplateJsonEmail(modelo.getCodigo(), dto, json.get("emailCopia"));
					break;
				default:
					throw new IllegalArgumentException("Não implementado");
	        }
			
			String serialized = new ObjectMapper().writeValueAsString(template);
			this.modeloComunicacaoService.enviarEmailModelo(json.get("destinatario"), template.getCodigo(), serialized);
			return new ResponseEntity<>(HttpStatus.OK);
			
		} catch (Exception e) {
			logger.error("Erro gerar-json", e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
