package br.com.tokiomarine.acsel.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import br.com.tokiomarine.acsel.dto.ApplicationProperties;
import br.com.tokiomarine.acsel.dto.CDN;
import br.com.tokiomarine.acsel.util.POMUtil;

public class ModelHandlerInterceptor extends HandlerInterceptorAdapter {

	private static final String ATRIBUTO_CDN = "cdn";
	private static final String ATRIBUTO_BUILD_VERSION = "buildVersion";
	private static final CDN cdn = new CDN();
	
	@Autowired
	private ApplicationProperties applicationProperties;

	@Override
	public void postHandle(final HttpServletRequest request,final HttpServletResponse response,final Object handler,final ModelAndView modelAndView) throws Exception {

		if (modelAndView != null) {
			//logger.info("Carregando CDN...");
			modelAndView.getModelMap().addAttribute(ATRIBUTO_CDN,cdn);
			modelAndView.getModelMap().addAttribute(ATRIBUTO_BUILD_VERSION,POMUtil.getDataNumerica());
			modelAndView.getModelMap().addAttribute("applicationProperties", applicationProperties);
		}
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		return super.preHandle(request, response, handler);
	}

}
