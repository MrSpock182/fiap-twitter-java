package br.com.tokiomarine.acsel.rest;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.tokiomarine.acsel.comunicador.mail.ProxyMail;
import br.com.tokiomarine.acsel.comunicador.mail.blackwhitelist.HostBlackWhiteList;
import br.com.tokiomarine.acsel.util.VariaveisAmbienteUtil;

@Path("/settings")
public class SettingsRestController {

	@Autowired
	private HostBlackWhiteList hostBlackWhiteList;
	
	@Autowired
	private ProxyMail proxyMail;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/env")
	public Ambiente getEnv() throws UnknownHostException {
		return Ambiente.builder()
						 .hostName(InetAddress.getLocalHost().getHostName())
						 .environment(VariaveisAmbienteUtil.getAmbienteDetectado())
						 .hostBlackWhiteList(hostBlackWhiteList.getEnv())
						 .proxyMail(proxyMail.getEnv())
						 .build();	
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/app")
	public Application getApp() {
		return Application.builder().name("DocumentosRest").version("2017.11.08.1").build();	
	}	
	
}

/**
 * @author t803520
 *
 */
class Ambiente {
	private String hostName;
	private String environment;
	private String hostBlackWhiteList;
	private String proxyMail;
	public static AmbienteBuilder builder() {
		return new AmbienteBuilder();
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getHostBlackWhiteList() {
		return hostBlackWhiteList;
	}
	public void setHostBlackWhiteList(String hostBlackWhiteList) {
		this.hostBlackWhiteList = hostBlackWhiteList;
	}
	public String getProxyMail() {
		return proxyMail;
	}
	public void setProxyMail(String proxyMail) {
		this.proxyMail = proxyMail;
	}
}

class AmbienteBuilder {
	private String hostName;
	private String environment;
	private String hostBlackWhiteList;
	private String proxyMail;
	
	public AmbienteBuilder hostName(String hostName) {
		this.hostName = hostName;
		return this;
	}
	public AmbienteBuilder proxyMail(String proxyMail) {
		this.proxyMail = proxyMail;
		return this;
	}
	public AmbienteBuilder hostBlackWhiteList(String hostBlackWhiteList) {
		this.hostBlackWhiteList = hostBlackWhiteList;
		return this;
	}
	public AmbienteBuilder environment(String environment) {
		this.environment = environment;
		return this;
	}
	public Ambiente build() {
		Ambiente ambiente = new Ambiente();
		ambiente.setHostName(hostName);
		ambiente.setEnvironment(environment);
		ambiente.setHostBlackWhiteList(hostBlackWhiteList);
		ambiente.setProxyMail(proxyMail);
		return ambiente;
	}
}

class Application {
	private String name;
	private String version;
	
	public static ApplicationBuilder builder() {
		return new ApplicationBuilder();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
}

class ApplicationBuilder {
	private String name;
	private String version;
	public ApplicationBuilder name(String name) {
		this.name = name;
		return this;
	}
	public ApplicationBuilder version(String version) {
		this.version = version;
		return this;
	}
	public Application build() {
		Application a = new Application();
		a.setName(name);
		a.setVersion(version);
		return a;
	}
}
