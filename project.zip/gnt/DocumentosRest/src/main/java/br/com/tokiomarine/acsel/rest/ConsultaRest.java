package br.com.tokiomarine.acsel.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.tokiomarine.acsel.dto.ConsultaDocumentosDTO;
import br.com.tokiomarine.acsel.dto.DocumentoImpressaoDTO;
import br.com.tokiomarine.acsel.service.ConsultaDocumentosService;

@Path("/consulta")
public class ConsultaRest {
	
	@Autowired
	ConsultaDocumentosService consultaDocumetosService;
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/documentos")
	public Response listaDocumentos(ConsultaDocumentosDTO consulta) {
		try{
			if(validaConsulta(consulta)){
				consulta = consultaDocumetosService.listaDocumentos(consulta);
			}
		}
		catch (Exception e) {
			consulta.setCodigoRetorno(3);
			consulta.setMensagemRetorno(e.getMessage());
		}
		if(consulta.getCodigoRetorno() == null) {
			consulta.setCodigoRetorno(0);
			consulta.setMensagemRetorno("");
		}
		return Response.ok(consulta).build();
	}
	
	private boolean validaConsulta(ConsultaDocumentosDTO consulta) {
		if(consulta.getCdRamoProdutoTmsr() == null) {
			consulta.setCodigoRetorno(1);
			consulta.setMensagemRetorno("Favor informar o código do ramo - cdRamoProdutoTmsr");
			return false;
		}
		if(consulta.getCdApoliceTmsr() == null) {
			consulta.setCodigoRetorno(2);
			consulta.setMensagemRetorno("Favor informar o código da apólice - cdApoliceTmsr");
			return false;
		}
		return true;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/documentos/disponiveis")
	public Response listaDocumentosDisponiveis() {
		
		List<DocumentoImpressaoDTO> documentos = consultaDocumetosService.listaDocumentosDisponiveis();
		
		return Response.ok(documentos).build();
	}
	
	

}
