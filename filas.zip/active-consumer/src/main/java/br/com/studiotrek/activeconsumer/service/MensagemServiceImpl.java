package br.com.studiotrek.activeconsumer.service;

import br.com.studiotrek.activeconsumer.orm.Mensagem;
import org.springframework.stereotype.Service;

@Service
public class MensagemServiceImpl implements MensagemService {

    @Override
    public void enviarMensagem(Mensagem mensagem) {
        System.out.print(mensagem.toString());
    }

}
