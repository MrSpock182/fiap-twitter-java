package br.com.studiotrek.activeconsumer.service;

import br.com.studiotrek.activeconsumer.orm.Mensagem;

public interface MensagemService {
    void enviarMensagem(Mensagem mensagem);
}
