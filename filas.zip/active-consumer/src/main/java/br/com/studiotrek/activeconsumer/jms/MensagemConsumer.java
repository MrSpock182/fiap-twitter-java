package br.com.studiotrek.activeconsumer.jms;

import br.com.studiotrek.activeconsumer.orm.Mensagem;
import br.com.studiotrek.activeconsumer.service.MensagemService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MensagemConsumer {

    @Autowired
    private MensagemService pessoaService;

    @Autowired
    private ObjectMapper mapper;

    @JmsListener(destination = "${queue.boot}")
    public void recievedMessage(String message) {
        try {
            Mensagem mensagem = mapper.readValue(message, Mensagem.class);
            pessoaService.enviarMensagem(mensagem);
        } catch (Exception ex) {
            throw new InternalError("Erro ao consumir mensagem");
        }
    }

}
