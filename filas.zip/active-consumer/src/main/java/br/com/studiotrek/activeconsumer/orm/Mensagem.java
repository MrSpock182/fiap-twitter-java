package br.com.studiotrek.activeconsumer.orm;

import lombok.*;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class Mensagem {
    private String email;
    private String message;
}