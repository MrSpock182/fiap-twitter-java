package br.com.studiotrek.activeconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActiveConsumerApplication {
	public static void main(String[] args) {
		SpringApplication.run(ActiveConsumerApplication.class, args);
	}
}
