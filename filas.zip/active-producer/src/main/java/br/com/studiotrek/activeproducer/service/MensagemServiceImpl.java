package br.com.studiotrek.activeproducer.service;

import br.com.studiotrek.activeproducer.jms.MensagemProducer;
import br.com.studiotrek.activeproducer.orm.Mensagem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MensagemServiceImpl implements MensagemService {

    @Autowired
    private MensagemProducer mensagemProducer;

    @Override
    public void enviaMensagem(Mensagem mensagem) {
        mensagemProducer.enviaMensagem(mensagem);
    }

}
