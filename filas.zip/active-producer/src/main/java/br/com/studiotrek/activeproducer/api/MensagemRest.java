package br.com.studiotrek.activeproducer.api;

import br.com.studiotrek.activeproducer.orm.Mensagem;
import br.com.studiotrek.activeproducer.service.MensagemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/mensagem")
public class MensagemRest {

    @Autowired
    private MensagemService mensagemService;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/send")
    public void send(@RequestBody Mensagem mensagem) {
        mensagemService.enviaMensagem(mensagem);
    }

}
