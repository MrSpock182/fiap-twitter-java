package br.com.studiotrek.activeproducer.service;

import br.com.studiotrek.activeproducer.orm.Mensagem;

public interface MensagemService {
    void enviaMensagem(Mensagem mensagem);
}
