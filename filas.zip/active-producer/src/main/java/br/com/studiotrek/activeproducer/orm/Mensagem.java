package br.com.studiotrek.activeproducer.orm;

import lombok.*;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Mensagem {
    private String email;
    private String message;
}
