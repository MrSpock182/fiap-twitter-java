package br.com.studiotrek.activeproducer.jms;

import br.com.studiotrek.activeproducer.orm.Mensagem;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MensagemProducer {

    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    private ObjectMapper mapper;

    @Value("${queue.boot}")
    private String queue;

    public void enviaMensagem(Mensagem mensagem) {
        try {
            jmsTemplate.convertAndSend(queue, mapper.writeValueAsString(mensagem));
        } catch (Exception ex) {
            throw new InternalError("Erro ao produzir mensagem na fila");
        }
    }

}
