var arr = [];
var app = angular.module('search', []);
var firebase = new Firebase('https://cineclassico-4d826.firebaseio.com');
var database = firebase.ref().child('categoria');

app.controller('SearchController', SearchController);

function SearchController($scope, $timeout) {
	$scope.noWrapSlides = false;
	$scope.activeSlide = 0;
		
	$scope.pesquisar = function(nome){
		database.on('value', function(snapshot) {
			$timeout(function() {
				snapshot.forEach(function(snap) {
					var filmes = snap.val().filmes;
					filmes.forEach(function(filme) {
						arr.push(filme);
					});
				});
				
				var search = nome.toLowerCase();
				var array = jQuery.grep(arr, function(value) {
					
					if(value.nome.toLowerCase().indexOf(search) >= 0) {
						return value.nome.toLowerCase().indexOf(search) >= 0;
					} else {
						if(value.diretor.toLowerCase().indexOf(search) >= 0) {
							return value.diretor.toLowerCase().indexOf(search) >= 0;
						}
					}
				});
				
				if(array.length != 0) {
					$scope.filmes = array;
				} else {
					$scope.mensagem = "Nenhum filme encontrado";
				}
			});
		});
	}
}
