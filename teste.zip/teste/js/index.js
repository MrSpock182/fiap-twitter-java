var app = angular.module('index', []);
var firebase = new Firebase('https://cineclassico-4d826.firebaseio.com');
var database = firebase.ref().child('categoria');

app.controller('IndexController', IndexController);

function IndexController($scope, $timeout) {
	$scope.noWrapSlides = false;
	$scope.activeSlide = 0;
			
	database.on('value', function(snap) {
		$timeout(function() {
			$scope.categorias = snap.val();
		});
	});
		
	$scope.assistir = function(filme){
		sessionStorage.setItem('filme', JSON.stringify(filme));
	}
}