package br.com.studiotrek.pontodigital.api.error;

import br.com.studiotrek.pontodigital.domain.dto.ErrorResponseDTO;
import br.com.studiotrek.pontodigital.exception.BadRequest;
import br.com.studiotrek.pontodigital.exception.InternalServerError;
import br.com.studiotrek.pontodigital.exception.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.Date;

@RestControllerAdvice
public class RestExceptionHandler {

    @ExceptionHandler(BadRequest.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ErrorResponseDTO handleBadRequest(BadRequest badRequest, WebRequest request) {

        return ErrorResponseDTO.builder()
                .timestamp(new Date())
                .status(HttpStatus.BAD_REQUEST.value())
                .error("BAD REQUEST")
                .message(badRequest.getMessage())
                .path(request.getDescription(false).replace("uri=", ""))
                .build();
    }

    @ExceptionHandler(InternalServerError.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ErrorResponseDTO handleInternalServerError(Exception exception, WebRequest request) {

        return ErrorResponseDTO.builder()
                .timestamp(new Date())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .error("INTERNAL SERVER ERROR")
                .message(exception.getMessage())
                .path(request.getDescription(false).replace("uri=", ""))
                .build();
    }

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public ErrorResponseDTO handleExpectationFailedError(NotFoundException notFoundException, WebRequest request) {

        return ErrorResponseDTO.builder()
                .timestamp(new Date())
                .status(HttpStatus.EXPECTATION_FAILED.value())
                .error("EXPECTATION FAILED")
                .message(notFoundException.getMessage())
                .path(request.getDescription(false).replace("uri=", ""))
                .build();
    }

}
