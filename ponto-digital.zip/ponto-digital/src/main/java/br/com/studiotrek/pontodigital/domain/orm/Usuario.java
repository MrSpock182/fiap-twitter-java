package br.com.studiotrek.pontodigital.domain.orm;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "usuario")
public class Usuario {
    @Id
    private Long id;
    private String username;
    private String password;
}
