package br.com.studiotrek.pontodigital.service.usuario;

import br.com.studiotrek.pontodigital.domain.orm.Usuario;

public interface UsuarioService {
    void save(Usuario usuario);
    Usuario findById(Long id);
}
