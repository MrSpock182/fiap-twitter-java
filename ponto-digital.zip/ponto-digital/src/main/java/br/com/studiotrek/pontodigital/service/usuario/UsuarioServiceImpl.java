package br.com.studiotrek.pontodigital.service.usuario;

import br.com.studiotrek.pontodigital.domain.orm.Usuario;
import br.com.studiotrek.pontodigital.domain.repository.UsuarioRepository;
import br.com.studiotrek.pontodigital.exception.BadRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    @Override
    public void save(Usuario usuario) {
        repository.save(usuario);
    }

    @Override
    public Usuario findById(Long id) {
        Optional<Usuario> usuario = repository.findById(id);

        if(!usuario.isPresent()) {
            throw new BadRequest("Usuario não encontrado");
        }

        return usuario.get();
    }

}
