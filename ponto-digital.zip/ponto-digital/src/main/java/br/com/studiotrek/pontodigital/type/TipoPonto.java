package br.com.studiotrek.pontodigital.type;

import br.com.studiotrek.pontodigital.exception.BadRequest;

import javax.validation.constraints.NotNull;

public enum TipoPonto {
    ENTRADA_TRABALHO("ET"),
    ENTRADA_ALMOCO("EA"),
    SAIDA_ALMOCO("SA"),
    SAIDA_TRABALHO("ST"),
    ENTRADA_EXTRA("EE"),
    SAIDA_EXTRA("SE");

    private String horario;

    TipoPonto(String horario) {
        this.horario = horario;
    }

    public String getHorario() {
        return horario;
    }

    public static TipoPonto get(@NotNull String status){
        for (TipoPonto tipo : TipoPonto.values()){
            if (tipo.horario.equals(status)){
                return tipo;
            }
        }

        throw new BadRequest("Nenhum tipo de ponto encontrado");
    }

}
