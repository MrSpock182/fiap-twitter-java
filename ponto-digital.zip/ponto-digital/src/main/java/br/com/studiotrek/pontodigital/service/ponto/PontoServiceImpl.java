package br.com.studiotrek.pontodigital.service.ponto;

import br.com.studiotrek.pontodigital.domain.dto.PontoDTO;
import br.com.studiotrek.pontodigital.domain.orm.Ponto;
import br.com.studiotrek.pontodigital.domain.orm.Usuario;
import br.com.studiotrek.pontodigital.domain.repository.PontoRepository;
import br.com.studiotrek.pontodigital.exception.BadRequest;
import br.com.studiotrek.pontodigital.service.usuario.UsuarioService;
import br.com.studiotrek.pontodigital.type.TipoPonto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

@Service
public class PontoServiceImpl implements PontoService {

    @Autowired
    private PontoRepository repository;

    @Autowired
    private UsuarioService usuarioService;

    @Override
    public Ponto findById(Date data, Usuario usuario) {
        Optional<Ponto> ponto = repository.findByDataAndUsuario(data, usuario);

        if(!ponto.isPresent()) {
            return Ponto.builder()
                    .data(data)
                    .usuario(usuario)
                    .build();
        }

        return ponto.get();
    }

    @Override
    public void save(PontoDTO pontoDTO) {
        Usuario usuario = usuarioService.findById(pontoDTO.getUsuario());
        Ponto ponto = findById(pontoDTO.getData(), usuario);

        TipoPonto tipoPonto = TipoPonto.get(pontoDTO.getTipoPonto());
        switch (tipoPonto) {
            case ENTRADA_TRABALHO:
                ponto.setEntradaTrabalho(pontoDTO.getHora());
                break;
            case ENTRADA_ALMOCO:
                ponto.setEntradaAlmoco(pontoDTO.getHora());
                break;
            case SAIDA_ALMOCO:
                ponto.setSaidaAlmoco(pontoDTO.getHora());
                break;
            case SAIDA_TRABALHO:
                ponto.setSaidaTrabalho(pontoDTO.getHora());
                break;
            case ENTRADA_EXTRA:
                ponto.setEntradaExtra(pontoDTO.getHora());
                break;
            case SAIDA_EXTRA:
                ponto.setSaidaExtra(pontoDTO.getHora());
                break;
            default:
                throw new BadRequest("Tipo de ponto não encontrado");
        }

        repository.save(ponto);
    }
}
