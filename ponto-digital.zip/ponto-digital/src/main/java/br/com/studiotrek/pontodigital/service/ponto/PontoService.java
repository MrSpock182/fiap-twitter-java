package br.com.studiotrek.pontodigital.service.ponto;

import br.com.studiotrek.pontodigital.domain.dto.PontoDTO;
import br.com.studiotrek.pontodigital.domain.orm.Ponto;
import br.com.studiotrek.pontodigital.domain.orm.Usuario;

import java.util.Date;

public interface PontoService {
    void save(PontoDTO pontoDTO);
    Ponto findById(Date data, Usuario usuario);
}
