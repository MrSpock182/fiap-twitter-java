package br.com.studiotrek.pontodigital.domain.dto;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponseDTO {
    private Date timestamp;
    private Integer status;
    private String error;
    private String message;
    private String path;
}
