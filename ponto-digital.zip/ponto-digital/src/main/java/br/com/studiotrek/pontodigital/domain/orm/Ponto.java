package br.com.studiotrek.pontodigital.domain.orm;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "ponto")
public class Ponto {
    @Id
    private Date data;
    private String entradaTrabalho;
    private String entradaAlmoco;
    private String saidaAlmoco;
    private String saidaTrabalho;
    private String entradaExtra;
    private String saidaExtra;
    private Usuario usuario;
}
