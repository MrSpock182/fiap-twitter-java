package br.com.studiotrek.pontodigital.domain.repository;

import br.com.studiotrek.pontodigital.domain.orm.Ponto;
import br.com.studiotrek.pontodigital.domain.orm.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Optional;

@Repository
public interface PontoRepository extends MongoRepository<Ponto, Date> {
    Optional<Ponto> findByDataAndUsuario(Date data, Usuario usuario);
}
