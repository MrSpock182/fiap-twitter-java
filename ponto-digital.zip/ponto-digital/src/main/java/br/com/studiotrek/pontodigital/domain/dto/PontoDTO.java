package br.com.studiotrek.pontodigital.domain.dto;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class PontoDTO {
    private Long usuario;
    private Date data;
    private String tipoPonto;
    private String hora;
}
