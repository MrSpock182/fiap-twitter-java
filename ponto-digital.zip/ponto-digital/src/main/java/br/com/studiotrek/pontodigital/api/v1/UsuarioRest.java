package br.com.studiotrek.pontodigital.api.v1;

import br.com.studiotrek.pontodigital.domain.orm.Usuario;
import br.com.studiotrek.pontodigital.service.usuario.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/v1/usuario")
public class UsuarioRest {

    @Autowired
    private UsuarioService service;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/save")
    public void save(@RequestBody Usuario usuario) {
        service.save(usuario);
    }

}
