package br.com.studiotrek.pontodigital.api.v1;

import br.com.studiotrek.pontodigital.domain.dto.PontoDTO;
import br.com.studiotrek.pontodigital.service.ponto.PontoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/v1/ponto")
public class PontoRest {

    @Autowired
    private PontoService service;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/save")
    public void save(@RequestBody PontoDTO pontoDTO) {
        service.save(pontoDTO);
    }

}
