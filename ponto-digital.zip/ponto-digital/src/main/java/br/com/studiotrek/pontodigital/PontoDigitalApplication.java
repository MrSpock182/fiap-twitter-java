package br.com.studiotrek.pontodigital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PontoDigitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PontoDigitalApplication.class, args);
	}

}
