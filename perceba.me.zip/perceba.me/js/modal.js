var modal = document.getElementById('modal-message');
var span = document.getElementsByClassName("close")[0];

function showModal() {  
  modal.style.display = "block";
}

function closeModal() {  
	modal.style.display = "none";
}

span.onclick = function() {
	closeModal();
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}